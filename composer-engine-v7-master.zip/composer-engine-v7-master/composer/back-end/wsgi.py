import os
import logging.config

from django.core.wsgi import get_wsgi_application
from django.conf import settings
from tisco.core.tfg_log.logger import TfgLogger, log_decorator, LOGGING
# from socketio import Middleware
# from apps.socket_io.views import sio
logging.config.dictConfig(LOGGING)

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings.base')
TfgLogger.setup(settings=settings)
application = get_wsgi_application()

