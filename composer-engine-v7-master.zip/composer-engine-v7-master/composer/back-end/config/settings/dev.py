from .base import *

INSTALLED_APPS += [
    'django_extensions'
]
