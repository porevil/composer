import uuid
import os
import sys
import traceback
import threading

from datetime import datetime

from rest_framework.response import Response
from rest_framework import status

from apps.commons.utilities.common import CommonAPIView
from apps.commons.utilities.log import Logger
from apps.commons.generator.constants import ActionAuthority
from apps.commons.generator.managers.flow import FlowManager
from apps.console_output.models import ConsoleOutput
from apps.configurations.models import SubState
from apps.commons.utilities.response import ResponseAPI
from apps.commons.serializers import AbstractSerializer
from apps.commons.error.exception import *


class BuildAndPublishView(CommonAPIView):
    serializer_class = AbstractSerializer
    response_meta = ResponseAPI()

    def post(self, request):
        reference_id = str(uuid.uuid4())
        logger = Logger('Flow API', 'Build and Publish')
        logger.set_session_id(reference_id)

        try:
            logger.set_user_id(self.current_userid(request))
            logger.debug('build and publish flow [reference id = {}] start'.format(reference_id))

            request_data = request.data or dict()
            logger.debug(
                'build and publish flow [reference id = {}] request data = {}'.format(reference_id, request_data))

            flow_uuids = request_data.get('uuids')
            # destination_sub_state_id = request_data.get('destination_sub_state_id')
            authorized_ticket = request_data.get('authorized_ticket')

            if flow_uuids is None:
                raise Exception('bad request : "uuids" is required')
            # if destination_sub_state_id is None:
            #     raise Exception('bad request : "destination_sub_state_id" is required')

            # destination_sub_state = SubState.objects.filter(id=int(destination_sub_state_id)).first()
            destination_sub_state = SubState.objects.filter(is_default=True).first()
            if destination_sub_state is None:
                raise Exception('bad request : "destination_sub_state_id" is invalid')

            if destination_sub_state.need_authorized_ticket \
                    and (authorized_ticket is None or authorized_ticket.strip() == ''):
                raise Exception('bad request : "authorized_ticket" is required')

            if not self.has_permission(request, ActionAuthority.BUILD.value):
                raise Exception('not authorized : build')

            if destination_sub_state.is_production:
                if not self.has_permission(request, ActionAuthority.PUBLISH_PROD.value):
                    raise Exception('not authorized : publish on production')
            elif destination_sub_state.is_pre_production:
                if not self.has_permission(request, ActionAuthority.PUBLISH_PRE_PROD.value):
                    raise Exception('not authorized : publish on pre-production')
            else:
                if not self.has_permission(request, ActionAuthority.PUBLISH_NON_PROD.value):
                    raise Exception('not authorized : publish on non-production')

            executed_by = self.current_username(request)
            console_output = ConsoleOutput.objects.create(
                title='Build and Publish Flow to "{}"'.format(destination_sub_state.name), executed_by=executed_by
                , authorized_ticket=authorized_ticket)

            threading.Thread(target=lambda: self.process(flow_uuids, destination_sub_state, console_output, executed_by,
                                                         authorized_ticket)).start()
            response = self.response_meta.success('success', reference_id, {
                'console_output_id': console_output.id,
            })

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e), reference_id, str(exc_type), fname, str(exc_tb.tb_lineno))

            logger.error(
                'build and publish flow [reference id = {}] exception - {}'.format(reference_id, exception_message))

        finally:
            logger.debug('build and publish flow [reference id = {}] response = {}'.format(reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def process(self, flow_uuids, destination_sub_state, console_output, executed_by, authorized_ticket):
        try:
            success_all, error_list = FlowManager().build_and_publish(flow_uuids
                                                                      , destination_sub_state
                                                                      , console_output=console_output
                                                                      , executed_by=executed_by
                                                                      , authorized_ticket=authorized_ticket)
            console_output.append('complete')
            return success_all, error_list
        except Exception as e:
            console_output.append('fail with exception: {}'.format(str(e)))
            raise e
        finally:
            console_output.finish()


class RepublishView(CommonAPIView):
    serializer_class = AbstractSerializer
    response_meta = ResponseAPI()

    def post(self, request):
        reference_id = str(uuid.uuid4())
        logger = Logger('Flow API', 'Republish')
        logger.set_session_id(reference_id)

        try:
            logger.set_user_id(self.current_userid(request))
            logger.debug('republish flow [reference id = {}] start'.format(reference_id))

            request_data = request.data.get('data') or dict()
            logger.debug('republish flow [reference id = {}] request data = {}'.format(reference_id, request_data))

            flow_uuids = request_data.get('uuids')
            destination_sub_state_id = request_data.get('destination_sub_state_id')
            authorized_ticket = request_data.get('authorized_ticket')

            if flow_uuids is None:
                raise Exception('bad request : "uuid" is required')
            if destination_sub_state_id is None:
                raise Exception('bad request : "destination_sub_state_id" is required')

            destination_sub_state = SubState.objects.filter(id=int(destination_sub_state_id)).first()
            if destination_sub_state is None:
                raise Exception('bad request : "destination_sub_state_id" is invalid')

            if destination_sub_state.need_authorized_ticket \
                    and (authorized_ticket is None or authorized_ticket.strip() == ''):
                raise Exception('bad request : "authorized_ticket" is required')

            if destination_sub_state.is_production:
                if not self.has_permission(request, ActionAuthority.PUBLISH_PROD.value):
                    raise Exception('not authorized : republish on production')
            elif destination_sub_state.is_pre_production:
                if not self.has_permission(request, ActionAuthority.PUBLISH_PRE_PROD.value):
                    raise Exception('not authorized : republish on pre-production')
            else:
                if not self.has_permission(request, ActionAuthority.PUBLISH_NON_PROD.value):
                    raise Exception('not authorized : republish on non-production')

            executed_by = self.current_username(request)
            console_output = ConsoleOutput.objects.create(
                title='Republish Flow on "{}"'.format(destination_sub_state.name)
                , executed_by=executed_by
                , authorized_ticket=authorized_ticket)

            threading.Thread(target=lambda: self.process(flow_uuids, destination_sub_state, console_output, executed_by,
                                                         authorized_ticket)).start()
            response = self.response_meta.success('success', reference_id, {
                'console_output_id': console_output.id,
            })

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e), reference_id, str(exc_type), fname, str(exc_tb.tb_lineno))

            logger.error('republish flow [reference id = {}] exception - {}'.format(reference_id, exception_message))

        finally:
            logger.debug('republish flow [reference id = {}] response = {}'.format(reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def process(self, flow_uuids, destination_sub_state, console_output, executed_by, authorized_ticket):
        try:
            success_all, error_list = FlowManager().republish(flow_uuids
                                                              , destination_sub_state
                                                              , console_output=console_output
                                                              , executed_by=executed_by
                                                              , authorized_ticket=authorized_ticket)
            console_output.append('complete')
            return success_all, error_list
        except Exception as e:
            console_output.append('fail with exception: {}'.format(str(e)))
            raise e
        finally:
            console_output.finish()


class MoveView(CommonAPIView):
    serializer_class = AbstractSerializer
    response_meta = ResponseAPI()

    def post(self, request):
        reference_id = str(uuid.uuid4())
        logger = Logger('Flow API', 'Move')
        logger.set_session_id(reference_id)

        try:
            logger.set_user_id(self.current_userid(request))
            logger.debug('move flow [reference id = {}] start'.format(reference_id))

            request_data = request.data.get('data') or dict()
            logger.debug('move flow [reference id = {}] request data = {}'.format(reference_id, request_data))

            flow_uuids = request_data.get('uuids')
            source_sub_state_id = request_data.get('source_sub_state_id')
            destination_sub_state_id = request_data.get('destination_sub_state_id')
            authorized_ticket = request_data.get('authorized_ticket')

            if flow_uuids is None:
                raise Exception('bad request : "uuid" is required')
            if source_sub_state_id is None:
                raise Exception('bad request : "source_sub_state_id" is required')
            if destination_sub_state_id is None:
                raise Exception('bad request : "destination_sub_state_id" is required')

            source_sub_state = SubState.objects.filter(id=int(source_sub_state_id)).first()
            if source_sub_state is None:
                raise Exception('bad request : "source_sub_state_id" is invalid')

            destination_sub_state = SubState.objects.filter(id=int(destination_sub_state_id)).first()
            if destination_sub_state is None:
                raise Exception('bad request : "destination_sub_state_id" is invalid')
            if destination_sub_state.id not in (source_sub_state.next_sub_states or list()):
                raise Exception('bad request : "destination_sub_state_id" is invalid')

            if destination_sub_state.need_authorized_ticket \
                    and (authorized_ticket is None or authorized_ticket.strip() == ''):
                raise Exception('bad request : "authorized_ticket" is required')

            if destination_sub_state.is_production:
                if not self.has_permission(request, ActionAuthority.PUBLISH_PROD.value):
                    raise Exception('not authorized : move to production')
            elif destination_sub_state.is_pre_production:
                if not self.has_permission(request, ActionAuthority.PUBLISH_PRE_PROD.value):
                    raise Exception('not authorized : move to pre-production')
            else:
                if not self.has_permission(request, ActionAuthority.PUBLISH_NON_PROD.value):
                    raise Exception('not authorized : move to non-production')

            executed_by = self.current_username(request)
            console_output = ConsoleOutput.objects.create(
                title='Move Flow from "{}" to "{}"'.format(source_sub_state.name, destination_sub_state.name), executed_by=executed_by
                , authorized_ticket=authorized_ticket)

            threading.Thread(
                target=lambda: self.process(flow_uuids, source_sub_state, destination_sub_state, console_output,
                                            executed_by, authorized_ticket)).start()
            response = self.response_meta.success('success', reference_id, {
                'console_output_id': console_output.id,
            })

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e), reference_id, str(exc_type), fname, str(exc_tb.tb_lineno))

            logger.error('move flow [reference id = {}] exception - {}'.format(reference_id, exception_message))

        finally:
            logger.debug('move flow [reference id = {}] response = {}'.format(reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def process(self, flow_uuids, source_sub_state, destination_sub_state, console_output, executed_by,
                authorized_ticket):
        try:
            success_all, error_list = FlowManager().move(flow_uuids
                                                         , source_sub_state
                                                         , destination_sub_state
                                                         , console_output=console_output
                                                         , executed_by=executed_by
                                                         , authorized_ticket=authorized_ticket)
            console_output.append('complete')
            return success_all, error_list
        except Exception as e:
            console_output.append('fail with exception: {}'.format(str(e)))
            raise e
        finally:
            console_output.finish()


class RemoveView(CommonAPIView):
    serializer_class = AbstractSerializer
    response_meta = ResponseAPI()

    def post(self, request):
        reference_id = str(uuid.uuid4())
        logger = Logger('Flow API', 'Remove')
        logger.set_session_id(reference_id)

        try:
            logger.set_user_id(self.current_userid(request))
            logger.debug('remove flow [reference id = {}] start'.format(reference_id))

            request_data = request.data.get('data') or dict()
            logger.debug('remove flow [reference id = {}] request data = {}'.format(reference_id, request_data))

            flow_uuids = request_data.get('uuids')
            sub_state_id = request_data.get('sub_state_id')
            authorized_ticket = request_data.get('authorized_ticket')

            if flow_uuids is None:
                raise Exception('bad request : "uuids" is required')
            if sub_state_id is None:
                raise Exception('bad request : "sub_state_id" is required')

            sub_state = SubState.objects.filter(id=int(sub_state_id)).first()
            if sub_state is None:
                raise Exception('bad request : "sub_state_id" is invalid')

            if sub_state.need_authorized_ticket \
                    and (authorized_ticket is None or authorized_ticket.strip() == ''):
                raise Exception('bad request : "authorized_ticket" is required')

            if sub_state.is_production:
                if not self.has_permission(request, ActionAuthority.REMOVE_PROD.value):
                    raise Exception('not authorized : remove on production')
            elif sub_state.is_pre_production:
                if not self.has_permission(request, ActionAuthority.REMOVE_PRE_PROD.value):
                    raise Exception('not authorized : remove on pre-production')
            else:
                if not self.has_permission(request, ActionAuthority.REMOVE_NON_PROD.value):
                    raise Exception('not authorized : remove on non-production')

            executed_by = self.current_username(request)
            console_output = ConsoleOutput.objects.create(title='Remove Flow on "{}"'.format(sub_state.name), executed_by=executed_by
                                                          , authorized_ticket=authorized_ticket)

            response = self.response_meta.success('success', reference_id, {
                'console_output_id': console_output.id,
            })

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e), reference_id, str(exc_type), fname, str(exc_tb.tb_lineno))

            logger.error('remove flow [reference id = {}] exception - {}'.format(reference_id, exception_message))

        finally:
            logger.debug('remove flow [reference id = {}] response = {}'.format(reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def process(self, flow_uuids, sub_state, console_output, executed_by, authorized_ticket):
        try:
            success_all, error_list = FlowManager().remove(flow_uuids
                                                           , sub_state
                                                           , console_output=console_output
                                                           , executed_by=executed_by
                                                           , authorized_ticket=authorized_ticket)
            console_output.append('complete')
            return success_all, error_list
        except Exception as e:
            console_output.append('fail with exception: {}'.format(str(e)))
            raise e
        finally:
            console_output.finish()


class PurgeView(CommonAPIView):
    serializer_class = AbstractSerializer
    response_meta = ResponseAPI()

    def post(self, request):
        reference_id = str(uuid.uuid4())
        logger = Logger('Flow API', 'Purge')
        logger.set_session_id(reference_id)

        try:
            logger.set_user_id(self.current_userid(request))
            logger.debug('purge flow [reference id = {}] start'.format(reference_id))

            request_data = request.data.get('data') or dict()
            logger.debug('purge flow [reference id = {}] request data = {}'.format(reference_id, request_data))

            flow_uuids = request_data.get('uuids')

            if flow_uuids is None:
                raise Exception('bad request : "uuids" is required')

            if not self.has_permission(request, ActionAuthority.PURGE.value):
                raise Exception('not authorized : purge')

            executed_by = self.current_username(request)
            console_output = ConsoleOutput.objects.create(title='Purge Instance', executed_by=executed_by
                                                          , authorized_ticket=request.get('authorized_ticket'))

            threading.Thread(target=lambda: self.process(flow_uuids, console_output, executed_by)).start()
            response = self.response_meta.success('success', reference_id, {
                'console_output_id': console_output.id,
            })

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e), reference_id, str(exc_type), fname, str(exc_tb.tb_lineno))

            logger.error('purge flow [reference id = {}] exception - {}'.format(reference_id, exception_message))

        finally:
            logger.debug('purge flow [reference id = {}] response = {}'.format(reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def process(self, flow_uuids, console_output, executed_by):
        try:
            success_all, error_list = FlowManager().purge(flow_uuids
                                                          , console_output=console_output
                                                          , executed_by=executed_by)
            console_output.append('complete')
            return success_all, error_list
        except Exception as e:
            console_output.append('fail with exception: {}'.format(str(e)))
            raise e
        finally:
            console_output.finish()
