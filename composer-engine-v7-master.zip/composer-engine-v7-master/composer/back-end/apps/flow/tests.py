from django.test import TestCase
from rest_framework.test import APIRequestFactory
from apps.flow.api.viewsets import FlowViewSet
from apps.flow.api.serializers import FlowSerializer
from apps.flow.models import Flow, FlowInstance
from apps.authentication.tests import create_jwt_token
from apps.authentication.models import OpenIDUser

import uuid

flow_data = {
    'uuid': str(uuid.uuid4()),
    'code': 'test_code',
    'name': 'test_name',
    'description': 'des',
    'label': 'test_tlabel',
    'latest_build_no': 0,
    'build_with_latest_adjustment': 1,
    'system_generated': False,
}

flow_instance_data = {
    'instance_uuid': str(uuid.uuid4()),
    'config': 'test_cde',
    'instance_type': 'test_name',
    'sub_sequence': 'test_name',
    'sequence': 'test_name',
    'flow': None,
}


def create_flow(**kwargs):
    data = flow_data
    for k, v in kwargs.items():
        data[k] = v
    return Flow.objects.create(**data)


def create_flow_instance(flow, *kwargs):
    data = flow_instance_data
    data['flow'] = flow
    return Flow.objects.create(**flow_instance_data)


class FlowTestCase(TestCase):

    def setUp(self) -> None:
        self.factory = APIRequestFactory()
        self.oidc_user = OpenIDUser(create_jwt_token().id_token)

    def test_update(self):
        flow = create_flow(name='test_update', code='test_update')
        view = FlowViewSet.as_view({'put': 'update'})
        serializer = FlowSerializer(flow)
        request = self.factory.put('', data=serializer.data, format='json', oidc_user=self.oidc_user)
        response = view(request, pk=flow.pk)
        self.assertEqual(response.status_code, 200)
