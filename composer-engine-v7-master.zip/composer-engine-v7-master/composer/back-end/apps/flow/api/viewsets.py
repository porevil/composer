import uuid
import json
import traceback
import os
import sys

import rest_framework_filters as filters
from rest_framework import viewsets
from rest_framework import status
from django.db import transaction
from rest_framework.response import Response

from apps.flow.api.serializers import FlowSerializer, FlowDetailSerializer
from apps.flow.api.serializers import FlowRepositorySerializer, FlowRepositoryDetailSerializer
from apps.authentication.models import OpenIDUser as User
from apps.flow.models import Flow
from apps.flow.models import FlowInstance
from apps.flow.models import FlowRepository
from apps.commons.utilities.response import CustomJsonResponse
from apps.commons.utilities.log import Logger
from apps.commons.utilities.response import ResponseAPI
from apps.commons.error.exception import *


def is_valid_uuid(request_uuid, version=4):
    try:
        uuid_obj = uuid.UUID(str(request_uuid), version=version)
    except ValueError:
        return False

    return str(uuid_obj) == request_uuid


class FlowFilter(filters.FilterSet):
    class Meta:
        model = Flow
        fields = {
            'code': ['exact', 'startswith', 'contains', 'icontains', 'in'],
            'name': ['exact', 'startswith', 'contains', 'icontains'],
            'uuid': ['exact'],
            'system_generated': ['exact']
        }


class FlowViewSet(viewsets.ModelViewSet):
    queryset = Flow.objects.all()
    filter_class = FlowFilter
    logger = Logger('Flow View')

    def get_serializer_class(self):
        # if self.action == 'list':
        #     if not self.request.query_params('with_instances', False):
        #         return FlowSerializer
        # elif self.action in ['retrieve', 'create', 'update']:
        #     return FlowDetailSerializer
        return FlowDetailSerializer

    def create(self, request, **kwargs):
        try:
            with transaction.atomic():
                executed_by = request.oidc_user.full_name
                request_data = request.data

                code = request_data.get('code')
                name = request_data.get('name')
                description = request_data.get('description')
                label = request_data.get('label')

                if not code:
                    raise Exception('bad request : "code" is required')
                if not name:
                    raise Exception('bad request : "name" is required')

                # create 'flow'
                flow = Flow.objects.create(**{
                    'code': code,
                    'name': name,
                    'description': description,
                    'label': label,
                    'latest_build_no': None,
                    'build_with_latest_adjustment': False,
                    'system_generated': False,
                })

                flow_instances = request_data.get('instances') or list()

                # create 'flow instances'
                for instance in flow_instances:
                    flow_uuid = instance.get('uuid')
                    instance_type = instance.get('instance_type')
                    instance_uuid = instance.get('instance_uuid')
                    sequence = instance.get('sequence')
                    sub_sequence = instance.get('sub_sequence') or 1
                    next_instance_uuids = instance.get('next_instance_uuids') or list()

                    if flow_uuid is None:
                        raise Exception('bad request : "flow uuid" is required')

                    try:
                        config = json.loads(instance.get('config', {}))
                    except json.JSONDecodeError:
                        config = {}

                    FlowInstance.objects.create(**{
                        'flow': flow,
                        'uuid': flow_uuid,
                        'sequence': sequence,
                        'sub_sequence': sub_sequence,
                        'instance_type': instance_type,
                        'instance_uuid': instance_uuid,
                        'config': config,
                        'next_instance_uuids': next_instance_uuids,
                    })

                # flow action log (create)
                # FlowActionLog.log_create(flow, executed_by)

                return CustomJsonResponse(status=status.HTTP_201_CREATED,
                                          session_id=self.logger.session_id,
                                          description="Create Success",
                                          data=FlowDetailSerializer(flow).data)
        except Exception as e:
            # traceback.print_exc()
            return CustomJsonResponse(
                session_id=self.logger.session_id,
                status=status.HTTP_500_INTERNAL_SERVER_ERROR, data=e)

    def update(self, request, pk=None, **kwargs):
        try:
            with transaction.atomic():
                request_data = request.data

                flow = Flow.objects.filter(id=pk).first()
                if flow is None:
                    raise Exception('bad request : "id" is invalid')

                name = request_data.get('name')
                description = request_data.get('description')
                label = request_data.get('label')
                # bypass_launch_screen = request_data.get('bypass_launch_screen') or False

                # update 'flow'
                flow.name = name
                flow.description = description
                flow.label = label
                # flow.bypass_launch_screen = bypass_launch_screen
                flow.build_with_latest_adjustment = False
                flow.save()

                flow_instances = request_data.get('instances') or list()

                # create or update 'flow instances'
                _ids = list()
                for idx, instance in enumerate(flow_instances):
                    _id = instance.get('id')
                    flow_uuid = instance.get('uuid')
                    sequence = instance.get('sequence')
                    sub_sequence = instance.get('sub_sequence') or 0
                    instance_type = instance.get('instance_type')
                    instance_uuid = instance.get('instance_uuid')
                    config = instance.get('config') or dict()
                    next_instance_uuids = instance.get('next_instance_uuids') or list()
                    flow_data = FlowInstance.objects.filter(id=_id).first()

                    if flow_data is None:
                        if flow_uuid is None:
                            raise Exception('"flow uuid" is required')

                        flow_data = FlowInstance.objects.create(**{
                            'uuid': flow_uuid,
                            'flow': flow,
                            'sequence': sequence,
                            'sub_sequence': sub_sequence,
                            'instance_type': instance_type,
                            'instance_uuid': instance_uuid,
                            'config': config,
                            'next_instance_uuids': next_instance_uuids,
                        })
                    else:
                        flow_data.sequence = sequence
                        flow_data.sub_sequence = sub_sequence
                        flow_data.instance_type = instance_type
                        flow_data.instance_uuid = instance_uuid
                        flow_data.config = config
                        flow_data.next_instance_uuids = next_instance_uuids
                        flow_data.save()
                    _ids.append(flow_data.id)

                # delete 'flow instances'
                deleted_flow_data = FlowInstance.objects.filter(flow=flow).exclude(id__in=_ids)
                deleted_flow_data.delete()

                return CustomJsonResponse(status=status.HTTP_200_OK,
                                          session_id=self.logger.session_id,
                                          description="Update Success",
                                          data=FlowDetailSerializer(flow).data)
        except Exception as e:
            traceback.print_exc()
            return CustomJsonResponse(status=status.HTTP_500_INTERNAL_SERVER_ERROR,
                                      session_id=self.logger.session_id,
                                      data=e)

    def retrieve(self, request, *args, **kwargs):
        try:
            response = super().retrieve(request, *args, **kwargs)
            return CustomJsonResponse(
                data=response.data,
                session_id=self.logger.session_id
            )
        except Exception as e:
            return CustomJsonResponse(data=e,
                                      session_id=self.logger.session_id)

    def list(self, request, **kwargs):
        try:
            request_params = request.query_params
            request_uuid = request_params.get('uuid')
            if request_uuid is not None and request_uuid:
                is_valid = is_valid_uuid(request_uuid)

                if not is_valid:
                    raise BadRequestException('"uuid" is invalid')

            queryset = self.filter_queryset(self.get_queryset())
            serializer = FlowSerializer(queryset, many=True)

            return CustomJsonResponse(
                session_id=self.logger.session_id,
                data=serializer.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = ResponseAPI().error(e, str(e) , None, str(exc_type), fname, str(exc_tb.tb_lineno) )
            return Response(response, status=status.HTTP_200_OK)

# class FlowRepositoryFilter(filters.FilterSet):
#     instance_uuids = filters.CharFilter(lookup_expr='icontains')
#
#     class Meta:
#         model = FlowRepository
#         fields = {
#             'code': ['exact', 'startswith', 'contains', 'icontains', 'in'],
#             'name': ['exact', 'startswith', 'contains', 'icontains'],
#             'uuid': ['exact'],
#             'sub_state_id': ['exact'],
#             'instance_uuids': [],
#             'flow__system_generated': ['exact'],
#         }
#
#
# class FlowRepositoryViewSet(viewsets.ModelViewSet):
#     queryset = FlowRepository.objects.all().order_by('id')
#     filter_class = FlowRepositoryFilter
#     logger = Logger('Flow Repository View')
#
#     def get_serializer_class(self):
#         if self.action == 'list':
#             return FlowRepositorySerializer
#         if self.action == 'retrieve':
#             return FlowRepositoryDetailSerializer
#         return FlowRepositorySerializer
#
#     def list(self, request, **kwargs):
#         queryset = self.get_queryset()
#         queryset = self.filter_queryset(queryset)
#         serializer = FlowRepositoryDetailSerializer(queryset, many=True)
#
#         return CustomJsonResponse(data=serializer.data,
#                                   session_id=self.logger.session_id,
#                                   )
