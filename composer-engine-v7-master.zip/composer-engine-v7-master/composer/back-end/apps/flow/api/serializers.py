import uuid
import json

from rest_framework import serializers
from jsonfield import JSONField

from apps.flow.models import Flow
from apps.flow.models import FlowInstance
from apps.flow.models import FlowPackage
from apps.flow.models import FlowRepository


class FlowInstanceSerializer(serializers.ModelSerializer):
    config = serializers.JSONField()

    class Meta:
        model = FlowInstance
        fields = [
            'id',
            'sequence',
            'sub_sequence',
            'instance_type',
            'instance_uuid',
            'uuid',
            'next_instance_uuids',
            'config',
        ]

class FlowSerializer(serializers.ModelSerializer):
    class Meta:
        model = Flow
        fields = [
            'id',
            'uuid',
            'code',
            'name',
            'description',
            'label',
            'latest_build_no',
            'build_with_latest_adjustment',
            'system_generated',
            'created_date',
            'updated_date',
        ]
        read_only_fields = [
            'id',
            'uuid'
        ]

class FlowDetailSerializer(FlowSerializer):
    instances = FlowInstanceSerializer(many=True)

    class Meta:
        model = Flow
        fields = [
            'id',
            'uuid',
            'code',
            'name',
            'description',
            'label',
            'latest_build_no',
            'instances',
        ]

class FlowRepositorySerializer(serializers.ModelSerializer):
    class Meta:
        model = FlowRepository
        fields = [
            'id',
            'uuid',
            'code',
            'name',
            'description',
            'label',
            'build_no',
            'sub_state_id',
            'created_date',
            'updated_date',
        ]

class FlowRepositoryDetailSerializer(serializers.ModelSerializer):
    build_data = serializers.SerializerMethodField()

    class Meta:
        model = FlowRepository
        fields = [
            'id',
            'uuid',
            'code',
            'name',
            'description',
            'label',
            'build_no',
            'sub_state_id',
            'build_data',
            'created_date',
            'updated_date',
        ]

    def get_build_data(self, obj):
        package = FlowPackage.objects.filter(uuid=obj.uuid, build_no=obj.build_no).first()
        build_data = package.build_data
        return json.loads(build_data)
