import reversion

from uuid import uuid4
from django.utils import timezone
from django.utils.translation import ugettext_lazy as _
from django.contrib.postgres.fields import ArrayField
from django.db import models
from jsonfield import JSONField

from apps.commons.generator.constants import InstanceType
from apps.configurations.models import SubState


@reversion.register()
class Flow(models.Model):
    uuid = models.UUIDField(db_index=True, default=uuid4, editable=False, unique=True)
    code = models.CharField(max_length=100, unique=False, verbose_name=_("Code"))
    name = models.CharField(max_length=150, verbose_name=_("Name"))
    description = models.TextField(blank=True, null=True, verbose_name=_("Description"))

    label = models.CharField(max_length=150, null=True, verbose_name=_("Label"))
    latest_build_no = models.PositiveIntegerField(null=True, verbose_name=_("Latest Build No"))
    build_with_latest_adjustment = models.BooleanField(default=False, verbose_name=_("Build with Latest Adjustment"))

    system_generated = models.BooleanField(default=False, verbose_name=_("System Generated"))
    created_date = models.DateTimeField(auto_now_add=True)
    updated_date = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ("code",)

    def __str__(self):
        return "%s - %s" % (self.code, self.name)


@reversion.register()
class FlowInstance(models.Model):
    INSTANCE_TYPE_CHOICES = (
        (InstanceType.Common.value, _('common instance')),
        (InstanceType.Custom.value, _('custom instance')),
        (InstanceType.Service.value, _('service instance')),
        (InstanceType.Combined.value, _('combined instance')),
        (InstanceType.Virtual.value, _('virtual')),
        (InstanceType.Pass.value, _('pass')),
        (InstanceType.End.value, _('end')),
    )

    uuid = models.UUIDField(db_index=True, default=uuid4, null=True, verbose_name=_("UUID"))
    flow = models.ForeignKey(Flow, on_delete=models.CASCADE, related_name='instances', verbose_name=_("Flow"))
    sequence = models.PositiveIntegerField(verbose_name=_("Sequence"))
    sub_sequence = models.PositiveIntegerField(null=True, default=1, verbose_name=_("Sub Sequence"))
    instance_type = models.PositiveSmallIntegerField(default=InstanceType.Common.value
                                                     , choices=INSTANCE_TYPE_CHOICES
                                                     , verbose_name=_('Instance Type'))
    instance_uuid = models.UUIDField(editable=False)
    next_instance_uuids = ArrayField(models.UUIDField(), default=list, blank=True, verbose_name=_("Next Instances UUIDs"))
    config = JSONField(null=True, default=(), verbose_name=_("Configuration"))

    def __str__(self):
        return "%s - %s" % (self.flow.code, self.flow.name)


@reversion.register()
class FlowPackage(models.Model):
    uuid = models.UUIDField(db_index=True, null=True, verbose_name=_("UUID"))
    build_no = models.PositiveIntegerField(null=True, verbose_name=_("Build No"))
    build_data = JSONField(null=True, default=dict(), verbose_name=_("Build Data"))

    def __str__(self):
        return "%s - %s" % (self.uuid, self.build_no)


@reversion.register()
class FlowRepository(models.Model):
    uuid = models.UUIDField(db_index=True, verbose_name=_("UUID"))
    code = models.CharField(db_index=True, max_length=100, verbose_name=_("Code"))
    name = models.CharField(max_length=150, verbose_name=_("Name"))
    description = models.TextField(blank=True, null=True, verbose_name=_("Description"))

    label = models.CharField(max_length=150, null=True, verbose_name=_("Label"))
    role = JSONField(default=dict(), verbose_name=_("Role"))
    instance_uuids = ArrayField(models.UUIDField(), default=list, blank=True, verbose_name=_("Instance UUIDS"))
    build_no = models.PositiveIntegerField(null=True, verbose_name=_("Build No"))

    flow = models.ForeignKey(Flow, on_delete=models.CASCADE, verbose_name=_("Flow"))
    sub_state = models.ForeignKey(SubState, on_delete=models.CASCADE, null=True, verbose_name=_("Sub state"))

    created_date = models.DateTimeField(auto_now_add=True)
    updated_date = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ('uuid', 'sub_state')

    def __str__(self):
        return "%s - %s" % (self.code, self.name)
