import uuid
import os
import sys
import re
import threading

from uuid import UUID
from django.conf import settings
from django.db.models import Q
from rest_framework.response import Response
from rest_framework import status, generics

from apps.commons.logger.views import ViewLogger
from apps.commons.utilities.response import ResponseAPI
from apps.pre_defined_generator.views.automation import AutomationAPIView
from apps.commons.utilities.response import ResponseAPI
from apps.commons.serializers import AbstractSerializer
from apps.commons.generator.constants import ElementAction
from apps.commons.generator.constants import ElementType
from apps.commons.generator.constants import GeneratingType
from apps.commons.error.exception import *
from apps.configurations.models import SubState
from apps.routines.models import Routine
from apps.custom_instance.models import CustomInstance, CustomInstanceRepository
from apps.flow.models import Flow, FlowRepository 
from apps.node_repositories.models import NodeRepository
from apps.standard_process.models import StandardProcess
from apps.console_output.models import ConsoleOutput
from apps.generator_setting.models import VirtualGroup
from apps.authorization.models import ProfileMapping
from apps.commons.generator.managers.configuration import ConfigurationManager
from apps.commons.managers.custom_instance import CustomInstanceManager
from apps.commons.generator.managers.flow import FlowManager


class ElementManipulationView(generics.ListCreateAPIView, ViewLogger):
    serializer_class = AbstractSerializer
    response_meta = ResponseAPI()
    reference_id = str(uuid.uuid4())

    def post(self, request):
        try:
            self.logger.debug('element manipulation [reference id = {}] start'.format(request.session_id))

            request_data = request.data or dict()
            self.logger.debug('element manipulation [reference id = {}] request data - {}'.format(request.session_id, request_data))

            element_type = request_data.get('element_type')
            element_action = request_data.get('element_action')
            element_inputs = request_data.get('element_inputs')
            authorized_ticket = request_data.get('authorized_ticket')
            options = request_data.get('options') or dict()

            if element_type is None:
                raise BadRequestException('"element type" is required')
            if element_action is None:
                raise BadRequestException('"element action" is required')
            if element_inputs is None:
                raise BadRequestException('"element inputs" is required')
            if type(element_inputs) is not list:
                raise BadRequestException('"element inputs" is wrong format')

            # find sub state
            next_sub_state = None
            sub_state_check_authorization = None

            if element_action in [ElementAction.REGENERATION.value, ElementAction.BUILD_AND_PUBLISH.value, ElementAction.PURGE.value]:
                sub_state = SubState.objects.filter(is_default=True).first()
                if sub_state is None:
                    raise BadRequestException('"sub state" is invalid')

                sub_state_check_authorization = sub_state

            else:
                sub_state_id = options.get('sub_state_id')
                if sub_state_id is None:
                    raise BadRequestException('"sub state id" is required')

                sub_state = SubState.objects.filter(id=sub_state_id).first()
                if sub_state is None:
                    raise BadRequestException('"sub state" is invalid')

                sub_state_check_authorization = sub_state

                if element_action == ElementAction.Move.value:
                    next_sub_state_id = options.get('next_sub_state_id')
                    if next_sub_state is None:
                        raise BadRequestException('"next sub state id" is required for move action')

                    next_sub_state = SubState.objects.filter(id=next_sub_state_id).first()
                    if next_sub_state is None:
                        raise BadRequestException('"next sub state id" is invalid')

                    sub_state_check_authorization = next_sub_state

            if sub_state_check_authorization.need_authorized_ticket and (authorized_ticket is None or authorized_ticket.strip() == ''):
                raise BadRequestException('"authorized_ticket" is required')

            # Initial instance
            if element_type == ElementType.COMMON_INSTANCE.value:
                instance = CommonInstanceOperation(request)      
            elif element_type == ElementType.CUSTOM_INSTANCE.value:
                if element_action == ElementAction.REGENERATION.value:
                    raise BadRequestException('Custom Instance is not support Regenerate Configuration')

                instance = CustomInstanceOperation(request)
            elif element_type == ElementType.FLOW.value:
                if element_action == ElementAction.REGENERATION.value:
                    raise BadRequestException('Flow Instance is not support Regenerate Configuration')

                instance = FlowInstanceOperation(request)
            else:
                raise BadRequestException('"element type" is required')

            # Query role
            profile_mappings = ProfileMapping.objects.filter(user_profile__role=request.oidc_user.permission)
            has_permissions = list(filter(lambda p: p.action.code , profile_mappings))

            instance_uuids = self.cleaning_element_input(element_type, element_action, sub_state, element_inputs)
            if not instance_uuids:
                raise BadRequestException('all "element inputs" are invalid')

            # Check action authority and action
            if element_action == ElementAction.REGENERATION.value:
                if ActionAuthority.GENERATE_CONFIG.value not in has_permissions:
                    raise ActionUnAuthorizedException('not authorized to generate configuration')

                instance.regeneration(instance_uuids, sub_state, authorize_ticket)

            elif element_action == ElementAction.BUILD_AND_PUBLISH.value:
                if ActionAuthority.BUILD.value not in has_permissions:
                    raise ActionUnAuthorizedException('not authorized to build')

                if sub_state_check_authorization.is_production:
                    if ActionAuthority.PUBLISH_PROD.value not in has_permissions:
                        raise ActionUnAuthorizedException('not authorized to publish on production')
                elif sub_state_check_authorization.is_pre_production:
                    if ActionAuthority.PUBLISH_PRE_PROD.value not in has_permissions:
                        raise ActionUnAuthorizedException('not authorized to publish on pre-production')
                else:
                    if ActionAuthority.PUBLISH_NON_PROD.value not in has_permissions:
                        raise ActionUnAuthorizedException('not authorized to publish on non-production')

                instance.build_and_publish(instance_uuids, sub_state, authorize_ticket)

            elif element_action == ElementAction.REPUBLISH.value:
                if sub_state_check_authorization.is_production:
                    if ActionAuthority.PUBLISH_PROD.value not in has_permissions:
                        raise ActionUnAuthorizedException('not authorized to publish on production')
                elif sub_state_check_authorization.is_pre_production:
                    if ActionAuthority.PUBLISH_PRE_PROD.value not in has_permissions:
                        raise ActionUnAuthorizedException('not authorized to publish on pre-production')
                else:
                    if ActionAuthority.PUBLISH_NON_PROD.value not in has_permissions:
                        raise ActionUnAuthorizedException('not authorized to publish on non-production')

                instance.republish(instance_uuids, sub_state, authorize_ticket)                

            elif element_action == ElementAction.MOVE.value:
                if sub_state_check_authorization.is_production:
                    if ActionAuthority.PUBLISH_PROD.value not in has_permissions:
                        raise ActionUnAuthorizedException('not authorized to publish on production')
                elif sub_state_check_authorization.is_pre_production:
                    if ActionAuthority.PUBLISH_PRE_PROD.value not in has_permissions:
                        raise ActionUnAuthorizedException('not authorized to publish on pre-production')
                else:
                    if ActionAuthority.PUBLISH_NON_PROD.value not in has_permissions:
                        raise ActionUnAuthorizedException('not authorized to publish on non-production')

                instance.move(instance_uuids, sub_state, next_sub_state, authorize_ticket)

            elif element_action == ElementAction.REMOVE.value:
                if sub_state_check_authorization.is_production:
                    if ActionAuthority.REMOVE_PROD.value not in has_permissions:
                        raise ActionUnAuthorizedException('not authorized to remove on production')
                elif sub_state_check_authorization.is_pre_production:
                    if ActionAuthority.REMOVE_PRE_PROD.value not in has_permissions:
                        raise ActionUnAuthorizedException('not authorized to remove on pre-production')
                else:
                    if ActionAuthority.REMOVE_NON_PROD.value not in has_permissions:
                        raise ActionUnAuthorizedException('not authorized to remove on non-production')

                instance.remove(instance_uuids, sub_state, authorize_ticket)

            elif element_action == ElementAction.PURGE.value:
                if ActionAuthority.PURGE.value not in has_permissions:
                    raise ActionUnAuthorizedException('not authorized to purge')

                instance.purge(instance_uuids, sub_state, authorize_ticket)

            else:
                raise BadRequestException('"element action" is invalid')

            response = self.response_meta.success("success", request.session_id, data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , request.session_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('element manipulation [reference id = {}] exception - {}'.format(request.session_id, exception_message))

        finally:
            self.logger.debug('element manipulation [reference id = {}] response - {}'.format(request.session_id, response))
            return Response(response, status=status.HTTP_200_OK)
    
    
    def cleaning_element_input(self, element_type, element_action, sub_state, element_inputs):
        instances = set(element_inputs)
        instance_uuids = set(filter(lambda x: re.match(r'^[\da-f]{8}-([\da-f]{4}-){3}[\da-f]{12}$', x), instances))
        instance_codes = instances - instance_uuids
        instance_class = None

        if element_action in [ElementAction.REGENERATION.value, ElementAction.BUILD_AND_PUBLISH.value, ElementAction.PURGE.value]:
            if element_type == ElementType.COMMON_INSTANCE.value:
                instance_class = Routine
            elif element_type == ElementType.CUSTOM_INSTANCE.value:
                instance_class = CustomInstance
            elif element_type == ElementType.FLOW.value:
                instance_class = Flow

        else:
            if element_type == ElementType.COMMON_INSTANCE.value:
                instance_class = NodeRepository
            elif element_type == ElementType.CUSTOM_INSTANCE.value:
                instance_class = CustomInstanceRepository
            elif element_type == ElementType.FLOW.value:
                instance_class = FlowRepository
                
        if instance_class is None:
            return list()

        if element_action in [ElementAction.REGENERATION.value, ElementAction.BUILD_AND_PUBLISH.value, ElementAction.PURGE.value]:
            instances = instance_class.objects.filter(Q(uuid__in=instance_uuids) | Q(code__in=instance_codes))

        else:
            instances = instance_class.objects.filter(Q(uuid__in=instance_uuids) | Q(code__in=instance_codes), Q(sub_state=sub_state))

        return list(set(map(lambda r: r.uuid, instances)))


class CommonInstanceOperation(ViewLogger):

    def __init__(self, request):
        self.request = request
        self.executed_by = self.request.oidc_user.preferred_username
        self.response_meta = ResponseAPI()

    def regeneration(self, instance_uuids, sub_state, authorize_ticket):
        try:
            self.logger.debug('regenerate routines [reference id = {}] start'.format(self.request.session_id))

            console_output = ConsoleOutput.objects.create(**{
                'titile': 'Regeneration Configuration',
                'executed_by': self.executed_by
            })

            threading.Thread(target=lambda: self.regeneration_process(instance_uuids, sub_state, console_output, self.executed_by, authorized_ticket)).start()

            response = self.response_meta.success('success', self.request.session_id, {
                'console_output_id': console_output.id,
            })

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e), self.request.session_id, str(exc_type), fname, str(exc_tb.tb_lineno))

            self.logger.error('regenerate routines [reference id = {}] exception - {}'.format(self.request.session_id, exception_message))

        finally:
            self.logger.debug('regenerate routines [reference id = {}] response = {}'.format(self.request.session_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def regeneration_process(self, instance_uuids, sub_state, console_output, executed_by, authorized_ticket):
        try:
            self.logger.debug('regenerate pre-defined process | start')

            generating_tag = RoutineTags.next()
            configuration_manager = ConfigurationManager(self.request.session_id)

            total = len(instance_uuids)
            count = 0
            for instance_uuid in instance_uuids:
                try:
                    error_message = None
                    routine = Routine.objects.filter(uuid=instance_uuid).first()

                    if routine is None:
                        raise Exception('routine not found')

                    standard_process = routine.standard_process
                    dataset_name = routine.dataset_name

                    if standard_process is None or dataset_name is None:
                        raise Exception('standard process or dataset name is null')

                    standard_process = StandardProcess.objects.get(id=standard_process.id)
                    additional_config = dict()

                    generating_type = GeneratingType.PreDefinedSingleDataset.value
                    virtual_group = VirtualGroup.objects.filter(name=dataset_name).first()
                    if virtual_group is not None:
                        generating_type = GeneratingType.PreDefinedMultipleDataset.value

                    configuration_manager.generate(standard_process
                                                   , dataset_name
                                                   , generating_type
                                                   , generating_tag
                                                   , additional_config
                                                   , executed_by)
                    
                except Exception as ie:
                    error_message = str(ie)
                    self.logger.error(
                        'regenerate pre-defined process | generate (dataset={} standard process={}) exception: {}' \
                        .format(dataset_name, standard_process.code, error_message))

                finally:
                    count = count + 1
                    message = 'success' if error_message is None else error_message
                    code = routine.code if routine is not None else '-'
                    console_output.append('({}/{}) "{}" (code: {}) : {}' \
                                          .format(count, total, instance_uuid, code, message))

            console_output.append('complete')

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('regenerate pre-defined process | exception: {}'.format(exception_message))
            console_output.append('fail with exception: {}'.format(exception_message))
            
        finally:
            console_output.finish()

    def build_and_publish(self, instance_uuids, sub_state, authorized_ticket):
        try:
            self.logger.debug('build and publish common instances [reference id = {}] start'.format(self.request.session_id))

            console_output = ConsoleOutput.objects.create(**{
                'titile': f'Build and Publish Common Instance to {sub_state.name}',
                'executed_by': self.executed_by
            })

            threading.Thread(target=lambda: self.build_and_publish_process(instance_uuids, sub_state, console_output, self.executed_by, authorized_ticket)).start()

            response = self.response_meta.success('success', self.request.session_id, {
                'console_output_id': console_output.id,
            })

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e), self.request.session_id, str(exc_type), fname, str(exc_tb.tb_lineno))

            self.logger.error('build and publish common instances [reference id = {}] exception - {}'.format(self.request.session_id, exception_message))

        finally:
            self.logger.debug('build and publish common instances [reference id = {}] response = {}'.format(self.request.session_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def build_and_publish_process(self, instance_uuids, sub_state, console_output, executed_by, authorized_ticket):
        try:
            success, error_list = CommonInstanceManager().build_and_publish(instance_uuids
                                                                            , sub_state
                                                                            , console_output=console_output
                                                                            , executed_by=executed_by
                                                                            , authorized_ticket=authorized_ticket)
            console_output.append('complete')
            return success, error_list

        except Exception as e:
            console_output.append('fail with exception: {}'.format(str(e)))
            raise e

        finally:
            console_output.finish()

    def republish(self, instance_uuids, sub_state, authorized_ticket):
        try:
            self.logger.debug('republish common instances [reference id = {}] start'.format(self.request.session_id))

            console_output = ConsoleOutput.objects.create(**{
                'titile': f'Republish Common Instance on {sub_state.name}',
                'executed_by': self.executed_by
            })

            threading.Thread(target=lambda: self.republish_process(instance_uuids, sub_state, console_output, self.executed_by, authorized_ticket)).start()

            response = self.response_meta.success('success', self.request.session_id, {
                'console_output_id': console_output.id,
            })

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e), self.request.session_id, str(exc_type), fname, str(exc_tb.tb_lineno))

            self.logger.error('republish common instances [reference id = {}] exception - {}'.format(self.request.session_id, exception_message))

        finally:
            self.logger.debug('republish common instances [reference id = {}] response = {}'.format(self.request.session_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def republish_process(self, instance_uuids, sub_state, console_output, executed_by, authorized_ticket):
        try:
            success, error_list = CommonInstanceManager().republish(instance_uuids
                                                                    , sub_state
                                                                    , console_output=console_output
                                                                    , executed_by=executed_by
                                                                    , authorized_ticket=authorized_ticket)
            console_output.append('complete')
            return success, error_list
        except Exception as e:
            console_output.append('fail with exception: {}'.format(str(e)))
            raise e
        finally:
            console_output.finish()

    def move(self, instance_uuids, source_sub_state, destination_sub_state, authorized_ticket):
        try:
            self.logger.debug('move common instances [reference id = {}] start'.format(self.request.session_id))

            console_output = ConsoleOutput.objects.create(**{
                'titile': f'Move Common Instance from {source_sub_state.name} to {destination_sub_state.name}',
                'executed_by': self.executed_by
            })

            threading.Thread(target=lambda: self.move_process(instance_uuids \
                                                , source_sub_state \
                                                , destination_sub_state \
                                                , console_output \
                                                , self.executed_by \
                                                , authorized_ticket)).start()

            response = self.response_meta.success('success', self.request.session_id, {
                'console_output_id': console_output.id,
            })

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e), self.request.session_id, str(exc_type), fname, str(exc_tb.tb_lineno))

            self.logger.error('move common instances [reference id = {}] exception - {}'.format(self.request.session_id, exception_message))

        finally:
            self.logger.debug('move common instances [reference id = {}] response = {}'.format(self.request.session_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def move_process(self, instance_uuids, source_sub_state, destination_sub_state, console_output, executed_by, authorized_ticket):
        try:
            success, error_list = CommonInstanceManager().move(instance_uuids
                                                               , source_sub_state
                                                               , destination_sub_state
                                                               , console_output=console_output
                                                               , executed_by=executed_by
                                                               , authorized_ticket=authorized_ticket)
            console_output.append('complete')
            return success, error_list
        except Exception as e:
            console_output.append('fail with exception: {}'.format(str(e)))
            raise e
        finally:
            console_output.finish()

    def remove(self, instance_uuids, sub_state, authorized_ticket):
        try:
            self.logger.debug('remove common instances [reference id = {}] start'.format(self.request.session_id))

            console_output = ConsoleOutput.objects.create(**{
                'titile': f'Remove Common Instance on {sub_state.name}',
                'executed_by': self.executed_by
            })

            threading.Thread(target=lambda: self.remove_process(instance_uuids
                                                            , sub_state
                                                            , console_output
                                                            , self.executed_by
                                                            , authorized_ticket)).start()

            response = self.response_meta.success('success', self.request.session_id, {
                'console_output_id': console_output.id,
            })

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e), self.request.session_id, str(exc_type), fname, str(exc_tb.tb_lineno))

            self.logger.error('remove common instances [reference id = {}] exception - {}'.format(self.request.session_id, exception_message))

        finally:
            self.logger.debug('remove common instances [reference id = {}] response = {}'.format(self.request.session_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def remove_process(self, instance_uuids, sub_state, console_output, executed_by, authorized_ticket):
        try:
            success, error_list = CommonInstanceManager().remove(instance_uuids
                                                                 , sub_state
                                                                 , console_output=console_output
                                                                 , executed_by=executed_by
                                                                 , authorized_ticket=authorized_ticket)
            console_output.append('complete')
            return success, error_list
        except Exception as e:
            console_output.append('fail with exception: {}'.format(str(e)))
            raise e
        finally:
            console_output.finish()

    def purge(self, instance_uuids, sub_state, authorized_ticket):
        try:
            self.logger.debug('purge common instances [reference id = {}] start'.format(self.request.session_id))

            console_output = ConsoleOutput.objects.create(**{
                'titile': 'Purge Common Instance',
                'executed_by': self.executed_by
            })

            threading.Thread(target=lambda: self.purge_process(instance_uuids, console_output)).start()

            response = self.response_meta.success('success', self.request.session_id, {
                'console_output_id': console_output.id,
            })

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e), self.request.session_id, str(exc_type), fname, str(exc_tb.tb_lineno))

            self.logger.error('purge common instances [reference id = {}] exception - {}'.format(self.request.session_id, exception_message))

        finally:
            self.logger.debug('purge common instances [reference id = {}] response = {}'.format(self.request.session_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def purge_process(self, instance_uuids, console_output):
        try:
            success, error_list = CommonInstanceManager().purge(instance_uuids, console_output=console_output)
            console_output.append('complete')
            return success, error_list

        except Exception as e:
            console_output.append('fail with exception: {}'.format(str(e)))
            raise e

        finally:
            console_output.finish()


class CustomInstanceOperation(ViewLogger):

    def build_and_publish(self, instance_uuids, sub_state, authorized_ticket):
        pass

    def republish(self, instance_uuids, sub_state, authorized_ticket):
        pass

    def move(self, instance_uuids, source_sub_state, destination_sub_state, authorized_ticket):
        pass

    def remove(self, instance_uuids, sub_state, authorized_ticket):
        pass

    def purge(self, instance_uuids, authorized_ticket):
        pass


class FlowInstanceOperation(ViewLogger):

    def __init__(self, request):
        self.request = request
        self.executed_by = self.request.oidc_user.preferred_username
        self.response_meta = ResponseAPI()

    def build_and_publish(self, instance_uuids, sub_state, authorized_ticket):
        try:
            self.logger.debug('build and publish flow instances [reference id = {}] start'.format(self.request.session_id))

            console_output = ConsoleOutput.objects.create(**{
                'titile': f'Build and Publish Flow Instance to {sub_state.name}',
                'executed_by': self.executed_by
            })

            threading.Thread(target=lambda: self.build_and_publish_process(instance_uuids, sub_state, console_output, self.executed_by, authorized_ticket)).start()

            response = self.response_meta.success('success', self.request.session_id, {
                'console_output_id': console_output.id,
            })

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e), self.request.session_id, str(exc_type), fname, str(exc_tb.tb_lineno))

            self.logger.error('build and publish flow instances [reference id = {}] exception - {}'.format(self.request.session_id, exception_message))

        finally:
            self.logger.debug('build and publish flow instances [reference id = {}] response = {}'.format(self.request.session_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def build_and_publish_process(self, instance_uuids, sub_state, console_output, executed_by, authorized_ticket):
        try:
            success, error_list = FlowManager().build_and_publish(instance_uuids
                                                                , sub_state
                                                                , console_output=console_output
                                                                , executed_by=executed_by
                                                                , authorized_ticket=authorized_ticket)
            console_output.append('complete')
            return success, error_list

        except Exception as e:
            console_output.append('fail with exception: {}'.format(str(e)))
            raise e

        finally:
            console_output.finish()

    def republish(self, instance_uuids, sub_state, authorized_ticket):
        try:
            self.logger.debug('republish flow instances [reference id = {}] start'.format(self.request.session_id))

            console_output = ConsoleOutput.objects.create(**{
                'titile': f'Republish Flow Instance on {sub_state.name}',
                'executed_by': self.executed_by
            })

            threading.Thread(target=lambda: self.republish_process(instance_uuids, sub_state, console_output, self.executed_by, authorized_ticket)).start()

            response = self.response_meta.success('success', self.request.session_id, {
                'console_output_id': console_output.id,
            })

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e), self.request.session_id, str(exc_type), fname, str(exc_tb.tb_lineno))

            self.logger.error('republish flow instances [reference id = {}] exception - {}'.format(self.request.session_id, exception_message))

        finally:
            self.logger.debug('republish flow instances [reference id = {}] response = {}'.format(self.request.session_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def republish_process(self, instance_uuids, sub_state, console_output, executed_by, authorized_ticket):
        try:
            success, error_list = FlowManager().republish(instance_uuids
                                                            , sub_state
                                                            , console_output=console_output
                                                            , executed_by=executed_by
                                                            , authorized_ticket=authorized_ticket)
            console_output.append('complete')
            return success, error_list
        except Exception as e:
            console_output.append('fail with exception: {}'.format(str(e)))
            raise e
        finally:
            console_output.finish()

    def move(self, instance_uuids, source_sub_state, destination_sub_state, authorized_ticket):
        try:
            self.logger.debug('move flow instances [reference id = {}] start'.format(self.request.session_id))

            console_output = ConsoleOutput.objects.create(**{
                'titile': f'Move Flow Instance from {source_sub_state.name} to {destination_sub_state.name}',
                'executed_by': self.executed_by
            })

            threading.Thread(target=lambda: self.move_process(instance_uuids \
                                                , source_sub_state \
                                                , destination_sub_state \
                                                , console_output \
                                                , self.executed_by \
                                                , authorized_ticket)).start()

            response = self.response_meta.success('success', self.request.session_id, {
                'console_output_id': console_output.id,
            })

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e), self.request.session_id, str(exc_type), fname, str(exc_tb.tb_lineno))

            self.logger.error('move flow instances [reference id = {}] exception - {}'.format(self.request.session_id, exception_message))

        finally:
            self.logger.debug('move flow instances [reference id = {}] response = {}'.format(self.request.session_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def move_process(self, instance_uuids, source_sub_state, destination_sub_state, console_output, executed_by, authorized_ticket):
        try:
            success, error_list = FlowManager().move(instance_uuids
                                                    , source_sub_state
                                                    , destination_sub_state
                                                    , console_output=console_output
                                                    , executed_by=executed_by
                                                    , authorized_ticket=authorized_ticket)
            console_output.append('complete')
            return success, error_list
        except Exception as e:
            console_output.append('fail with exception: {}'.format(str(e)))
            raise e
        finally:
            console_output.finish()

    def remove(self, instance_uuids, sub_state, authorized_ticket):
        try:
            self.logger.debug('remove flow instances [reference id = {}] start'.format(self.request.session_id))

            console_output = ConsoleOutput.objects.create(**{
                'titile': f'Remove Flow Instance on {sub_state.name}',
                'executed_by': self.executed_by
            })

            threading.Thread(target=lambda: self.remove_process(instance_uuids
                                                            , sub_state
                                                            , console_output
                                                            , self.executed_by
                                                            , authorized_ticket)).start()

            response = self.response_meta.success('success', self.request.session_id, {
                'console_output_id': console_output.id,
            })

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e), self.request.session_id, str(exc_type), fname, str(exc_tb.tb_lineno))

            self.logger.error('remove flow instances [reference id = {}] exception - {}'.format(self.request.session_id, exception_message))

        finally:
            self.logger.debug('remove flow instances [reference id = {}] response = {}'.format(self.request.session_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def remove_process(self, instance_uuids, sub_state, console_output, executed_by, authorized_ticket):
        try:
            success, error_list = FlowManager().remove(instance_uuids
                                                        , sub_state
                                                        , console_output=console_output
                                                        , executed_by=executed_by
                                                        , authorized_ticket=authorized_ticket)
            console_output.append('complete')
            return success, error_list
        except Exception as e:
            console_output.append('fail with exception: {}'.format(str(e)))
            raise e
        finally:
            console_output.finish()

    def purge(self, instance_uuids, authorized_ticket):
        try:
            self.logger.debug('purge flow instances [reference id = {}] start'.format(self.request.session_id))

            console_output = ConsoleOutput.objects.create(**{
                'titile': 'Purge Flow Instance',
                'executed_by': self.executed_by
            })

            threading.Thread(target=lambda: self.purge_process(instance_uuids, console_output)).start()

            response = self.response_meta.success('success', self.request.session_id, {
                'console_output_id': console_output.id,
            })

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e), self.request.session_id, str(exc_type), fname, str(exc_tb.tb_lineno))

            self.logger.error('purge flow instances [reference id = {}] exception - {}'.format(self.request.session_id, exception_message))

        finally:
            self.logger.debug('purge flow instances [reference id = {}] response = {}'.format(self.request.session_id, response))
            return Response(response, status=status.HTTP_200_OK)
    
    def purge_process(self, instance_uuids, console_output):
        try:
            success, error_list = FlowManager().purge(instance_uuids, console_output=console_output)
            console_output.append('complete')
            return success, error_list

        except Exception as e:
            console_output.append('fail with exception: {}'.format(str(e)))
            raise e

        finally:
            console_output.finish()
