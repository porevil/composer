from django.conf.urls import url
from django.urls import path, include
from django.contrib import admin
from django.conf import settings

from rest_framework.routers import DefaultRouter
from rest_framework import permissions
from drf_yasg.views import get_schema_view
from drf_yasg import openapi

from apps.authorization.api.viewsets import MenuViewSet, UserProfileViewSet, ActionViewSet
from apps.configurations.api.viewsets import StateViewSet, \
    SubStateViewSet, \
    InstanceEnvironmentVariableViewSet, \
    InstanceDeploymentSpecificationViewSet
from apps.standard_process.api.viewsets import ComponentViewSet, StandardTemplateViewSet, StandardProcessViewSet
from apps.routines.api.viewsets import LotViewSet, RoutineViewSet
from apps.node_repositories.api.viewsets import NodeRepositoryViewSet
from apps.console_output.api.viewsets import ConsoleOutputViewSet
from apps.rules.api.viewsets import TemplateRuleViewSet
from apps.element_manipulation.views import ElementManipulationView

from apps.authentication.views import Login, Authorize, RefreshToken
from apps.authorization.views import ProfileMenuMappingView, ProfileActionMappingView
from apps.menu.views import MenuView
from apps.client_logger.api.views import ClientLoggerView

from apps.metadata.views import MetadataView
from apps.generator_setting.views import ListDatafieldSettingView, \
    DeleteDatafieldSettingView, \
    DeleteVirtualSettingView, \
    SaveVirtualDataset, \
    ListDatasetView, \
    DeleteDatasetSettingView, \
    SearchOrCreateVirtualView, \
    ListVirtualView, \
    SearchOrCreateDatasetView, \
    SaveDatasetSetting, \
    GetVirtualDetailByGroupId, \
    CheckVersionDatasetFromDataEngine, \
    RetrieveDatafieldSettingByNameView, \
    GetSubFieldVirtualSettingView

from apps.pre_defined_generator.views.configuration import \
    GenerateConfigurationView as AutomatedGenerateConfigurationView
from apps.pre_defined_generator.views.configuration import \
    RegenerateConfigurationView as AutomatedRegenerateConfigurationView
from apps.pre_defined_generator.views.configuration import AdjustConfigurationView
from apps.pre_defined_generator.views.deployment import BuildAndPublishView as AutomatedBuildAndPublishView
from apps.pre_defined_generator.views.deployment import RepublishView as AutomatedRepublishView
from apps.pre_defined_generator.views.deployment import MoveView as AutomatedMoveView
from apps.pre_defined_generator.views.deployment import RemoveView as AutomatedRemoveView
from apps.pre_defined_generator.views.purge import PurgeView as AutomatedPurgeView

from apps.common_instance.views import BuildAndPublishView as InstanceBuildAndPublishView
from apps.common_instance.views import RepublishView as InstanceRepublishView
from apps.common_instance.views import MoveView as InstanceMoveView
from apps.common_instance.views import RemoveView as InstanceRemoveView
from apps.common_instance.views import PurgeView as InstancePurgeView

from apps.combined_instance.views import BuildView as CombinedInstanceBuildView
from apps.combined_instance.views import PurgeView as CombinedInstancePurgeView

from apps.user_defined_generator.views import GenerateUserDefinedView

from apps.flow.views import BuildAndPublishView as FlowBuildAndPublishView
from apps.flow.views import RepublishView as FlowRepublishView
from apps.flow.views import MoveView as FlowMoveView
from apps.flow.views import RemoveView as FlowRemoveView
from apps.flow.views import PurgeView as FlowPurgeView


from apps.routines.views import ListRoutineByLotView, GetActivityConfigurationView
from apps.node_repositories.views import ListNodeRepositoriesByLotView

from apps.launcher.api.viewsets import LauncherApplicationViewSet
from apps.launcher.api.viewsets import LauncherProcedureViewSet
from apps.launcher.api.viewsets import LauncherFlowViewSet

from apps.statistic.api import views as statistic_views
from apps.environment_variable.views import EnvironmentVariable

from apps.service_instance.api.viewsets import ServiceInstanceViewSet
from apps.service_repository.api.viewsets import ServiceRepositoryViewSet

from apps.flow.api.viewsets import FlowViewSet

from apps.combined_instance.api.viewsets import CombinedInstanceViewSet, \
    CombinedInstanceRepositoryViewSet

from apps.custom_instance.api.viewsets import CustomInstanceViewSets, \
    CustomInstanceRepositoryViewSets, \
    CustomInstanceExecutionViewSets

# from apps.test_virtual_instance.views import GenerateConfigurationView

schema_view = get_schema_view(
    openapi.Info(
        title="Composer API",
        default_version='v1',
        description="Test description",
        terms_of_service="https://www.google.com/policies/terms/",
        contact=openapi.Contact(email="laphatrad@tisco.co.th"),
        license=openapi.License(name="BSD License"),
    ),
    public=True,
    permission_classes=(permissions.AllowAny,),
)

router = DefaultRouter()
# viewsets
router.register(r'^authorization/menu', MenuViewSet, basename='authorization_menu')
router.register(r'^authorization/user_profile', UserProfileViewSet, basename='authorization_menu')
router.register(r'^authorization/action', ActionViewSet, basename='authorization_menu')
router.register(r'^configurations/state', StateViewSet, basename='State')
router.register(r'^configurations/sub_state', SubStateViewSet, basename='State')
router.register(r'^configurations/instance_environment_variable', InstanceEnvironmentVariableViewSet,
                basename='Instance Environment Variable')
router.register(r'^configurations/instance_deployment_specification', InstanceDeploymentSpecificationViewSet,
                basename='Instance Deployment Specification')
router.register(r'^common_mbs/generator/lot', LotViewSet, basename='Lot')
router.register(r'^common_mbs/catalog/list_routine', RoutineViewSet, basename='Routine')
router.register(r'^common_mbs/repositories/list_node_repository', NodeRepositoryViewSet, basename='Node Repository')
router.register(r'^standard_process/component', ComponentViewSet, basename='Cokmponent')
router.register(r'^standard_process/standard_template', StandardTemplateViewSet, basename='Standard Template')
router.register(r'^standard_process/standard_mapping', StandardProcessViewSet, basename='Standard Mapping')
router.register(r'^standard_process/template_rules', TemplateRuleViewSet, basename='Template Rule')
router.register(r'^console_output', ConsoleOutputViewSet, basename='Console Output')
router.register(r'^launcher/application', LauncherApplicationViewSet, basename='Application')
router.register(r'^launcher/procedure', LauncherProcedureViewSet, basename='Procedure')
router.register(r'^launcher/flow', LauncherFlowViewSet, basename='Flow')
router.register(r'^service_repository', ServiceRepositoryViewSet, basename='Service Repository')
router.register(r'^service_instance', ServiceInstanceViewSet, basename='service-instance')
router.register(r'^flows/configuration', FlowViewSet, basename='flow-configuration')

router.register(r'^combined_instance/configuration', CombinedInstanceViewSet,
                basename='combined-instance-configuration')
router.register(r'^combined_instance/repositories', CombinedInstanceRepositoryViewSet,
                basename='combined-instance-repository')

router.register(r'^custom_instance/configuration', CustomInstanceViewSets,
                basename='custom-instance-configuration')
router.register(r'^custom_instance/repositories', CustomInstanceRepositoryViewSets,
                basename='custom-instance-repository')
router.register(r'^custom_instance/executions', CustomInstanceExecutionViewSets,
                basename='custom-instance-execution')
# router.register(r'^generator_setting/dataset/save', DatasetSettingViewSet, basename='State')

# router.register(r'^virtual/dataset', DatasetViewSet, basename='Dataset')
# router.register(r'^virtual/group', GroupViewSet, basename='Dataset')

urlpatterns = [
    url(settings.SECRET_URL, admin.site.urls),
    url(r'^swagger(?P<format>\.json|\.yaml)/?$', schema_view.without_ui(cache_timeout=0), name='schema-json'),
    url(r'^swagger/?$', schema_view.with_ui('swagger', cache_timeout=0), name='schema-swagger-ui'),
    url(r'^redoc/?$', schema_view.with_ui('redoc', cache_timeout=0), name='schema-redoc'),

    # url(r'^authentication/$', Authentication.as_view(), name="acs_app"),
    url(r'^authentication/login/?$', Login.as_view(), name="login"),
    url(r'^authentication/verifycode/(?P<code>[^/.]+)/?$', Authorize.as_view(), name="verifycode"),
    url(r'^authentication/refresh/?$', RefreshToken.as_view(), name="refresh_token"),

    url(r'^authorization/profile_menu_mapping/?$', ProfileMenuMappingView.as_view(), name='profile_menu_mapping'),
    url(r'^authorization/profile_action_mapping/?$', ProfileActionMappingView.as_view(), name='profile_action_mapping'),

    url(r'^menu/$', MenuView.as_view(), name="get_menu"),
    url(r'^client_logger/$', ClientLoggerView.as_view(), name='client_logger'),

    url(r'^generator_setting/dataset/save/?$', SaveDatasetSetting.as_view(), name='savedataset'),
    url(r'^generator_setting/dataset/?$', ListDatasetView.as_view(), name='datasetList'),
    url(r'^generator_setting/dataset/(?P<name>[^/.]+)/?$', SearchOrCreateDatasetView.as_view(), name='dataset'),
    url(r'^generator_setting/refresh_dataset/(?P<name>[^/.]+)/?$', CheckVersionDatasetFromDataEngine.as_view(),
        name='dataset'),

    url(r'^generator_setting/dataset/delete/(?P<name>[^/.]+)/?$', DeleteDatasetSettingView.as_view(), name='dataset'),
    url(r'^generator_setting/datafields/?$', ListDatafieldSettingView.as_view(), name='datafields'),
    url(r'^generator_setting/datafields/delete/(?P<id>[^/.]+)/?$', DeleteDatafieldSettingView.as_view(),
        name='datafields'),
    url(r'^generator_setting/datafields/(?P<name>[^/.]+)/?$', RetrieveDatafieldSettingByNameView.as_view(),
        name='datafields'),
    url(r'^generator_setting/virtualdataset/save/?$', SaveVirtualDataset.as_view(), name='virtualdataset'),
    url(r'^generator_setting/virtualdataset/get/(?P<id>[^/.]+)/?$', GetVirtualDetailByGroupId.as_view(),
        name='virtualdataset'),
    url(r'^generator_setting/virtualdataset/?$', ListVirtualView.as_view(), name='virtualdataset'),
    url(r'^generator_setting/virtualdataset/(?P<name>[^/.]+)/?$', SearchOrCreateVirtualView.as_view(), name='dataset'),
    url(r'^generator_setting/virtualdataset/getsubfield/(?P<id>[^/.]+)/?$', GetSubFieldVirtualSettingView.as_view(), name='dataset'),
    url(r'^generator_setting/virtualdataset/delete/(?P<id>[^/.]+)/?$', DeleteVirtualSettingView.as_view(),
        name='datafields'),

    url(r'^get_metadata/?$', MetadataView.as_view(), name='metadata'),
    url(r'^get_metadata/(?P<dataset_name>\w+)/?$',
        MetadataView.as_view(), name='metadata'),

    url(r'^common_mbs/generator/adjust_configuration/?$', AdjustConfigurationView.as_view(),
        name='adjust_configuration'),
    url(
        r'^common_mbs/generator/adjust_configuration/(?P<uuid>[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})/?$',
        AdjustConfigurationView.as_view(), name='adjust_configuration'),
    url(r'^common_mbs/generator/generate_configuration/?$', AutomatedGenerateConfigurationView.as_view(),
        name='automated_generate_configuration'),
    url(r'^common_mbs/generator/regenerate_configuration/?$', AutomatedRegenerateConfigurationView.as_view(),
        name='automated_regenerate_configuration'),
    url(r'^common_mbs/generator/build_and_publish/?$', AutomatedBuildAndPublishView.as_view(),
        name='automated_build_and_publish'),
    url(r'^common_mbs/generator/republish/?$', AutomatedRepublishView.as_view(), name='automated_republish'),
    url(r'^common_mbs/generator/move/?$', AutomatedMoveView.as_view(), name='automated_move'),
    url(r'^common_mbs/generator/remove/?$', AutomatedRemoveView.as_view(), name='automated_remove'),
    url(r'^common_mbs/generator/purge/?$', AutomatedPurgeView.as_view(), name='automated_purge'),

    url(r'^common_mbs/generator/get_activities_configuration/?$', GetActivityConfigurationView.as_view(),
        name='get_activities_configuration'),
    url(r'^common_mbs/generator/list_routine_by_lot/?$', ListRoutineByLotView.as_view(), name='list_routine_by_lot'),
    url(r'^common_mbs/generator/list_node_repository_by_lot/?$', ListNodeRepositoriesByLotView.as_view(),
        name='list_node_repository_by_lot'),

    url(r'^common_mbs/catalog/build_and_publish/?$', InstanceBuildAndPublishView.as_view(),
        name='build_and_publish_instance'),
    url(r'^common_mbs/catalog/purge/?$', InstancePurgeView.as_view(), name='purge_instance'),
    url(r'^common_mbs/repositories/republish/?$', InstanceRepublishView.as_view(), name='republish_instance'),
    url(r'^common_mbs/repositories/move/?$', InstanceMoveView.as_view(), name='move_instance'),
    url(r'^common_mbs/repositories/remove/?$', InstanceRemoveView.as_view(), name='remove_instance'),

    url(r'^generator/user_defined/?$', GenerateUserDefinedView.as_view(), name='generate_user_defined'),

    url(r'^combined_instance/build/?$', CombinedInstanceBuildView.as_view(), name='combined_instance_build'),
    url(r'^combined_instance/purge/?$', CombinedInstancePurgeView.as_view(), name='combined_instance_purge'),

    url(r'^flow/build_and_publish/?$', FlowBuildAndPublishView.as_view(), name='build_and_publish_flow'),
    url(r'^flow/republish/?$', FlowRepublishView.as_view(), name='republish_flow'),
    url(r'^flow/move/?$', FlowMoveView.as_view(), name='move_flow'),
    url(r'^flow/remove/?$', FlowRemoveView.as_view(), name='remove_flow'),
    url(r'^flow/purge/?$', FlowPurgeView.as_view(), name='purge_flow'),

    # url(r'^test_virtual_instance/?$', GenerateConfigurationView.as_view(), name='test_virtual'),
    url(r'^element_manipulation/?$', ElementManipulationView.as_view(), name='element_manipulation'),

    url(r'^statistic/instance/?$', statistic_views.InstanceStatisticView.as_view(), name='instance_statistic'),
    url(r'^statistic/instance_deployment_resource/?$', statistic_views.InstanceDeploymentResourceView.as_view(),
        name='instance_deployment_resource'),

    url(r'^get_environment_variable/?$', EnvironmentVariable.as_view(), name='purge_flow'),

    # url(r'^custom_instance/execution', CustomInstanceExecutionViewSets.as_view(), name="custom-instance-execution")


]

# Final URL
urlpatterns += router.urls
