import re

from rest_framework import serializers
from rest_framework.fields import JSONField

from apps.configurations.models import SubState, InstanceDeploymentSpecification
from apps.node_repositories.models import NodeRepository
from apps.commons.generator.constants import GeneratingType


class SubStateInstanceSerializer(serializers.ModelSerializer):
    """
    example_response = {
        "sub_state_name": "state2 (channelState 1)",
        "state_name": "learning",
        "statistics": [{
            "generating_type": "pre-defined",
            "count": 100
        }, {
            "generating_type": "user-defined",
            "count": 200
        }]
    }
    """
    sub_state_name = serializers.SerializerMethodField()
    state_name = serializers.SerializerMethodField()
    statistics = serializers.SerializerMethodField()

    class Meta:
        model = SubState
        fields = [
            'sub_state_name',
            'state_name',
            'statistics'
        ]

    def get_sub_state_name(self, obj):
        return obj.name

    def get_state_name(self, obj):
        return obj.state.name

    def get_statistics(self, obj):
        mapping = {}
        for name, item in GeneratingType.__members__.items():
            mapping[item] = {
                "generating_type": re.sub(r'(?<!^)(?=[A-Z])', '-', name).lower(),  # camelCase to kebab-case
                "count": 0
            }
        query_set = NodeRepository.objects.filter(sub_state_id=obj.id)
        for instance in query_set:
            try:
                mapping[GeneratingType(instance.generating_type)]['count'] += 1
            except Exception as e:
                # TODO: implement on generating type no matching constant and database
                pass
        return [result for _, result in mapping.items()]


class NotificationConfig(object):
    def __init__(self, recipients, cc=None, bcc=None):
        if bcc is None:
            bcc = []
        if cc is None:
            cc = []
        self.recipients = recipients
        self.cc = cc
        self.bcc = bcc


class SubStateDeploymentResourceSerializer(serializers.ModelSerializer):
    """
    example_response = [
        {
            "sub_state_name": "state2 (channelState 1)",
            "state_name": "learning",
            "capacity": 240,
            "used": 215,
            "warning_threshold": 30,
            "critical_threshold": 15
        },
        {
            "sub_state_name": "state3 (channelState 2)",
            "state_name": "learning",
            "capacity": 120,
            "used": 119,
            "warning_threshold": 50,
            "critical_threshold": 10
        }
    ]
    """
    sub_state_name = serializers.SerializerMethodField()
    state_name = serializers.SerializerMethodField()
    capacity = serializers.SerializerMethodField()
    warning_threshold = serializers.SerializerMethodField()
    critical_threshold = serializers.SerializerMethodField()
    used = serializers.SerializerMethodField()

    class Meta:
        model = SubState
        fields = [
            'sub_state_name',
            'state_name',
            'capacity',
            'used',
            'warning_threshold',
            'critical_threshold'
        ]

    def get_sub_state_name(self, obj):
        return obj.name

    def get_state_name(self, obj):
        return obj.state.name

    def get_capacity(self, obj):
        total = 0
        try:
            spec = obj.deployment_specification
            if spec:
                for bl in spec.config['load_balances']:
                    for node in bl['nodes']:
                        total += int(node['limit_instance'])
        except Exception as e:
            pass
        return total

    def get_used(self, obj):
        nodes = NodeRepository.objects.filter(sub_state_id=obj.id)
        total = len(nodes)
        return total

    def get_warning_threshold(self, obj):
        result = 0
        try:
            spec = obj.deployment_specification
            result = spec.notification.warning_threshold
        except Exception as e:
            pass
        finally:
            return result

    def get_critical_threshold(self, obj):
        result = 0
        try:
            spec = obj.deployment_specification
            result = spec.notification.critical_threshold
        except Exception as e:
            pass
        finally:
            return result
