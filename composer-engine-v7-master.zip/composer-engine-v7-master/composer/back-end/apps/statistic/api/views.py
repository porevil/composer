from rest_framework.views import APIView

from apps.commons.logger.views import ViewLogger
from apps.configurations.models import SubState
from apps.statistic.api.serializers import SubStateInstanceSerializer, SubStateDeploymentResourceSerializer
from apps.commons.utilities.response import CustomJsonResponse


# GET /api/instance_statistic
class InstanceStatisticView(APIView):
    def get(self, request, **kwargs):
        query_set = SubState.objects.all().order_by('id')
        serializers = SubStateInstanceSerializer(query_set, many=True)
        return CustomJsonResponse(data=serializers.data)


# GET /api/instance_deployment_resource
class InstanceDeploymentResourceView(APIView, ViewLogger):
    def get(self, request, **kwargs):
        query_set = SubState.objects.all().order_by('id')
        serializers = SubStateDeploymentResourceSerializer(query_set, many=True)
        return CustomJsonResponse(data=serializers.data)
