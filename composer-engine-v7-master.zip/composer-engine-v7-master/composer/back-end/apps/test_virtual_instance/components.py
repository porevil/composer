import copy
import json

from apps.commons.generator.constants import Component as ComponentEnum
from apps.commons.generator.configuration.constants import ActivityConstants
from apps.test_virtual_instance.utilities import ActivityUtilities

from apps.generator_setting.models import DatasetConfiguration, VirtualGroup, VirtualDatafieldConfig
from apps.commons.connectors.metadata import Metadata


class ComponentTextbox:
    name = ComponentEnum.TEXTBOX.value

    @staticmethod
    def attributes(**kwargs):
        return {
            'type': kwargs.get('type'),
            'max-character': kwargs.get('max_character'),
            'splitter': kwargs.get('splitter'),
            'currency-symbol': kwargs.get('currency_symbol'),
            'number-of-digit': kwargs.get('number_of_digit'),
            'encrypt-field': kwargs.get('encrypt'),
            'default-value': kwargs.get('default_value'),
            'auto-format-pattern': kwargs.get('text_format')
        }


class ComponentNumber:
    name = ComponentEnum.NUMBER.value

    @staticmethod
    def attributes(**kwargs):
        return {
            'format': kwargs.get('format'),
            'symbol': kwargs.get('symbol'),
            'currency-symbol': kwargs.get('currency_symbol'),
            'unit-type': kwargs.get('unit'),
            'min-number': kwargs.get('min_number'),
            'max-number': kwargs.get('max_number'),
            'default-value': kwargs.get('default_value'),
        }


class ComponentTextarea:
    name = ComponentEnum.TEXT_AREA.value

    @staticmethod
    def attributes(**kwargs):
        return {
            'max-character': kwargs.get('max_character') or 60000,
            'height': kwargs.get('height') or 5
        }


class ComponentRichText:
    name = ComponentEnum.RICH_TEXT.value

    @staticmethod
    def attributes(**kwargs):
        return {
            'max-character': kwargs.get('max_character') or 60000
        }


class ComponentDatePicker:
    name = ComponentEnum.DATEPICKER.value

    @staticmethod
    def attributes(**kwargs):
        return {
            'calendar-language': kwargs.get('calendar_language') if kwargs.get('calendar_language') or False else None,
            'default-value': 'dd/MM/yyyy' if kwargs.get('is_default') or False else None,
            'business-days': kwargs.get('business_days'),
            'format': 'dd/MM/yyyy'
        }


class ComponentTimePicker:
    name = ComponentEnum.TIMEPICKER.value

    @staticmethod
    def attributes(**kwargs):
        return {
            'default-value': kwargs.get('default_value'),
            'format': 'HH:mm'
        }


class ComponentDatetimePicker:
    name = ComponentEnum.DATETIMEPICKER.value

    @staticmethod
    def attributes(**kwargs):
        return {
            'calendar-language': kwargs.get('calendar_language') if kwargs.get('calendar_language') or False else None,
            'default-value': 'dd/MM/yyyy' if kwargs.get('is_default') or False else None,
            'business-days': kwargs.get('business_days'),
            'default-time': kwargs.get('default_time'),
            'format': 'dd/MM/yyyy HH:mm'
        }


class ComponentDateBetween:
    name = ComponentEnum.DATE_BETWEEN.value

    @staticmethod
    def attributes():
        return {
            'show-picker': 'true',
            'show-bc': 'true'
        }


class ComponentToggle:
    name = ComponentEnum.TOGGLE.value

    @staticmethod
    def attributes(**kwargs):
        return {
            'format': kwargs.get('label_format') or 'ใช่,ไม่ใช่,ไม่ระบุ',
            'default-value': kwargs.get('default_value'),
            'description': ''
        }


class ComponentAutogenUCID:
    name = ComponentEnum.AUTO_GENERATE_UCID.value

    @staticmethod
    def attributes(key):
        return {
            'appearance': 'hidden',
            'value': 'biz',
            'key': key,
        }


class ComponentRadioButtom:
    name = ComponentEnum.RADIO_BUTTON.value

    @staticmethod
    def attributes(**kwargs):
        return {
            'format': kwargs.get('label_format') or 'ใช่,ไม่ใช่,ไม่ระบุ',
            'display-unassigned': 'true' if kwargs.get('display_unassigned') or True else 'false',
            'default-value': kwargs.get('default_value'),
            'description': ''
        }


class ComponentRadioGroup:
    name = ComponentEnum.RADIO_GROUP.value

    @staticmethod
    def attributes(options, **kwargs):
        return {
            'show-other': kwargs.get('show_other'),
            'other-model': kwargs.get('other_field_name'),
            'show-check-all': 'true',
            'item-bind': options
        }


class ComponentCheckboxGroup:
    name = ComponentEnum.CHECKBOX_GROUP.value

    @staticmethod
    def attributes(options, **kwargs):
        return {
            'number-of-selected': kwargs.get('number_of_selected'),
            'show-other': kwargs.get('show_other'),
            'othr-model': kwargs.get('other_field_name'),
            'item-bind': options
        }


class ComponentRanking:
    name = ComponentEnum.RANKING.value

    @staticmethod
    def attributes(options, **kwargs):
        return {
            'number-of-selected': kwargs.get('number_of_selected'),
            'item-bind': options
        }


class ComponentRating:
    name = ComponentEnum.RATING.value

    @staticmethod
    def attributes(**kwargs):
        return {
            'number-of-selected': kwargs.get('number_of_selected'),
            'min-indicator-text': kwargs.get('min_indicator_text'),
            'max-indicator-text': kwargs.get('max_indicator_text')
        }


class ComponentCameraUpload:
    name = ComponentEnum.CAMERA_UPLOAD.value

    @staticmethod
    def attributes(dataset_name, **kwargs):
        return {
            'dataset-name': dataset_name,
            'multiple-file': 'true' if kwargs.get('multiple') or False else 'false'
        }


class ComponentFileUpload:
    name = ComponentEnum.FILE_UPLOAD.value

    @staticmethod
    def attributes(dataset_name, **kwargs):
        return {
            'dataset-name': dataset_name,
            'multiple-file': 'true' if kwargs.get('multiple') or False else 'false'
        }


class ComponentMap:
    name = ComponentEnum.MAP.value

    @staticmethod
    def attributes():
        return {}


class ComponentSignature:
    name = ComponentEnum.SIGNATURE.value

    @staticmethod
    def attributes():
        return {}


class ComponentPreformattedText:
    name = ComponentEnum.PREFORMATTED_TEXT.value

    @staticmethod
    def attributes(**kwargs):
        return {
            'is-indent': kwargs.get('indent'),
            'default-value': kwargs.get('default_value')
        }


class ComponentDropdown:
    name = ComponentEnum.DROPDOWN.value

    @staticmethod
    def attributes(**kwargs):
        attributes = {
            'dataset-name': kwargs.get('dataset_name'),
            'dataset-working': 'true' if kwargs.get('dataset_working') or True else 'false',
            'parameter-code': kwargs.get('condition'),
            'delimiter': kwargs.get('delimiter'),
            'value-field': '{}:{}'.format(kwargs.get('value_field_name'), kwargs.get('value_field_type')) if kwargs.get(
                'value_field_type') else kwargs.get('value_field_name'),
            'group-key-fields': json.dumps(kwargs.get('group_key_fields'), ensure_ascii=False) if kwargs.get(
                'group_key_fields') else dict(),
            'use-cache': 'true' if kwargs.get('use_cache') or False else 'false',
            'default-value': kwargs.get('default_value'),
            'journal': 'true',
            'dataset-working': 'false',
            'is-lazy-load': 'true',
            'max-record-lazy-load-display': 30,
            'delimiter': ' : ',
        }

        display_fields = kwargs.get('display_fields')
        if display_fields:
            display_field = ''
            for idx, field in enumerate(display_fields, 1):
                if idx > 1:
                    display_field = display_field + ','
                display_field = display_field + '{}:{}'.format(field['name'], field['type'])
            attributes['display-field'] = display_field

        parent_field_name = kwargs.get('parent_field_name')
        parent_field_type = kwargs.get('parent_field_type')
        filter_field_name = kwargs.get('filter_field_name')
        activity_name = kwargs.get('activity_name')
        if parent_field_name:
            filter_field = filter_field_name if filter_field_name else parent_field_name
            parent_model = parent_field_name
            if parent_field_type:
                filter_field = '{}:{}'.format(filter_field, parent_field_type)
            if activity_name:
                parent_model = '{}.{}'.format(activity_name, parent_field_name)
            attributes['parent-field'] = filter_field
            attributes['parent-model'] = parent_model
  
        return attributes

    
    @staticmethod
    def attributes_by_parameter_reference(field_name, parameter_reference, **kwargs):
        show_reference_code = kwargs.get('show_reference_code', True)
        parent_field_name = kwargs.get('parent_field_name')
        parent_field_type = kwargs.get('parent_field_type')
        filter_field_name = kwargs.get('filter_field_name')
        activity_name = kwargs.get('activity_name')
        condition = kwargs.get('condition')
        delimiter = kwargs.get('delimiter')
        use_cache = kwargs.get('use_cache') or False
        default_value = kwargs.get('default_value')
        virtual_name = kwargs.get('virtual_name')
        field_id = kwargs.get('field_id')
        
        ref_conditions = parameter_reference.get('condition') or list() 
        ref_metadata = parameter_reference.get('dataset') or dict()
        dataset_name = ref_metadata.get('dataset_name')
        dataset_working = (ref_metadata.get('group_type') == 'WORKING')

        value_field_name = None
        for ref_condition in ref_conditions:
            if ref_condition.get('default_val') == '${{{}}}'.format(field_name):
                value_field_name = ref_condition.get('name')
                break

        if virtual_name is not None:
            dataset_setting = VirtualGroup.objects.filter(name=virtual_name).first()
        else:
            dataset_setting = DatasetConfiguration.objects.filter(dataset_id__dataset_name=dataset_name).first()

        if dataset_setting is not None:
            dataset_additional_condition = dataset_setting.config.get('additional_condition')
            if dataset_additional_condition:
                condition = '{} and {}'.format(condition, dataset_additional_condition) if condition else dataset_additional_condition

        value_field_type = None
        display_fields = list()

        # first level
        main_dataset_name = dataset_setting.main_dataset_name

        datafields = ActivityUtilities.get_flat_datafields_by_dataset_metadata(virtual_name, main_dataset_name, field_id)

        group_key_fields = list(map(lambda f: f['name'], filter(lambda f: f.get('group_of_record'), datafields)))
        display_datafields = list(filter(lambda f: (f.get('pre_setting') or dict()).get('business_reference') or False, datafields))
        display_datafields = sorted(display_datafields, key=lambda f: (f.get('pre_setting') or dict()).get('sequence') or 999)

        for datafield in display_datafields:
            field_id = datafield.get('field_id')
            field_name = datafield.get('name')
            field_type = datafield.get('type')
            reference_name = datafield.get('reference_name')
            parameter_type = datafield.get('parameter_type')
        
            if parameter_type == ActivityConstants.PARAMETER_TYPE_MASTER:
                continue

            if field_name == value_field_name:
                value_field_type = field_type
                if not show_reference_code:
                    continue
            
            if field_type == 'datetime':
                field_type = 'date'

            inner_parameter_reference = datafield.get('parameter_ref') or dict()
            inner_parameter_ref_metadata = inner_parameter_reference.get('dataset')

            if parameter_type == ActivityConstants.PARAMETER_TYPE_PUBLIC and inner_parameter_ref_metadata is not None:
                inner_ref_conditions = inner_parameter_reference.get('condition') or list() 
                inner_parameter_code_field_name = None
                for ref_condition in inner_ref_conditions:
                    if ref_condition.get('default_val') == '${{{}}}'.format(field_name):
                        inner_parameter_code_field_name = ref_condition.get('name')
                        break

                inner_datafields = ActivityUtilities.get_flat_datafields_by_dataset_metadata(virtual_name, main_dataset_name, field_id)                
                inner_show_datafields = list(filter(lambda f: (f.get('pre_setting') or dict()).get('business_reference') or False, inner_datafields))
                inner_show_datafields = sorted(inner_show_datafields, key=lambda f: (f.get('pre_setting') or dict()).get('sequence') or 999)
                for inner_datafield in inner_show_datafields:
                    inner_field_name = inner_datafield.get('name')
                    inner_field_type = inner_datafield.get('type')
                    inner_reference_name = inner_datafield.get('reference_name')
                    if inner_field_name == inner_parameter_code_field_name:
                        continue
                    if inner_field_type == 'datetime':
                        inner_field_type = 'date'
                    if inner_reference_name is not None:
                        inner_field_name = '{}.{}'.format(inner_reference_name, inner_field_name)
                    display_fields.append({
                        'name': '{}.{}'.format(field_name, inner_field_name),
                        'type': inner_field_type,
                    })
            else:
                if reference_name is not None:
                    field_name = '{}.{}'.format(reference_name, field_name)
                display_fields.append({
                    'name': field_name,
                    'type': field_type,
                })
        
        return ComponentDropdown.attributes(dataset_name=dataset_name
                                            , dataset_working=dataset_working
                                            , value_field_name=value_field_name
                                            , value_field_type=value_field_type
                                            , display_fields=display_fields
                                            , group_key_fields=group_key_fields
                                            , parent_field_name=parent_field_name
                                            , parent_field_type=parent_field_type
                                            , filter_field_name=filter_field_name
                                            , activity_name=activity_name
                                            , condition=condition
                                            , delimiter=delimiter
                                            , use_cache=use_cache
                                            , default_value=default_value)


class ComponentDropdownLazyLoad:
    name = ComponentEnum.DROPDOWN_LAZY_LOAD.value

    @staticmethod
    def attributes(**kwargs):
        # 'dropdown lazy-load' widget has the same logic as 'dropdown' widget
        return ComponentDropdown.attributes(**kwargs)


    @staticmethod
    def attributes_by_parameter_reference(field_name, parameter_reference, **kwargs):
        # 'dropdown lazy-load' widget has the same logic as 'dropdown' widget
        return ComponentDropdown.attributes_by_parameter_reference(field_name, parameter_reference, **kwargs)


class ComponentDropdownMultipleValue:
    name = ComponentEnum.DROPDOWN_MULTIPLE_VALUE.value

    @staticmethod
    def attributes(**kwargs):
        # 'dropdown multi-select' widget has the same logic as 'dropdown' widget
        return ComponentDropdown.attributes(**kwargs)


    @staticmethod
    def attributes_by_parameter_reference(field_name, parameter_reference, **kwargs):
        # 'dropdown multi-select' widget has the same logic as 'dropdown' widget
        return ComponentDropdown.attributes_by_parameter_reference(field_name, parameter_reference, **kwargs)


class ComponentCreatableSearchAnyField:
    name = ComponentEnum.CREATABLE_SEARCH_ANY_FIELD.value

    @staticmethod
    def attributes(**kwargs):
        attributes = {
            'description': kwargs.get('description'),
            'dataset-name': kwargs.get('dataset_name'),
            'dataset-working': kwargs.get('dataset_working') or False,
            'value-field': '{}:{}'.format(kwargs.get('value_field_name'), kwargs.get('value_field_type')) if kwargs.get(
                'value_field_type') is not None else kwargs.get('value_field_name'),
            'search-condition': kwargs.get('condition'),
            'group-key-fields': json.dumps(kwargs.get('group_key_fields'), ensure_ascii=False) if kwargs.get(
                'group_key_fields') else dict(),
            'auto-search': 'true' if kwargs.get('auto_search') or False else 'false',
            'journal': 'true'
        }

        create_fields = kwargs.get('create_fields')
        if create_fields:
            attribute_create_fields = list()
            for field in create_fields:
                attribute_create_field = {
                    'datasetField': field['name'],
                    'data_type': field['type'],
                    'label': field['label'],
                }
                if field.get('required'):
                    attribute_create_field['required'] = True
                if field.get('input_type'):
                    attribute_create_field['input_type'] = field.get('input_type')
                if field.get('config'):
                    attribute_create_field['config'] = field.get('config')
                if field.get('business_key'):
                    attribute_create_field['business_key'] = field.get('business_key')
                attribute_create_fields.append(attribute_create_field)
            attributes['create-field'] = json.dumps(attribute_create_fields, ensure_ascii=False)

        search_fields = kwargs.get('search_fields')
        if search_fields:
            attribute_search_fields = list()
            for field in search_fields:
                attribute_search_field = {
                    'datasetField': field['name'],
                    'data_type': field['type'],
                    'label': field['label'],
                    'encrypt_field': field['encrypt'],
                }
                if field.get('search_type'):
                    attribute_search_field['search_type'] = field.get('search_type')
                if field.get('search_config'):
                    attribute_search_field['search_config'] = field.get('search_config')
                attribute_search_fields.append(attribute_search_field)
            attributes['search-field'] = json.dumps(attribute_search_fields, ensure_ascii=False)

        result_fields = kwargs.get('result_fields')
        if result_fields:
            attribute_result_fields = list()
            for field in result_fields:
                attribute_result_field = {
                    'datasetField': field['display_field'],
                    'label': field['label'],
                }
                if 'format' in field:
                    attribute_result_field['format'] = field['format']
                attribute_result_fields.append(attribute_result_field)
            attributes['search-result-field'] = json.dumps(attribute_result_fields, ensure_ascii=False)

        display_fields = kwargs.get('display_fields')
        if display_fields:
            attribute_display_fields = list()
            for field in display_fields:
                attribute_display_field = {
                    'datasetField': field['display_field'],
                    'label': field['label'],
                }
                if 'format' in field:
                    attribute_display_field['format'] = field['format']
                attribute_display_fields.append(attribute_display_field)
            attributes['result-field'] = json.dumps(attribute_display_fields, ensure_ascii=False)

        embed_field = kwargs.get('embed_field') or list()
        if embed_field:
            attributes['embed-field'] = embed_field

        parent_field_name = kwargs.get('parent_field_name')
        parent_field_type = kwargs.get('parent_field_type')
        filter_field_name = kwargs.get('filter_field_name')
        activity_name = kwargs.get('activity_name')

        if parent_field_name:
            filter_field = filter_field_name if filter_field_name else parent_field_name
            parent_model = parent_field_name
            if parent_field_type:
                filter_field = '{}:{}'.format(filter_field, parent_field_type)
            if activity_name:
                parent_model = '{}.{}'.format(activity_name, parent_field_name)
            attributes['parent-field'] = filter_field
            attributes['parent-model'] = parent_model

        return attributes


    @staticmethod
    def attributes_by_ref_metadata(value_field_name, value_field_type, ref_metadata, **kwargs):
        condition = kwargs.get('condition')
        parent_field_name = kwargs.get('parent_field_name')
        parent_field_type = kwargs.get('parent_field_type')
        filter_field_name = kwargs.get('filter_field_name')
        activity_name = kwargs.get('activity_name')
        auto_search = kwargs.get('auto_search')
        creatable = kwargs.get('creatable') or True
        virtual_name = kwargs.get('virtual_name')

        dataset_name = ref_metadata.get('dataset_name')
        dataset_working = (ref_metadata.get('group_type') == 'WORKING')

        virtual_group = VirtualGroup.objects.filter(name=virtual_name).first()
        main_dataset_name = virtual_group.main_dataset_name

        field_id = kwargs.get('field_id')
        datafields = ActivityUtilities.get_flat_datafields_by_dataset_metadata(virtual_name, main_dataset_name, field_id)
        group_key_fields = list(map(lambda f: f['name'], filter(lambda f: f.get('group_of_record'), datafields)))

        create_fields = None

        search_datafields = list(filter(lambda f: (f.get('pre_setting') or dict()).get('search_field') or False, datafields))
        search_datafields = sorted(search_datafields, key=lambda f: (f.get('pre_setting') or dict()).get('sequence') or 999)
        search_fields = list()

        for datafield in search_datafields:
            field_id = datafield.get('field_id')
            field_name = datafield.get('name')
            field_type = datafield.get('type')
            field_label = (datafield.get('pre_setting') or dict()).get('label') or datafield.get('label_th')
            encrypt = datafield.get('encrypt') or False
            reference_name = datafield.get('reference_name')
            parameter_type = datafield.get('parameter_type')
            parameter_reference = datafield.get('parameter_ref')

            if reference_name is not None:
                field_name = '{}.{}'.format(reference_name, field_name)

            search_field = {
                'name': field_name,
                'type': field_type,
                'label': field_label,
                'encrypt': encrypt,
            }

            if field_type == 'datetime':
                search_field['search_type'] = 'date'
            elif parameter_type == ActivityConstants.PARAMETER_TYPE_PUBLIC and parameter_reference is not None:
                parameter_ref_conditions = parameter_reference.get('condition') or list() 
                parameter_ref_metadata = parameter_reference.get('dataset') or dict()
                parameter_dataset = parameter_ref_metadata.get('dataset_name')
                parameter_dataset_working = (parameter_ref_metadata.get('group_type') == 'WORKING') or False
                parameter_datafields = ActivityUtilities.get_flat_datafields_by_dataset_metadata(virtual_name, main_dataset_name, field_id)
                
                parameter_value_field_name = None
                parameter_value_field_type = field_type
                for parameter_ref_condition in parameter_ref_conditions:
                    if parameter_ref_condition.get('default_val') == '${{{}}}'.format(field_name.split('.')[-1]):
                        parameter_value_field_name = parameter_ref_condition.get('name')
                        break
                parameter_value_field = '{}:{}'.format(parameter_value_field_name, parameter_value_field_type)

                show_parameter_datafields = list(filter(lambda f: (f.get('pre_setting') or dict()).get('business_reference') or False, parameter_datafields))
                show_parameter_datafields = sorted(show_parameter_datafields, key=lambda f: (f.get('pre_setting') or dict()).get('sequence') or 999)

                display_field = ''
                for idx, show_parameter_datafield in enumerate(show_parameter_datafields):
                    if idx > 0:
                        display_field = '{},'.format(display_field)
                    display_field = '{}{}:{}'.format(display_field, show_parameter_datafield.get('name'), show_parameter_datafield.get('type')) 

                dataset_setting = DatasetConfiguration.objects.filter(dataset_id__dataset_name=parameter_dataset).first()
                parameter_condition = '{} = {}'.format(ActivityConstants.TECHNICAL_FIELD_RECORD_STATUS, ActivityConstants.RECORD_STATUS_ACTIVE)
                if dataset_setting is not None:
                    dataset_additional_condition = dataset_setting.config.get('additional_condition')
                    if dataset_additional_condition:
                        parameter_condition = '{} and {}'.format(parameter_condition, dataset_additional_condition)

                search_field['search_type'] = 'dropdown'
                search_field['search_config'] = {
                    'dataset': parameter_dataset,
                    'value_field': parameter_value_field,
                    'description_field': display_field,
                    'parameter_code': parameter_condition,
                    'dataset_working': 'true' if parameter_dataset_working else 'false',
                    'journal': 'true',
                    'lazy_load': 'true',
                    'max_record_display': 100,
                    'placeholder': 'โปรดระบุ',
                    'use_cache': 'true',
                }
            elif parameter_type == ActivityConstants.PARAMETER_TYPE_MASTER and parameter_reference is not None:
                parameter_ref_conditions = parameter_reference.get('condition') or list() 
                parameter_ref_metadata = parameter_reference.get('dataset') or dict()
                parameter_dataset = parameter_ref_metadata.get('dataset_name')
                parameter_ref_fields = parameter_ref_metadata.get('fields') or list()

                metadata = Metadata.get(None, parameter_dataset)

                parameter_datafields = ActivityUtilities.get_flat_datafields_by_dataset_metadata(virtual_name, main_dataset_name, field_id)
                
                search_field_configuration = list(filter(lambda f: \
                    (f.get('pre_setting') or dict()).get('search_field') or False \
                        and f.get('parameter_type') != ActivityConstants.PARAMETER_TYPE_MASTER \
                            , parameter_datafields))
                search_field_configuration = sorted(search_field_configuration, key=lambda f: (f.get('pre_setting') or dict()).get('sequence') or 999)
                search_field_configuration = ComponentCreatableSearchAnyField().__get_search_fields(search_field_configuration, metadata, **{
                    'virtual_name': virtual_name,
                    'main_dataset_name': main_dataset_name,
                })

                search_result_field_configuration = list(filter(lambda f: \
                    (f.get('pre_setting') or dict()).get('result_field') or False \
                        and f.get('parameter_type') != ActivityConstants.PARAMETER_TYPE_MASTER \
                            , parameter_datafields))
                search_result_field_configuration = sorted(search_result_field_configuration, key=lambda f: (f.get('pre_setting') or dict()).get('sequence') or 999)
                search_result_field_configuration = ComponentCreatableSearchAnyField().__get_search_result_fields(search_result_field_configuration, **{
                    'virtual_name': virtual_name,
                    'main_dataset_name': main_dataset_name,
                })

                result_field_configuration = list(filter(lambda f: \
                    (f.get('pre_setting') or dict()).get('business_reference') or False \
                        and f.get('parameter_type') != ActivityConstants.PARAMETER_TYPE_MASTER \
                            , parameter_datafields))
                result_field_configuration = sorted(result_field_configuration, key=lambda f: (f.get('pre_setting') or dict()).get('sequence') or 999)
                result_field_configuration = ComponentCreatableSearchAnyField().__get_result_fields(result_field_configuration, **{
                    'virtual_name': virtual_name,
                    'main_dataset_name': main_dataset_name,
                })

                embed_fields_configuration = list(filter(lambda f: \
                    ((f.get('parameter_ref') \
                        and f.get('parameter_type') in [ActivityConstants.PARAMETER_TYPE_MASTER, ActivityConstants.PARAMETER_TYPE_PUBLIC] \
                            and f.get('multiple_value') == False) or dict()) or False \
                                , parameter_datafields))
                embed_fields_configuration = list(map(lambda f: ('{}.{}'.format(f.get('reference_name'), f.get('name')) if f.get('reference_name') is not None else f.get('name')), embed_fields_configuration))

                parameter_value_field_name = None
                parameter_value_field_type = field_type
                for parameter_ref_condition in parameter_ref_conditions:
                    if parameter_ref_condition.get('default_val') == '${{{}}}'.format(field_name.split('.')[-1]):
                        parameter_value_field_name = parameter_ref_condition.get('name')
                        break
                parameter_value_field = '{}:{}'.format(parameter_value_field_name, parameter_value_field_type)

                dataset_setting = DatasetConfiguration.objects.filter(dataset_id__dataset_name=parameter_dataset).first()
                parameter_condition = '{} = {}'.format(ActivityConstants.TECHNICAL_FIELD_RECORD_STATUS, ActivityConstants.RECORD_STATUS_ACTIVE)
                if dataset_setting is not None:
                    dataset_additional_condition = dataset_setting.config.get('additional_condition')
                    if dataset_additional_condition:
                        parameter_condition = '{} and {}'.format(parameter_condition, dataset_additional_condition)

                search_field['search_type'] = 'reference'
                search_field['search_config'] = {
                    'dataset_name': parameter_dataset,
                    'search_field': search_field_configuration,
                    'embed_field': embed_fields_configuration,
                    'search_result_field': search_result_field_configuration,
                    'result_field': result_field_configuration,
                    'search_condition': parameter_condition,
                    'value_field': parameter_value_field
                }

            search_fields.append(search_field)

        result_datafields = list(filter(lambda f: (f.get('pre_setting') or dict()).get('result_field') or False, datafields))
        result_datafields = sorted(result_datafields,
                                   key=lambda f: (f.get('pre_setting') or dict()).get('sequence') or 999)
        
        result_fields, result_embed_field = ComponentCreatableSearchAnyField().__get_attribute_fields(result_datafields, **{
            'virtual_name': virtual_name,
            'main_dataset_name': main_dataset_name,
        })

        display_datafields = list(
            filter(lambda f: (f.get('pre_setting') or dict()).get('business_reference') or False, datafields))
        display_datafields = sorted(display_datafields,
                                    key=lambda f: (f.get('pre_setting') or dict()).get('sequence') or 999)
       
        display_fields, display_embed_field = ComponentCreatableSearchAnyField().__get_attribute_fields(display_datafields, **{
            'virtual_name': virtual_name,
            'main_dataset_name': main_dataset_name,
        })

        dataset_setting = DatasetConfiguration.objects.filter(dataset_id__dataset_name=dataset_name).first()
        if dataset_setting is not None:
            dataset_additional_condition = dataset_setting.config.get('additional_condition')
            if dataset_additional_condition:
                condition = '{} and {}'.format(condition,
                                               dataset_additional_condition) if condition else dataset_additional_condition

        result_embed_field_set = set(result_embed_field)
        display_embed_field_set = set(display_embed_field)
        result_embed_field_set.update(display_embed_field_set)
        embed_field = list(result_embed_field_set)
        embed_field = ','.join(embed_field)

        return ComponentCreatableSearchAnyField.attributes(dataset_name=dataset_name
                                                           , dataset_working=dataset_working
                                                           , value_field_name=value_field_name
                                                           , value_field_type=value_field_type
                                                           , create_fields=create_fields
                                                           , search_fields=search_fields
                                                           , result_fields=result_fields
                                                           , display_fields=display_fields
                                                           , group_key_fields=group_key_fields
                                                           , condition=condition
                                                           , parent_field_name=parent_field_name
                                                           , parent_field_type=parent_field_type
                                                           , filter_field_name=filter_field_name
                                                           , activity_name=activity_name
                                                           , auto_search=auto_search
                                                           , embed_field=embed_field)

    
    @staticmethod
    def attributes_by_parameter_reference(field_name, parameter_reference, **kwargs):
        ref_conditions = parameter_reference.get('condition') or list() 
        ref_metadata = parameter_reference.get('dataset') or dict()
        datafields = ref_metadata.get('fields') or list()

        value_field_name = None
        value_field_type = None
        for condition in ref_conditions:
            if condition.get('default_val') == '${{{}}}'.format(field_name):
                value_field_name = condition.get('name')
                break

        for datafield in datafields:
            field_name = datafield.get('name')
            field_type = datafield.get('type')
            if field_name == value_field_name:
                value_field_type = field_type
                break
        return ComponentCreatableSearchAnyField.attributes_by_ref_metadata(value_field_name, value_field_type, ref_metadata, **kwargs)


    @staticmethod
    def __get_search_fields(attr_datafields, metadata, **kwargs):
        virtual_name = kwargs.get('virtual_name')
        main_dataset_name = kwargs.get('main_dataset_name')

        attribute_search_fields = list()
        for field in attr_datafields:
            field_id = field.get('field_id')
            field_type = field.get('type')
            field_name = field.get('name')
            field_parameter_type = field.get('parameter_type')
            field_parameter_reference = field.get('parameter_ref')

            if field_parameter_type == ActivityConstants.PARAMETER_TYPE_MASTER:
                continue

            attribute_search_field = {
                'datasetField': field['name'],
                'data_type': field['type'],
                'label': field.get('pre_setting', dict()).get('label') or field['label_th'],
                'encrypt_field': field['encrypt'],
            }

            if field_type == 'datetime':
                attribute_search_field['search_type'] = 'date'

            elif field_parameter_type == ActivityConstants.PARAMETER_TYPE_PUBLIC and field_parameter_reference is not None:
                parameter_ref_conditions = field_parameter_reference.get('condition') or list() 
            
                parameter_value_field_name = None
                parameter_value_field_type = field_type
                for parameter_ref_condition in parameter_ref_conditions:
                    if parameter_ref_condition.get('default_val') == '${{{}}}'.format(field_name.split('.')[-1]):
                        parameter_value_field_name = parameter_ref_condition.get('name')
                        break
                parameter_value_field = '{}:{}'.format(parameter_value_field_name, parameter_value_field_type)

                parameter_dataset_ref_id = field_parameter_reference.get('dataset_ref_id')
                if parameter_dataset_ref_id is not None:
                    parameter_ref_metadata = ComponentCreatableSearchAnyField().__get_parameter_ref_from_id(metadata, parameter_dataset_ref_id)

                    if parameter_ref_metadata is None:
                        continue
                else:
                    parameter_ref_metadata = field_parameter_reference.get('dataset') or dict()

                parameter_dataset = parameter_ref_metadata.get('dataset_name')
                parameter_dataset_working = (parameter_ref_metadata.get('group_type') == 'WORKING')
                parameter_datafields = ActivityUtilities.get_flat_datafields_by_dataset_metadata(virtual_name, main_dataset_name, field_id)

                show_parameter_datafields = list(filter(lambda f: (f.get('pre_setting') or dict()).get('business_reference') or False, parameter_datafields))
                show_parameter_datafields = sorted(show_parameter_datafields, key=lambda f: (f.get('pre_setting') or dict()).get('sequence') or 999)

                display_field = ''
                for idx, show_parameter_datafield in enumerate(show_parameter_datafields):
                    if idx > 0:
                        display_field = '{},'.format(display_field)
                    display_field = '{}{}:{}'.format(display_field, show_parameter_datafield.get('name'), show_parameter_datafield.get('type')) 

                dataset_setting = VirtualGroup.objects.filter(main_dataset_name=main_dataset_name).first()
                parameter_condition = '{} = {}'.format(ActivityConstants.TECHNICAL_FIELD_RECORD_STATUS, ActivityConstants.RECORD_STATUS_ACTIVE)
                if dataset_setting is not None:
                    dataset_additional_condition = dataset_setting.config.get('additional_condition')
                    if dataset_additional_condition:
                        parameter_condition = '{} and {}'.format(parameter_condition, dataset_additional_condition)

                        
                attribute_search_field['search_type'] = 'dropdown'
                attribute_search_field['search_config'] = {
                    'dataset': parameter_dataset,
                    'value_field': parameter_value_field,
                    'description_field': display_field,
                    'parameter_code': parameter_condition,
                    'dataset_working': 'true' if parameter_dataset_working else 'false',
                    'journal': 'true',
                    'lazy_load': 'true',
                    'max_record_display': 100,
                    'placeholder': 'โปรดระบุ',
                    'use_cache': 'true',
                }

            attribute_search_fields.append(attribute_search_field)
        return json.dumps(attribute_search_fields, ensure_ascii=False)


    @staticmethod
    def __get_parameter_ref_from_id(metadata, ref_id):
        datafields = metadata.get('fields')
        for datafield in datafields:
            parameter_ref = datafield.get('parameter_ref')
            if parameter_ref is not None:
                dataset = parameter_ref.get('dataset')
                if dataset is not None:
                    if dataset.get('_id') == ref_id:
                        return dataset
                    else:
                        result = ComponentCreatableSearchAnyField().__get_parameter_ref_from_id(dataset, ref_id)
                        if result is not None:
                            return result
        return None


    @staticmethod
    def __get_result_fields(attr_datafields, **kwargs):
        virtual_name = kwargs.get('virtual_name')
        main_dataset_name = kwargs.get('main_dataset_name')

        return_fields = list()
        for datafield in attr_datafields:
            field_id = datafield.get('field_id')
            field_name = datafield.get('name')
            field_type = datafield.get('type')
            field_label = (datafield.get('pre_setting') or dict()).get('label') or datafield.get('label_th')
            reference_name = datafield.get('reference_name')
            parameter_type = datafield.get('parameter_type')
            parameter_reference = datafield.get('parameter_ref')

            if parameter_type == ActivityConstants.PARAMETER_TYPE_MASTER:
                continue

            if reference_name is not None:
                field_name = '{}.{}'.format(reference_name, field_name)

            if field_type == 'datetime':
                field_type = 'date'

            display = ''
            if parameter_type == ActivityConstants.PARAMETER_TYPE_PUBLIC and parameter_reference is not None:
                parameter_ref_conditions = parameter_reference.get('condition') or list() 
                parameter_ref_metadata = parameter_reference.get('dataset') or dict()
                parameter_value_field_name = None
                parameter_value_field_type = field_type
                for parameter_ref_condition in parameter_ref_conditions:
                    if parameter_ref_condition.get('default_val') == '${{{}}}'.format(field_name.split('.')[-1]):
                        parameter_value_field_name = parameter_ref_condition.get('name')
                        break

                displays = list()

                parameter_datafields = ActivityUtilities.get_flat_datafields_by_dataset_metadata(virtual_name, main_dataset_name, field_id)

                show_parameter_datafields = list(filter(lambda f: ((f.get('pre_setting') or dict()).get('result_field') or False) \
                                                                    and f.get('name') != parameter_value_field_name \
                                                            , parameter_datafields))
                show_parameter_datafields = sorted(show_parameter_datafields, key=lambda f: (f.get('pre_setting') or dict()).get('sequence') or 999)
                for parameter_datafield in show_parameter_datafields:
                    parameter_field_name = parameter_datafield.get('name')
                    parameter_field_type = parameter_datafield.get('type')
                    if parameter_field_type == 'datetime':
                        parameter_field_type = 'date'
                    displays.append('{}.{}:{}'.format(field_name, parameter_field_name, parameter_field_type))
                    display = ','.join(displays)
            else:
                display = '{}:{}'.format(field_name, field_type)

            return_field = {
                'datasetField': display,
                'label': field_label,
            }

            number_format = (datafield.get('pre_setting') or dict()).get('number_format')
            if field_type in ('integer', 'decimal') and number_format:
                return_field['format'] = number_format

            return_fields.append(return_field)
        
        return json.dumps(return_fields, ensure_ascii=False)


    @staticmethod
    def __get_search_result_fields(attr_datafields, **kwargs):
        virtual_name = kwargs.get('virtual_name')
        main_dataset_name = kwargs.get('main_dataset_name')

        return_fields = list()
        for datafield in attr_datafields:
            field_id = datafield.get('field_id')
            field_name = datafield.get('name')
            field_type = datafield.get('type')
            field_label = (datafield.get('pre_setting') or dict()).get('label') or datafield.get('label_th')
            reference_name = datafield.get('reference_name')
            parameter_type = datafield.get('parameter_type')
            parameter_reference = datafield.get('parameter_ref')

            if parameter_type == ActivityConstants.PARAMETER_TYPE_MASTER:
                continue

            if reference_name is not None:
                field_name = '{}.{}'.format(reference_name, field_name)

            if field_type == 'datetime':
                field_type = 'date'

            display = ''
            if parameter_type == ActivityConstants.PARAMETER_TYPE_PUBLIC and parameter_reference is not None:
                parameter_ref_conditions = parameter_reference.get('condition') or list() 
                parameter_ref_metadata = parameter_reference.get('dataset') or dict()
                parameter_value_field_name = None
                parameter_value_field_type = field_type
                for parameter_ref_condition in parameter_ref_conditions:
                    if parameter_ref_condition.get('default_val') == '${{{}}}'.format(field_name.split('.')[-1]):
                        parameter_value_field_name = parameter_ref_condition.get('name')
                        break

                displays = list()
                parameter_datafields = ActivityUtilities.get_flat_datafields_by_dataset_metadata(virtual_name, main_dataset_name, field_id)
                show_parameter_datafields = list(filter(lambda f: ((f.get('pre_setting') or dict()).get('business_reference') or False) \
                                                                    and f.get('name') != parameter_value_field_name \
                                                            , parameter_datafields))
                show_parameter_datafields = sorted(show_parameter_datafields, key=lambda f: (f.get('pre_setting') or dict()).get('sequence') or 999)
                for parameter_datafield in show_parameter_datafields:
                    parameter_field_name = parameter_datafield.get('name')
                    parameter_field_type = parameter_datafield.get('type')
                    if parameter_field_type == 'datetime':
                        parameter_field_type = 'date'
                    displays.append('{}.{}:{}'.format(field_name, parameter_field_name, parameter_field_type))
                    display = ','.join(displays)
            else:
                display = '{}:{}'.format(field_name, field_type)

            return_field = {
                'datasetField': display,
                'label': field_label,
            }

            number_format = (datafield.get('pre_setting') or dict()).get('number_format')
            if field_type in ('integer', 'decimal') and number_format:
                return_field['format'] = number_format

            return_fields.append(return_field)
        
        return json.dumps(return_fields, ensure_ascii=False)


    @staticmethod
    def __get_attribute_fields(attr_datafields, **kwargs):
        virtual_name = kwargs.get('virtual_name')
        main_dataset_name = kwargs.get('main_dataset_name')

        return_fields = list()
        embed_field = list()

        for datafield in attr_datafields:
            field_id = datafield.get('field_id')
            field_name = datafield.get('name')
            field_type = datafield.get('type')
            field_label = (datafield.get('pre_setting') or dict()).get('label') or datafield.get('label_th')
            reference_name = datafield.get('reference_name')
            parameter_type = datafield.get('parameter_type')
            parameter_reference = datafield.get('parameter_ref')

            # if parameter_type == ActivityConstants.PARAMETER_TYPE_MASTER:
            #     continue

            if reference_name is not None:
                field_name = '{}.{}'.format(reference_name, field_name)

            if field_type == 'datetime':
                field_type = 'date'

            display = ''
            if parameter_type == ActivityConstants.PARAMETER_TYPE_PUBLIC and parameter_reference is not None:
                parameter_ref_conditions = parameter_reference.get('condition') or list() 
                parameter_ref_metadata = parameter_reference.get('dataset') or dict()
                parameter_value_field_name = None
                parameter_value_field_type = field_type
                for parameter_ref_condition in parameter_ref_conditions:
                    if parameter_ref_condition.get('default_val') == '${{{}}}'.format(field_name.split('.')[-1]):
                        parameter_value_field_name = parameter_ref_condition.get('name')
                        break

                displays = list()
                parameter_datafields = ActivityUtilities.get_flat_datafields_by_dataset_metadata(virtual_name, main_dataset_name, field_id)
                show_parameter_datafields = list(filter(lambda f: ((f.get('pre_setting') or dict()).get('business_reference') or False) \
                                                                    and f.get('name') != parameter_value_field_name \
                                                            , parameter_datafields))
                show_parameter_datafields = sorted(show_parameter_datafields, key=lambda f: (f.get('pre_setting') or dict()).get('sequence') or 999)
                for parameter_datafield in show_parameter_datafields:
                    parameter_field_name = parameter_datafield.get('name')
                    parameter_field_type = parameter_datafield.get('type')
                    if parameter_field_type == 'datetime':
                        parameter_field_type = 'date'
                    displays.append('{}.{}:{}'.format(field_name, parameter_field_name, parameter_field_type))
                display = ','.join(displays)

            elif parameter_type == ActivityConstants.PARAMETER_TYPE_MASTER and parameter_reference is not None:
                parameter_ref_conditions = parameter_reference.get('condition') or list() 
                parameter_ref_metadata = parameter_reference.get('dataset') or dict()
                parameter_dataset = parameter_ref_metadata.get('dataset_name')
                parameter_ref_fields = parameter_ref_metadata.get('fields') or list()
                parameter_datafields = ActivityUtilities.get_flat_datafields_by_dataset_metadata(virtual_name, main_dataset_name, field_id)

                show_parameter_datafields = list(filter(lambda f: \
                                (f.get('pre_setting') or dict()).get('business_reference') or False \
                                    and f.get('parameter_type') != ActivityConstants.PARAMETER_TYPE_MASTER \
                                                        , parameter_datafields))

                show_parameter_datafields = sorted(show_parameter_datafields,
                                                   key=lambda f: (f.get('pre_setting') or dict()).get(
                                                       'sequence') or 999)
                show_parameter_datafields, _ = ComponentCreatableSearchAnyField().__get_attribute_fields(show_parameter_datafields, **{
                    'virtual_name': virtual_name,
                    'main_dataset_name': main_dataset_name,
                })

                displays = list()
                for parameter_datafield in show_parameter_datafields:
                    _parameter_datafields = parameter_datafield.get('display_field').split(',')

                    for _parameter_datafield in _parameter_datafields:
                        displays.append('{}.{}'.format(field_name, _parameter_datafield))
                display = ','.join(displays)

                embed_field.append(field_name)

            else:
                display = '{}:{}'.format(field_name, field_type)

            return_field = {
                'display_field': display,
                'label': field_label,
            }

            number_format = (datafield.get('pre_setting') or dict()).get('number_format')
            if field_type in ('integer', 'decimal') and number_format:
                return_field['format'] = number_format

            return_fields.append(return_field)

        return return_fields, embed_field


class ComponentSearchAnyField:
    name = ComponentEnum.SEARCH_ANY_FIELD.value

    @staticmethod
    def attributes(**kwargs):
        # 'search any field' widget has the same logic as 'creatable search any field' widget
        return ComponentCreatableSearchAnyField.attributes(**kwargs)

    @staticmethod
    def attributes_by_ref_metadata(value_field_name, value_field_type, ref_metadata, **kwargs):
        # 'search any field' widget has the same logic as 'creatable search any field' widget
        kwargs['creatable'] = False
        return ComponentCreatableSearchAnyField.attributes_by_ref_metadata(value_field_name, value_field_type, ref_metadata, **kwargs)

    @staticmethod
    def attributes_by_parameter_reference(field_name, parameter_reference, **kwargs):
        # 'search any field' widget has the same logic as 'creatable search any field' widget
        kwargs['creatable'] = False
        return ComponentCreatableSearchAnyField.attributes_by_parameter_reference(field_name, parameter_reference, **kwargs)


class ComponentSearchAnyFieldMultipleValue:
    name = ComponentEnum.SEARCH_ANY_FIELD_MULTIPLE_VALUE.value

    @staticmethod
    def attributes(**kwargs):
        # 'search any field multiple value' widget has the same logic as 'search any field' widget
        return ComponentSearchAnyField.attributes(**kwargs)

    @staticmethod
    def attributes_by_ref_metadata(value_field_name, value_field_type, ref_metadata, **kwargs):
        # 'search any field multiple value' widget has the same logic as 'search any field' widget
        return ComponentSearchAnyField.attributes_by_ref_metadata(value_field_name, value_field_type, ref_metadata, **kwargs)

    @staticmethod
    def attributes_by_parameter_reference(field_name, parameter_reference, **kwargs):
        # 'search any field multiple value' widget has the same logic as 'search any field' widget
        return ComponentSearchAnyField.attributes_by_parameter_reference(field_name, parameter_reference, **kwargs)


class ComponentReference:
    name = ComponentEnum.REFERENCE.value

    @staticmethod
    def attributes(**kwargs):
        # 'reference' widget has the same logic as 'search any field' widget
        return ComponentSearchAnyField.attributes(**kwargs)

    @staticmethod
    def attributes_by_ref_metadata(value_field_name, value_field_type, ref_metadata, **kwargs):
        # 'reference' widget has the same logic as 'search any field' widget
        return ComponentSearchAnyField.attributes_by_ref_metadata(value_field_name, value_field_type, ref_metadata, **kwargs)

    @staticmethod
    def attributes_by_parameter_reference(field_name, parameter_reference, **kwargs):
        # 'reference' widget has the same logic as 'search any field' widget
        return ComponentSearchAnyField.attributes_by_parameter_reference(field_name, parameter_reference, **kwargs)


class ComponentReferenceMultipleValue:
    name = ComponentEnum.REFERENCE_MULTIPLE_VALUE.value

    @staticmethod
    def attributes(**kwargs):
        # 'reference multiple value' widget has the same logic as 'reference' widget
        return ComponentReference.attributes(**kwargs)

    @staticmethod
    def attributes_by_ref_metadata(value_field_name, value_field_type, ref_metadata, **kwargs):
        # 'reference multiple value' widget has the same logic as 'reference' widget
        return ComponentReference.attributes_by_ref_metadata(value_field_name, value_field_type, ref_metadata, **kwargs)

    @staticmethod
    def attributes_by_parameter_reference(field_name, parameter_reference, **kwargs):
        # 'reference multiple value' widget has the same logic as 'reference' widget
        return ComponentReference.attributes_by_parameter_reference(field_name, parameter_reference, **kwargs)


class ComponentEmbeddedDisplay:
    name = ComponentEnum.EMBEDDED_DISPLAY.value

    @staticmethod
    def attributes(**kwargs):
        display_fields = kwargs.get('display_fields')
        attributes = {
            'display-type': 'object',
        }
        if display_fields is not None:
            attr_display_fields = list()
            for idx, field in enumerate(display_fields, 1):
                attr_display_fields.append('{}:{}'.format(field['name'], field['type']))
            attributes['display-field'] = ','.join(attr_display_fields)
        return attributes

    
    @staticmethod
    def attributes_by_parameter_reference(target_field_name, parameter_reference, **kwargs):
        show_reference_code = kwargs.get('show_reference_code', True)
        ref_conditions = parameter_reference.get('condition') or list() 
        virtual_name = kwargs.get('virtual_name')
        field_id = kwargs.get('field_id')

        virtual_group = VirtualGroup.objects.filter(name=virtual_name).first()
        main_dataset_name = virtual_group.main_dataset_name

        parameter_code_field_name = None
        for condition in ref_conditions:
            if condition.get('default_val') == '${{{}}}'.format(target_field_name):
                parameter_code_field_name = condition.get('name')
                break

        parameter_ref_metadata = parameter_reference.get('dataset') or dict()

        datafields = ActivityUtilities.get_flat_datafields_by_dataset_metadata(virtual_name, main_dataset_name, field_id)
        show_datafields = list(filter(lambda f: (f.get('pre_setting') or dict()).get('business_reference') or False, datafields))
        show_datafields = sorted(show_datafields, key=lambda f: (f.get('pre_setting') or dict()).get('sequence') or 999)

        display_fields = list()

        for datafield in show_datafields:
            field_id = datafield.get('field_id')
            field_name = datafield.get('name')
            field_type = datafield.get('type')
            reference_name = datafield.get('reference_name')
            parameter_type = datafield.get('parameter_type')

            if parameter_type == ActivityConstants.PARAMETER_TYPE_MASTER:
                continue
            if not show_reference_code and field_name == parameter_code_field_name:
                continue
            if field_type == 'datetime':
                field_type = 'date'

            inner_parameter_reference = datafield.get('parameter_ref') or dict()
            inner_parameter_ref_metadata = inner_parameter_reference.get('dataset')

            if parameter_type == ActivityConstants.PARAMETER_TYPE_PUBLIC and inner_parameter_ref_metadata is not None:
                inner_ref_conditions = inner_parameter_reference.get('condition') or list() 
                inner_parameter_code_field_name = None
                for condition in inner_ref_conditions:
                    if condition.get('default_val') == '${{{}}}'.format(field_name):
                        inner_parameter_code_field_name = condition.get('name')
                        break

                inner_datafields = ActivityUtilities.get_flat_datafields_by_dataset_metadata(virtual_name, main_dataset_name, field_id)
                inner_show_datafields = list(filter(lambda f: (f.get('pre_setting') or dict()).get('business_reference') or False, inner_datafields))
                inner_show_datafields = sorted(inner_show_datafields, key=lambda f: (f.get('pre_setting') or dict()).get('sequence') or 999)
                for inner_datafield in inner_show_datafields:
                    inner_field_name = inner_datafield.get('name')
                    inner_field_type = inner_datafield.get('type')
                    inner_reference_name = inner_datafield.get('reference_name')
                    if inner_field_name == inner_parameter_code_field_name:
                        continue
                    if inner_field_type == 'datetime':
                        inner_field_type = 'date'
                    if inner_reference_name is not None:
                        inner_field_name = '{}.{}'.format(inner_reference_name, inner_field_name)
                    display_fields.append({
                        'name': '{}.{}'.format(field_name, inner_field_name),
                        'type': inner_field_type,
                    })
            else:
                if reference_name is not None:
                    field_name = '{}.{}'.format(reference_name, field_name)
                display_fields.append({
                    'name': field_name,
                    'type': field_type,
                })
                
        return ComponentEmbeddedDisplay.attributes(display_fields=display_fields)
