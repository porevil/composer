import copy

from apps.test_virtual_instance.abstract import AbstractActivities
from apps.commons.generator.configuration.constants import ActivityConstants
from apps.commons.generator.constants import StandardProcessType as StandardProcessTypeEnum
from apps.commons.generator.constants import Activity as ActivityEnum
from apps.commons.generator.constants import ActivitySection as SectionEnum
from apps.commons.generator.constants import StandardProcess as StandardProcessEnum
from apps.generator_setting.models import VirtualElements


class PreDefinedMultipleDatasetActivities(AbstractActivities):
    COMPONENT_PER_ROW = 2

    def _create_active_fields(self, activity_name, section_type):
        fields = list()
        active_datafields = self._get_active_datafields(activity_name, section_type)
        component_count = 0

        for idx, datafield in enumerate(active_datafields, 1):
            field_name = datafield.get('name')
            parameter_type = datafield.get('parameter_type')
            can_enter = (len(fields) > 0 and fields[len(fields)-1].get('field_type') != 'new_line')

            if datafield.get('fieldset') is not None:
                if can_enter:
                    fields.append(self._create_enter_field())
                fields.append(self._create_fieldset(datafield['fieldset'], True))
                component_count = 0

            component_name, attributes = self._get_common_component_with_attributes(activity_name, section_type, datafield)
            attributes = attributes or dict()
            attributes = self._adjust_common_attributes(activity_name, section_type, datafield, component_name, attributes)
            mandatory = self._get_standard_mandatory(activity_name, section_type, field_name)
            label = (datafield.get('pre_setting') or dict()).get('label')
            sorting = 'asc' if (activity_name == ActivityEnum.SEARCH.value and section_type == SectionEnum.DATA.value and idx == 1) else None

            if self._is_whole_line_component(component_name) and can_enter:
                fields.append(self._create_enter_field())
                component_count = 0

            field = self._create_field(datafield, component_name, True, attributes, mandatory, label, None, sorting)
            fields.append(field)

            component_count = component_count + 1
            is_enter = ( (component_count == PreDefinedMultipleDatasetActivities.COMPONENT_PER_ROW) \
                                or ((datafield.get('pre_setting') or dict()).get('end_line') or False) \
                                or (activity_name == ActivityEnum.SEARCH.value and section_type == SectionEnum.CRITERIA.value) \
                                or (self._is_whole_line_component(component_name)) ) \
                            and (not (activity_name == ActivityEnum.SEARCH.value and section_type == SectionEnum.DATA.value))

            if is_enter: 
                fields.append(self._create_enter_field())
                component_count = 0
                
        return fields


    def _get_active_datafields(self, activity_name, section_type):
        datafields = list()
        
        if activity_name == ActivityEnum.SEARCH.value:
            if section_type == SectionEnum.CRITERIA.value:
                datafields = list(filter(lambda f: (f.get('pre_setting') or dict()).get('search_field') or False and
                                (f.get('pre_setting') or dict()).get('sequence') is not None, self.datafields))

            elif section_type == SectionEnum.DATA.value:
                datafields = list(filter(lambda f: (f.get('pre_setting') or dict()).get('result_field') or False and
                                (f.get('pre_setting') or dict()).get('sequence') is not None, self.datafields))

        elif activity_name == ActivityEnum.VIEW.value:
            if section_type == SectionEnum.DATA.value:
                # datafields = list(filter(lambda f: (f.get('pre_setting') or dict()).get('sequence') is not None or
                #                 ((f.get('pre_setting') or dict()).get('top_field') or False) and
                #                     (f.get('pre_setting') or dict()).get('sequence') is not None
                #                         , self.datafields))
                datafields = list(filter(lambda f: (f.get('pre_setting') or dict()).get('sequence') is not None, self.datafields))

        element_datafields = list()
        if activity_name == ActivityEnum.VIEW.value and section_type == SectionEnum.DATA.value:
            virtual_elements = VirtualElements.objects.filter(group_id__name=self.virtual_name).order_by('sequence')
            for virtual_element in virtual_elements:
                elements = list(filter(lambda f: (f.get('element_id') == virtual_element.id), datafields))
                elements = sorted(elements, key=lambda f: (f.get('pre_setting') or dict()).get('sequence'))
                elements[0]['fieldset'] = virtual_element.element_name

                element_datafields = element_datafields + elements

            element_datafields = self._adjust_standard_datafields(activity_name, section_type, element_datafields)

        else:
            for datafield in datafields:
                datafield['fieldset'] = None

            element_datafields = self._adjust_standard_datafields(activity_name, section_type, datafields)
        
        return element_datafields
