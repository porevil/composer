import uuid
import threading
import itertools
import os
import sys

from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status

from apps.commons.utilities.log import Logger
from apps.commons.utilities.response import ResponseAPI
from apps.commons.generator.constants import GeneratingType
from apps.commons.generator.constants import StandardProcessType
from apps.metadata.models import Dataset
from apps.standard_process.models import StandardProcess
from apps.test_virtual_instance.manager import VirtualConfigurationManager
from apps.pre_defined_generator.views.automation import AutomationAPIView
from apps.commons.serializers import AbstractSerializer
from apps.commons.error.exception import *
from apps.routines.models import Lot, LotRoutine, RoutineTags


class GenerateConfigurationView(AutomationAPIView):
    serializer_class = AbstractSerializer
    reference_id = str(uuid.uuid4())
    response_meta = ResponseAPI()

    def post(self, request):
        try:
            request_data = request.data

            lot_id = request_data.get('lot_id')
            if lot_id is None:
                raise BadRequestException('"lot_id" is required')

            lot = Lot.objects.filter(id=lot_id).first()
            if lot is None:
                raise BadRequestException('"lot_id" is invalid')

            lot_routines = LotRoutine.objects.filter(lot=lot)
            standard_process_ids = lot.standard_process_ids or list()
            dataset_names = lot.datasets or list()

            all_products = set(itertools.product(dataset_names, standard_process_ids))
            existing_products = set(map(lambda lr: (lr.routine.dataset_name, lr.routine.standard_process.id), lot_routines))
            generating_products = all_products.difference(existing_products)

            generating_tag = RoutineTags.next()

            configuration_manager = VirtualConfigurationManager(self.reference_id)

            for generating_product in generating_products:
                dataset_name = generating_product[0]
                standard_process_id = generating_product[1]
                try:
                    standard_process = StandardProcess.objects.get(id=standard_process_id)
                    if standard_process.get_type().value != StandardProcessType.OUTPUT.value:
                        continue
                        
                    standard_process_code = standard_process.code or '-'
                    additional_config = dict()
                    executed_by = self.current_username(request)
                    routine = configuration_manager.generate(standard_process
                                                            , dataset_name
                                                            , GeneratingType.PreDefinedMultipleDataset.value
                                                            , generating_tag
                                                            , additional_config
                                                            , executed_by)

                    lot_routine = LotRoutine.objects.filter(routine=routine).first()
                    if lot_routine is not None and lot_routine.lot.id != lot.id:
                        lot_routine.delete()
                    lot_routine, _ = LotRoutine.objects.update_or_create(lot=lot, routine=routine)
                    
                except Exception as ie:
                    continue
                
            response = self.response_meta.success('success', self.reference_id, 'generate success')

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

        finally:
            return Response(response, status=status.HTTP_200_OK)
