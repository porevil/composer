import copy
import uuid
import json

from abc import abstractmethod

from apps.commons.utilities.log import Logger
from apps.commons.generator.constants import StandardProcessType as StandardProcessTypeEnum
from apps.commons.generator.constants import Activity as ActivityEnum
from apps.commons.generator.constants import ActivitySection as SectionEnum
from apps.commons.generator.constants import StandardProcess as StandardProcessEnum
from apps.commons.connectors.metadata import Metadata
from apps.commons.generator.configuration.constants import ActivityConstants
from apps.test_virtual_instance.utilities import ActivityUtilities
from apps.test_virtual_instance.components import *
from apps.generator_setting.models import DatasetSetting, DatasetConfiguration
from apps.standard_process.models import Component
from apps.generator_setting.models import VirtualGroup


class AbstractActivities:
    LOGGER = Logger('Abstract Activities')

    def __init__(self, standard_process, virtual_name, ref_log):
        try:
            self.reference_id = ref_log
            self.virtual_name = virtual_name
            self.standard_process = standard_process
            self.standard_process_type = standard_process.get_type()
            self.standard_process_config = self.standard_process.config or dict()
            self.template = standard_process.template
            self.template_config = self.template.config or dict()
            self.template_activities = self.template_config.get("activities") or list()

            self.virtual_group = VirtualGroup.objects.filter(name=self.virtual_name).first()
            if self.virtual_group is None:
                raise Exception('virtual name is invalid')

            self.dataset_name = self.virtual_group.main_dataset_name
    
            # Get component data
            self.default_component_name = ComponentTextbox.name
            self.component_map = dict()
            for component in Component.objects.all():
                self.component_map[component.code] = component

            # Declare 'related_dataset_metadata' variable to cache related dataset fields metadata (from data engine)
            self.related_dataset_metadata = dict()

            # Initial 'datafields' (of this dataset)
            self.datafields = ActivityUtilities.get_flat_datafields_by_dataset_metadata(self.virtual_name, self.dataset_name)

            # Declare 'additional descriptive metadata' variable
            self.has_data_privacy = False
            self.has_data_migration = False
            self.additional_data_migration_fields = list()

            # Declare 'additional configuration' (datafields, intents and additional attributes) variable
            self.config_datafields = list()
            self.config_intent_ins = list()
            self.config_intent_outs = list()
            self.attr_inquiry_data_filter = None
            self.attr_inquiry_embedded_fields = set()
            self.attr_embedded_fields = set()
            self.attr_group_key_fields = set()
            self.attr_business_key_fields = set()
            self.attr_business_key_gen_fields = list()
            self.attr_autofill_fields = list()
            self.attr_data_privacy = False
            self.attr_data_privacy_datasets = set()
            self.attr_related_parameter_datasets = set()
            self.attr_reference_search_fields = set()

            # Assign 'additional descriptive metadata' and 'additional configuration' value
            template_intents = (self.template_config.get('intent') or dict()).get('template') or dict()
            for intent_in in template_intents.get('ins') or list():
                self.config_intent_ins.append({
                    'name': intent_in.get('name'),
                    'type': intent_in.get('type'),
                    'multiple': intent_in.get('multiple') or False,
                    'label': intent_in.get('label'),
                    'template': True,
                })
            for intent_out in template_intents.get('outs') or list():
                self.config_intent_outs.append({
                    'name': intent_out.get('name'),
                    'type': intent_out.get('type'),
                    'multiple': intent_out.get('multiple') or False,
                    'label': intent_out.get('label'),
                    'template': True,
                })

            # First level
            for datafield in self.datafields:
                name = datafield.get('name')
                ref_name = datafield.get('reference_name')
                fullname = ('{}.{}'.format(ref_name, name) if ref_name is not None else name)
                label = datafield.get('label_th')
                ftype = datafield.get('type')
                multiple = datafield.get('multiple_value') or False
                parameter_type = datafield.get('parameter_type')
                parameter_ref_metadata = (datafield.get('parameter_ref') or dict()).get('dataset')
                parameter_ref_dataset = (parameter_ref_metadata or dict()).get('dataset_name')
                dataset_relations = datafield.get('dataset_relations') or False # support user-defined
                auto_gen = datafield.get('auto_gen') or False
                key = datafield.get('key') or False
                group_key = datafield.get('group_of_record') or False
                business_keygen_id = (datafield.get('business_keygen') or dict()).get('id')
                autofill = (datafield.get('pre_setting') or dict()).get('autofill')
                autofill_field = (datafield.get('pre_setting') or dict()).get('autofill_field')

                if parameter_type == ActivityConstants.PARAMETER_TYPE_EMBEDDED and multiple:
                    continue

                if name == ActivityConstants.DATA_PRIVACY_FIELD_DATA_CONTROLLER:
                    self.has_data_privacy = True
                    self.attr_data_privacy = True
                if name == ActivityConstants.DATA_MIGRATION_FIELD_TABLE_NAME:
                    self.has_data_migration = True
                if name not in ActivityConstants.DATA_MIGRATION_FIELDS and '(Data Migration)' in label:
                    self.additional_data_migration_fields.append(name)
                if parameter_type in [ActivityConstants.PARAMETER_TYPE_MASTER, ActivityConstants.PARAMETER_TYPE_PUBLIC] \
                        and parameter_ref_metadata:
                    self.attr_embedded_fields.add(fullname)
                    if ActivityConstants.DATA_PRIVACY_FIELD_DATA_CONTROLLER in \
                            list(map(lambda f: f.get('name'), parameter_ref_metadata.get('fields') or list())):
                        self.attr_data_privacy_datasets.add(parameter_ref_dataset)

                if parameter_type == ActivityConstants.PARAMETER_TYPE_PUBLIC:
                    self.attr_related_parameter_datasets.add(parameter_ref_dataset)

                if key:
                    self.attr_business_key_fields.add(fullname)
                if group_key:
                    self.attr_group_key_fields.add(fullname)
                if business_keygen_id:
                    self.attr_business_key_gen_fields.append({
                        'name': fullname,
                        'type': ftype,
                        'key': business_keygen_id,
                    })
                if autofill:
                    self.attr_autofill_fields.append({
                        'name': fullname,
                        'type': ftype,
                        'value': {
                            'name': autofill,
                            'sub_name': autofill_field if autofill_field else name
                        },
                        'source_value': autofill # backward compat
                    })
                
                config_datafield = {
                    'name': fullname,
                    'type': ftype,
                    'multiple': multiple,
                    'label': label,
                }
                if parameter_ref_dataset:
                    config_datafield['ref_ds'] = parameter_ref_dataset
                self.config_datafields.append(config_datafield)

                try:
                    intent_ftype = self.__parse_intent_field_type(ftype)
                    intent = {
                        'name': fullname,
                        'type': intent_ftype,
                        'multiple': multiple,
                        'label': label,
                    }
                    if key or group_key:
                        self.config_intent_ins.append(intent)
                    self.config_intent_outs.append(intent)
                except:
                    continue

            if self.virtual_group.config:
                self.attr_inquiry_data_filter = self.virtual_group.get('additional_condition')

        except Exception as e:
            raise e


    def __parse_intent_field_type(self, field_type):
        field_type = field_type.lower()
        if field_type not in ['text', 'integer', 'decimal', 'boolean', 'datetime']:
            raise Exception('not support field type')
        if field_type in ['integer', 'decimal']:
            field_type = 'number'
        return field_type


    def generate(self, additional_config=dict()):
        self.additional_config = additional_config

        # Generate activity configuration
        activities = dict()
        for activity in ActivityEnum:
            activities[activity.value] = self._create_activity_configuration(activity.value)

        return activities, {
            'datafields': self.config_datafields,
            'intent': {
                'ins': self.config_intent_ins,
                'outs': self.config_intent_outs,
            },
            'additional_attributes': {
                'inquiry_data_filter': self.attr_inquiry_data_filter,
                'embeded_fields': list(self.attr_embedded_fields),
                'inquiry_embeded_fields': list(self.attr_inquiry_embedded_fields),
                'group_key_fields': list(self.attr_group_key_fields),
                'business_key_fields': list(self.attr_business_key_fields),
                'business_key_gen_fields': self.attr_business_key_gen_fields,
                'autofill_fields': self.attr_autofill_fields,
                'data_privacy': self.attr_data_privacy,
                'data_privacy_datasets': list(self.attr_data_privacy_datasets),
                'related_parameter_datasets': list(self.attr_related_parameter_datasets),
                'reference_search_fields': list(self.attr_reference_search_fields),
            },
        }
    
    
    def _create_activity_configuration(self, activity_name):
        activity_configuration = {
            'sections': self._create_sections(activity_name),
        }
        return activity_configuration

    
    def _create_sections(self, activity_name):
        sections = []
        for section in SectionEnum:
            if activity_name != ActivityEnum.SEARCH.value and section.value == SectionEnum.CRITERIA.value:
                continue

            sections.append(self._create_section(activity_name, section.value))
        return sections


    def _create_section(self, activity_name, section_type):
        section_name_prefix = ((self.standard_process_config.get('activities') or dict()) \
                                    .get(activity_name) or dict()) \
                                    .get(section_type) or activity_name.capitalize()

        section = dict()
        section['type'] = section_type

        if activity_name in self.template_activities:
            virtual_description = self.virtual_group.description

            if virtual_description is None:
                section_name = section_name = '{}'.format(section_name_prefix)
            else: 
                section_name = '{} {}'.format(section_name_prefix, self.virtual_group.description)

            fields = self._create_active_fields(activity_name, section_type)
        else:
            section_name = '{}'.format(section_name_prefix)
            fields = list()

        # Add inactive fields
        # active_field_names = list(
        #     map(lambda f: f['field_name'], list(filter(lambda f: f['field_name'] is not None, fields))))
        # inactive_datafields = list(filter(lambda f: f['name'] not in active_field_names, self.datafields))

        # for datafield in inactive_datafields:
        #     parameter_type = datafield.get('parameter_type')
        #     is_multiple = datafield.get('multiple_value') or False
        #     if parameter_type == ActivityConstants.PARAMETER_TYPE_EMBEDDED and is_multiple:
        #         field = self._create_multiple_embedded_field(datafield)
        #     else:
        #         field = self._create_field(datafield, self.default_component_name)
        #     fields.append(field)

        section['fields'] = fields
        section['no_of_field'] = len(fields)
        section['section_name'] = section_name
        return section

    
    @abstractmethod
    def _create_active_fields(self, activity_name, section_type):
        return list()


    def _adjust_standard_datafields(self, activity_name, section_type, datafields):
        # special case for standard process I10
        # if self.standard_process.code == StandardProcessEnum.I10.value:
        #     if activity_name == ActivityEnum.VIEW.value and section_type == SectionEnum.DATA.value:
        #         datafields.append(self._get_datafield(ActivityConstants.TECHNICAL_FIELD_CREATE_USER))
        #         datafields.append(self._get_datafield(ActivityConstants.TECHNICAL_FIELD_PROCESS_STATUS))
        #         datafields.append(self._get_datafield(ActivityConstants.TECHNICAL_FIELD_RECORD_STATUS))
        #     return datafields

        # ignore if 'show_standard_datafields' flag is not true
        show_standard_datafields = self.standard_process_config.get('show_standard_datafields') or False
        if not show_standard_datafields:
            return datafields

        # get standard datafields
        standard_datafields = list()
        if activity_name == ActivityEnum.VIEW.value and section_type == SectionEnum.DATA.value:
            # Data Migration Fields
            if self.has_data_migration:
                add_fieldset = False
                data_migration_fields = [ActivityConstants.DATA_MIGRATION_FIELD_SYSTEM \
                                        , ActivityConstants.DATA_MIGRATION_FIELD_REFERENCE_SYSTEM_NO \
                                        , ActivityConstants.DATA_MIGRATION_FIELD_TABLE_NAME ]

                data_migration_fields = data_migration_fields + self.additional_data_migration_fields
                for data_migration_field in data_migration_fields:
                    datafield = self._get_datafield(data_migration_field)

                    if datafield is not None:
                        standard_datafields.append(datafield)
                        if add_fieldset == False:
                            standard_datafields[len(standard_datafields) - 1]['fieldset'] = 'ข้อมูล Data Migration'
                            add_fieldset = True

            # Technical Fields
            add_fieldset = False
            technical_fields = [ActivityConstants.TECHNICAL_FIELD_CREATE_USER \
                , ActivityConstants.TECHNICAL_FIELD_CREATE_DATE \
                , ActivityConstants.TECHNICAL_FIELD_RECORD_STATUS \
                , ActivityConstants.TECHNICAL_FIELD_PROCESS_STATUS \
                , ActivityConstants.TECHNICAL_FIELD_EFFECTIVE_DATE \
                , ActivityConstants.TECHNICAL_FIELD_EXECUTION_APPLICATION \
                , ActivityConstants.TECHNICAL_FIELD_EXECUTION_LOCATION]

            for technical_field in technical_fields:
                datafield = self._get_datafield(technical_field)

                if datafield is not None:
                    standard_datafields.append(datafield)
                    if add_fieldset == False:
                        standard_datafields[len(standard_datafields) - 1]['fieldset'] = 'ข้อมูล Technical'
                        add_fieldset = True

            # Data Privacy
            if self.has_data_privacy:
                add_fieldset = False
                data_privacy_fields = [ActivityConstants.DATA_PRIVACY_FIELD_DATA_PROCESSOR \
                                    , ActivityConstants.DATA_PRIVACY_FIELD_DATA_CONTROLLER \
                                    , ActivityConstants.DATA_PRIVACY_FIELD_SUB_CONTROLLER \
                                    , ActivityConstants.DATA_PRIVACY_FIELD_THIRD_PARTY ]
                
                for data_privacy_field in data_privacy_fields:
                    datafield = self._get_datafield(data_privacy_field)

                    if datafield is not None:
                        standard_datafields.append(datafield)
                        if add_fieldset == False:
                            standard_datafields[len(standard_datafields) - 1]['fieldset'] = 'ข้อมูล Data Privacy'
                            add_fieldset = True

        for standard_datafield in standard_datafields:
            standard_datafield['standard'] = True
            standard_datafield.pop('pre_setting', None)

        # return adjusted datafields
        datafields = datafields + standard_datafields
        return datafields


    def _get_datafield(self, field_name, reference_name=None, ignore_reference_name=False):
        for datafield in self.datafields:
            if (not ignore_reference_name and datafield['name'] == field_name and datafield.get('reference_name') == reference_name) \
                    or (ignore_reference_name and datafield['name'] == field_name):
                return copy.deepcopy(datafield)
        return None


    def _create_field(self, datafield, component_name, enable=False, attributes=dict(), mandatory=None, label=None, embedded_field_display=None, sorting=None):
        component = self.component_map.get(component_name)
        return {
            'field_name': datafield['name'],
            'field_type': datafield['type'],
            'enable': enable,
            'tisco_param': datafield.get('tisco_param') or False,
            'mandatory': mandatory if mandatory is not None else datafield['require'],
            'editable': True,
            'component': self._create_component(component, attributes),
            'key': True,
            'meta_type': 'master',
            'caption_eng': datafield['label_en'],
            'caption_th': label or datafield['label_th'],
            'sortable': sorting,
            'embeded_field': embedded_field_display,
            'hide_widget_area': self._is_hide_widget_area(component_name),
            'ref_name': datafield.get('reference_name'),
            'ref_setname': datafield.get('reference_dataset'),
        }


    def _create_component(self, component, attributes):
        return {
            'id': component.id,
            'code': component.code,
            'name': component.name,
            'attributes': self._create_attributes(component, attributes)
        }

    
    def _create_attributes(self, component, attributes):
        component_data = component.config
        return_attributes = copy.deepcopy(component_data.get('attributes') or list())

        for attr in return_attributes:
            if attr['code'] in attributes:
                attr['value'] = attributes[attr['code']]

            if attr['value'] == '':
                attr['value'] = None

        return return_attributes


    def _create_information_field(self, information):
        component = self.component_map.get(ComponentPreformattedText.name)
        indent = (information is not None and information[0] == ' ')
        attributes = ComponentPreformattedText.attributes(indent=indent, default_value=information)
       
        return {
            'field_name': 'dummy_' + str(uuid.uuid4())[-12:],
            'field_type': 'text',
            'enable': True,
            'tisco_param': False,
            'mandatory': False,
            'editable': True,
            'component': self._create_component(component, attributes),
            'key': False,
            'meta_type': 'dummy',
            'hide_widget_area': False,
        }

    
    def _create_fieldset(self, title, collapse=False):
        return {
            'field_name': None,
            'field_type': 'field_set',
            'enable': True,
            'tisco_param': False,
            'mandatory': False,
            'editable': True,
            'component': None,
            'key': True,
            'meta_type': 'field_set',
            'caption_eng': None,
            'caption_th': title,
            'collapse': collapse,
        }


    def _create_enter_field(self):
        return {
            'field_name': None,
            'field_type': 'new_line',
            'enable': True,
            'tisco_param': False,
            'mandatory': False,
            'editable': True,
            'component': None,
            'key': True,
            'meta_type': 'enter',
        }

    def _create_multiple_embedded_field(self, datafield, active_embedded_fields=list()):
        fields = copy.deepcopy(active_embedded_fields)
        active_embedded_field_names = list(map(lambda f: f.get('field_name'), active_embedded_fields))
        inactive_embedded_fields = list(filter(lambda f: f['name'] not in active_embedded_field_names, datafield['fields']))

        for embedded_datafield in inactive_embedded_fields:
            field = self._create_field(embedded_datafield, self.default_component_name)
            fields.append(field)

        return {
            'field_name': datafield.get('name'),
            'field_type': 'Array Object',
            'enable': (len(active_embedded_fields) > 0),
            'tisco_param': False,
            'mandatory': False,
            'editable': True,
            'fields': fields,
            'no_of_field': len(fields),
            'component': None,
            'key': False,
            'meta_type': 'multiple'
        }


    def _get_common_component_with_attributes(self, activity_name, section_type, datafield):
        field_id = datafield.get('field_id')
        field_name = datafield.get('name')
        reference_name = datafield.get('reference_name')
        field_type = datafield.get('type')
        parameter_type = datafield.get('parameter_type')
        parameter_reference = datafield.get('parameter_ref')
        is_encrypt = datafield.get('encrypt') or False
        is_multiple = datafield.get('multiple_value') or False
        is_relation_field = False
        relation_field_name = None
        relation_dataset_name = None
        default_value = None if activity_name not in (ActivityEnum.CREATE.value) else (datafield.get('pre_setting') or dict()).get('default_value')
        dataset_relation_flag = datafield.get('dataset_relations') or False
        relation_field_info = datafield.get('dataset_relations_info')

        if dataset_relation_flag and relation_field_info is not None \
                and len(relation_field_info) > 0  and 'dataset_name' in relation_field_info[0] \
                and 'field_name' in relation_field_info[0]:
            is_relation_field = True
            relation_field_name = relation_field_info[0]['field_name']
            relation_dataset_name = relation_field_info[0]['dataset_name']

        # Add Additional Attribute 'inquiry embedded fields' to list
        if activity_name == ActivityEnum.SEARCH.value and section_type == SectionEnum.DATA.value:
            if parameter_reference is not None:
                inquiry_embedded_field = ('{}.{}'.format(reference_name, field_name) if reference_name is not None else field_name)
                self.attr_inquiry_embedded_fields.add(inquiry_embedded_field)

        # Select Component with Attributes by using metadata
        if activity_name == ActivityEnum.SEARCH.value and section_type == SectionEnum.DATA.value:
            if parameter_reference is not None:
                show_reference_code = not (parameter_type == ActivityConstants.PARAMETER_TYPE_PUBLIC)
                return ComponentEmbeddedDisplay.name, ComponentEmbeddedDisplay.attributes_by_parameter_reference(field_name \
                                                                                , parameter_reference
                                                                                , show_reference_code=show_reference_code
                                                                                , field_id=field_id
                                                                                , virtual_name=self.virtual_name)

        # Data Type: Relative
        if parameter_type in (ActivityConstants.PARAMETER_TYPE_PUBLIC, ActivityConstants.PARAMETER_TYPE_MASTER) \
                and parameter_reference is not None:
            
            data_dependency = (datafield.get('pre_setting') or dict()).get('data_dependency')
            dependency_filter = (datafield.get('pre_setting') or dict()).get('dependency_filter')
            relative_component_type = (datafield.get('pre_setting') or dict()).get('relative_data_component')
            relative_condition = (datafield.get('pre_setting') or dict()).get('relative_data_condition')
            show_reference_code = not (activity_name == ActivityEnum.VIEW.value or parameter_type == ActivityConstants.PARAMETER_TYPE_MASTER)

            # Generate Condition
            condition = ''
            if parameter_type == ActivityConstants.PARAMETER_TYPE_PUBLIC:
                condition = '{} = {}'.format(ActivityConstants.TECHNICAL_FIELD_RECORD_STATUS, ActivityConstants.RECORD_STATUS_ACTIVE)
            if relative_condition:
                condition = '{} and {}'.format(condition, relative_condition) if condition else relative_condition
            
            # Default Component Type
            # - Master Parameter : Popup
            # - Public Parameter : Dropdown
            if not relative_component_type:
                relative_component_type = 'popup' if parameter_type == ActivityConstants.PARAMETER_TYPE_MASTER else 'dropdown'

            # Initial Data in case of Data Dependency
            parent_field_name = None
            parent_field_type = None
            filter_field_name = None
            if data_dependency:
                parent_field_name = data_dependency
                filter_field_name = dependency_filter
                parent_field_names = parent_field_name.split('.')
                parent_datafield = self._get_datafield(parent_field_names[-1], parent_field_names[0] if len(parent_field_names) == 2 else None)
                if parent_datafield is not None:
                    parent_field_type = parent_datafield.get('type')

            # Select Component and Set Attributes
            # if parameter_type == ActivityConstants.PARAMETER_TYPE_MASTER \
            #         and ((activity_name == ActivityEnum.SEARCH.value and ((datafield.get('pre_setting') or dict()).get('search_field') or False)) \
            #             or (activity_name != ActivityEnum.SEARCH.value and ((datafield.get('pre_setting') or dict()).get('top_field') or False))):
            if parameter_type == ActivityConstants.PARAMETER_TYPE_MASTER \
                    and (activity_name == ActivityEnum.SEARCH.value and ((datafield.get('pre_setting') or dict()).get('search_field') or False)):
                
                # Add Additional Attribute 'reference search fields' to list
                if activity_name == ActivityEnum.SEARCH.value and section_type == SectionEnum.CRITERIA.value:
                    reference_search_field = ('{}.{}'.format(reference_name, field_name) if reference_name is not None else field_name)
                    self.attr_reference_search_fields.add(reference_search_field)

                component_kwargs = {
                    'parent_field_name': parent_field_name,
                    'parent_field_type': parent_field_type,
                    'filter_field_name': filter_field_name,
                    'activity_name': activity_name,
                    'condition': condition,
                    'auto_search': relative_component_type in ('popuplist', 'creatable_popuplist'),
                    'virtual_name': self.virtual_name,
                    'field_id': field_id
                }

                if is_multiple:
                    return ComponentReferenceMultipleValue.name, ComponentReferenceMultipleValue.attributes_by_parameter_reference(field_name
                                                                                        , parameter_reference
                                                                                        , **component_kwargs)
                return ComponentReference.name, ComponentReference.attributes_by_parameter_reference(field_name
                                                                                        , parameter_reference
                                                                                        , **component_kwargs)

            if relative_component_type in ('dropdown'):
                component_kwargs = {
                    'parent_field_name': parent_field_name,
                    'parent_field_type': parent_field_type,
                    'filter_field_name': filter_field_name,
                    'activity_name': activity_name,
                    'show_reference_code': show_reference_code,
                    'delimiter': ' ' if parameter_type == ActivityConstants.PARAMETER_TYPE_MASTER else None,
                    'condition': condition,
                    'use_cache': (parameter_type == ActivityConstants.PARAMETER_TYPE_PUBLIC),
                    'default_value': default_value,
                    'virtual_name': self.virtual_name,
                    'field_id': field_id
                }

                if is_multiple:
                    return ComponentDropdownMultipleValue.name, ComponentDropdownMultipleValue.attributes_by_parameter_reference(field_name
                                                                                        , parameter_reference
                                                                                        , **component_kwargs)
                if relative_component_type == 'dropdown':
                    return ComponentDropdown.name, ComponentDropdown.attributes_by_parameter_reference(field_name
                                                                                        , parameter_reference
                                                                                        , **component_kwargs)

            if relative_component_type in ('popup', 'popuplist', 'creatable_popup', 'creatable_popuplist'):
                component_kwargs = {
                    'parent_field_name': parent_field_name,
                    'parent_field_type': parent_field_type,
                    'filter_field_name': filter_field_name,
                    'activity_name': activity_name,
                    'condition': condition,
                    'auto_search': relative_component_type in ('popuplist', 'creatable_popuplist'),
                    'virtual_name': self.virtual_name,
                    'field_id': field_id
                } 

                if relative_component_type in ('popup', 'popuplist') and is_multiple:
                    return ComponentSearchAnyFieldMultipleValue.name, ComponentSearchAnyFieldMultipleValue.attributes_by_parameter_reference(field_name
                                                                                        , parameter_reference
                                                                                        , **component_kwargs)
                if relative_component_type in ('popup', 'popuplist'):
                    return ComponentSearchAnyField.name, ComponentSearchAnyField.attributes_by_parameter_reference(field_name
                                                                                        , parameter_reference
                                                                                        , **component_kwargs)
                if relative_component_type in ('creatable_popup', 'creatable_popuplist') and is_multiple:
                    return ComponentSearchAnyFieldMultipleValue.name, ComponentSearchAnyFieldMultipleValue.attributes_by_parameter_reference(field_name
                                                                                        , parameter_reference
                                                                                        , **component_kwargs)
                if relative_component_type in ('creatable_popup', 'creatable_popuplist'):
                    return ComponentCreatableSearchAnyField.name, ComponentCreatableSearchAnyField.attributes_by_parameter_reference(field_name
                                                                                        , parameter_reference
                                                                                        , **component_kwargs)

        # Data Type: Number
        if field_type in ('integer', 'decimal'):
            number_format = (datafield.get('pre_setting') or dict()).get('number_format')
            number_unit = (datafield.get('pre_setting') or dict()).get('number_unit')
            attributes = {
                'format': number_format,
                'unit': number_unit,
                'default_value': default_value,
            }
            return ComponentNumber.name, ComponentNumber.attributes(**attributes)


        # Data Type: Text
        if field_type == 'text':
            text_component_type = (datafield.get('pre_setting') or dict()).get('text_component')
            max_character = datafield.get('maxLength')
            text_format = (datafield.get('pre_setting') or dict()).get('text_format')

            if text_component_type == 'textarea':
                return ComponentTextarea.name, ComponentTextarea.attributes(max_character=max_character)

            elif text_component_type == 'richtext':
                return ComponentRichText.name, ComponentRichText.attributes(max_character=max_character)
            
            return ComponentTextbox.name, ComponentTextbox.attributes(**{
                'type': field_type,
                'splitter': (',' if is_multiple else None),
                'encrypt': is_encrypt,
                'default_value': default_value,
                'text_format': text_format,
            })


        # Data Type: Datetime
        if field_type == 'datetime':
            display_type = (datafield.get('pre_setting') or dict()).get('datetime_display_type')
            year_format = (datafield.get('pre_setting') or dict()).get('datetime_year_format')
            calendar_language = 'en' if year_format == 'AD' else ('th' if year_format == 'BE' else None)
            default_value = default_value.lower().strip() if default_value else ''
            is_default_date = True if default_value.startswith('current_date') else False
            business_days, default_time = '', ''
            if is_default_date:
                business_days = default_value.replace('current_date', '').strip()
                if ':' in default_value: # default time
                    default_time = business_days.split()[-1]
                    business_days = business_days.replace(default_time, '').strip()
            if activity_name == ActivityEnum.SEARCH.value and section_type == SectionEnum.CRITERIA.value:
                return ComponentDateBetween.name, ComponentDateBetween.attributes()
            if display_type == 'T':
                return ComponentTimePicker.name, ComponentTimePicker.attributes(default_value=default_value)
            if display_type == 'DnT':
                return ComponentDatetimePicker.name, ComponentDatetimePicker.attributes(calendar_language=calendar_language 
                                                                                            , is_default=is_default_date
                                                                                            , business_days=business_days
                                                                                            , default_time=default_time)
            if activity_name == ActivityEnum.CREATE.value and field_name == ActivityConstants.TECHNICAL_FIELD_EFFECTIVE_DATE:
                return ComponentDatePicker.name, ComponentDatePicker.attributes(calendar_language=calendar_language, is_default=True)
            if field_name in ActivityConstants.TECHNICAL_FIELDS and field_name != ActivityConstants.TECHNICAL_FIELD_EFFECTIVE_DATE:
                return ComponentDatetimePicker.name, ComponentDatetimePicker.attributes(calendar_language=calendar_language
                                                                                            , is_default=is_default_date
                                                                                            , business_days=business_days
                                                                                            , default_time=default_time)
            return ComponentDatePicker.name, ComponentDatePicker.attributes(calendar_language=calendar_language
                                                                                            , is_default=is_default_date
                                                                                            , business_days=business_days)


        # Data Type: Boolean
        if field_type == 'boolean':
            toggle_description = (datafield.get('pre_setting') or dict()).get('toggle_desc') or None
            hide_unassigned = (datafield.get('pre_setting') or dict()).get('toggle_hide_unassigned') or False
            default_value = default_value.lower() if default_value is not None else default_value
            return ComponentRadioButtom.name, ComponentRadioButtom.attributes(label_format=toggle_description, display_unassigned=(not hide_unassigned), default_value=default_value)


        # Data Type: Document
        if field_type == 'document':
            return ComponentCameraUpload.name, ComponentCameraUpload.attributes(self.dataset_name, multiple=is_multiple)


        # Data Type: Location
        if field_type == 'location':
            return ComponentMap.name, ComponentMap.attributes()


        return self.default_component_name, dict()

    
    def _get_standard_mandatory(self, activity_name, section_type, field_name):
        if activity_name == ActivityEnum.SEARCH.value and section_type == SectionEnum.CRITERIA.value:
            return False
        if activity_name == ActivityEnum.SEARCH.value and section_type == SectionEnum.DATA.value:
            return False
        return None


    def _adjust_common_attributes(self, activity_name, section_type, datafield, component_name, attributes):
        if 'appearance' not in attributes:
            if activity_name == ActivityEnum.CREATE.value:
                if self.standard_process.code in (StandardProcessEnum.I9.value, StandardProcessEnum.I12.value) \
                        and datafield.get('name') == ActivityConstants.TECHNICAL_FIELD_EFFECTIVE_DATE:
                    attributes['appearance'] = 'input'  
                elif datafield.get('name') in ActivityConstants.TECHNICAL_FIELDS:
                    attributes['appearance'] = 'display'
                else:
                    attributes['appearance'] = 'input'
            elif activity_name == ActivityEnum.UPDATE.value:
                attributes['appearance'] = 'input'
            elif activity_name == ActivityEnum.SEARCH.value and section_type == SectionEnum.CRITERIA.value:
                attributes['appearance'] = 'search'
            elif activity_name == ActivityEnum.SEARCH.value and section_type == SectionEnum.DATA.value:
                attributes['appearance'] = 'display'
            elif activity_name == ActivityEnum.VIEW.value:
                attributes['appearance'] = 'display'

        if 'placeholder' not in attributes:
            if activity_name == ActivityEnum.SEARCH.value and section_type == SectionEnum.CRITERIA.value:
                override_label = (datafield.get('pre_setting') or dict()).get('label')
                attributes['placeholder'] = override_label or datafield['label_th']

        if 'description' not in attributes:
            if component_name in (ComponentReference.name, ComponentReferenceMultipleValue.name \
                                    , ComponentSearchAnyField.name, ComponentSearchAnyFieldMultipleValue.name):
                override_label = (datafield.get('pre_setting') or dict()).get('label')
                attributes['description'] = override_label or datafield['label_th']
        
        if 'show-popover' not in attributes:
            hint_message = None
            if activity_name != ActivityEnum.SEARCH.value:
                hint_message = (datafield.get('pre_setting') or dict()).get('hint')
            elif section_type == SectionEnum.CRITERIA.value:
                hint_message = (datafield.get('pre_setting') or dict()).get('hint_search')

            if hint_message:
                attributes['show-popover'] = True
                attributes['popover-message'] = hint_message

        return attributes


    def _is_hide_widget_area(self, component_name):
        return component_name in (ComponentAutogenUCID.name)


    def _is_whole_line_component(self, component_name):
        return component_name in (ComponentSearchAnyField.name, ComponentSearchAnyFieldMultipleValue.name \
                                    , ComponentReference.name, ComponentReferenceMultipleValue.name \
                                    , ComponentCameraUpload.name, ComponentFileUpload.name \
                                    , ComponentMap.name)

    
    def _get_attributes_by_component(self, component_name, adjusted_attributes):
        attributes = dict()

        if component_name == ComponentDropdown.name:
            attributes = ComponentDropdown.attributes()
        elif component_name == ComponentDropdownMultipleValue.name:
            attributes = ComponentDropdownMultipleValue.attributes()
        elif component_name == ComponentDatePicker.name:
            attributes = ComponentDatePicker.attributes()
        elif component_name == ComponentTimePicker.name:
            attributes = ComponentTimePicker.attributes()
        elif component_name == ComponentDatetimePicker.name:
            attributes = ComponentDatetimePicker.attributes()
        elif component_name == ComponentDateBetween.name:
            attributes = ComponentDateBetween.attributes()
        elif component_name == ComponentAutogenUCID.name:
            attributes = ComponentAutogenUCID.attributes()
        elif component_name == ComponentCameraUpload.name:
            attributes = ComponentCameraUpload.attributes()
        elif component_name == ComponentFileUpload.name:
            attributes = ComponentFileUpload.attributes()
        elif component_name == ComponentSearchAnyField.name:
            attributes = ComponentSearchAnyField.attributes()
        elif component_name == ComponentSearchAnyFieldMultipleValue.name:
            attributes = ComponentSearchAnyFieldMultipleValue.attributes()
        elif component_name == ComponentReference.name:
            attributes = ComponentReference.attributes()
        elif component_name == ComponentReferenceMultipleValue.name:
            attributes = ComponentReferenceMultipleValue.attributes()
        elif component_name == ComponentEmbeddedDisplay.name:
            attributes = ComponentEmbeddedDisplay.attributes()
        elif component_name == ComponentToggle.name:
            attributes = ComponentToggle.attributes()
        elif component_name == ComponentMap.name:
            attributes = ComponentMap.attributes()
        elif component_name == ComponentSignature.name:
            attributes = ComponentSignature.attributes()

        for key in adjusted_attributes:
            attributes[key] = adjusted_attributes[key]

        return attributes


    def _get_related_dataset_metadata(self, related_dataset_name):
        if related_dataset_name not in self.related_dataset_metadata:
            self.related_dataset_metadata[related_dataset_name] = Metadata.get(None, related_dataset_name)
        return self.related_dataset_metadata[related_dataset_name]
