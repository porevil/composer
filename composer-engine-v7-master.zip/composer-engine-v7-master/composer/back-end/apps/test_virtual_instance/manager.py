import json
import re
import traceback
import uuid

from datetime import datetime
from django.db import transaction

from apps.commons.connectors.metadata import Metadata
from apps.commons.utilities.log import Logger
from apps.commons.generator.constants import GeneratingType, InstanceRole, Activity
from apps.routines.models import Routine, ActivityConfiguration, RoutineTags
from apps.metadata.models import Dataset
from apps.generator_setting.models import VirtualGroup
from apps.rules.models import TemplateRule
from apps.test_virtual_instance.pre_defined_multiple_dataset import PreDefinedMultipleDatasetActivities 
from apps.commons.generator.configuration.pre_defined_single_dataset import PreDefinedSingleDatasetActivities
from apps.commons.generator.configuration.user_defined import UserDefinedActivities


class VirtualConfigurationManager:
    LOGGER = Logger('Configuration Manager')

    def __init__(self, reference_id=None):
        try:
            self.dataset_cache = dict()
            self.reference_id = reference_id or uuid.uuid4()
        except Exception as e:
            raise e


    def generate(self, standard_process, dataset_name, generating_type, generating_tag=None, additional_config=dict(), executed_by=None):
        try:
            dataset_repository = VirtualGroup.objects.filter(name=dataset_name).first()
            if dataset_repository is None:
                raise Exception('dataset_name ({}) is invalid').format(dataset_name)

            dataset = Dataset.objects.filter(dataset_name=dataset_name).first()
            if dataset is not None:
                raise Exception('dataset name - {} same in meta dataset'.format(dataset_name))

            main_dataset_name = dataset_repository.main_dataset_name

            dataset = Dataset.objects.filter(dataset_name=main_dataset_name).first()
            if dataset is None:
                raise Exception('main dataset name - {} not found in dataset'.format(main_dataset_name))

            dataset_version = dataset.version

            routine_code = '{}_{}'.format(standard_process.code, dataset_name)
            routine_name = dataset_repository.description
            routine_description = '{} {}'.format(standard_process.name, routine_name)

            virtual_name = dataset_name

            # Generate configuration
            common_configuration, activities_configuration = self.generate_configuration(standard_process, \
                                                                                         virtual_name, \
                                                                                         generating_type, \
                                                                                         additional_config)

            # Get generating tag
            if generating_tag is None:
                generating_tag = RoutineTags.next()

            # Create or Update routine, document narrative, activity configuration
            with transaction.atomic():
                # routine
                routine_data = {
                    'code': routine_code,
                    'name': routine_name,
                    'description': routine_description,
                    'dataset_version': dataset_version,
                    'data': common_configuration,
                    'template': standard_process.template,
                    'generating_type': generating_type,
                    'generating_tag': generating_tag,
                    'adjusted': False,
                    'build_with_generating_tag': False,
                }

                routine, created = Routine.objects.update_or_create(
                    dataset_name=dataset_name,
                    generating_type=generating_type,
                    standard_process=standard_process,
                    defaults=routine_data)

                for activity in Activity:
                    activity_data = activities_configuration.get(activity.value) or dict()
                    ActivityConfiguration.objects.update_or_create(routine=routine, activity=activity.value, defaults={
                        'data': activity_data,
                    })

            return routine
        except Exception as e:
            traceback.print_exc()
            raise e


    def _get_dataset_metadata(self, dataset_name):
        try:
            if self.dataset_cache.get(dataset_name) is None:
                self.dataset_cache[dataset_name] = Metadata.get(None, dataset_name)
            return self.dataset_cache.get(dataset_name)
        except Exception as e:
            VirtualConfigurationManager.LOGGER.error('get dataset metadata | exception: {}'.format(str(e)))
            raise e


    def generate_configuration(self, standard_process, virtual_name, generating_type, additional_config=dict()):
        try:
            standard_process_code = standard_process.code
            virtual_group = VirtualGroup.objects.filter(name=virtual_name).first()
            main_dataset_name = virtual_group.main_dataset_name

            # Get dataset metadata
            dataset_metadata = self._get_dataset_metadata(main_dataset_name)

            # Generate common configuration
            common_configuration = {
                'dataset': {
                    'dataset_name': dataset_metadata['dataset_name'],
                    'description': dataset_metadata['description'],
                    'haveJournal': dataset_metadata['journal'],
                    'table_type': dataset_metadata['table_type'],
                    'group_type': dataset_metadata['group_type'],
                    'dataset_type': dataset_metadata.get('dataset_type') or '',
                    'journal': {
                        'key': 1,
                        'desc': 'Present',
                    }
                },
                'template_attributes': self._template_predict(generating_type, standard_process_code,
                                                              main_dataset_name) or dict(),
            }

            # Generate activity configuration
            activities_configuration, additional_configuration = self._get_activities_configuration(standard_process,
                                                                                                    virtual_name,
                                                                                                    generating_type,
                                                                                                    additional_config)

            common_configuration.update(additional_configuration)

            return common_configuration, activities_configuration
        except Exception as e:
            VirtualConfigurationManager.LOGGER.error(
                'Generate configuration [reference id = {}] exception: {}'.format(self.reference_id, str(e)))
            raise e
    

    def _get_activities_configuration(self, standard_process, virtual_name, generating_type, additional_config=dict()):
        try:
            if generating_type == GeneratingType.PreDefinedSingleDataset.value:
                raise Exception('Single dataset not support')
                
            elif generating_type == GeneratingType.PreDefinedMultipleDataset.value:
                return PreDefinedMultipleDatasetActivities(standard_process, virtual_name, self.reference_id).generate(
                    additional_config)

            elif generating_type == GeneratingType.UserDefined.value:
                raise Exception('User defined not support')

        except Exception as e:
            VirtualConfigurationManager.LOGGER.error(
                'get activities configuration [reference id = {}] exception: {}'.format(self.reference_id, str(e)))
            raise e


    def _template_predict(self, generating_type, standard_process_code, dataset_name):
        try:
            # set up rule configuration
            decision_model = dict()
            template_rules = TemplateRule.objects.all()
            for template_rule in template_rules:
                template_rule_generating_type = str(template_rule.generating_type or 'default')
                template_rule_standard_process_name = template_rule.standard_process_name or 'default'
                template_rule_dataset = template_rule.dataset or 'default'
                template_rule_attributes = template_rule.attributes

                if template_rule_generating_type not in decision_model:
                    decision_model[template_rule_generating_type] = dict()

                if template_rule_standard_process_name not in decision_model[template_rule_generating_type]:
                    decision_model[template_rule_generating_type][template_rule_standard_process_name] = dict()

                decision_model[template_rule_generating_type][template_rule_standard_process_name][template_rule_dataset] = template_rule_attributes

            # decision
            generating_type = str(generating_type) if generating_type is not None else None
            output = None

            try:
                if generating_type in decision_model and standard_process_name in decision_model[generating_type] \
                        and dataset in decision_model[generating_type][standard_process_name]:
                    output = decision_model[generating_type][standard_process_name][dataset]

                elif generating_type in decision_model and standard_process_name in decision_model[generating_type] \
                        and 'default' in decision_model[generating_type][standard_process_name]:
                    output = decision_model[generating_type][standard_process_name]['default']

                elif generating_type in decision_model and 'default' in decision_model[generating_type] \
                        and dataset in decision_model[generating_type][standard_process_name]:
                    output = decision_model[generating_type]['default'][dataset]

                elif 'default' in decision_model and standard_process_name in decision_model[generating_type] \
                        and dataset in decision_model[generating_type][standard_process_name]:
                    output = decision_model['default'][standard_process_name][dataset]

                elif generating_type in decision_model and 'default' in decision_model[generating_type] \
                        and 'default' in decision_model[generating_type][standard_process_name]:
                    output = decision_model[generating_type]['default']['default']

                elif 'default' in decision_model and standard_process_name in decision_model[generating_type] \
                        and 'default' in decision_model[generating_type][standard_process_name]:
                    output = decision_model['default'][standard_process_name]['default']

                elif 'default' in decision_model and 'default' in decision_model[generating_type] \
                        and dataset in decision_model[generating_type][standard_process_name]:
                    output = decision_model['default']['default'][dataset]

                elif 'default' in decision_model and 'default' in decision_model[generating_type] \
                        and 'default' in decision_model[generating_type][standard_process_name]:
                    output = decision_model['default']['default']['default']

                if output is None:
                    raise Exception('Not found')

                return output['attributes']
            except:
                return None

        except Exception as e:
            VirtualConfigurationManager.LOGGER.error('template predict | exception: {}'.format(str(e)))
            raise e
