import copy

from apps.commons.generator.configuration.constants import ActivityConstants
from apps.generator_setting.models import VirtualDatafieldConfig
from apps.generator_setting.models import DatasetSetting
from apps.commons.connectors.metadata import Metadata
from apps.metadata.models import Datafield


class Singleton:
    __instance = None
    __dataset_cache = dict()

    @staticmethod
    def get_dataset_metadata(dataset_name):
        try:
            if Singleton.__instance == None:
                Singleton()

            if Singleton.__dataset_cache.get(dataset_name) is None:
                Singleton.__dataset_cache[dataset_name] = Metadata.get(None, dataset_name)

            return Singleton.__dataset_cache.get(dataset_name)
        except Exception as e:
            raise e

    def __init__(self):
        if Singleton.__instance != None:
            raise Exception("This class is a singleton!")
        else:
            Singleton.__instance = self


class ActivityUtilities:

    @staticmethod
    def get_flat_datafields_by_dataset_metadata(virtual_name, main_dataset_name, parent_field_id=None):
        try:
            virtual_configurations = VirtualDatafieldConfig.objects.filter(element_id__group_id__name=virtual_name)
            
            if parent_field_id is not None:
               virtual_configurations = list(filter(lambda vc: (vc.parent_virtual_config is not None) and 
                    (vc.parent_virtual_config.field_id_id == parent_field_id), virtual_configurations)) 

            else:
                virtual_configurations = list(filter(lambda vc: vc.parent_virtual_config is None 
                    , virtual_configurations))

            results = list()
            for virtual_configuration in virtual_configurations:
                dataset_name = virtual_configuration.field_id.dataset_id.dataset_name
                field_id = virtual_configuration.field_id_id
                field_name = virtual_configuration.field_id.field_name
                element_id = virtual_configuration.element_id_id

                if field_id in list(map(lambda r: r.get('field_id'), results)) or virtual_configuration.sequence is None:
                    continue
                
                pre_setting_field = dict()
                for key, value in virtual_configuration.config.items():
                    if type(value) is dict:
                        if 'overridden' in value:
                            virtual_configuration.config[key] = None
                            if value.get('overridden'):
                                virtual_configuration.config[key] = value.get('value')
                
                pre_setting_field[field_name] = virtual_configuration.config
                pre_setting_field[field_name]['sequence'] = virtual_configuration.sequence

                dataset_metadata = Singleton.get_dataset_metadata(dataset_name)
                datafields = dataset_metadata['fields']

                for datafield in datafields:
                    if field_name == datafield.get('name'):
                        parameter_type = datafield.get('parameter_type')
                        parameter_ref_metadata = (datafield.get('parameter_ref') or dict()).get('dataset')

                        if parameter_type in [ActivityConstants.PARAMETER_TYPE_MASTER, ActivityConstants.PARAMETER_TYPE_PUBLIC] \
                                and parameter_ref_metadata:
                            parameter_ref_dataset = (parameter_ref_metadata or dict()).get('dataset_name')
                            reference_name = ActivityUtilities.find_reference_field(field_name, parameter_ref_dataset, main_dataset_name)
                            
                            datafield['reference_name'] = reference_name

                        datafield['tisco_param'] = False    
                        datafield['element_id'] = element_id
                        datafield['field_id'] = field_id

                        # Add attributes (from pre-setting)
                        ActivityUtilities.add_pre_setting_attributes(datafield, pre_setting_field)

                        # Remove de unused attributes
                        ActivityUtilities.remove_de_unused_attributes(datafield)

                        results.append(datafield)
                        break

            return results

        except Exception as e:
            raise e


    @staticmethod
    def find_reference_field(field_name, child_dataset_name, main_dataset_name):
        if field_name is None or child_dataset_name is None:
            return None

        meta_datafields = Datafield.objects.filter(field_name=field_name, child_dataset_id__dataset_name=child_dataset_name)
        if not meta_datafields:
            return None

        for meta_datafield in meta_datafields:
            if meta_datafield.dataset_id.dataset_name == main_dataset_name:
                return None
                # return '{}'.format(meta_datafield.field_name)

        else:
            parent_meta_datafields = Datafield.objects.filter(child_dataset_id__dataset_name=field_name)
            for parent_meta_datafield in parent_meta_datafields:
                embed_field = ActivityUtilities.find_reference_field(parent_meta_datafield.field_name, parent_meta_datafield.dataset_id.dataset_name, main_dataset_name)

                if embed_field is not None:
                    return '{}.{}'.format(embed_field, parent_meta_datafield.field_name)
            else:
                return None


    @staticmethod
    def add_pre_setting_attributes(datafield, pre_setting_fields=dict()):
        pre_setting_field = pre_setting_fields.get(datafield.get('name')) or dict()

        datafield['pre_setting'] = {
            'sequence': pre_setting_field.get('sequence'),
            # 'top_field': pre_setting_field.get('top_field'),
            'search_field': pre_setting_field.get('search_field'),
            'result_field': pre_setting_field.get('result_field'),
            'business_reference': pre_setting_field.get('business_reference'),
            'uneditable': pre_setting_field.get('uneditable'),
            'end_line': pre_setting_field.get('end_line'),
            'data_dependency': pre_setting_field.get('data_dependency'),
            'dependency_filter': pre_setting_field.get('dependency_filter'),
            'autofill': pre_setting_field.get('autofill'),
            'autofill_field': pre_setting_field.get('autofill_field'),
            'label': pre_setting_field.get('label'),
            'hint': pre_setting_field.get('hint'),
            'hint_search': pre_setting_field.get('hint_search'),
            'default_value': pre_setting_field.get('default_value'),
            'text_component': pre_setting_field.get('text_component'),
            'number_format': pre_setting_field.get('number_format'),
            'text_format': pre_setting_field.get('text_format'),
            'number_unit': pre_setting_field.get('number_unit'),
            'datetime_display_type': pre_setting_field.get('datetime_display_type'),
            'datetime_year_format': pre_setting_field.get('datetime_year_format'),
            'toggle_desc': pre_setting_field.get('toggle_desc'),
            'toggle_hide_unassigned': pre_setting_field.get('toggle_hide_unassigned'),
            'relative_data_component': pre_setting_field.get('relative_data_component'),
            'relative_data_condition': pre_setting_field.get('relative_data_condition'),
        }



    @staticmethod
    def remove_de_unused_attributes(datafield):
        datafield.pop('sequence', None)
        datafield.pop('mark_search_field', None)
        datafield.pop('show_in_result_screen', None)
        datafield.pop('reference', None)
        datafield.pop('top', None)
        datafield.pop('end_line', None)
