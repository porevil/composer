import uuid
import threading
import os
import sys

from datetime import datetime
from rest_framework.response import Response
from rest_framework import status

from apps.commons.generator.constants import ActionAuthority
from apps.commons.utilities.log import Logger
from apps.commons.utilities.response import ResponseAPI
from apps.routines.models import Lot, Routine
from apps.configurations.models import SubState
from apps.console_output.models import ConsoleOutput
from apps.commons.generator.managers.common_instance import CommonInstanceManager
from apps.pre_defined_generator.views.automation import AutomationAPIView
from apps.commons.serializers import AbstractSerializer
from apps.commons.error.exception import *


class BuildAndPublishView(AutomationAPIView):
    response_meta = ResponseAPI()
    serializer_class = AbstractSerializer
    reference_id = str(uuid.uuid4())
    response_meta = ResponseAPI()
    logger = Logger('Automation API')
    logger.set_session_id(reference_id)

    def post(self, request):
        try:
            self.logger.set_user_id(self.current_userid(request))
            self.logger.debug('build and publish instances [reference id = {}] start'.format(self.reference_id))

            request_data = request.data
            self.logger.debug(
                'build and publish instances [reference id = {}] request data = {}'.format(self.reference_id,
                                                                                           request_data))

            lot_id = request_data.get('lot_id')
            instance_uuids = request_data.get('uuids')
            authorized_ticket = request_data.get('authorized_ticket')

            if lot_id is None:
                raise BadRequestException('"lot_id" is required')
            if instance_uuids is None:
                raise BadRequestException('"uuids" is required')
            if type(instance_uuids) != list:
                raise BadRequestException('"uuids" should be list')

            lot = Lot.objects.filter(id=lot_id).first()
            if lot is None:
                raise BadRequestException('"lot_id" is invalid')

            destination_sub_state = SubState.objects.filter(is_default=True).first()
            if destination_sub_state is None:
                raise BadRequestException('"destination_sub_state_id" is invalid')

            if destination_sub_state.need_authorized_ticket \
                    and (authorized_ticket is None or authorized_ticket.strip() == ''):
                raise BadRequestException('"authorized_ticket" is required')

            if not self.has_permission(request, ActionAuthority.BUILD.value):
                raise ActionUnAuthorizedException('not authorized to build')

            if destination_sub_state.is_production:
                if not self.has_permission(request, ActionAuthority.PUBLISH_PROD.value):
                    raise ActionUnAuthorizedException('not authorized to publish on production')
            elif destination_sub_state.is_pre_production:
                if not self.has_permission(request, ActionAuthority.PUBLISH_PRE_PROD.value):
                    raise ActionUnAuthorizedException('not authorized to publish on pre-production')
            else:
                if not self.has_permission(request, ActionAuthority.PUBLISH_NON_PROD.value):
                    raise ActionUnAuthorizedException('not authorized to publish on non-production')

            executed_by = self.current_username(request)
            console_output = self.get_console_output(lot, 'Build and Publish Instance to "{}"'.format(
                destination_sub_state.name), executed_by)
            threading.Thread(target=lambda: self.process(instance_uuids
                                                         , destination_sub_state
                                                         , console_output
                                                         , executed_by
                                                         , authorized_ticket)).start()
            response = self.response_meta.success('success', self.reference_id, {
                'console_output_id': console_output.id,
            })

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('build and publish instances [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug(
                'build and publish instances [reference id = {}] response = {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def process(self, instance_uuids, destination_sub_state, console_output, executed_by, authorized_ticket):
        try:
            success, error_list = CommonInstanceManager().build_and_publish(instance_uuids
                                                                            , destination_sub_state
                                                                            , console_output=console_output
                                                                            , executed_by=executed_by
                                                                            , authorized_ticket=authorized_ticket)
            console_output.append('complete')
            return success, error_list
        except Exception as e:
            console_output.append('fail with exception: {}'.format(str(e)))
            raise e
        finally:
            console_output.finish()


class RepublishView(AutomationAPIView):
    response_meta = ResponseAPI()
    serializer_class = AbstractSerializer
    reference_id = str(uuid.uuid4())
    logger = Logger('Automation API', 'Republish')
    logger.set_session_id(reference_id)

    def post(self, request):
        try:
            self.logger.set_user_id(self.current_userid(request))
            self.logger.debug('republish instances [reference id = {}] start'.format(self.reference_id))

            request_data = request.data
            self.logger.debug(
                'republish instances [reference id = {}] request data = {}'.format(self.reference_id, request_data))

            lot_id = request_data.get('lot_id')
            instance_uuids = request_data.get('uuids')
            destination_sub_state_id = request_data.get('destination_sub_state_id')
            authorized_ticket = request_data.get('authorized_ticket')

            if lot_id is None:
                raise BadRequestException('"lot_id" is required')
            if instance_uuids is None:
                raise BadRequestException('"uuids" is required')
            if type(instance_uuids) != list:
                raise BadRequestException('"uuids" should be list')
            if destination_sub_state_id is None:
                raise BadRequestException('"destination_sub_state_id" is required')

            lot = Lot.objects.filter(id=lot_id).first()
            if lot is None:
                raise BadRequestException('"lot_id" is invalid')

            destination_sub_state = SubState.objects.filter(id=int(destination_sub_state_id)).first()
            if destination_sub_state is None:
                raise BadRequestException('"destination_sub_state_id" is invalid')

            if destination_sub_state.need_authorized_ticket \
                    and (authorized_ticket is None or authorized_ticket.strip() == ''):
                raise BadRequestException('"authorized_ticket" is required')

            if destination_sub_state.is_production:
                if not self.has_permission(request, ActionAuthority.PUBLISH_PROD.value):
                    raise ActionUnAuthorizedException('not authorized to republish on production')
            elif destination_sub_state.is_pre_production:
                if not self.has_permission(request, ActionAuthority.PUBLISH_PRE_PROD.value):
                    raise ActionUnAuthorizedException('not authorized to republish on pre-production')
            else:
                if not self.has_permission(request, ActionAuthority.PUBLISH_NON_PROD.value):
                    raise ActionUnAuthorizedException('not authorized to republish on non-production')

            executed_by = self.current_username(request)
            console_output = self.get_console_output(lot,
                                                     'Republish Instance on "{}"'.format(destination_sub_state.name),
                                                     executed_by)
            threading.Thread(target=lambda: self.process(instance_uuids
                                                         , destination_sub_state
                                                         , console_output
                                                         , executed_by
                                                         , authorized_ticket)).start()

            response = self.response_meta.success('success', self.reference_id, {
                'console_output_id': console_output.id,
            })

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('republish instances [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug(
                'republish instances [reference id = {}] response = {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def process(self, instance_uuids, destination_sub_state, console_output, executed_by, authorized_ticket):
        try:
            success, error_list = CommonInstanceManager().republish(instance_uuids
                                                                    , destination_sub_state
                                                                    , console_output=console_output
                                                                    , executed_by=executed_by
                                                                    , authorized_ticket=authorized_ticket)
            console_output.append('complete')
            return success, error_list
        except Exception as e:
            console_output.append('fail with exception: {}'.format(str(e)))
            raise e
        finally:
            console_output.finish()


class MoveView(AutomationAPIView):
    response_meta = ResponseAPI()
    serializer_class = AbstractSerializer
    reference_id = str(uuid.uuid4())
    logger = Logger('Automation API', 'Move')
    logger.set_session_id(reference_id)

    def post(self, request):
        try:
            self.logger.set_user_id(self.current_userid(request))
            self.logger.debug('move instances [reference id = {}] start'.format(self.reference_id))

            request_data = request.data
            self.logger.debug(
                'move instances [reference id = {}] request data = {}'.format(self.reference_id, request_data))

            lot_id = request_data.get('lot_id')
            instance_uuids = request_data.get('uuids')
            source_sub_state_id = request_data.get('source_sub_state_id')
            destination_sub_state_id = request_data.get('destination_sub_state_id')
            authorized_ticket = request_data.get('authorized_ticket')

            if lot_id is None:
                raise BadRequestException('"lot_id" is required')
            if instance_uuids is None:
                raise BadRequestException('"uuids" is required')
            if type(instance_uuids) != list:
                raise BadRequestException('"uuids" should be list')
            if source_sub_state_id is None:
                raise BadRequestException('"source_sub_state_id" is required')
            if destination_sub_state_id is None:
                raise BadRequestException('"destination_sub_state_id" is required')

            lot = Lot.objects.filter(id=lot_id).first()
            if lot is None:
                raise BadRequestException('"lot_id" is invalid')

            source_sub_state = SubState.objects.filter(id=int(source_sub_state_id)).first()
            if source_sub_state is None:
                raise BadRequestException('"source_sub_state_id" is invalid')

            destination_sub_state = SubState.objects.filter(id=int(destination_sub_state_id)).first()
            if destination_sub_state is None:
                raise BadRequestException('"destination_sub_state_id" is invalid')
            if destination_sub_state.id not in (source_sub_state.next_sub_state_ids or list()):
                raise BadRequestException('"destination_sub_state_id" is invalid')

            if destination_sub_state.need_authorized_ticket \
                    and (authorized_ticket is None or authorized_ticket.strip() == ''):
                raise BadRequestException('"authorized_ticket" is required')

            if destination_sub_state.is_production:
                if not self.has_permission(request, ActionAuthority.PUBLISH_PROD.value):
                    raise ActionUnAuthorizedException('not authorized to move to production')
            elif destination_sub_state.is_pre_production:
                if not self.has_permission(request, ActionAuthority.PUBLISH_PRE_PROD.value):
                    raise ActionUnAuthorizedException('not authorized to move to pre-production')
            else:
                if not self.has_permission(request, ActionAuthority.PUBLISH_NON_PROD.value):
                    raise ActionUnAuthorizedException('not authorized to move to non-production')

            executed_by = self.current_username(request)
            console_output = self.get_console_output(lot,
                                                     'Move Instance from "{}" to "{}"'.format(source_sub_state.name,
                                                                                              destination_sub_state.name),
                                                     executed_by)
            threading.Thread(target=lambda: self.process(instance_uuids
                                                         , source_sub_state
                                                         , destination_sub_state
                                                         , console_output
                                                         , executed_by
                                                         , authorized_ticket)).start()

            response = self.response_meta.success('success', self.reference_id, {
                'console_output_id': console_output.id,
            })

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('move instances [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('move instances [reference id = {}] response = {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def process(self, instance_uuids, source_sub_state, destination_sub_state, console_output, executed_by,
                authorized_ticket):
        try:
            success, error_list = CommonInstanceManager().move(instance_uuids
                                                               , source_sub_state
                                                               , destination_sub_state
                                                               , console_output=console_output
                                                               , executed_by=executed_by
                                                               , authorized_ticket=authorized_ticket)
            console_output.append('complete')
            return success, error_list
        except Exception as e:
            console_output.append('fail with exception: {}'.format(str(e)))
            raise e
        finally:
            console_output.finish()


class RemoveView(AutomationAPIView):
    response_meta = ResponseAPI()
    serializer_class = AbstractSerializer
    reference_id = str(uuid.uuid4())
    logger = Logger('Automation API', 'Remove')
    logger.set_session_id(reference_id)

    def post(self, request):
        try:
            self.logger.set_user_id(self.current_userid(request))
            self.logger.debug('remove instances [reference id = {}] start'.format(self.reference_id))

            request_data = request.data
            self.logger.debug(
                'remove instances [reference id = {}] request data = {}'.format(self.reference_id, request_data))

            lot_id = request_data.get('lot_id')
            instance_uuids = request_data.get('uuids')
            destination_sub_state_id = request_data.get('destination_sub_state_id')
            authorized_ticket = request_data.get('authorized_ticket')

            if lot_id is None:
                raise BadRequestException('"lot_id" is required')
            if instance_uuids is None:
                raise BadRequestException('"uuids" is required')
            if type(instance_uuids) != list:
                raise BadRequestException('"uuids" should be list')
            if destination_sub_state_id is None:
                raise BadRequestException('"destination_sub_state_id" is required')

            lot = Lot.objects.filter(id=lot_id).first()
            if lot is None:
                raise BadRequestException('"lot_id" is invalid')

            sub_state = SubState.objects.filter(id=int(destination_sub_state_id)).first()
            if sub_state is None:
                raise BadRequestException('"destination_sub_state_id" is invalid')

            if sub_state.need_authorized_ticket \
                    and (authorized_ticket is None or authorized_ticket.strip() == ''):
                raise BadRequestException('"authorized_ticket" is required')

            if sub_state.is_production:
                if not self.has_permission(request, ActionAuthority.REMOVE_PROD.value):
                    raise ActionUnAuthorizedException('not authorized to remove on production')
            elif sub_state.is_pre_production:
                if not self.has_permission(request, ActionAuthority.REMOVE_PRE_PROD.value):
                    raise ActionUnAuthorizedException('not authorized to remove on pre-production')
            else:
                if not self.has_permission(request, ActionAuthority.REMOVE_NON_PROD.value):
                    raise ActionUnAuthorizedException('not authorized to remove on non-production')

            executed_by = self.current_username(request)
            console_output = self.get_console_output(lot, 'Remove Instance on "{}"'.format(sub_state.name), executed_by)
            threading.Thread(target=lambda: self.process(instance_uuids
                                                         , sub_state
                                                         , console_output
                                                         , executed_by
                                                         , authorized_ticket)).start()
            response = self.response_meta.success('success', self.reference_id, {
                'console_output_id': console_output.id,
            })

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('remove instances [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('remove instances [reference id = {}] response = {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def process(self, instance_uuids, sub_state, console_output, executed_by, authorized_ticket):
        try:
            success, error_list = CommonInstanceManager().remove(instance_uuids
                                                                 , sub_state
                                                                 , console_output=console_output
                                                                 , executed_by=executed_by
                                                                 , authorized_ticket=authorized_ticket)
            console_output.append('complete')
            return success, error_list
        except Exception as e:
            console_output.append('fail with exception: {}'.format(str(e)))
            raise e
        finally:
            console_output.finish()
