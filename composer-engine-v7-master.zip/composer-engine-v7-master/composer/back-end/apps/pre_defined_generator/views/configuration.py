import uuid
import threading
import itertools
import os
import sys
import traceback

from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status

from apps.commons.utilities.log import Logger
from apps.commons.utilities.response import ResponseAPI
from apps.commons.generator.constants import GeneratingType, StandardProcessType
from apps.commons.generator.constants import ActionAuthority
from apps.commons.generator.managers.configuration import ConfigurationManager
from apps.metadata.models import Dataset
from apps.routines.models import Routine, RoutineTags, Lot, LotRoutine, ActivityConfiguration
from apps.standard_process.models import StandardProcess
from apps.console_output.models import ConsoleOutput
from apps.generator_setting.models import VirtualGroup
from apps.pre_defined_generator.views.automation import AutomationAPIView
from apps.commons.serializers import AbstractSerializer
from apps.routines.api.serializers import AdjustActivitySerializer
from apps.commons.error.exception import *


class GenerateConfigurationView(AutomationAPIView):
    serializer_class = AbstractSerializer
    reference_id = str(uuid.uuid4())
    logger = Logger('Automation API', 'Generate Configuration')
    logger.set_session_id(reference_id)
    response_meta = ResponseAPI()

    def post(self, request):
        try:
            self.logger.set_user_id(self.current_userid(request))
            self.logger.debug('generate routines [reference id = {}] start'.format(self.reference_id))

            request_data = request.data
            self.logger.debug(
                'generate routines [reference id = {}] request data = {}'.format(self.reference_id, request_data))

            if not self.has_permission(request, ActionAuthority.GENERATE_CONFIG.value):
                raise ActionUnAuthorizedException('not authorized to generate configuration')

            lot_id = request_data.get('lot_id')
            if lot_id is None:
                raise BadRequestException('"lot_id" is required')

            lot = Lot.objects.filter(id=lot_id).first()
            if lot is None:
                raise BadRequestException('"lot_id" is invalid')

            executed_by = self.current_username(request)
            console_output = self.get_console_output(lot, 'Generate Configuration', executed_by)
            threading.Thread(target=lambda: self.process(lot, console_output, executed_by)).start()
            response = self.response_meta.success('success', self.reference_id, {
                'console_output_id': console_output.id,
            })

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('generate routines [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('generate routines [reference id = {}] response = {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    
    def process(self, lot, console_output, executed_by):
        try:
            self.logger.debug('generate pre-defined process [reference id = {}] start'.format(self.reference_id))

            lot_routines = LotRoutine.objects.filter(lot=lot)
            standard_process_ids = lot.standard_process_ids or list()
            dataset_names = lot.datasets or list()

            all_products = set(itertools.product(dataset_names, standard_process_ids))
            existing_products = set(
                map(lambda lr: (lr.routine.dataset_name, lr.routine.standard_process.id), lot_routines))
            generating_products = all_products.difference(existing_products)

            self.logger.debug(
                'generate pre-defined process [reference id = {}] generating products = {}'.format(self.reference_id,
                                                                                                   generating_products))

            generating_tag = RoutineTags.next()
            configuration_manager = ConfigurationManager(self.reference_id)

            total = len(generating_products)
            count = 0
            for generating_product in generating_products:
                try:
                    standard_process_code = '-'
                    dataset_name = generating_product[0]
                    standard_process_id = generating_product[1]

                    generating_type = GeneratingType.PreDefinedSingleDataset.value

                    virtual_group = VirtualGroup.objects.filter(name=dataset_name).first()
                    if virtual_group is not None:
                        generating_type = GeneratingType.PreDefinedMultipleDataset.value

                    standard_process = StandardProcess.objects.get(id=standard_process_id)
                    standard_process_code = standard_process.code or '-'
                    if generating_type == GeneratingType.PreDefinedMultipleDataset.value:
                        if standard_process.get_type().value != StandardProcessType.OUTPUT.value:
                            raise Exception('Multiple dataset not support {} standard process'.format(standard_process.get_type_name()))

                    self.logger.debug(
                        'generate pre-defined process [reference id = {}] generating = {}'.format(self.reference_id,
                                                                                                generating_product))
                    error_message = None
                    additional_config = dict()
                    routine = configuration_manager.generate(standard_process
                                                            , dataset_name
                                                            , generating_type
                                                            , generating_tag
                                                            , additional_config
                                                            , executed_by)
                    
                    # Check if routine in other lot, it shall be deleted
                    lot_routine = LotRoutine.objects.filter(routine=routine).first()
                    if lot_routine is not None and lot_routine.lot.id != lot.id:
                        lot_routine.delete()
                    lot_routine, created = LotRoutine.objects.update_or_create(lot=lot, routine=routine)

                except Exception as ie:
                    error_message = str(ie)
                    traceback.print_exc()
                    self.logger.error(
                        'generate pre-defined process [reference id = {}] generate (dataset={} standard process={}) exception: {}' \
                        .format(self.reference_id, dataset_name, standard_process_code, error_message))

                finally:
                    count = count + 1
                    message = 'success' if error_message is None else error_message
                    console_output.append('({}/{}) standard process = {} and dataset name = {} : {}' \
                                            .format(count, total, standard_process_code, dataset_name, message))

            # Clear, in case re-setting with delete standard_process or dataset
            lot_routines = LotRoutine.objects.filter(lot=lot)
            for lot_routine in lot_routines:
                routine = lot_routine.routine
                # if routine.generating_type == GeneratingType.PreDefinedMultipleDataset.value:
                #     if routine.virtual_name not in dataset_names or routine.standard_process.id not in standard_process_ids:
                #         lot_routine.delete()
                # else:
                if routine.dataset_name not in dataset_names or routine.standard_process.id not in standard_process_ids:
                    lot_routine.delete()

            console_output.append('complete')

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )
            
            self.logger.error('generate pre-defined process | exception: {}'.format(exception_message))
            console_output.append('fail with exception: {}'.format(exception_message))

        finally:
            console_output.finish()


class RegenerateConfigurationView(AutomationAPIView):
    serializer_class = AbstractSerializer
    reference_id = str(uuid.uuid4())
    logger = Logger('Automation API', 'Regenerate Configuration')
    logger.set_session_id(reference_id)
    response_meta = ResponseAPI()

    def post(self, request):
        try:
            self.logger.set_user_id(self.current_userid(request))
            self.logger.debug('regenerate routines [reference id = {}] start'.format(self.reference_id))

            request_data = request.data
            self.logger.debug(
                'regenerate routines [reference id = {}] request data = {}'.format(self.reference_id, request_data))

            if not self.has_permission(request, ActionAuthority.GENERATE_CONFIG.value):
                raise ActionUnAuthorizedException('not authorized to generate configuration')

            lot_id = request_data.get('lot_id')
            instance_uuids = request_data.get('uuids')

            if lot_id is None:
                raise BadRequestException('"lot_id" is required')
            if instance_uuids is None:
                raise BadRequestException('"uuids" is required')
            if type(instance_uuids) != list:
                raise BadRequestException('"uuids" should be list')

            lot = Lot.objects.filter(id=lot_id).first()
            if lot is None:
                raise BadRequestException('"lot_id" is invalid')

            executed_by = self.current_username(request)
            console_output = self.get_console_output(lot, 'Regenerate Configuration', executed_by)
            threading.Thread(target=lambda: self.process(instance_uuids, lot, console_output, executed_by)).start()
            
            response = self.response_meta.success('success', self.reference_id, {
                'console_output_id': console_output.id,
            })

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('regenerate routines [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('regenerate routines [reference id = {}] response = {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def process(self, instance_uuids, lot, console_output, executed_by):
        try:
            self.logger.debug('regenerate pre-defined process | start')

            generating_tag = RoutineTags.next()
            configuration_manager = ConfigurationManager(self.reference_id)

            total = len(instance_uuids)
            count = 0
            for instance_uuid in instance_uuids:
                try:
                    error_message = None
                    routine = Routine.objects.filter(uuid=instance_uuid).first()

                    if routine is None:
                        raise Exception('routine not found')

                    standard_process = routine.standard_process
                    # dataset_name = routine.virtual_name or routine.dataset_name
                    dataset_name = routine.dataset_name

                    if standard_process is None or dataset_name is None:
                        raise Exception('standard process or dataset name is null')

                    standard_process = StandardProcess.objects.get(id=standard_process.id)
                    additional_config = dict()

                    generating_type = GeneratingType.PreDefinedSingleDataset.value
                    virtual_group = VirtualGroup.objects.filter(name=dataset_name).first()
                    if virtual_group is not None:
                        generating_type = GeneratingType.PreDefinedMultipleDataset.value

                    configuration_manager.generate(standard_process
                                                   , dataset_name
                                                   , generating_type
                                                   , generating_tag
                                                   , additional_config
                                                   , executed_by)
                    
                except Exception as ie:
                    error_message = str(ie)
                    self.logger.error(
                        'regenerate pre-defined process | generate (dataset={} standard process={}) exception: {}' \
                        .format(dataset_name, standard_process.code, error_message))

                finally:
                    count = count + 1
                    message = 'success' if error_message is None else error_message
                    code = routine.code if routine is not None else '-'
                    console_output.append('({}/{}) "{}" (code: {}) : {}' \
                                          .format(count, total, instance_uuid, code, message))

            console_output.append('complete')

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('regenerate pre-defined process | exception: {}'.format(exception_message))
            console_output.append('fail with exception: {}'.format(exception_message))
            
        finally:
            console_output.finish()


class AdjustConfigurationView(APIView):
    serializer_class = AdjustActivitySerializer
    reference_id = str(uuid.uuid4())
    logger = Logger('Adjust Configuration')
    logger.set_session_id(reference_id)
    response_meta = ResponseAPI()

    def get(self, request, uuid=None):
        try:
            if uuid is None:
                raise BadRequestException('"uuid" is required')

            routine = Routine.objects.filter(uuid=uuid).first()
            if routine is None:
                raise BadRequestException('"uuid" is invalid')

            serializer = AdjustActivitySerializer(routine)

            response = self.response_meta.success('success', self.reference_id, serializer.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('get adjust configuration [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            return Response(response, status=status.HTTP_200_OK)

    def post(self, request):
        try:
            request_data = request.data
            routine_uuid = request_data.get('uuid')
            if routine_uuid is None:
                raise Exception('bad request : "uuid" is required')

            routine = Routine.objects.filter(uuid=routine_uuid).first()
            if routine is None:
                raise Exception('bad request : "routine_uuid" is invalid')

            activities = request_data.get('activities') or list()
            for activity in activities:
                activity_name = activity.get('name')
                activity_data = activity.get('data') or dict()

                activity_configuration, created = ActivityConfiguration.objects.update_or_create(
                    routine=routine,
                    activity=activity_name,
                    defaults={
                        'data': activity_data
                    })

            response = self.response_meta.success('success', self.reference_id, AdjustActivitySerializer(routine).data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('post adjust configuration [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            return Response(response, status=status.HTTP_200_OK)
