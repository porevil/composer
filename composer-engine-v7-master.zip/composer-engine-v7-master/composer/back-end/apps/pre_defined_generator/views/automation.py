from django.db import transaction

from apps.commons.utilities.common import CommonAPIView
# from apps.routines.models import LotConsoleOutput
from apps.console_output.models import ConsoleOutput


class AutomationAPIView(CommonAPIView):
    MAX_HISTORICAL_CONSOLE_OUTPUT = 25

    def get_console_output(self, lot, title, executed_by):
        # with transaction.atomic():
        #     historicle_console_outputs = LotConsoleOutput.objects.filter(lot=lot).order_by('console_output_id')
        #     historicle_console_output_size = len(historicle_console_outputs)

        #     if historicle_console_output_size >= self.MAX_HISTORICLE_CONSOLE_OUTPUT:
        #         over_record_size = historicle_console_output_size - self.MAX_HISTORICLE_CONSOLE_OUTPUT
        #         deleted_historicle_console_outputs = historicle_console_outputs[:over_record_size + 1]
        #         for historicle_console_output in deleted_historicle_console_outputs:
        #             console_output = historicle_console_output.console_output
        #             historicle_console_output.delete()
        #             console_output.delete()

        console_output = ConsoleOutput.objects.create(title=title, executed_by=executed_by)
        # LotConsoleOutput.objects.create(lot=lot, console_output=console_output)

        return console_output
