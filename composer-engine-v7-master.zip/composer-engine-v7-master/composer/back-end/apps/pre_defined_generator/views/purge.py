import uuid
import sys
import os
import threading

from rest_framework.response import Response
from rest_framework import status

from apps.pre_defined_generator.views.automation import AutomationAPIView
from apps.commons.utilities.log import Logger
from apps.commons.generator.constants import ActionAuthority
from apps.commons.generator.managers.common_instance import CommonInstanceManager
from apps.routines.models import Lot
from apps.commons.serializers import AbstractSerializer
from apps.commons.utilities.response import ResponseAPI
from apps.commons.error.exception import *


class PurgeView(AutomationAPIView):
    response_meta = ResponseAPI()
    serializer_class = AbstractSerializer
    reference_id = str(uuid.uuid4())
    logger = Logger('Automation API', 'Purge')
    logger.set_session_id(reference_id)

    def post(self, request):
        try:
            self.logger.debug('purge instances [reference id = {}] start'.format(self.reference_id))

            request_data = request.data
            self.logger.debug(
                'purge instances [reference id = {}] request data = {}'.format(self.reference_id, request_data))

            lot_id = request_data.get('lot_id')
            instance_uuids = request_data.get('uuids')

            if lot_id is None:
                raise BadRequestException('"lot_id" is required')
            if instance_uuids is None:
                raise BadRequestException('"uuids" is required')
            if type(instance_uuids) != list:
                raise BadRequestException('"uuids" should be list')

            lot = Lot.objects.filter(id=lot_id).first()
            if lot is None:
                raise BadRequestException('"lot_id" is invalid')

            if not self.has_permission(request, ActionAuthority.PURGE.value):
                raise ActionUnAuthorizedException('not authorized to purge')

            executed_by = self.current_username(request)
            console_output = self.get_console_output(lot, 'Purge Instance', executed_by)
            threading.Thread(target=lambda: self.process(instance_uuids, console_output)).start()
            response = self.response_meta.success('success', self.reference_id, {
                'console_output_id': console_output.id,
            })

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('purge instances [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('purge instances [reference id = {}] response = {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def process(self, instance_uuids, console_output):
        try:
            success, error_list = CommonInstanceManager().purge(instance_uuids, console_output=console_output)
            console_output.append('complete')
            return success, error_list

        except Exception as e:
            console_output.append('fail with exception: {}'.format(str(e)))
            raise e

        finally:
            console_output.finish()
