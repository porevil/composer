import uuid
import threading

from rest_framework.response import Response
from rest_framework import status

from apps.commons.utilities.common import CommonAPIView
from apps.commons.utilities.log import Logger
from apps.commons.generator.managers.configuration import ConfigurationManager
from apps.commons.generator.managers.common_instance import CommonInstanceManager
from apps.commons.generator.constants import GeneratingType
from apps.commons.generator.constants import StandardProcess as StandardProcessEnum
from apps.commons.utilities.response import ResponseAPI
from apps.configurations.models import SubState
from apps.routines.models import RoutineTags
from apps.standard_process.models import StandardProcess
from apps.console_output.models import ConsoleOutput
from apps.commons.serializers import AbstractSerializer


class GenerateUserDefinedView(CommonAPIView):
    serializer_class = AbstractSerializer
    reference_id = str(uuid.uuid4())
    logger = Logger('Genertor API', 'Generate user-defined')
    logger.set_session_id(reference_id)
    response_meta = ResponseAPI()

    def post(self, request):
        response = {}
        try:
            self.logger.set_user_id(self.current_userid(request))
            self.logger.debug('generate user-defined [reference id = {}] start'.format(self.reference_id))

            request_data = request.data or dict()
            self.logger.debug(
                'generate user-defined [reference id = {}] request data = {}'.format(self.reference_id, request_data))

            dataset_name = request_data.get('dataset_name')
            additional_config = request_data.get('additional_config') or dict()

            if dataset_name is None:
                raise Exception('bad request : "dataset_name" is required')

            sub_state = SubState.objects.filter(is_default=True).first()
            if sub_state is None:
                raise Exception('bad request: "sub_state" not exist')

            executed_by = self.current_username(request)
            console_output = ConsoleOutput.objects.create(title='Generate user-defined', executed_by=executed_by)
            threading.Thread(target=lambda: self.process(dataset_name
                                                         , sub_state
                                                         , additional_config
                                                         , console_output
                                                         , executed_by)).start()
            response = self.response_meta.success('success', self.reference_id, {
                'console_output_id': console_output.id,
            })
        except Exception as e:
            self.logger.error(
                'generate user-defined [reference id = {}] exception: {}'.format(self.reference_id, str(e)))
            response = self.get_error_response(str(e), None, self.reference_id)
        finally:
            self.logger.debug(
                'generate user-defined [reference id = {}] response = {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def process(self, dataset_name, sub_state, additional_config, console_output, executed_by):
        error_message = None
        try:
            self.logger.debug('generate user-defined process | start')
            standard_process_codes = [
                StandardProcessEnum.I9.value,
                StandardProcessEnum.O2.value,
                StandardProcessEnum.O3.value,
            ]

            generating_tag = RoutineTags.next()
            configuration_manager = ConfigurationManager(self.reference_id)
            common_instance_manager = CommonInstanceManager()

            total = len(standard_process_codes)
            count = 0
            for standard_process_code in standard_process_codes:
                self.logger.debug('generate user-defined process | generate {}'.format(standard_process_code))

                standard_process = StandardProcess.objects.filter(code=standard_process_code).first()
                if standard_process is None:
                    raise Exception('standard process "{}" not found'.format(standard_process_code))

                try:
                    error_message = None
                    routine = configuration_manager.generate(standard_process
                                                             , dataset_name
                                                             , GeneratingType.UserDefined.value
                                                             , generating_tag
                                                             , additional_config
                                                             , executed_by)

                    instance_uuid = str(routine.uuid)
                    success, error_list = common_instance_manager.build_and_publish([instance_uuid], sub_state)
                    if not success:
                        raise Exception(error_list[0]['message'])
                    self.logger.debug(
                        'generate user-defined process | generate {} success'.format(standard_process_code))

                except Exception as ie:
                    error_message = str(ie)
                    self.logger.error(
                        'generate user-defined process | generate {} exception: {}'.format(standard_process_code,
                                                                                           error_message))

                finally:
                    count = count + 1
                    message = 'success' if error_message is None else error_message
                    console_output.append('({}/{}) standard process = {} and dataset name = {} : {}' \
                                          .format(count, total, standard_process_code, dataset_name, message))

            console_output.append('complete')

        except Exception as e:
            self.logger.error('generate user-defined process | exception: {}'.format(str(e)))
            console_output.append('fail with exception: {}'.format(str(e)))

        finally:
            console_output.finish()
