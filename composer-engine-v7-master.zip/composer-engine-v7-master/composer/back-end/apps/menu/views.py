import uuid
import os
import sys

from apps.commons.utilities.log import Logger
from apps.commons.utilities.response import ResponseAPI
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from apps.authorization.models import Menu, UserProfile, ProfileMapping
from apps.authorization.api.serializers import MenuDetailSerializer
from apps.commons.error.exception import *
from apps.commons.logger.views import ViewLogger


def get_menu_mock():
    return [{
        'menu_sequence': 1,
        'menu_display_label': 'Dashboard',
        'menu_code': 'dashboard',
        'menu_name': 'dashboard',
        'type': 'simple',
        'submenus': [],
        'link': 'dashboard',
        'active': True
    }, {
        'menu_sequence': 2,
        'menu_display_label': 'Notifications',
        'menu_code': 'notifications',
        'menu_name': 'notifications',
        'type': 'simple',
        'submenus': [],
        'link': 'notifications',
        'active': False
    }, {
        'menu_sequence': 3,
        'menu_display_label': 'Generator Setting',
        'menu_code': 'generator_setting',
        'menu_name': 'generator_setting',
        'type': 'dropdown',
        'active': False,
        'submenus': [{
            'menu_display_label': "Datafield Setting",
            'link': "generator_setting/datafield"
        }, {
            'menu_display_label': "Dataset Setting",
            'link': "generator_setting/dataset"
        }, {
            'menu_display_label': "Virtual Setting",
            'link': "generator_setting/virtual"
        }],
    }, {
        'menu_sequence': 4,
        'menu_display_label': 'Common MBS',
        'menu_code': 'common_mbs',
        'menu_name': 'common_mbs',
        'type': 'dropdown',
        'active': False,
        'submenus': [{
            'menu_display_label': "Group",
            'link': "common_mbs/group"
        }, {
            'menu_display_label': "Generator",
            'link': "common_mbs/generator"
        }, {
            'menu_display_label': "Catalog",
            'link': "common_mbs/catalog"
        }, {
            'menu_display_label': "Repositories",
            'link': "common_mbs/repositorie"
        }],
    }, {
        'menu_sequence': 5,
        'menu_display_label': 'Custom MBS',
        'menu_code': 'custom_mbs',
        'menu_name': 'custom_mbs',
        'type': 'dropdown',
        'active': False,
        'submenus': [{
            'menu_display_label': "Generator",
            'link': "custom_mbs/generator"
        }, {
            'menu_display_label': "Catalog",
            'link': "custom_mbs/catalog"
        }, {
            'menu_display_label': "Repositories",
            'link': "custom_mbs/repositorie"
        }],
    }, {
        'menu_sequence': 6,
        'menu_display_label': 'Standard Template',
        'menu_code': 'standard_template',
        'menu_name': 'standard_template',
        'type': 'simple',
        'submenus': [],
        'link': 'standard_template',
        'active': False
    }, {
        'menu_sequence': 7,
        'menu_display_label': 'System Configuration',
        'menu_code': 'syystem_configuration',
        'menu_name': 'syystem_configuration',
        'type': 'dropdown',
        'submenus': [{
            'menu_display_label': "State",
            'link': "syystem_configuration/state"
        }, {
            'menu_display_label': "Sub State",
            'link': "syystem_configuration/sub_state"
        }, {
            'menu_display_label': "Instance Environment Variable",
            'link': "syystem_configuration/instance_environment_variable"
        }, {
            'menu_display_label': "Instance Development Specification",
            'link': "syystem_configuration/instance_environment_specification"
        }, {
            'menu_display_label': "Instance Development (EC2)",
            'link': "syystem_configuration/instance_environment_ec2"
        }],
        'link': 'syystem_configuration',
        'active': False
    }, {
        'menu_sequence': 8,
        'menu_display_label': 'Authority',
        'menu_code': 'authority',
        'menu_name': 'authority',
        'type': 'dropdown',
        'submenus': [{
            'menu_display_label': "Menu Mapping",
            'link': "authority/menu-mapping"
        }, {
            'menu_display_label': "Action Mapping",
            'link': "authority/action-mapping"
        }, {
            'menu_display_label': "Menu Configuration",
            'link': "authority/menu-configuration"
        }, {
            'menu_display_label': "Action Configuration",
            'link': "authority/action-configuration"
        }, {
            'menu_display_label': "User Profile",
            'link': "authority/user-profile"
        }],
        'link': 'authority',
        'active': False
    }, ]


def get_menu(role):
    menu_list = list()
    user_profile = UserProfile.objects.filter(role=role).first()
    if user_profile is None:
        return menu_list

    menus = Menu.objects.filter(is_active=True).order_by('sequence')
    for menu in menus:
        menu = MenuDetailSerializer(menu).data
        sub_menu_list = list()
        sub_menus = menu.pop('sub_menus') if menu.get('sub_menus') is not None else list()
        if sub_menus:
            for sub_menu in sub_menus:
                profile_mapping = ProfileMapping.objects.filter(user_profile=user_profile,
                                                                sub_menu__id=sub_menu['id'],
                                                                sub_menu__is_active=True).first()

                if profile_mapping is not None:
                    sub_menu_list.append(sub_menu)
            if sub_menu_list:
                menu['submenus'] = sub_menu_list
                menu_list.append(menu)
        else:
            profile_mapping = ProfileMapping.objects.filter(user_profile=user_profile, menu_id=menu['id']).first()
            if profile_mapping is not None:
                menu_list.append(menu)
    return menu_list


class MenuView(APIView, ViewLogger):

    def get(self, request, *args, **kwargs):
        reference_id = request.session_id
        response = None
        try:
            response_meta = ResponseAPI()
            result = get_menu(request.oidc_user.permission)

            self.logger.debug(
                'get menu [reference id = {}] user role = {}'.format(reference_id, request.oidc_user.permission))

            response = response_meta.success('success', reference_id, result)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error(
                'get menu [reference id = {}] exception - {}'.format(reference_id, exception_message))

        finally:
            self.logger.debug('get menu [reference id = {}] response = {}'.format(reference_id, None))
            return Response(response, status=status.HTTP_200_OK)
