import uuid
import os
import sys

from django.conf import settings
from rest_framework.response import Response
from rest_framework import status, generics

from apps.commons.logger.views import ViewLogger
from apps.commons.utilities.response import ResponseAPI
from apps.commons.serializers import AbstractSerializer


class EnvironmentVariable(generics.ListCreateAPIView, ViewLogger):
    serializer_class = AbstractSerializer
    response_meta = ResponseAPI()
    reference_id = str(uuid.uuid4())

    def get(self, request, *args, **kwargs):
        try:
            self.logger.debug('get environment variable [reference id = {}] start'.format(request.session_id))

            response = self.response_meta.success("success", request.session_id, {
                'okta_service_endpoint': settings.OKTA_SERVICE_ENDPOINT
            })

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , request.session_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('get environment variable  [reference id = {}] exception - {}'.format(request.session_id, exception_message))

        finally:
            self.logger.debug('get environment variable  [reference id = {}] response - {}'.format(request.session_id, response))
            return Response(response, status=status.HTTP_200_OK)
    