import uuid

from rest_framework import serializers

from apps.combined_instance.models import CombinedInstance
from apps.combined_instance.models import CombinedInstancePreSubmit
from apps.combined_instance.models import CombinedInstancePackage
from apps.combined_instance.models import CombinedInstanceRepository


class CombinedInstanceSerializer(serializers.ModelSerializer):
    class Meta:
        model = CombinedInstance
        fields = [
            'id',
            'uuid',
            'code',
            'name',
            'description',
            'base_instance_uuid',
            'base_instance_code',
            'base_instance_name',
            'base_instance_build_no',
            'dataset_name',
            'latest_build_no',
            'build_with_latest_adjustment',
            'data',
            'created_date',
            'updated_date',
        ]


class CombinedInstanceDetailSerializer(serializers.ModelSerializer):
    presubmit_services = serializers.SerializerMethodField()

    class Meta:
        model = CombinedInstance
        fields = [
            'id',
            'uuid',
            'code',
            'name',
            'description',
            'base_instance_uuid',
            'base_instance_code',
            'base_instance_name',
            'base_instance_build_no',
            'dataset_name',
            'data',
            # 'latest_build_no',
            # 'build_with_latest_adjustment',
            'presubmit_services',
            # 'created_date',
            # 'updated_date',
        ]

    def get_presubmit_services(self, obj):
        presubmit_services = CombinedInstancePreSubmit.objects.filter(combined_instance=obj).order_by('sequence')
        serializer = CombinedInstancePreSubmitSerializer(presubmit_services, many=True)
        return serializer.data


class CombinedInstancePreSubmitSerializer(serializers.ModelSerializer):
    class Meta:
        model = CombinedInstancePreSubmit
        fields = [
            'id',
            'sequence',
            'uuid',
            'combined_instance',
            'data',
        ]



class CombinedInstanceRepositorySerializer(serializers.ModelSerializer):
    class Meta:
        model = CombinedInstanceRepository
        fields = [
            'id',
            'uuid',
            'code',
            'name',
            'description',
            'build_no',
            'created_date',
            'updated_date',
        ]


class CombinedInstanceRepositoryDetailSerializer(serializers.ModelSerializer):
    build_data = serializers.SerializerMethodField()

    class Meta:
        model = CombinedInstanceRepository
        fields = [
            'id',
            'uuid',
            'code',
            'name',
            'description',
            'build_no',
            'build_data',
            'created_date',
            'updated_date',
        ]

    def get_build_data(self, obj):
        package = CombinedInstancePackage.objects.filter(uuid=obj.uuid, build_no=obj.build_no).first()
        if package:
            build_data = package.build_data
        else:
            build_data = {}
        return build_data
