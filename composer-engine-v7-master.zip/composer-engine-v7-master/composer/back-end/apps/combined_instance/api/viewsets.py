import json
import traceback
import uuid
import os
import sys

from django.db import transaction
import rest_framework_filters as filters
from rest_framework import viewsets, serializers, status
from rest_framework.response import Response
from apps.combined_instance.api.serializers import \
    CombinedInstanceRepositorySerializer, \
    CombinedInstanceRepositoryDetailSerializer, \
    CombinedInstanceSerializer, \
    CombinedInstanceDetailSerializer

from apps.combined_instance.models import CombinedInstance, \
    CombinedInstancePreSubmit, \
    CombinedInstanceRepository

from apps.commons.utilities.response import CustomJsonResponse, CustomResponseObject
from apps.commons.utilities.log import Logger
from apps.commons.error.exception import *
from apps.commons.utilities.response import ResponseAPI


def is_valid_uuid(request_uuid, version=4):
    try:
        uuid_obj = uuid.UUID(str(request_uuid), version=version)
    except ValueError:
        return False

    return str(uuid_obj) == request_uuid


class CombinedInstanceFilter(filters.FilterSet):
    class Meta:
        model = CombinedInstance
        fields = {
            'code': ['exact', 'startswith', 'contains', 'icontains'],
            'name': ['exact', 'startswith', 'contains', 'icontains'],
            'base_instance_code': ['exact', 'startswith', 'contains', 'icontains'],
            'base_instance_name': ['exact', 'startswith', 'contains', 'icontains'],
            'dataset_name': ['exact', 'startswith', 'contains'],
            'uuid': ['exact'],
        }


class CombinedInstanceViewSet(viewsets.ModelViewSet):
    queryset = CombinedInstance.objects.all().order_by('id')
    filter_class = CombinedInstanceFilter
    logger = Logger("Combined Instance Configuration")

    def get_serializer_class(self):
        if self.action == 'list':
            return CombinedInstanceSerializer
        if self.action == 'retrieve':
            return CombinedInstanceDetailSerializer
        return CombinedInstanceSerializer

    def create(self, request, **kwargs):
        try:
            with transaction.atomic():
                self.logger.debug("Request {}".format(request.data))
                request_data = request.data
                code = request_data.get('code')
                name = request_data.get('name')
                description = request_data.get('description')
                base_instance_uuid = request_data.get('base_instance_uuid')
                base_instance_code = request_data.get('base_instance_code')
                base_instance_name = request_data.get('base_instance_name')
                base_instance_build_no = request_data.get('base_instance_build_no')
                dataset_name = request_data.get('dataset_name')

                if not code:
                    raise BadRequestException('bad request : "code" is required')
                if not name:
                    raise BadRequestException('bad request : "name" is required')
                if not base_instance_uuid:
                    raise BadRequestException('bad request : "base_instance_uuid" is required')
                if not base_instance_code:
                    raise BadRequestException('bad request : "base_instance_code" is required')
                if not base_instance_name:
                    raise BadRequestException('bad request : "base_instance_name" is required')
                if not base_instance_build_no:
                    raise BadRequestException('bad request : "base_instance_build_no" is required')
                if not dataset_name:
                    raise BadRequestException('bad request : "dataset_name" is required')

                data = json.dumps(request_data.get('data', {}))

                # create 'combined instance'
                combined_instance = CombinedInstance.objects.create(**{
                    'code': code,
                    'name': name,
                    'description': description,
                    'base_instance_uuid': base_instance_uuid,
                    'base_instance_code': base_instance_code,
                    'base_instance_name': base_instance_name,
                    'base_instance_build_no': base_instance_build_no,
                    'dataset_name': dataset_name,
                    'data': data,
                    'latest_build_no': None,
                    'build_with_latest_adjustment': False,
                })

                presubmit_services = request_data.get('presubmit_services') or list()

                # create 'combined instance pre-submit services'
                for idx, presubmit in enumerate(presubmit_services):
                    CombinedInstancePreSubmit.objects.create(**{
                        'combined_instance': combined_instance,
                        'sequence': (idx + 1),
                        'uuid': presubmit.get('uuid'),
                        'data': presubmit.get('data'),
                    })

                return CustomJsonResponse(
                    session_id=self.logger.session_id,
                    status=status.HTTP_201_CREATED,
                    data=CombinedInstanceDetailSerializer(combined_instance).data)
        except Exception as e:
            traceback.print_exc()
            return CustomJsonResponse(status=status.HTTP_500_INTERNAL_SERVER_ERROR,
                                      session_id=self.logger.session_id,
                                      data=e)

    def update(self, request, pk=None, **kwargs):
        try:
            with transaction.atomic():
                request_data = request.data

                combined_instance = CombinedInstance.objects.filter(id=pk).first()
                if combined_instance is None:
                    raise BadRequestException('bad request : "id" is invalid')

                name = request_data.get('name')
                description = request_data.get('description')
                base_instance_uuid = request_data.get('base_instance_uuid')
                base_instance_code = request_data.get('base_instance_code')
                base_instance_name = request_data.get('base_instance_name')
                base_instance_build_no = request_data.get('base_instance_build_no')
                dataset_name = request_data.get('dataset_name')

                data = json.dumps(request_data.get('data'))
                # update 'combined instance'
                combined_instance.name = name
                combined_instance.description = description
                combined_instance.base_instance_uuid = base_instance_uuid
                combined_instance.base_instance_code = base_instance_code
                combined_instance.base_instance_name = base_instance_name
                combined_instance.base_instance_build_no = base_instance_build_no
                combined_instance.dataset_name = dataset_name
                combined_instance.data = data
                combined_instance.build_with_latest_adjustment = False
                combined_instance.save()

                presubmit_services = request_data.get('presubmit_services') or list()

                # create or update 'combined instance pre-submit services'
                _ids = list()
                for idx, presubmit in enumerate(presubmit_services):
                    _id = presubmit.get('id')
                    presubmit_sequence = (idx + 1)
                    presubmit_uuid = presubmit.get('uuid')
                    presubmit_data = presubmit.get('data')
                    presubmit_service = CombinedInstancePreSubmit.objects.filter(id=_id).first()

                    if presubmit_service is None:
                        presubmit_service = CombinedInstancePreSubmit.objects.create(**{
                            'combined_instance': combined_instance,
                            'sequence': presubmit_sequence,
                            'uuid': presubmit_uuid,
                            'data': presubmit_data,
                        })
                    else:
                        presubmit_service.sequence = presubmit_sequence
                        presubmit_service.uuid = presubmit_uuid
                        presubmit_service.data = presubmit_data
                        presubmit_service.save()
                    _ids.append(presubmit_service.id)

                # delete 'combined instance pre-submit services'
                deleted_presubmit_services = CombinedInstancePreSubmit.objects.filter(
                    combined_instance=combined_instance) \
                    .exclude(id__in=_ids)
                deleted_presubmit_services.delete()
                self.logger.debug(f"Before Response {combined_instance}")
                self.logger.debug("Response {}".format(CombinedInstanceDetailSerializer(combined_instance).data))
                return CustomJsonResponse(status=status.HTTP_200_OK,
                                          session_id=self.logger.session_id,
                                          data=CombinedInstanceDetailSerializer(combined_instance).data)
        except Exception as e:
            traceback.print_exc()
            return CustomJsonResponse(status=status.HTTP_500_INTERNAL_SERVER_ERROR,
                                      data=e,
                                      session_id=self.logger.session_id)

    def retrieve(self, request, *args, **kwargs):
        self.logger.debug(
            f'start get kwargs [{kwargs} {super().retrieve(request, *args, **kwargs)}] reference_id [{self.logger.session_id}]')
        model = self.get_object()
        serializer = CombinedInstanceDetailSerializer(model)
        response_data = serializer.data
        self.logger.debug(f'response detail [{response_data}] reference_id [{self.logger.session_id}]')

        return CustomJsonResponse(data=response_data)

    def list(self, request, **kwargs):
        try:
            request_params = request.query_params
            request_uuid = request_params.get('uuid')
            if request_uuid is not None and request_uuid:
                is_valid = is_valid_uuid(request_uuid)

                if not is_valid:
                    raise BadRequestException('"uuid" is invalid')

            queryset = self.get_queryset()
            queryset = self.filter_queryset(queryset)
            serializer = self.get_serializer_class()(queryset, many=True)

            return CustomJsonResponse(serializer.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            # exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = ResponseAPI().error(e, str(e), None, str(exc_type), fname, str(exc_tb.tb_lineno))
            return Response(response, status=status.HTTP_200_OK)

    def destroy(self, request, *args, **kwargs):
        try:
            super().destroy(request, *args, **kwargs)
            return CustomJsonResponse(description="Delete Success")
        except Exception as e:
            return CustomJsonResponse(data=e)


class CombinedInstanceRepositoryFilter(filters.FilterSet):
    pre_submit_instance_uuids = filters.CharFilter(lookup_expr='icontains')

    class Meta:
        model = CombinedInstanceRepository
        fields = {
            'code': ['exact', 'startswith', 'contains', 'icontains'],
            'name': ['exact', 'startswith', 'contains', 'icontains'],
            'base_instance_uuid': ['exact'],
            'uuid': ['exact'],
            'pre_submit_instance_uuids': []
        }


class CombinedInstanceRepositoryViewSet(viewsets.ModelViewSet):
    queryset = CombinedInstanceRepository.objects.all().order_by('id')
    filter_class = CombinedInstanceRepositoryFilter
    logger = Logger("Combined Instance Repository")

    def get_serializer_class(self):
        if self.action == 'list':
            return CombinedInstanceRepositorySerializer
        if self.action == 'retrieve':
            return CombinedInstanceRepositoryDetailSerializer
        return CombinedInstanceRepositorySerializer

    def list(self, request, **kwargs):
        response_data = None
        try:
            request_params = request.query_params
            request_uuid = request_params.get('uuid')
            if request_uuid is not None and request_uuid:
                is_valid = is_valid_uuid(request_uuid)

                if not is_valid:
                    raise BadRequestException('"uuid" is invalid')

            request_uuid = request_params.get('base_instance_uuid')
            if request_uuid is not None and request_uuid:
                is_valid = is_valid_uuid(request_uuid)

                if not is_valid:
                    raise BadRequestException('"base_instance_uuid" is invalid')

            queryset = self.get_queryset()
            queryset = self.filter_queryset(queryset)
            serializer = CombinedInstanceRepositoryDetailSerializer(queryset, many=True)

            response_data = CustomResponseObject(data=serializer.data, session_id=request.session_id).data
        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            # exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))
            response_data = ResponseAPI().error(e, str(e), None, str(exc_type), fname, str(exc_tb.tb_lineno))

        finally:
            return Response(response_data, status=status.HTTP_200_OK)

    def create(self, request, *args, **kwargs):
        response = super().create(request, *args, **kwargs)
        return CustomJsonResponse(data=response.data,
                                  description="Create Success"
                                  )

    def destroy(self, request, *args, **kwargs):
        response = super().create(request, *args, **kwargs)
        return CustomJsonResponse(data=response.data,
                                  description="Delete Success"
                                  )

    def update(self, request, *args, **kwargs):
        response_data = None
        try:
            response = super().update(request, *args, **kwargs)
            response_data = response.data
        except Exception as e:
            response_data = e
        finally:
            return CustomJsonResponse(data=response_data)

    def retrieve(self, request, *args, **kwargs):
        response_data = None
        try:
            response = super().create(request, *args, **kwargs)
            response_data = response.data
        except Exception as e:
            response_data = e
        finally:
            return CustomJsonResponse(data=response_data)
