from django.apps import AppConfig


class CombinedInstanceConfig(AppConfig):
    name = 'combined_instance'
