import json
import os
import sys
import uuid
import re
import traceback

from datetime import datetime
from django.db import transaction
from rest_framework import status
from rest_framework.response import Response

from apps.commons.utilities.log import Logger
from apps.commons.utilities.response import ResponseAPI
from apps.commons.utilities.common import CommonAPIView
from apps.commons.generator.constants import ActionAuthority
from apps.commons.generator.managers.combined_instance import CombinedInstanceManager
from apps.commons.serializers import AbstractSerializer
from apps.commons.error.exception import *


class BuildView(CommonAPIView):
    serializer_class = AbstractSerializer

    def post(self, request):
        reference_id = str(uuid.uuid4())
        logger = Logger('Combined Instance API', 'Build')
        logger.set_session_id(reference_id)
        response_meta = ResponseAPI
        
        try:
            logger.set_user_id(self.current_userid(request))
            logger.debug('build combined instances [reference id = {}] start'.format(reference_id))

            request_data = request.data or dict()
            logger.debug('build combined instances [reference id = {}] request data = {}'.format(reference_id, request_data))

            instance_uuid = request_data.get('uuid')

            if instance_uuid is None:
                raise BadRequestException('"uuid" is required')

            if not self.has_permission(request, ActionAuthority.BUILD.value):
                raise ActionUnAuthorizedException('not authorized to build')

            CombinedInstanceManager().build(instance_uuid)

            response = response_meta.success('success', reference_id, None)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = response_meta.error(e, str(e) , reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            logger.error('build combined instance [reference id = {}] exception - {}'.format(reference_id, exception_message))

        finally:
            logger.debug('build combined instance [reference id = {}] response = {}'.format(reference_id, response))
            return Response(response, status=status.HTTP_200_OK)


class PurgeView(CommonAPIView):
    serializer_class = AbstractSerializer

    def post(self, request):
        reference_id = str(uuid.uuid4())
        logger = Logger('Combined Instance API', 'Purge')
        logger.set_session_id(reference_id)
        response_meta = ResponseAPI
        
        try:
            logger.set_user_id(self.current_userid(request))
            logger.debug('purge combined instances [reference id = {}] start'.format(reference_id))

            request_data = request.data or dict()
            logger.debug('purge combined instances [reference id = {}] request data = {}'.format(reference_id, request_data))

            instance_uuid = request_data.get('uuid')

            if instance_uuid is None:
                raise BadRequestException('"uuid" is required')

            if not self.has_permission(request, ActionAuthority.PURGE.value):
                raise ActionUnAuthorizedException('not authorized to build')

            CombinedInstanceManager().purge(instance_uuid)

            response = response_meta.success('success', reference_id, None)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = response_meta.error(e, str(e) , reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            logger.error('purge combined instance [reference id = {}] exception - {}'.format(reference_id, exception_message))

        finally:
            logger.debug('purge combined instance [reference id = {}] response = {}'.format(reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

