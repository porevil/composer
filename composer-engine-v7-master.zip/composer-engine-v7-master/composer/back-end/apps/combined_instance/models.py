import reversion

from uuid import uuid4
from django.db import models
from django.contrib.postgres.fields import ArrayField, JSONField
from django.utils.translation import ugettext_lazy as _


class CombinedInstance(models.Model):
    uuid = models.UUIDField(db_index=True, default=uuid4, editable=False, unique=True)
    code = models.CharField(max_length=100, unique=False, verbose_name=_("Code"))
    name = models.CharField(max_length=150, verbose_name=_("Name"))
    description = models.TextField(blank=True, null=True, verbose_name=_("Description"))

    base_instance_uuid = models.UUIDField(null=True, verbose_name=_("Base Instance UUID"))
    base_instance_code = models.CharField(max_length=100, null=True, verbose_name=_("Base Instance Code"))
    base_instance_name = models.CharField(max_length=150, null=True, verbose_name=_("Base Instance Name"))
    base_instance_build_no = models.IntegerField(null=True, verbose_name=_("Base Instance Build No"))

    dataset_name = models.CharField(max_length=100, null=True, verbose_name=_("Dataset Name"))

    data = JSONField(default=dict, verbose_name=_("Data"))

    latest_build_no = models.PositiveIntegerField(null=True, verbose_name=_("Latest Build No"))
    build_with_latest_adjustment = models.BooleanField(default=False, verbose_name=_("Build with Latest Adjustment"))

    created_date = models.DateTimeField(auto_now_add=True)
    updated_date = models.DateTimeField(auto_now=True)

    def __str__(self):
        return "%s - %s" % (self.code, self.name)


class CombinedInstancePreSubmit(models.Model):

    combined_instance = models.ForeignKey(CombinedInstance, verbose_name=_("Combined Instance"), on_delete=models.CASCADE)
    sequence = models.PositiveIntegerField(verbose_name=_("Sequence"))
    uuid = models.UUIDField(editable=False)
    data = JSONField(default=dict, verbose_name=_("Configuration"))

    def __str__(self):
        return "%s - %s" % (self.combined_instance.code, self.combined_instance.name)


class CombinedInstancePackage(models.Model):
    uuid = models.UUIDField(db_index=True, null=True, verbose_name=_("UUID"))
    build_no = models.PositiveIntegerField(null=True, verbose_name=_("Build No"))
    build_data = JSONField(default=dict, verbose_name=_("Build Data"))


class CombinedInstanceRepository(models.Model):

    uuid = models.UUIDField(db_index=True, verbose_name=_("UUID"))
    code = models.CharField(db_index=True, max_length=100, verbose_name=_("Code"))
    name = models.CharField(max_length=150, verbose_name=_("Name"))
    description = models.TextField(blank=True, null=True, verbose_name=_("Description"))
    base_instance_uuid = models.UUIDField(null=True, verbose_name=_("Base Instance UUID"))
    pre_submit_instance_uuids = ArrayField(models.UUIDField(), default=list, blank=True,
                                           verbose_name=_("Pre-submit Instance UUIDS"))
    build_no = models.PositiveIntegerField(null=True, verbose_name=_("Build No"))
    combined_instance = models.ForeignKey(CombinedInstance, null=True, verbose_name=_("Combined Instance"), on_delete=models.CASCADE)

    created_date = models.DateTimeField(auto_now_add=True)
    updated_date = models.DateTimeField(auto_now=True)

    def __str__(self):
        return "%s - %s" % (self.code, self.name)
