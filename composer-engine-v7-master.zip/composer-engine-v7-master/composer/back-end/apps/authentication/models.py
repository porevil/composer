import jwt
import uuid
from apps.authorization.models import UserProfile, ProfileMapping
from django.db import models
from django.utils.timezone import now


class OpenIDUser(object):
    """User from id token"""

    def __init__(self, id_token: str):
        self.supper_admin_role = '47-4'
        id_token_info = jwt.decode(id_token, verify=False)
        self.full_name = id_token_info.get("name", " ")
        self.first_name = id_token_info.get("name", " ").split(" ")[0]
        self.last_name = id_token_info.get("name", " ").split(" ")[1]
        self.__permissions = id_token_info.get("47_group_name", [])
        self.id = id_token_info.get("user_id", None)
        self.email = id_token_info.get("email", None)
        self.erm_role = id_token_info.get("erm_role", None)
        self.preferred_username = id_token_info.get("preferred_username", None)
        self.id_token = id_token

        # 47-1, 47-2, {app_code}-{role_code}
        self.group_role = self.__get_group_role()
        self.permission = self.group_role

    def __get_group_role(self):
        """
        get single group role
        """
        priorities_role = UserProfile.objects.values_list('role')
        if len(self.__permissions) == 0:
            return None
        else:
            if self.supper_admin_role in self.__permissions:
                return self.supper_admin_role
                
            for role in priorities_role:
                if role[0] in self.__permissions:
                    return role[0]
            return None

    def has_permission(self, action_code):
        profile_mapping = ProfileMapping.objects.filter(action__code=action_code,
                                                        user_profile__role=self.permission).first()
        if profile_mapping:
            return True
        return False

    def __str__(self):
        return self.full_name


class JSONWebToken(models.Model):
    uuid = models.UUIDField(verbose_name="UUID", null=False, default=uuid.uuid4)
    id_token = models.TextField(verbose_name="ID Token", null=False)
    expired_at = models.DateTimeField(verbose_name="Expired Datetime", null=False, default=now)
    access_token = models.TextField(verbose_name="Access Token")
    refresh_token = models.TextField(verbose_name="Refresh Token")
