import jwt
import datetime
from .models import JSONWebToken
from django.test import TestCase

mock_id_token = {
    "sub": "00ucgtwsgd6bo1RAP1t7",
    "name": "User Test",
    "ver": 1,
    "iss": 'https://alpha-tisco.okta.com/oauth2/default',
    "aud": "0oadsyg55ohXur2HN1t7",
    "iat": 1589099883,
    "exp": 1589103483,
    "jti": "ID.6oHaO4oMaPDcrs3NfEc3ZuMsfdZkFE2TkVG-iB9iE2k",
    "amr": [
        "pwd"
    ],
    "idp": "00o19kwu6yGUej4Un1t7",
    "nonce": "1000047",
    "preferred_username": "test_jwt_alpha@tisco.co.th",
    "auth_time": 1589098877,
    "at_hash": "I9GWKFVDZE2h2sYDyM52aQ",
    "47_group_name": [
        "47-1"
    ],
    "cloudflare_group": [
        "13-6"
    ],
    "user_id": "630ba9ba-835b-474a-ba6f-f7ec5a6fd044",
    "erm_role": "EJ-18-1",
    "regis_service_id": "",
    "status": "078ce03c-8c72-4b4f-a001-1e6bbee27db1"
}

key = """
-----BEGIN RSA PRIVATE KEY-----
Proc-Type: 4,ENCRYPTED
DEK-Info: AES-256-CBC,6D0EBE4E8D5BE0F90D42041D5BF41F70

FO+bTZ3nZ7Ib65df7/xhA0ZVTfXIFND5gvXVMd3SpbsPgIxStRatMqqACA+k3HvJ
e86VXv7nveJ5/1/EF9A8p+XyaNu+LmvKuapGIE8wz/7Z/C10USozCNBlYFpA+t1P
8lv6yemeSjbNtrX4LCnazwfbOfgZtrPoIbotLBevoFvsn7/utHakt8537NO0lOMp
VwRpsu03gk34ZE0MI+HXMqpH8pmcIlrUlA2p9qK4mbimR9LC9npRHkigJ+qgAcXH
jluVETKNpEVvRqI6/7ws8GNM+6cNWsclbs4QyJlOvTVuaYtC5CL6KYA+YEO1xBH7
aqs4MW3ypMlVgaUjOjwA3XhedLRh4HEEMOT5Or193aTy/qDJ/Sv7QhLvdFk/NV6q
rzjDwsBUBxklsyzVTN6nPdnFE2SFW7ajDGX2xL3MKOUxaO4JYu0X+7JUQXcr0fiP
AKX0X/8Ym5WdDI5SdjEODk1vKJLg6/i8iMa9wLFjd2L4BLYyjTu4Y9nAPHmgCbNh
K6y0k3FmGBjHm96N9rCEs3JjnVedmaTl3e+voa9ulPLUGAhasz+XJI1R6ZqgvT0M
iov+VnGdFzcWhHmNA+HkhnLbNZiKPbwDjHEthqt/3lbrrjxwPp4y6vKTKMp/6Qpf
0jJJ7uNEjIzmdAmgw17VCxfHGPTBeHlTw2dALM7YdPXBecXutCQvAdV+sZ/iBi0k
D1jE9hOzNF5A7NKydJndSRDk+nLY5MzkC1tzWonQvu4elLPyLXl48bGDt47UiAJY
Rpta9DysCOS8qYHrTr3pFeX9JrmCRMI2hs0+Nl5DKoyZxn9HoqXMSc/4UL2hxxkz
ik0FGJaDuvWpCWkUDfEIgnXTN4gAThFgsQrEjHv6lemaijOKl/+hkRyRrDskBqu5
N1hqighCLjiTREs6VQHiVzxDMpi2PCNdRriwgW0ZoVB8/Xg/Ac2pGhVWs3Z4adAU
O9XqnQ5wxb4dvXacZ7HI1Dvz8GtWu7x1YXGbbi0W6VF7AcjTy0nfvIjX2qmKKLbu
zAXYJveVhBBYBTVwjis8XZcauLoda+UCh1xnXX2VxnCYl9+qeLo8ZKf5Xk6FYjY3
cGFN5iXrXpldZ3DFgocpWVaXxhMAFIEGrZif/ph8NNVJRgewa87WHXSfDC9FRhnG
voRBS6mKB2ZLxhRs6f4ZRWaKe4t3G1M+Qlu06lvjp/9LYuvu9Vsl5M6Hq0Zwsu+j
z6lNG5bX/2Gkb7bd3OGW6wyGqg9vrdtM6JDPAEAwNe1HxITNquQlYCSN+wQYcHij
fhzlcfrepJfsRRcNJKkCtlgHmqguWXKm17QH93uiBQD81yKmQh8GVclRe4ZLhDB5
wNDSBLowAlAtY4ti7bBKRJImPzemq9tkGkyXgYimAWYaavbL69Vtl0vmU0hK1k0s
4q/8AyIHVVs/rf+QciNULKxDBvAMMDqFc1qLUAWHxFhbv2LAOVkmq5fXLeLWwvzE
Jes8A4kxbLl2b9X12NHeQj0BH4UTrl3PYjiVyVSVInWeSdkr6XiA7GcPBNguZ2OB
0kG+yNXjRBdJQH04vw2uHekrcW/v7iNeG2nGa6QaDfKWB5HpLwCXxYb9p1n+FIJa
KlVPOv3gJ2+z8HxKsA+UyzWBSuOrVJnkMs02MPIkwedkjp6Dp0mpygCisI6wZyOl
L3OuAFuNNbIMaASk3B/XD07TXd5qLs07Uwe0fmQTG+jBhtRAloVPvoA1dVhexNU0
ypl8GeugrzcXEgVenn2ybCz5DBW+PiiwGE0ahwcXUTCOnogmHIkbdsYEvtDI/qUe
7K+sWb+344+pTH4c5PCd7Jy/QsWF1xRTz5/5xjGskGCE0478KpilanP4kchTFbUR
jEyr/wwsMwlnkx13fijWRvLEVujl81lmuEcEGW2t/CI5WWz44Qh1fPd++AeLoK5H
dkZPyXHqkFme9ZABwoTSEO4LkJjKf/8aeVo8+L0NuTIBjrPyxjSBO9AfLTREhjtA
8uDQfYTT9ohAiVMKUOa6rvrznVE6MWvRW9fB6szWGdgj/GmEIkjBigGyjFOzmCzL
vH67cVhW81zSpbIjCLNjHrStCctM+Eo/BHZi2AaFZSUMzn5lTmXNROyWVM4lI2B4
BzThpw8CF0AaPui7c3zOHzrQxL86/OOAlqs5fQyNjFG9JBzzUYB6ognQTyFEmip8
nUVkJqwPdtHwlL1ZtLVchRQu1gldmvkBjlkSy8Qp1ZcqrC8HH9spX8F5WvKzCJP+
dmpAT/6bXbky5H6/N5uoqd2qlJh+N4oREYxBoUfWcc3GE/Hj8dGYWLHDKTxgXllO
bMuBQZqr7xYRTKsNcJMzSQ+Yt9zIMSEDAQsawMlAEtT2YGb+pfzWpLXD3ETL4OXR
tdRtT+xkIl8gMIpN9KY84A27pME+gebX0UFaTVbj4NIRkUSvgRiARPYWQhOjFySs
jZNg+JbVccdlaztvZ6EvyZlcL4WfQP6HP7HPfjWPlgzuEQzPGMKa0s6CmcBdYfN4
dbdHhAnAimSidTxn+sxxWmrtFICQWh8oViwrIrYJMFwMQ4mG7R4o1q/2dl9oNZy2
cNWJwomaCFt5sj1TT5754EloYXXqq4HKgterUHuWHdukLqV0A2mu4SVuJdiui1qs
8Zs3XZUQ2JyIbyYai34gIlMlUEdor1RbXae1EEgG/TTY4pyv2BFleRKR3hJtvMTY
sP5lMhp1oJP/a6TuO9K22x9KGx85CsTjweqNH6vNqnc9QFfBg01k7cj2giwMHhIH
Ph84afOiC9IHVgYVZMPf135ecEyWqGt5wMgny19a8b9NGl3ZUgaKb6OMALJj39mo
mFbuD2WzThAhfGXZ6NGLTp5lX37znq/24wxZzCu1kABG7V9QXQFaMFkTC87hDUgL
NWI00omQVW0yVKMbDJXdudylhuFJHcSfZEIxxhWzOa4CTCnb966spPvQZtNFIupz
sWnaorW0kKvQfPzlJU4G2YUgDpRKSpB//5mzGOA3BZQ9+rLhIaIZJf2iT53ntvsk
FD8CogM4KrcB4J/0g37xDeGpuWM0Wg6Y08nYiZyHB8kNuZ4WlZ5Ks1I4GZayyBJS
DeSysFOBodUKtHHFl+oMXRJJ7DVMjG1GhLaDkQP/bQg/WWfgYIHWPFAAv50WXmB9
-----END RSA PRIVATE KEY-----
"""
#
# _header = {
#     "kid": "5ld73KlW6_lj18RLZ-Ff4plPw7pzxBXBjt4FvvFKktU",
#     "alg": "RS256"
# }


def create_jwt_token():
    insert_data = {
        'id_token': jwt.encode(mock_id_token, key=key).decode('utf-8'),
        'expired_at': datetime.datetime.now() + datetime.timedelta(days=1)
    }
    return JSONWebToken.objects.create(**insert_data)


class JWTModelTestCase(TestCase):

    def test_create_jwt_model(self):
        # model = create_jwt_token()
        model = create_jwt_token()
        self.assertEqual(JSONWebToken.objects.count(), 1)
        self.assertEqual(JSONWebToken.objects.first().id_token, model.id_token)
