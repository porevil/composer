import uuid
import jwt
import sys
import os

from django.http.response import HttpResponseRedirect
from rest_framework.response import Response
from rest_framework import status
from rest_framework.views import APIView
from datetime import datetime, timedelta
from django.db import Error

from apps.commons.logger.views import ViewLogger
from apps.commons.utilities.log import Logger
from apps.commons.okta import core as okta
from apps.authentication.models import JSONWebToken
from apps.commons.error.exception import StandardException
from apps.commons.utilities.response import CustomJsonResponse, CustomResponseObject
from apps.commons.utilities.response import ResponseAPI
from apps.commons.error.exception import *


class Login(APIView, ViewLogger):
    """
    OpenID login by return endpoint to Okta SSO
    """

    def get(self, request):
        response_meta = ResponseAPI()
        logger = Logger('Login')
        response_data = response_meta

        try:
            logger.debug('login [reference id = {}] start'.format(request.session_id))

            end_point = okta.generate_authen_endpoint()
            force_redirect = request.query_params.get('force_redirect', None)
            if force_redirect or force_redirect == '':
                return HttpResponseRedirect(redirect_to=end_point)
            else:
                response_data = response_meta.success('success', request.session_id, end_point)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            logger.error('login [reference id = {}] exception: {}'.format(request.session_id, exception_message))
            response_data = response_meta.error(LoginFailedException(e), exception_message, request.session_id)

        finally:
            if response_data:
                logger.debug('login [reference id = {}] response = {}'.format(request.session_id, response_data))
                return Response(response_data, status=status.HTTP_200_OK)


class Authorize(APIView, ViewLogger):
    """
    Authorize by verify code from okta
    """

    @staticmethod
    def build_response_data(access_token: str, id_token: str):
        """
        Build response data after get data from okta verify code
        """
        try:
            id_token_info = jwt.decode(id_token, verify=False)
            data = {
                "agent_code": id_token_info.get("user_id"),
                "agent_id": id_token_info.get("user_id"),
                "agent_name": id_token_info.get("name"),
                "agent_user_lan": id_token_info.get("name").split('@')[0] if id_token_info.get("name", None) else '-',
                "agent_email": id_token_info.get("preferred_username"),
                "external_reference_code": "external_reference_code",
                "access_token": access_token,
                "id_token": id_token,
            }
        except Exception as e:
            # fname = os.path.abspath(__file__)
            # exc_type, exc_obj, exc_tb = sys.exc_info()
            # exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), str(fname), str(exc_tb.tb_lineno))
            raise Exception(e)
            # data = response_meta.error(UnAuthorizedException(e), exception_message, request.session_id)

        return data

    def get(self, request, code=None):
        """
        Check Authorize Code from Okta
        """
        response_meta = ResponseAPI()
        logger = Logger('Authorize')
        success = True

        try:
            logger.debug('authorize [reference id = {}] start'.format(request.session_id))
            if code is None:
                raise BadRequestException('"code" is required')

            okta_response = okta.verify_okta_token(code)

            logger.debug('authorize [reference id = {}] okta response - {}'.format(request.session_id, okta_response))

            id_token = okta_response.get('id_token')
            access_token = okta_response.get('access_token')
            refresh_token = okta_response.get('refresh_token')

            if access_token is not None and id_token is not None:
                id_token_info = jwt.decode(id_token, verify=False)
                logger.debug(
                    'authorize [reference id = {}] token information - {}'.format(request.session_id, id_token_info))

                expires = datetime.utcfromtimestamp(id_token_info['exp'])
                logger.debug('authorize [reference id = {}] okta token expires [{}] {}'.format(request.session_id,
                                                                                               id_token_info['exp'],
                                                                                               expires))

                JSONWebToken.objects.create(**{
                    'id_token': id_token,
                    'expired_at': datetime.fromtimestamp(id_token_info['exp']),
                    'access_token': access_token,
                    'refresh_token': refresh_token
                })

                response_data = response_meta.success('success', request.session_id,
                                                      self.build_response_data(access_token, id_token))

            else:
                raise Exception("Invalid token")

        except Exception as e:
            success = False
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), str(fname), str(exc_tb.tb_lineno))

            response_data = response_meta.error(UnAuthorizedException(e), exception_message, request.session_id)

        finally:
            logger.debug('authorize [reference id = {}] response - {}'.format(request.session_id, str(response_data)))

            if success:
                response = Response(response_data, status=status.HTTP_200_OK)
                response.set_cookie('id_token', id_token, expires=expires)
                return response

            return Response(response_data, status=status.HTTP_200_OK)


class RefreshToken(APIView, ViewLogger):
    logger = Logger("RefreshToken")

    def get(self, request):
        try:
            response_meta = ResponseAPI()
            success = True

            self.logger.debug('refresh token [reference id = {}] start'.format(request.session_id))

            jwt_model = JSONWebToken.objects.get(id_token=request.oidc_user.id_token)
            self.logger.debug('refresh token [reference id = {}] length - {}'.format(request.session_id,
                                                                                     len(jwt_model.refresh_token)))

            identity_response = okta.refresh_token(jwt_model.refresh_token)
            self.logger.debug(
                'refresh token [reference id = {}] response - {}'.format(request.session_id, identity_response))

            id_token = identity_response.get('id_token')
            access_token = identity_response.get('access_token')
            refresh_token = identity_response.get('refresh_token')
            if access_token is not None and id_token is not None:
                id_token_info = jwt.decode(id_token, verify=False)
                expires = datetime.utcfromtimestamp(id_token_info['exp'])
                self.logger.debug(
                    'refresh token [reference id = {}] okta token expires [{}] {}'.format(request.session_id,
                                                                                          id_token_info['exp'],
                                                                                          expires))
                jwt_model.delete()
                JSONWebToken.objects.create(**{
                    'id_token': id_token,
                    'expired_at': datetime.fromtimestamp(id_token_info['exp']),
                    'access_token': access_token,
                    'refresh_token': refresh_token
                })

                data = {
                    'id_token': id_token
                }
                response_data = response_meta.success('success', request.session_id, data)

                response = Response(response_data, status=status.HTTP_200_OK)
                response.set_cookie('id_token', id_token, expires=expires)

                return response

            else:
                raise Exception("Invalid token")

        except ValueError as e:
            return CustomJsonResponse(data=e)
        except StandardException as e:
            return CustomJsonResponse(data=e)
        except Exception as e:
            return CustomJsonResponse(data=e)
