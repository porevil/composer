from django.apps import AppConfig


class ServiceInstancesConfig(AppConfig):
    name = 'service_instance'
