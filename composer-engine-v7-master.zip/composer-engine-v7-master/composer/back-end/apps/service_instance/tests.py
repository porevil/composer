import json
from django.test import TestCase
from rest_framework.test import APIClient, APIRequestFactory
from django.urls import reverse

from .api import viewsets, serializers
from apps.service_instance.models import ServiceInstance, ServiceInstanceRepository
from apps.configurations.models import SubState, State
from apps.authentication.tests import create_jwt_token
from apps.authentication.models import OpenIDUser

state_data = {
    "name": "test2",
    "virtual_name": "test2",
    "config": json.loads(
        "{\"aws\": {\"region\": \"ap-southeast-1\", \"account_id\": \"935529356946\", \"ecr_domain\": \"dkr.ecr.ap-southeast-1.amazonaws.com\", \"access_key_id\": \"AKIAIYCL4KWIY3K2CQ3Q\", \"secret_access_key\": \"psuvJmBx4bFgIsZ+TC4xl+\/M8Oy80P\/AxzbazljW\", \"ecr_repository_prefix\": \"channel\/dev\/mbs\"}, \"mule\": {\"client_id\": \"7d54f79fb17946678775205aab308619\", \"client_secret\": \"530d2e1111174443BFB01891E40BD091\"}, \"ag_service\": {\"endpoint\": \"https:\/\/api-v1-service.c1-alpha-tiscogroup.com\/public\/accessgovern-v1-app\/mgt-ags\", \"runtime_endpoint\": \"https:\/\/api-v1-service.c1-alpha-tiscogroup.com\/public\/accessgovern-v1-service\/sep-ags\", \"management_endpoint\": \"https:\/\/api-v1-service.c1-alpha-tiscogroup.com\/public\/accessgovern-v1-app\/mgt-ags\"}, \"service_account\": \"00u6ilmd4qVBUfkMC0h7\", \"launcher_service\": {\"endpoint\": \"https:\/\/launcher-v4-ch1-app.c1-alpha-tiscogroup.com\/api\"}, \"metadata_service\": {\"endpoint\": \"https:\/\/api-v1-service.c1-alpha-tiscogroup.com\/public\/data-v3-service\/dep-api\/GetMetaData\"}, \"tisco_log_library\": {\"endpoint\": \"https:\/\/s3-ap-southeast-1.amazonaws.com\/tisco.alpha.source\/core\/loglib-python-1.0.93.zip\"}}")
}

sub_state_data = {
    "name": "testInsertSubstate",
    "virtual_name": "testInsertSubstateVir",
    "is_default": True,
    "is_advisor": True,
    "is_pre_production": False,
    "is_production": True,
    "need_authorized_ticket": False,
    "has_shelf": False,
    "next_sub_state_ids": None,
}

instance_data = {
    "code": "si_test",
    "name": "si_test",
    "description": "generate_output_template_prepare_data_identity",
    "config": json.loads(
        "{\"response\": {\"message\": \"msg_detail\", \"properties\": [{\"label\": \"response_data.update_by\", \"type\": \"text\", \"name\": \"response_data.update_by\"}, {\"label\": \"response_data.name\", \"type\": \"text\", \"name\": \"response_data.name\"}, {\"label\": \"response_data.status_detail\", \"type\": \"text\", \"name\": \"response_data.status_detail\"}, {\"label\": \"response_data.type\", \"type\": \"text\", \"name\": \"response_data.type\"}, {\"label\": \"response_data.id\", \"type\": \"text\", \"name\": \"response_data.id\"}, {\"label\": \"response_data.profile_name\", \"type\": \"text\", \"name\": \"response_data.profile_name\"}, {\"label\": \"response_data.output_data\", \"type\": \"text\", \"name\": \"response_data.output_data\"}, {\"label\": \"response_data.create_date\", \"type\": \"datetime\", \"name\": \"response_data.create_date\"}, {\"label\": \"response_data.status_code\", \"type\": \"text\", \"name\": \"response_data.status_code\"}, {\"label\": \"response_data.create_by\", \"type\": \"text\", \"name\": \"response_data.create_by\"}, {\"label\": \"response_data.update_date\", \"type\": \"datetime\", \"name\": \"response_data.update_date\"}], \"success\": {\"type\": \"text\", \"name\": \"msg_code\", \"value\": \"30000\"}}, \"request\": {\"http_method\": \"POST\", \"params\": [{\"multiple\": false, \"label\": \"prepare_data_id\", \"required\": true, \"type\": \"text\", \"name\": \"{{prepare_data_id}}\"}]}, \"tracking\": {\"checking\": {\"message\": \"response_data.status_detail\", \"status\": {\"type\": \"text\", \"complete_value\": \"Done\", \"name\": \"response_data.status_code\", \"fail_value\": \"Error\"}}, \"response\": {\"message\": \"msg_detail\", \"properties\": [{\"multiple\": false, \"label\": \"response_data.update_by\", \"type\": \"text\", \"name\": \"response_data.update_by\"}, {\"multiple\": false, \"label\": \"response_data.name\", \"type\": \"text\", \"name\": \"response_data.name\"}, {\"multiple\": false, \"label\": \"response_data.status_detail\", \"type\": \"text\", \"name\": \"response_data.status_detail\"}, {\"multiple\": false, \"label\": \"response_data.type\", \"type\": \"text\", \"name\": \"response_data.type\"}, {\"multiple\": false, \"label\": \"response_data.id\", \"type\": \"text\", \"name\": \"response_data.id\"}, {\"multiple\": false, \"label\": \"response_data.profile_name\", \"type\": \"text\", \"name\": \"response_data.profile_name\"}, {\"multiple\": false, \"label\": \"response_data.output_data\", \"type\": \"text\", \"name\": \"response_data.output_data\"}, {\"multiple\": false, \"label\": \"response_data.create_date\", \"type\": \"datetime\", \"name\": \"response_data.create_date\"}, {\"multiple\": false, \"label\": \"response_data.status_code\", \"type\": \"text\", \"name\": \"response_data.status_code\"}, {\"multiple\": false, \"label\": \"response_data.create_by\", \"type\": \"text\", \"name\": \"response_data.create_by\"}, {\"multiple\": false, \"label\": \"response_data.update_date\", \"type\": \"datetime\", \"name\": \"response_data.update_date\"}], \"success\": {\"type\": \"text\", \"name\": \"msg_code\", \"value\": \"30000\"}}, \"reference_id_property_name\": \"response_data.id\"}}"),
    "data": json.loads(
        "{\"intents\": {\"in\": [{\"multiple\": false, \"label\": \"prepare_data_id\", \"required\": true, \"type\": \"text\", \"name\": \"{{prepare_data_id}}\"}], \"out\": [{\"multiple\": false, \"label\": \"response_data.update_by\", \"type\": \"text\", \"name\": \"response_data.update_by\"}, {\"multiple\": false, \"label\": \"response_data.name\", \"type\": \"text\", \"name\": \"response_data.name\"}, {\"multiple\": false, \"label\": \"response_data.status_detail\", \"type\": \"text\", \"name\": \"response_data.status_detail\"}, {\"multiple\": false, \"label\": \"response_data.type\", \"type\": \"text\", \"name\": \"response_data.type\"}, {\"multiple\": false, \"label\": \"response_data.id\", \"type\": \"text\", \"name\": \"response_data.id\"}, {\"multiple\": false, \"label\": \"response_data.profile_name\", \"type\": \"text\", \"name\": \"response_data.profile_name\"}, {\"multiple\": false, \"label\": \"response_data.output_data\", \"type\": \"text\", \"name\": \"response_data.output_data\"}, {\"multiple\": false, \"label\": \"response_data.create_date\", \"type\": \"datetime\", \"name\": \"response_data.create_date\"}, {\"multiple\": false, \"label\": \"response_data.status_code\", \"type\": \"text\", \"name\": \"response_data.status_code\"}, {\"multiple\": false, \"label\": \"response_data.create_by\", \"type\": \"text\", \"name\": \"response_data.create_by\"}, {\"multiple\": false, \"label\": \"response_data.update_date\", \"type\": \"datetime\", \"name\": \"response_data.update_date\"}]}}"),
    "latest_version": "2",
    "response_type": "json",
    "service_type": "async"
}

instance_repo_data = [
    {
        "service_endpoint": "https://api-v1-service.c1-alpha-tiscogroup.com/public/output-v1-service/opp-api/task/execute/profile_name/template_prepare_data_identity/prepared_data/{{prepare_data_id}}",
        "service_version": "2",
        "created_date": "2020-02-05T04:47:56Z",
        "updated_date": "2020-02-05T04:47:56Z",
        # "service_instance_id": 162,
        # "sub_state_id" : 4,
        "tracking_endpoint": "https://api-v1-service.c1-alpha-tiscogroup.com/public/output-v1-service/opp-api/task/search/"
    },
    {
        "service_endpoint": "https://api-v1-service.c1-alpha-tiscogroup.com/public/output-v1-service/opp-api/task/execute/profile_name/template_prepare_data_identity/prepared_data/{{prepare_data_id}}",
        "service_version": "2",
        "created_date": "2019-08-20T06:27:15Z",
        "updated_date": "2020-02-05T04:47:56Z",
        # "service_instance_id": 162,
        # "sub_state_id" : 3,
        "tracking_endpoint": "https://api-v1-service.c1-alpha-tiscogroup.com/public/output-v1-service/opp-api/task/search/"
    }
]


# url = reverse('service-instance')


def create_state():
    return State.objects.create(**state_data)


def create_sub_state(state):
    data = sub_state_data
    data['state_id'] = state.id
    return SubState.objects.create(**sub_state_data)


def create_service_instance(**kwargs):
    data = instance_data
    for k, v in kwargs.items():
        data[k] = v
    return ServiceInstance.objects.create(**data)


def create_service_instance_repo(instance, sub_state):
    data = instance_repo_data[0]
    data['sub_state_id'] = sub_state.id
    data['service_instance_id'] = instance.id
    return ServiceInstanceRepository.objects.create(**data)


class ServiceInstanceViewSetTests(TestCase):

    def setUp(self) -> None:
        self.factory = APIRequestFactory()
        self.client = APIClient()
        self.state = create_state()
        self.sub_state = create_sub_state(self.state)
        self.service_instance = create_service_instance()
        self.service_instance_repo = create_service_instance_repo(self.service_instance, self.sub_state)
        self.oidc_user = OpenIDUser(create_jwt_token().id_token)
        mapping_view = {
            'get': 'list',
            'post': 'create',
            'put': 'update',
            'delete': 'destroy'
        }
        self.view = viewsets.ServiceInstanceViewSet.as_view(mapping_view)
        self.client.defaults['HTTP_AUTHORIZATION'] = 'token ' + self.oidc_user.id_token

    def test_list(self):
        request = self.factory.get('/api/service_instance')
        response = self.view(request)
        self.assertEqual(response.status_code, 200)
        self.assertListEqual(response.data['data'],
                             serializers.ServiceInstanceSerializer(ServiceInstance.objects.all(), many=True).data)

    def test_search(self):
        create_service_instance(name="test_search_1", code="test_search_1")
        request = self.factory.get('/api/service_instance/?name__icontains=search&code__icontains=search')
        response = self.view(request)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.data['data']), 1)

    def test_create(self):
        data = instance_data
        data['code'] = 'test_create'
        data['name'] = 'test_create'
        request = self.factory.post('/api/service_instance', data, format='json')
        request.oidc_user = self.oidc_user
        response = self.view(request)
        self.assertEqual(response.status_code, 200)
        self.assertIn(response.data['meta'].get('response_desc', ''), 'Success')
        self.assertEqual(ServiceInstance.objects.filter(name=data['name']).count(), 1)
        self.assertEqual(ServiceInstance.objects.filter(name=data['code']).count(), 1)

    def test_retrieve(self):
        data = instance_data
        data['name'] = 'test_retrieve'
        data['code'] = 'test_retrieve'
        model = create_service_instance(**data)
        request = self.factory.get(f'/api/service_instance/{model.id}')
        response = viewsets.ServiceInstanceViewSet.as_view({'get': 'retrieve'})(request, pk=model.id)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data['data'].get('name', ''), model.name)

    def test_update(self):
        model = create_service_instance(name="test_update_1", code="test_update_1")
        update_data = {
            'name': 'test_update_new_name',
            'code': 'test_update_new_name',
        }
        ser = serializers.ServiceInstanceDetailSerializer(model)
        data = ser.data
        data.update(update_data)
        request = APIRequestFactory().put(f'/api/service_instance/{model.id}', data, format='json')
        request.oidc_user = self.oidc_user
        response = self.view(request, pk=model.id)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data['data'].get('name', ''), 'test_update_new_name')

    def test_destroy(self):
        model = create_service_instance(name="test_destroy", code="test_destroy")
        request = APIRequestFactory().delete(f'/api/service_instance/{model.id}')
        request.oidc_user = self.oidc_user
        response = self.view(request, pk=model.id)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(ServiceInstance.objects.filter(pk=model.id).count(), 0)


class ServiceInstanceRepositoryAPITests(TestCase):

    def setUp(self) -> None:
        pass

    def test_list(self):
        pass

    def test_create(self):
        pass

    def test_update(self):
        pass

    def test_destroy(self):
        pass
