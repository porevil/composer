import json, re

from rest_framework import serializers
from apps.service_instance.models import ServiceInstance
from apps.service_instance.models import ServiceInstanceRepository


class ServiceInstanceSerializer(serializers.ModelSerializer):
    class Meta:
        model = ServiceInstance
        fields = [
            'id',
            'uuid',
            'code',
            'name',
            'config',
            'data',
            'description',
            'service_type',
            'response_type',
            'latest_version',
            'created_date',
            'updated_date',
        ]
        read_only_fields = ['id', 'uuid', 'created_date', 'updated_date']


class ServiceInstanceDetailSerializer(serializers.ModelSerializer):
    # config = serializers.SerializerMethodField()
    # data = serializers.SerializerMethodField()
    repositories = serializers.SerializerMethodField()

    class Meta:
        model = ServiceInstance
        fields = [
            'id',
            'uuid',
            'code',
            'name',
            'description',
            'service_type',
            'response_type',
            'latest_version',
            'config',
            'data',
            'repositories',
            'created_date',
            'updated_date',
        ]

        read_only_fields = ('id', 'uuid', 'code')

    # def get_data(self, obj):
    #     return obj

    def get_repositories(self, obj):
        repositories = ServiceInstanceRepository.objects.filter(service_instance=obj).order_by('sub_state__id')
        serializer = ServiceInstanceRepositorySerializer(repositories, many=True)
        return serializer.data


class ServiceInstanceRepositorySerializer(serializers.ModelSerializer):
    state_name = serializers.SerializerMethodField()
    sub_state_name = serializers.SerializerMethodField()

    class Meta:
        model = ServiceInstanceRepository
        fields = [
            'service_instance_id',
            'sub_state_id',
            'sub_state_name',
            'state_name',
            'service_endpoint',
            'tracking_endpoint',
            'service_version',
        ]

    def get_state_name(self, obj):
        return obj.sub_state.state.name

    def get_sub_state_name(self, obj):
        return obj.sub_state.name
