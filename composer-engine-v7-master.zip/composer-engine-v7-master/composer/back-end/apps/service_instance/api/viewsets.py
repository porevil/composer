import traceback
import uuid
import re

from django_filters import rest_framework as filters

from django.db import transaction

from rest_framework import viewsets
from rest_framework import serializers
from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import action, detail_route

from apps.commons.logger.views import ViewLogger
from apps.service_instance.api.serializers import ServiceInstanceSerializer, ServiceInstanceDetailSerializer
from apps.service_instance.models import ServiceInstance, ServiceInstanceRepository
from apps.commons.utilities.response import CustomJsonResponse, CustomResponseObject, BadRequestException
from apps.commons.utilities.log import Logger


def is_valid_uuid(request_uuid, version=4):
    try:
        uuid_obj = uuid.UUID(str(request_uuid), version=version)
    except ValueError:
        return False

    return str(uuid_obj) == request_uuid
    
class ServiceInstanceFilter(filters.FilterSet):
    class Meta:
        model = ServiceInstance
        fields = {
            # 'code': ['exact', 'startswith', 'contains', 'icontains'],
            # 'name': ['exact', 'startswith', 'contains', 'icontains'],
            'code': ['icontains'],
            'name': ['icontains'],
            'uuid': ['exact'],
            'service_type': ['exact'],
            'response_type': ['exact'],
        }


class ServiceInstanceViewSet(viewsets.ModelViewSet, ViewLogger):
    queryset = ServiceInstance.objects.all()
    filter_class = ServiceInstanceFilter
    serializer_class = ServiceInstanceSerializer

    # filter_backends = (filters.DjangoFilterBackend, ServiceInstanceFilter)
    def get_serializer_class(self):
        if self.action == 'retrieve':
            return ServiceInstanceDetailSerializer
        return ServiceInstanceSerializer

    def list(self, request, **kwargs):
        response_data = []
        try:
            self.logger.debug('list service instance [reference id = {}] start'.format(request.session_id))

            request_uuid = request.query_params.get('uuid')
            if request_uuid is not None and request_uuid:
                is_valid = is_valid_uuid(request_uuid)

                if not is_valid:
                    raise BadRequestException('"uuid" is invalid')

            queryset = self.filter_queryset(self.get_queryset())
            response_data = self.get_serializer(queryset, many=True).data

        except Exception as e:
            self.logger.error(
                'list service instance [reference id = {}] exception = {}'.format(request.session_id, str(e)))
            response_data = e

        finally:
            self.logger.debug(
                'list service instance [reference id = {}] response len = {}'.format(request.session_id,
                                                                                     response_data))
            return CustomJsonResponse(data=response_data)

    def create(self, request, **kwargs):
        print(self.get_serializer_class())
        try:
            with transaction.atomic():
                executed_by = request.oidc_user.full_name
                self.logger.debug(
                    f'create service instance [reference id = {request.session_id}] excecuted by [{executed_by}] start')

                request_data = request.data

                code = request_data.get('code')
                name = request_data.get('name')
                description = request_data.get('description')
                service_type = request_data.get('service_type')
                response_type = request_data.get('response_type')
                latest_version = request_data.get('latest_version')

                if not code:
                    raise Exception('bad request : "code" is required')
                if not name:
                    raise Exception('bad request : "name" is required')

                config = request_data.get('config')

                service_instance = ServiceInstance.objects.create(**{
                    'code': code,
                    'name': name,
                    'description': description,
                    'service_type': service_type,
                    'response_type': response_type,
                    'latest_version': latest_version,
                    'config': config,
                })

                repositories = request_data.get('repositories')

                if repositories is not None and repositories:
                    # create 'service instance repositories'
                    for idx, repository in enumerate(repositories):
                        ServiceInstanceRepository.objects.create(**{
                            'service_endpoint': repository.get('service_endpoint'),
                            'service_version': repository.get('service_version'),
                            'sub_state_id': repository.get('sub_state_id'),
                            'tracking_endpoint': repository.get('tracking_endpoint'),
                            'service_instance_id': service_instance.id,
                        })
                serializer = ServiceInstanceDetailSerializer(service_instance)
                return CustomJsonResponse(status=status.HTTP_200_OK,
                                          data=serializer.data)
        except Exception as e:
            traceback.print_exc()
            return CustomJsonResponse(
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
                data=e)
            # return Response(status=status.HTTP_500_INTERNAL_SERVER_ERROR, data={
            #     "error_message": str(e)
            # })

    def update(self, request, **kwargs):
        try:
            pk = kwargs.get('pk', None)
            with transaction.atomic():
                self.logger.debug(f"Request Update data [{request.data}] \nreference_id [{request.session_id}]")
                request_data = request.data

                service_instance = ServiceInstance.objects.filter(pk=pk).first()
                if service_instance is None:
                    raise Exception('bad request : "id" is invalid')

                # getStringWithDecodedUnicode = lambda str: re.sub("\\\\u([\da-f]{4})",
                #                                                  (lambda x: chr(int(x.group(1), 16))), str)

                name = request_data.get('name')
                description = request_data.get('description')
                service_type = request_data.get('service_type')
                response_type = request_data.get('response_type')
                latest_version = request_data.get('latest_version')
                config = request_data.get('config')

                # config = getStringWithDecodedUnicode(json.dumps(request_data.get('config')))

                # update 'service instance'
                service_instance.name = name
                service_instance.description = description
                service_instance.service_type = service_type
                service_instance.response_type = response_type
                service_instance.latest_version = latest_version
                service_instance.config = config
                service_instance.save()

                repositories = request_data.get('repositories')

                # create or update 'repositories'
                _ids = list()
                for idx, repository in enumerate(repositories):
                    service_endpoint = repository.get('service_endpoint')
                    tracking_endpoint = repository.get('tracking_endpoint')
                    service_version = repository.get('service_version')
                    sub_state_id = repository.get('sub_state_id')

                    service_instance_repository = ServiceInstanceRepository.objects.filter(
                        service_instance=service_instance,
                        sub_state_id=sub_state_id).first()

                    if service_instance_repository is None:
                        service_instance_repository = ServiceInstanceRepository.objects.create(**{
                            'service_endpoint': repository.get('service_endpoint'),
                            'tracking_endpoint': repository.get('tracking_endpoint'),
                            'service_version': repository.get('service_version'),
                            'sub_state_id': repository.get('sub_state_id'),
                            'service_instance_id': service_instance.id,
                        })
                    else:
                        service_instance_repository.service_endpoint = repository.get('service_endpoint')
                        service_instance_repository.tracking_endpoint = repository.get('tracking_endpoint')
                        service_instance_repository.service_version = repository.get('service_version')
                        service_instance_repository.sub_state_id = repository.get('sub_state_id')
                        service_instance_repository.service_instance = service_instance
                        service_instance_repository.save()

                    _ids.append(service_instance_repository.id)

                # delete 'repositories'
                deleted_services_repositories = ServiceInstanceRepository.objects.filter(
                    service_instance=service_instance) \
                    .exclude(id__in=_ids)
                deleted_services_repositories.delete()

                return CustomJsonResponse(data=ServiceInstanceDetailSerializer(service_instance).data)
        except Exception as e:
            traceback.print_exc()
            return Response(status=status.HTTP_500_INTERNAL_SERVER_ERROR, data={
                "error_message": str(e)
            })

    def retrieve(self, request, *args, **kwargs):
        self.logger.debug(
            f'start get kwargs [{kwargs} {super().retrieve(request, *args, **kwargs)}] reference_id [{request.session_id}]')
        model = self.get_object()
        serializer = ServiceInstanceDetailSerializer(model)
        response_data = serializer.data
        self.logger.debug(f'response detail [{response_data}] reference_id [{request.session_id}]')

        return CustomJsonResponse(data=response_data)

    def destroy(self, request, pk=None, *args, **kwargs):
        try:
            self.logger.debug(f"Request Delete pk={pk}")
            model = ServiceInstance.objects.filter(pk=pk).first()
            if model is None:
                raise Exception("bad request: invalid id")
            model.delete()
            return CustomJsonResponse(description="Delete Success")
        except Exception as e:
            return CustomJsonResponse(data=e)
