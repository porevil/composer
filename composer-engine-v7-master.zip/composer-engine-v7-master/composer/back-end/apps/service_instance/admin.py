from django.contrib import admin
from apps.service_instance.models import ServiceInstance, ServiceInstanceRepository



@admin.register(ServiceInstance)
class ServiceInstanceAdmin(admin.ModelAdmin):
    pass


@admin.register(ServiceInstanceRepository)
class ServiceInstanceRepositoryAdmin(admin.ModelAdmin):
    pass
