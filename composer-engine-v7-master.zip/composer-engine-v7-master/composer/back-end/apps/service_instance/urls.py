from django.conf.urls import url
from django.urls import path, include
from rest_framework.routers import DefaultRouter

from apps.service_instance.api import viewsets

router = DefaultRouter()
router.register('', viewsets.ServiceInstanceViewSet)

app_name = 'service_instance'

urlpatterns = [
    path('', include(router.urls)),
]
