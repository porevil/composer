import reversion

from uuid import uuid4
from django.db import models
from django.utils.translation import ugettext_lazy as _

from django.db.models.signals import pre_save
from django.dispatch import receiver
from django.contrib.postgres.fields import JSONField

from apps.configurations.models import SubState


@reversion.register()
class ServiceInstance(models.Model):
    uuid = models.UUIDField(db_index=True, default=uuid4,
                            editable=False, unique=True)
    code = models.CharField(max_length=100, unique=False,
                            editable=False, verbose_name=_("Code"))
    name = models.CharField(max_length=150, verbose_name=_("Name"))
    description = models.TextField(
        blank=True, null=True, verbose_name=_("Description"))
    service_type = models.CharField(
        max_length=100, blank=True, null=True, verbose_name=_("Service Type"))
    response_type = models.CharField(
        max_length=100, blank=True, null=True, verbose_name=_("Response Type"))
    latest_version = models.CharField(
        max_length=100, blank=True, null=True, verbose_name=_("Latest Version"))

    config = JSONField(verbose_name=_("Configuration"), default=dict)
    data = JSONField(verbose_name=_("Data"), default=dict)

    created_date = models.DateTimeField(auto_now_add=True)
    updated_date = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ("code",)

    def __str__(self):
        return "%s - %s" % (self.code, self.name)


@reversion.register()
class ServiceInstanceRepository(models.Model):

    service_instance = models.ForeignKey(
        ServiceInstance, verbose_name=_("Service Instance"), on_delete=models.CASCADE)
    sub_state = models.ForeignKey(
        SubState, null=True, verbose_name=_("Sub state"), on_delete=models.CASCADE)
    service_endpoint = models.CharField(
        max_length=250, verbose_name=_("Service Endpoint"))
    tracking_endpoint = models.CharField(
        max_length=250, null=True, verbose_name=_("Tracking Endpoint"))
    service_version = models.CharField(
        max_length=100, blank=True, null=True, verbose_name=_("Service Version"))

    created_date = models.DateTimeField(auto_now_add=True)
    updated_date = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ('service_instance', 'sub_state')

    def __str__(self):
        return "%s - %s" % (self.service_instance.code, self.service_instance.name)

# Receiver
@receiver(pre_save, sender=ServiceInstance)
def service_instance_receiver(sender, instance, *args, **kwargs):
    try:
        if instance.config:
            intent_ins = list()
            intent_outs = list()
            instance_config = instance.config

            # intent-in
            request_parameters = (instance_config.get(
                'request') or dict()).get('params') or list()
            for param in request_parameters:
                if not param.get('value'):
                    intent_in = {
                        'name': param.get('name'),
                        'type': param.get('type'),
                        'multiple': param.get('multiple'),
                        'label': param.get('label'),
                    }
                    if param.get('required'):
                        intent_in['required'] = True
                    intent_ins.append(intent_in)

            # intent-out
            if instance.response_type == 'json':
                properties = list()
                if instance.service_type == 'sync':
                    properties = (instance_config.get('response')
                                  or dict()).get('properties') or list()
                elif instance.service_type == 'async':
                    properties = ((instance_config.get('tracking') or dict()).get(
                        'response') or dict()).get('properties') or list()

                for prop in properties:
                    intent_out = {
                        'name': prop.get('name'),
                        'type': prop.get('type'),
                        'multiple': prop.get('multiple'),
                        'label': prop.get('label'),
                    }
                    intent_outs.append(intent_out)

            # persist intent data
            instance.data = {
                'intent': {
                    'ins': intent_ins,
                    'outs': intent_outs,
                }
            }
    except Exception as e:
        raise e
