import uuid
import os
import sys

from rest_framework.response import Response
from rest_framework import status

from apps.commons.utilities.log import Logger
from apps.commons.utilities.response import ResponseAPI
from apps.routines.models import LotRoutine
from apps.node_repositories.models import NodeRepository
from apps.node_repositories.api.serializers import NodeRepositorySerializer
from apps.commons.utilities.common import CommonAPIView
from apps.commons.serializers import AbstractSerializer
from apps.commons.error.exception import *


class ListNodeRepositoriesByLotView(CommonAPIView):
    serializer_class = AbstractSerializer
    response_meta = ResponseAPI()
    reference_id = str(uuid.uuid4())

    def post(self, request):
        try:
            logger = Logger('List Node Repositories By Lot')
            logger.set_session_id(self.reference_id)
            logger.debug('list node repositories by lot [reference id = {}] start'.format(self.reference_id))

            request_data = request.data
            logger.debug('list node repositories by lot [reference id = {}] request data'.format(self.reference_id, request_data))

            lot_id = request_data.get('lot_id')
            sub_state_id = request_data.get('sub_state_id')

            if lot_id is None:
                raise BadRequestException('"lot_id" is required')
            if sub_state_id is None:
                raise BadRequestException('"sub_state_id" is required')

            lot_routines = LotRoutine.objects.filter(lot__id=lot_id)
            routine_uuids = list(map(lambda lr: lr.routine.uuid, lot_routines))

            node_repositories = NodeRepository.objects.filter(routine__uuid__in=routine_uuids,
                                                              sub_state__id=sub_state_id)

            serializer = NodeRepositorySerializer(node_repositories, many=True)
            response = self.response_meta.success('success', self.reference_id, serializer.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            logger.error('list node repositories by lot [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            logger.debug(
                'list node repositories by lot [reference id = {}] response'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)
