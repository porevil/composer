import reversion
from django.db import models
from django.utils.translation import ugettext_lazy as _
from jsonfield import JSONField

from apps.commons.generator.constants import GeneratingType
from apps.routines.models import Routine
from apps.configurations.models import SubState


@reversion.register()
class NodeRepository(models.Model):
    GENERATING_TYPE_CHOICES = (
        (GeneratingType.PreDefinedSingleDataset.value, _('pre-defined single dataset')),
        (GeneratingType.PreDefinedMultipleDataset.value, _('pre-defined multiple dataset')),
        (GeneratingType.UserDefined.value, _('user-defined')),
    )

    uuid = models.UUIDField(db_index=True, verbose_name=_("Node ID"))
    code = models.CharField(db_index=True, max_length=100, verbose_name=_("Node Code"))
    name = models.CharField(max_length=200, verbose_name=_("Node Name"))
    description = models.TextField(null=True, blank=True, verbose_name=_("Node Description"))
    url = models.CharField(max_length=255, verbose_name=_("Url"))

    generating_type = models.PositiveSmallIntegerField(default=GeneratingType.PreDefinedSingleDataset.value
                                                       , choices=GENERATING_TYPE_CHOICES
                                                       , verbose_name=_('Generating Type'))

    build_no = models.PositiveIntegerField(null=True, verbose_name=_("Build No"))
    build_data = JSONField(default=dict(), verbose_name=_("Build Data"))

    load_balance_name = models.CharField(max_length=150, default=None, verbose_name=_("Target Load Balance Name"))
    node_name = models.CharField(max_length=150, default=None, verbose_name=_("Target Node Name"))

    routine = models.ForeignKey(Routine, on_delete=models.CASCADE, null=True, verbose_name=_("Routine"))
    sub_state = models.ForeignKey(SubState, on_delete=models.CASCADE, null=True, verbose_name=_("Sub state"))

    created_date = models.DateTimeField(auto_now_add=True, verbose_name=_("Create date"))
    updated_date = models.DateTimeField(auto_now=True, blank=True, verbose_name=_("Update date"))

    class Meta:
        unique_together = ('uuid', 'sub_state')

    def __str__(self):
        return '{} {}'.format(self.name, self.sub_state.name)
