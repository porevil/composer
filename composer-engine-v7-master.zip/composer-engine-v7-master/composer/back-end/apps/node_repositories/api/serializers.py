from rest_framework import serializers
from rest_framework.fields import JSONField

from apps.node_repositories.models import NodeRepository
from apps.routines.models import LotRoutine


class NodeRepositorySerializer(serializers.ModelSerializer):
    dataset_name = serializers.SerializerMethodField()
    lot_id = serializers.SerializerMethodField()

    class Meta:
        model = NodeRepository
        fields = [
            'id',
            'uuid',
            'code',
            'name',
            'description',
            'url',
            'sub_state_id',
            'build_no',
            'dataset_name',
            'generating_type',
            'load_balance_name',
            'node_name',
            'lot_id',
            'created_date',
            'updated_date'
        ]

    def get_dataset_name(self, obj):
        return obj.routine.dataset_name if obj.routine is not None else None

    def get_lot_id(self, obj):
        lot_routine = LotRoutine.objects.filter(routine=obj.routine).first()
        if lot_routine is None or lot_routine.lot is None:
            return None
        return lot_routine.lot.id


class NodeRepositoryDetailSerializer(serializers.ModelSerializer):
    dataset_name = serializers.SerializerMethodField()
    lot_id = serializers.SerializerMethodField()

    class Meta:
        model = NodeRepository
        fields = [
            'id',
            'uuid',
            'code',
            'name',
            'description',
            'url',
            'sub_state_id',
            'build_no',
            'build_data',
            'dataset_name',
            'generating_type',
            'load_balance_name',
            'node_name',
            'routine',
            'lot_id',
            'created_date',
            'updated_date'
        ]

    def get_dataset_name(self, obj):
        return obj.routine.dataset_name if obj.routine is not None else None

    def get_lot_id(self, obj):
        lot_routine = LotRoutine.objects.filter(routine=obj.routine).first()
        if lot_routine is None or lot_routine.lot is None:
            return None
        return lot_routine.lot.id
