import json
import uuid
import os
import sys
import rest_framework_filters as filters

from django.db import transaction
from rest_framework import status
from rest_framework import viewsets
from rest_framework.response import Response
from rest_framework.views import APIView
from django_filters.rest_framework import DjangoFilterBackend

from apps.commons.utilities.response import ResponseAPI
from apps.node_repositories.models import NodeRepository
from apps.node_repositories.api.serializers import NodeRepositorySerializer, NodeRepositoryDetailSerializer
from apps.commons.utilities.log import Logger
from apps.commons.error.exception import *


def is_valid_uuid(request_uuid, version=4):
    try:
        uuid_obj = uuid.UUID(str(request_uuid), version=version)
    except ValueError:
        return False

    return str(uuid_obj) == request_uuid

class NodeRepositoryFilter(filters.FilterSet):

    class Meta:
        model = NodeRepository
        fields = {
            'code': ['exact', 'startswith', 'icontains'],
            'name': ['icontains'],
            'uuid': ['exact'],
            'routine__dataset_name': ['exact'],
            'sub_state_id': ['exact'],
            'generating_type': ['exact'],
        }


class NodeRepositoryViewSet(viewsets.ModelViewSet):
    http_method_names = ['get']
    response_meta = ResponseAPI()
    reference_id = str(uuid.uuid4())
    serializer_class = NodeRepositorySerializer
    filter_class = NodeRepositoryFilter
    logger = Logger('Node Repositories')
    queryset = NodeRepository.objects.all()

    def list(self, request, **kwargs):
        try:
            self.logger.debug('list node repositories [reference id = {}] start'.format(self.reference_id))

            request_uuid = request.query_params.get('uuid')
            if request_uuid is not None and request_uuid:
                is_valid = is_valid_uuid(request_uuid)

                if not is_valid:
                    raise BadRequestException('"uuid" is invalid')

            detail = False
            for key, value in request.query_params.items():
                if key == 'detail':
                    detail = True if value in ['true', 'True'] else False

            queryset = NodeRepository.objects.all()
            queryset = DjangoFilterBackend().filter_queryset(self.request, queryset, self)

            if detail:
                serializer = NodeRepositoryDetailSerializer(queryset, many=True)
            else:
                serializer = NodeRepositorySerializer(queryset, many=True)

            response = self.response_meta.success("success", self.reference_id, serializer.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('list node repositories [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug(
                'list node repositories [reference id = {}] response = {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)


# class NodeRepositoryDetailViewset(viewsets.ModelViewSet):
#     http_method_names = ['get']
#     response_meta = ResponseAPI()
#     reference_id = str(uuid.uuid4())
#     serializer_class = NodeRepositoryDetailSerializer
#     filter_class = NodeRepositoryFilter
#     logger = Logger('Node Repositories')

#     def list(self, request, **kwargs):
#         try:
#             self.logger.debug('list node repositories [reference id = {}] start'.format(self.reference_id))

#             queryset = NodeRepository.objects.all()
#             queryset = DjangoFilterBackend().filter_queryset(self.request, queryset, self)
#             serializer = NodeRepositoryDetailSerializer(queryset, many=True)
#             response = self.response_meta.success("success", self.reference_id, serializer.data)

#         except Exception as e:
#             fname = os.path.abspath(__file__)
#             exc_type, exc_obj, exc_tb = sys.exc_info()
#             exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

#             response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

#             self.logger.error('list node repositories [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

#         finally:
#             self.logger.debug(
#                 'list node repositories [reference id = {}] response = {}'.format(self.reference_id, response))
#             return Response(response, status=status.HTTP_200_OK)
