import uuid
import threading
import os
import sys

import rest_framework_filters as filters
from rest_framework import viewsets
from rest_framework.response import Response
from rest_framework import status
from rest_framework.schemas import AutoSchema

from apps.commons.logger.views import ViewLogger
from apps.commons.utilities.log import Logger
from apps.commons.utilities.response import ResponseAPI
from apps.commons.connectors.launcher_service_repository import LauncherServiceRepository
from apps.configurations.models import State, SubState
from apps.commons.serializers import AbstractSerializer
from apps.commons.error.exception import *
from apps.service_instance.models import ServiceInstance


class ServiceRepositoryFilter(filters.FilterSet):
    class Meta:
        model = SubState
        fields = {
            'state_id': ['exact']
        }


class ServiceRepositoryViewSet(viewsets.ModelViewSet, ViewLogger):
    response_meta = ResponseAPI()
    reference_id = str(uuid.uuid4())
    filter_class = ServiceRepositoryFilter
    serializer_class = AbstractSerializer
    queryset = SubState.objects.all()

    def list(self, request):
        try:
            # logger = Logger('List Service Repository')
            self.logger.debug('list service repository [reference id = {}] start'.format(request.session_id))

            state_id = request.query_params.get('state_id')
            if state_id is None:
                raise BadRequestException('"state id" is required')

            state = State.objects.filter(id=state_id).first()
            if state is None:
                raise BadRequestException('"state id" is invalid')

            self.logger.debug(
                'list service repository [reference id = {}] state name: {}'.format(request.session_id, state.name))

            response = LauncherServiceRepository.list(state)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , request.session_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('list service repository [reference id = {}] exception - {}'.format(request.session_id, exception_message))

        finally:
            self.logger.debug('list service repository [reference id = {}] response: {}'.format(request.session_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def retrieve(self, request, pk=None, **kwargs):
        try:
            # logger = Logger('Get Service Repository')
            self.logger.debug('get service repository [reference id = {}] start'.format(request.session_id))

            state_id = request.query_params.get('state_id')
            if state_id is None:
                raise BadRequestException('"state id" is required')

            state = State.objects.filter(id=state_id).first()
            if state is None:
                raise BadRequestException('"state id" is invalid')

            self.logger.debug(
                'get service repository [reference id = {}] state name: {}'.format(request.session_id, state.name))

            response = LauncherServiceRepository.retrieve(state, pk)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , request.session_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('get service repository [reference id = {}] exception - {}'.format(request.session_id, exception_message))

        finally:
            self.logger.debug('get service repository [reference id = {}] response: {}'.format(request.session_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def create(self, request, **kwargs):
        try:
            # logger = Logger('Create Service Repository')
            self.logger.debug('create service repository [reference id = {}] start'.format(request.session_id))

            request_data = request.data
            self.logger.debug('create service repository [reference id = {}] request data: {}'.format(request.session_id,
                                                                                                 request_data))

            state_id = request_data.get('state_id')
            name = request_data.get('name')
            url = request_data.get('url')
            request_config = request_data.get('request') or dict()

            if name is None:
                raise BadRequestException('"name" is required')
            if state_id is None:
                raise BadRequestException('"state id" is required')

            state = State.objects.filter(id=state_id).first()
            if state is None:
                raise BadRequestException('"state id" is invalid')

            self.logger.debug(
                'create service repository [reference id = {}] state name: {}'.format(request.session_id, state.name))

            response = LauncherServiceRepository.create(state, **{
                'name': name,
                'url': url,
                'request': request_config,
            })

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , request.session_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('create service repository [reference id = {}] exception - {}'.format(request.session_id, exception_message))

        finally:
            self.logger.debug('create service repository [reference id = {}] response: {}'.format(request.session_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def update(self, request, pk=None, **kwargs):
        try:
            # logger = Logger('Update Service Repository')
            self.logger.debug('update service repository [reference id = {}] start'.format(request.session_id))

            request_data = request.data
            self.logger.debug('update service repository [reference id = {}] request data: {}'.format(request.session_id,
                                                                                                 request_data))

            if pk is None:
                raise BadRequestException('"id" is required')

            state_id = request_data.get('state_id')
            name = request_data.get('name')
            url = request_data.get('url')
            request_config = request_data.get('request') or dict()

            if state_id is None:
                raise BadRequestException('"state id" is required')

            state = State.objects.filter(id=state_id).first()
            if state is None:
                raise BadRequestException('"state id" is invalid')

            self.logger.debug(
                'update service repository [reference id = {}] state name: {}'.format(request.session_id, state.name))

            response = LauncherServiceRepository.update(state, pk, **{
                'name': name,
                'url': url,
                'request': request_config,
            })

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , request.session_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('update service repository [reference id = {}] exception - {}'.format(request.session_id, exception_message))

        finally:
            self.logger.debug('update service repository [reference id = {}] response - {}'.format(request.session_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def destroy(self, request, *args, **kwargs):
        try:
            # logger = Logger('Delete Service Repository')
            self.logger.debug('delete service repository [reference id = {}] start'.format(request.session_id))

            state_id = request.query_params.get('state_id')
            if state_id is None:
                raise BadRequestException('"state id" is required')

            state = State.objects.filter(id=state_id).first()
            if state is None:
                raise BadRequestException('"state id" is invalid')

            self.logger.debug(
                'delete service repository [reference id = {}] state name: {}'.format(request.session_id, state.name))

            id = kwargs.get('pk')
            response = LauncherServiceRepository.delete(state, id)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , request.session_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('delete service repository [reference id = {}] exception - {}'.format(request.session_id, exception_message))

        finally:
            self.logger.debug('delete service repository [reference id = {}] exception - {}'.format(request.session_id, response))
            return Response(response, status=status.HTTP_200_OK)
