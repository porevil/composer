import uuid
import os
import sys

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.schemas import AutoSchema
from rest_framework import viewsets

from apps.generator_setting.models import VirtualGroup
from apps.commons.utilities.log import Logger
from apps.metadata.models import Datafield, Dataset
from apps.generator_setting.api.serializers import GroupSerializer
from apps.metadata.api.serializers import DatasetSerializer ,DatafieldSerializer
from apps.commons.utilities.response import ResponseAPI
from apps.commons.error.exception import *


class DatasetViewSet(viewsets.ModelViewSet):
    http_method_names = ['get', 'post']
    response_meta = ResponseAPI()
    reference_id = str(uuid.uuid4())
    serializer_class = DatasetSerializer
    logger = Logger('Dataset API')

    def list(self, request):
        try:
            self.logger.debug('list dataset [reference id = {}] start'.format(self.reference_id))

            dataset = Dataset.objects.all().order_by('id')
            serializer = DatasetSerializer(dataset, many=True)
            response = self.response_meta.success("success", self.reference_id, serializer.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('list dataset [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('list dataset [reference id = {}] response - {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)
    

    def create(self, request):
        try:
            self.logger.debug('create or update dataset [reference id = {}] start'.format(self.reference_id))

            request_data = request.data or dict()

            self.logger.debug('create or update dataset [reference id = {}] request data - {}'.format(self.reference_id, request_data))

            description = request_data.get('description')
            dataset_name = request_data.get('dataset_name')
            version = request_data.get('version')
            updated_by = request_data.get('updated_by')

            result, created = Dataset.objects.update_or_create(description=description,dataset_name=dataset_name,version=version,updated_by=updated_by, defaults={
                'description': description,
                'dataset_name': dataset_name,
                'version': version,
                'updated_by':updated_by
            })

            if created:
                response = self.response_meta.success("create success", self.reference_id, DatasetSerializer(result).data)
            else:
                response = self.response_meta.success("update success", self.reference_id, DatasetSerializer(result).data)
        
        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('create or update dataset [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('create or update dataset [reference id = {}] response - {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)


    def retrieve(self, request, pk=None ):
        try:
            self.logger.debug('retrieve dataset [reference id = {}] start'.format(self.reference_id))

            if pk is None:
                raise BadRequestException('"dataset name" is required')

            datafields = Datafield.objects.filter(dataset_id__dataset_name=pk)
            serializer = DatafieldSerializer(datafields, many=True)

            response = self.response_meta.success("success", self.reference_id, serializer.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('retrieve dataset [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('retrieve dataset [reference id = {}] response - {}'.format(self.reference_id, resposne))
            return Response(response, status=status.HTTP_200_OK)

    