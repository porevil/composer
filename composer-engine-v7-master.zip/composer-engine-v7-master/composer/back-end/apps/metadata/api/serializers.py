from rest_framework import serializers
from rest_framework.fields import JSONField

from apps.metadata.models import Datafield, Dataset
from apps.generator_setting.models import VirtualDatafieldConfig, DatasetConfiguration, DatasetSetting ,DatafieldSetting


class DatafieldSerializer(serializers.ModelSerializer):
    class Meta:
        model = Datafield
        fields = [
            'id',
            'field_name',
            'field_type',
            'label_name',
            'parameter_type',
        ]


class DatafieldRefConfigSerializer(serializers.ModelSerializer):
    config = serializers.SerializerMethodField()
    sequence = serializers.SerializerMethodField()

    class Meta:
        model = Datafield
        fields = [
            'id',
            'field_name',
            'field_type',
            'label_name',
            'parameter_type',
            'config',
            'sequence'
        ]

    def get_config(self, obj):
        config = DatasetSetting.objects.filter(field_id=obj.id).first()
        if config is not None:
            return config.config
        else:
            return dict()

    def get_sequence(self, obj):
        config = DatasetSetting.objects.filter(field_id=obj.id).first()
        if config is not None:
            return config.sequence
        else:
            return None

class DatafieldSettingRefConfigSerializer(serializers.ModelSerializer):
    datafields = serializers.SerializerMethodField()
    config = serializers.SerializerMethodField()
    sequence = serializers.SerializerMethodField()
    datafield_setting_config = serializers.SerializerMethodField()
    class Meta:
        model = Datafield
        fields = [
            'id',
            'field_name',
            'field_type',
            'label_name',
            'parameter_type',
            'datafields',
            'config',
            'sequence',
            'datafield_setting_config'
        ]

    def get_datafields(self, obj):
        if obj.parameter_type == 'EMBEDED' or obj.parameter_type == 'TISCO':
            datafields = Datafield.objects.filter(ref_name=obj.field_name).order_by('id')
            serializer = DatafieldRefConfigSerializer(datafields, many=True)
            return serializer.data
        else:
            return list()

    def get_datafield_setting_config(self, obj):
        datafield_setting_config = DatafieldSetting.objects.filter(name=obj.field_name).first()
        if datafield_setting_config:
            return datafield_setting_config.config
        else:
            return dict()

    def get_config(self, obj):
        config = DatasetSetting.objects.filter(field_id=obj.id).first()
        if config:
            return config.config
        else:
            return dict()

    def get_sequence(self, obj):
        config = DatasetSetting.objects.filter(field_id=obj.id).first()
        if config:
            return config.sequence
        else:
            return None

class DatafieldRefSerializer(serializers.ModelSerializer):
    datafields = serializers.SerializerMethodField()
    config = serializers.SerializerMethodField()
    sequence = serializers.SerializerMethodField()

    class Meta:
        model = Datafield
        fields = [
            'id',
            'field_name',
            'field_type',
            'label_name',
            'parameter_type',
            'datafields',
            'config',
            'sequence'
        ]

    def get_datafields(self, obj):
        if obj.parameter_type == 'EMBEDED' or obj.parameter_type == 'TISCO':
            datafields = Datafield.objects.filter(ref_name=obj.field_name).order_by('id')
            serializer = DatafieldRefConfigSerializer(datafields, many=True)
            return serializer.data
        else:
            return list()

    def get_config(self, obj):
        config = DatasetSetting.objects.filter(field_id=obj.id).first()
        if config:
            return config.config
        else:
            return dict()

    def get_sequence(self, obj):
        config = DatasetSetting.objects.filter(field_id=obj.id).first()
        if config:
            return config.sequence
        else:
            return None


class DatafieldDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = Datafield
        fields = [
            'id',
            'field_name',
            'field_type',
            'label_name',
            'parameter_type',
            'dataset_id'
        ]


class DatasetSerializer(serializers.ModelSerializer):

    class Meta:
        model = Dataset
        fields = [
            'id',
            'dataset_name',
            'version',
            'description',
            'created_by',
            'updated_by',
            'created_date',
            'updated_date',
        ]


class DatasetDetailSerializer(serializers.ModelSerializer):
    datafields = serializers.SerializerMethodField()

    class Meta:
        model = Dataset
        fields = [
            'id',
            'dataset_name',
            'version',
            'description',
            'created_by',
            'updated_by',
            'created_date',
            'updated_date',
            'datafields'
        ]

    def get_datafields(self, obj):
        datafields = Datafield.objects.filter(dataset_id=obj.id, ref_name=None).order_by('id')
        serializer = DatafieldRefSerializer(datafields, many=True)
        return serializer.data


class DatasetSettingDetailSerializer(serializers.ModelSerializer):
    datafields = serializers.SerializerMethodField()
    config = serializers.SerializerMethodField()
    
    class Meta:
        model = Dataset
        fields = [
            'id',
            'dataset_name',
            'version',
            'description',
            'created_by',
            'updated_by',
            'created_date',
            'updated_date',
            'config',
            'datafields'
        ]

    def get_datafields(self, obj):
        datafields = Datafield.objects.filter(dataset_id=obj.id,ref_name=None).order_by('id')
        serializer = DatafieldSettingRefConfigSerializer(datafields, many=True)
        return serializer.data
    
    def get_config(self, obj):
        config = DatasetConfiguration.objects.filter(dataset_id=obj.id).first()
        if config is not None:
            return config.config
        else:
            return dict()

class DatafieldVirtualRefSerializer(serializers.ModelSerializer):
    datafields = serializers.SerializerMethodField()
    dataset_name =  serializers.SerializerMethodField()
    config = serializers.SerializerMethodField()
    sequence = serializers.SerializerMethodField()
    field_id = serializers.SerializerMethodField()
    class Meta:
        model = Datafield
        fields = [
            'id',
            'field_name',
            'field_type',
            'label_name',
            'parameter_type',
            'datafields',
            'child_dataset_id',
            'dataset_id',
            'dataset_name',
            'config',
            'sequence',
            'field_id'
        ]

    def get_datafields(self, obj):
        if obj.parameter_type == 'PUBLIC' or obj.parameter_type == 'MASTER':
            datafields = Datafield.objects.filter(dataset_id=obj.child_dataset_id).order_by('id')
            serializer = DatafieldVirtual3RefSerializer(datafields, many=True)
            return serializer.data
        else:
            return list()

    def get_dataset_name(self, obj):
        return obj.dataset_id.dataset_name
    
    def get_config(self, obj):
            return dict()

    def get_sequence(self, obj):
            return None
    
    def get_field_id(self, obj):
        return obj.id

class DatafieldVirtual2RefSerializer(DatafieldVirtualRefSerializer):

    def get_datafields(self, obj):
        if obj.parameter_type == 'PUBLIC' or obj.parameter_type == 'MASTER':
            datafields = Datafield.objects.filter(dataset_id=obj.child_dataset_id).order_by('id')
            serializer = DatafieldVirtual3RefSerializer(datafields, many=True)
            return serializer.data
        else:
            return list()

class DatafieldVirtual3RefSerializer(DatafieldVirtualRefSerializer):

    def get_datafields(self, obj):
        return list()

class DatasetVirtualDetailSerializer(serializers.ModelSerializer):
    datafields = serializers.SerializerMethodField()
    field_id = serializers.SerializerMethodField()
    class Meta:
        model = Dataset
        fields = [
            'id',
            'dataset_name',
            'version',
            'description',
            'created_by',
            'updated_by',
            'created_date',
            'updated_date',
            'datafields',
            'field_id'
        ]

    def get_datafields(self, obj):
        datafields = Datafield.objects.filter(dataset_id=obj.id, ref_name=None).order_by('id')
        serializer = DatafieldVirtual1RefSerializer(datafields, many=True)
        return serializer.data
    
    def get_field_id(self, obj):
        return obj.id

class DatafieldVirtual1RefSerializer(DatafieldVirtualRefSerializer):

    def get_datafields(self, obj):
        if obj.parameter_type == 'MASTER' or obj.parameter_type == 'PUBLIC':
            datafields = Datafield.objects.filter(dataset_id=obj.child_dataset_id).order_by('id')
            serializer = DatafieldVirtual3RefSerializer(datafields, many=True)
            return serializer.data
        else:
            return list()