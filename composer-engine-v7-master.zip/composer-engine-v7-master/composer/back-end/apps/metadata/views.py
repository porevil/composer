import uuid
import threading
import os
import sys

from datetime import datetime

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from apps.commons.utilities.log import Logger
from apps.commons.utilities.response import ResponseAPI
from apps.commons.connectors.metadata import Metadata
from apps.commons.managers.role import RoleManager
from apps.commons.error.exception import *
from apps.configurations.models import SubState


class MetadataView(APIView):

    response_meta = ResponseAPI()
    reference_id = str(uuid.uuid4())

    def get(self, request, dataset_name=None):
        if dataset_name is None:
            return self._list_metadata()
        else:
            return self._get_metadata(dataset_name)

    
    def _list_metadata(self):
        try:
            logger = Logger('Core API', 'List Metadata')
            logger.set_session_id(self.reference_id)
            logger.debug('list metadata [reference id = {}] start'.format(self.reference_id))

            metadata_sub_state = SubState.default()
            if metadata_sub_state is None:
                raise ConfigurationErrorException("no default sub state")

            meta_response = Metadata.list(metadata_sub_state)
            response = self.response_meta.success("success", self.reference_id, meta_response)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            logger.error('list metadata [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            logger.debug('list metadata [reference id = {}] resposne - {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    
    def _get_metadata(self, dataset_name):
        try:
            logger = Logger('Core API', 'Get Metadata')
            logger.set_session_id(self.reference_id)
            logger.debug('get metadata ({}) [reference id = {}] start'.format(dataset_name, self.reference_id))

            metadata_sub_state = SubState.default()
            if metadata_sub_state is None:
                raise ConfigurationErrorException("no default sub state")

            logger.debug('get metadata ({}) [reference id = {}] automated grant metadata access roles'.format(dataset_name, self.reference_id))
            RoleManager().grant_metadata_access_roles([dataset_name], metadata_sub_state)

            meta_response = Metadata.get(metadata_sub_state, dataset_name)
            response = self.response_meta.success("success", self.reference_id, meta_response)
            
        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            logger.error('get metadata [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            logger.debug('get metadata [reference id = {}] response - {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

