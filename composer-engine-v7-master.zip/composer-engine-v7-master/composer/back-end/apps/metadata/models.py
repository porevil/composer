import reversion

from jsonfield import JSONField
from django.db import models
from django.utils.translation import ugettext_lazy as _

@reversion.register()
class Dataset(models.Model):
    dataset_name = models.CharField(max_length=100, unique=True, verbose_name=_("Dataset Name"))
    description = models.CharField(max_length=200, verbose_name=_("Description"))
    version = models.CharField(max_length=25, null=True, blank=True, verbose_name=_("Version"))
    created_by = models.CharField(max_length=100, blank=True, null=True, verbose_name=_("Created by"))
    updated_by = models.CharField(max_length=100, null=True, blank=True, verbose_name=_("Updated by"))
    created_date = models.DateTimeField(auto_now_add=True, verbose_name=_("Created date"))
    updated_date = models.DateTimeField(auto_now=True, blank=True, verbose_name=_("Updated date"))

    def __str__(self):
        return "%s " % (self.dataset_name)


@reversion.register()
class Datafield(models.Model):
    field_name = models.CharField(max_length=100, verbose_name=_("Field Name"))
    dataset_id = models.ForeignKey(Dataset, null=True, blank=True, default=None, on_delete=models.deletion.CASCADE, verbose_name=_("Parent Dataset Id"), related_name='dataset_id')
    field_type = models.CharField(max_length=100, null=True, blank=True, verbose_name=_("Field Type"))
    parameter_type = models.CharField(max_length=100, null=True, blank=True, verbose_name=_("Parameter Type"))
    label_name = models.CharField(max_length=100,  null=True, blank=True,  verbose_name=_("Label Name"))
    ref_name = models.CharField(max_length=100, null=True, blank=True, default=None, verbose_name=_("Reference Name"))
    child_dataset_id = models.ForeignKey(Dataset, null=True, blank=True, default=None, on_delete=models.deletion.CASCADE, verbose_name=_("Child Dataset Id"), related_name='child_dataset_id')
    
    class Meta:
        unique_together = (['field_name','dataset_id','ref_name', 'child_dataset_id'])

    def __str__(self):
        return "%s " % (self.field_name)

