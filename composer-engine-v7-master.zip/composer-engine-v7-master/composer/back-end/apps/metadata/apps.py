from django.apps import AppConfig


class Metadata(AppConfig):
    name = 'metadata'
