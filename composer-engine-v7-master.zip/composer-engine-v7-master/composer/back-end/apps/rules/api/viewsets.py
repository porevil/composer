import json
import uuid
import os
import sys
import rest_framework_filters as filters
import re

from django.db import transaction
from rest_framework import status
from rest_framework import viewsets
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.commons.utilities.response import ResponseAPI
from apps.rules.models import TemplateRule
from apps.rules.api.serializers import TemplateRuleSerializer, TemplateRuleDetailSerializer
from apps.commons.utilities.log import Logger
from apps.commons.error.exception import *


class TemplateRuleViewSet(viewsets.ModelViewSet):
    response_meta = ResponseAPI()
    reference_id = str(uuid.uuid4())
    serializer_class = TemplateRuleSerializer
    logger = Logger('Template Rule')
    queryset = TemplateRule.objects.all()

    def list(self, request):
        try:
            self.logger.debug('list template rule [reference id = {}] start'.format(self.reference_id))

            template_rules = TemplateRule.objects.all()
            serializer = TemplateRuleSerializer(template_rules, many=True)
            response = self.response_meta.success("success", self.reference_id, serializer.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('list template rule [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('list template rule [reference id = {}] response = {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def retrieve(self, request, pk=None):
        try:
            self.logger.debug('retrieve template rule [reference id = {}] start'.format(self.reference_id))

            if pk is None:
                raise BadRequestException('"id" is required')

            if type(pk) is not int and (type(pk) is str and not pk.isdigit()):
                raise BadRequestException('"id" is invalid')

            template_rule = TemplateRule.objects.filter(id=pk).first()
            if template_rule is None:
                raise BadRequestException('"id" is invalid')

            serializer = TemplateRuleDetailSerializer(template_rule)
            response = self.response_meta.success("success", self.reference_id, serializer.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('retrieve template rule [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('retrieve template rule [reference id = {}] response = {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def create(self, request):
        try:
            with transaction.atomic():
                self.logger.debug('create template rule [reference id = {}] start'.format(self.reference_id))

                request_data = request.data or dict()
                self.logger.debug(
                    'create template rule [reference id = {}] request data = {}'.format(self.reference_id, request_data))

                generating_type = request_data.get('generating_type')
                standard_process_code = request_data.get('standard_process_code')
                dataset_name = request_data.get('dataset_name')
                attributes = request_data.get('attributes') or dict()

                template_rule = TemplateRule.objects.create(**{
                    'generating_type': generating_type,
                    'standard_process_code': standard_process_code,
                    'dataset_name': dataset_name,
                    'attributes': attributes
                })

                response = self.response_meta.success('create success', self.reference_id,
                                                      TemplateRuleDetailSerializer(template_rule).data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('create template rule [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('create template rule [reference id = {}] response = {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def update(self, request, pk=None):
        try:
            with transaction.atomic():
                self.logger.debug('update template rule [reference id = {}] start'.format(self.reference_id))

                if pk is None:
                    raise BadRequestException('"id" is required')

                if type(pk) is not int and (type(pk) is str and not pk.isdigit()):
                    raise BadRequestException('"id" is invalid')

                template_rule = TemplateRule.objects.filter(id=pk).first()
                if template_rule is None:
                    raise BadRequestException('"id" is invalid')

                request_data = request.data or dict()
                self.logger.debug(
                    'update template rule [reference id = {}] request data = {}'.format(self.reference_id, request_data))

                generating_type = request_data.get('generating_type')
                standard_process_code = request_data.get('standard_process_code')
                dataset_name = request_data.get('dataset_name')
                attributes = request_data.get('attributes') or dict()

                # update menu model
                template_rule.generating_type = generating_type
                template_rule.standard_process_code = standard_process_code
                template_rule.dataset_name = dataset_name
                template_rule.attributes = attributes
                template_rule.save()

                response = self.response_meta.success('update success', self.reference_id,
                                                      TemplateRuleDetailSerializer(template_rule).data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('update template rule [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('update template rule [reference id = {}] response = {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def destroy(self, request, *args, **kwargs):
        try:
            self.logger.debug('delete lot [reference id = {}] start'.format(self.reference_id))

            id = kwargs.get('pk')
            if id is None:
                raise BadRequestException('"id" is required')

            if type(id) is not int and (type(id) is str and not id.isdigit()):
                raise BadRequestException('"id" is invalid')

            template_rule = TemplateRule.objects.filter(id=id).first()
            if template_rule is None:
                raise BadRequestException('"id" is invalid')

            template_rule.delete()

            response = self.response_meta.success('delete success', self.reference_id)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('delete template rule [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('delete template rule [reference id = {}] response = {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

