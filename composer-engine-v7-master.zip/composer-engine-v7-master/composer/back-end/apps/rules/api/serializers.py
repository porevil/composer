from rest_framework import serializers
from rest_framework.fields import JSONField

from apps.rules.models import TemplateRule


class TemplateRuleSerializer(serializers.ModelSerializer):
    class Meta:
        model = TemplateRule
        fields = [
            'id',
            'generating_type',
            'standard_process_code',
            'dataset_name',
        ]


class TemplateRuleDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = TemplateRule
        fields = [
            'id',
            'generating_type',
            'standard_process_code',
            'dataset_name',
            'attributes',
        ]
