import reversion

from django.db import models
from django.utils.translation import ugettext_lazy as _
from jsonfield import JSONField


@reversion.register()
class TemplateRule(models.Model):
    generating_type = models.CharField(max_length=10, null=True, blank=True, default='default', verbose_name=_("Generating Type"))
    standard_process_code = models.CharField(max_length=10, null=True, blank=True, default='default', verbose_name=_("Standard Process Name"))
    dataset_name = models.CharField(max_length=10, null=True, blank=True, default='default', verbose_name=_("Dataset"))
    attributes = JSONField(verbose_name=_("Attributes"))
    
    class Meta:
        unique_together = ("generating_type", "standard_process_code", "dataset_name")

    def __str__(self):
        return "input({}, {}, {})".format(self.generating_type, self.standard_process_code, self.dataset_name)
    
