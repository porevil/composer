import json
import uuid
import os
import sys
import rest_framework_filters as filters

from django.db import transaction
from django.db import Error
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import viewsets
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.schemas import AutoSchema

from apps.console_output.api.serializers import ConsoleOutputSerializer, ConsoleOutputDetailSerializer
from apps.console_output.models import ConsoleOutput
from apps.commons.utilities.common import CommonAPIView
from apps.commons.generator.constants import ActionAuthority
from apps.commons.utilities.response import ResponseAPI
from apps.commons.utilities.log import Logger
from apps.commons.error.exception import *


class ConsoleOutputFilter(filters.FilterSet):

    class Meta:
        model = ConsoleOutput
        fields = {
            'executed_by': ['exact', 'startswith', 'contains', 'icontains'],
            'start_datetime': ['gt', 'gte'],
            'end_datetime': ['lt', 'lte'],
            'id': ['exact'],
            'authorized_ticket': ['exact'],
        }


class ConsoleOutputViewSet(viewsets.ModelViewSet):
    response_meta = ResponseAPI()
    reference_id = str(uuid.uuid4())
    serializer_class = ConsoleOutputDetailSerializer
    filter_class = ConsoleOutputFilter
    logger = Logger('Console Output')
    queryset = ConsoleOutput.objects.all()

    def list(self, request):
        try:
            self.logger.debug('list console output [reference id = {}] start'.format(self.reference_id))

            request_params = request.query_params
            request_id = request_params.get('id')
            if request_id is not None and request_id:
                is_valid = type(request_id) is int or (type(request_id) is str and request_id.isdigit())

                if not is_valid:
                    raise BadRequestException('"id" is invalid')

            queryset = ConsoleOutput.objects.all().order_by('-id')
            queryset = DjangoFilterBackend().filter_queryset(self.request, queryset, self)
            serializer = ConsoleOutputSerializer(queryset, many=True)
            response = self.response_meta.success("success", self.reference_id, serializer.data)


        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('list console output [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            return Response(response, status=status.HTTP_200_OK)


    def retrieve(self, request, pk=None):
        try:
            self.logger.debug('retrieve console output [reference id = {}] start'.format(self.reference_id))

            console_output = ConsoleOutput.objects.filter(id=pk).first()
            if console_output is None:
                raise BadRequestException('"id" is invalid')

            serializer = ConsoleOutputDetailSerializer(console_output)
            response = self.response_meta.success("success", self.reference_id, serializer.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('retrieve console output [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            return Response(response, status=status.HTTP_200_OK)
    

    def destroy(self, request, *args, **kwargs):
        try:
            if not CommonAPIView().has_permission(request, ActionAuthority.REMOVE_CONSOLE.value):
                raise ActionUnAuthorizedException('not authorized to purge')

            self.logger.debug('delete console output [reference id = {}] start'.format(self.reference_id))

            console_output = ConsoleOutput.objects.filter(id=kwargs.get('pk')).first()
            if console_output is None:
                raise BadRequestException('"id" is invalid')

            console_output.delete()

            response = self.response_meta.success('delete success', self.reference_id)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('delete console output [reference id = {}] exception - {}'.format(self.reference_id, exception_message))
            
        finally:
            self.logger.debug('delete console output [reference id = {}] response - {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

