from rest_framework import serializers

from apps.console_output.models import ConsoleOutput


class ConsoleOutputSerializer(serializers.ModelSerializer):
    class Meta:
        model = ConsoleOutput
        fields = [
            'id',
            'title',
            'authorized_ticket',
            'start_datetime',
            'end_datetime',
            'executed_by'
        ]

class ConsoleOutputDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = ConsoleOutput
        fields = [
            'id',
            'title',
            'output',
            'authorized_ticket',
            'start_datetime',
            'end_datetime',
            'executed_by'
        ]
