import reversion

from django.utils import timezone
from django.db import models


@reversion.register()
class ConsoleOutput(models.Model):

    title = models.CharField(max_length=100)
    output = models.TextField(null=True)
    authorized_ticket = models.CharField(max_length=30, null=True)
    executed_by = models.CharField(max_length=30, null=True)
    start_datetime = models.DateTimeField(auto_now_add=True)
    end_datetime = models.DateTimeField(null=True)

    def __str__(self):
        return '{} - {}'.format(self.title, self.start_datetime)

    def append(self, output):
        self.output = (output if self.output is None else self.output + '\n\n' + output)
        self.save()

    def finish(self):
        self.end_datetime = timezone.now()
        self.save()

