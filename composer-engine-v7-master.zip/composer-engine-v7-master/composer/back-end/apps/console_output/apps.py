from django.apps import AppConfig


class ConsoleOutputConfig(AppConfig):
    name = 'console_output'
