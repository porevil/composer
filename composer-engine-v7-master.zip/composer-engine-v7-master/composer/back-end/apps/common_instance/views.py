import uuid
import threading
import os
import sys

from datetime import datetime
from rest_framework.response import Response
from rest_framework import status

from apps.commons.utilities.response import ResponseAPI
from apps.commons.utilities.common import CommonAPIView
from apps.commons.utilities.log import Logger
from apps.commons.generator.constants import ActionAuthority
from apps.commons.generator.managers.common_instance import CommonInstanceManager
from apps.console_output.models import ConsoleOutput
from apps.configurations.models import SubState
from apps.commons.serializers import AbstractSerializer
from apps.commons.error.exception import *


class BuildAndPublishView(CommonAPIView):
    serializer_class = AbstractSerializer
    response_meta = ResponseAPI()

    def post(self, request, *args, **kwargs):
        reference_id = request.session_id
        logger = Logger('Instance API', 'Build and Publish')
        logger.set_session_id(reference_id)

        try:
            logger.set_user_id(self.current_userid(request))
            logger.debug('build and publish instance [reference id = {}] start'.format(reference_id))

            request_data = request.data
            logger.debug(
                'build and publish instance [reference id = {}] request data = {}'.format(reference_id, request_data))

            instance_uuid = request_data.get('uuid')
            authorized_ticket = request_data.get('authorized_ticket')

            if instance_uuid is None:
                raise BadRequestException('"uuid" is required')

            destination_sub_state = SubState.objects.filter(is_default=True).first()
            if destination_sub_state is None:
                raise BadRequestException('"destination_sub_state_id" is invalid')

            if destination_sub_state.need_authorized_ticket \
                    and (authorized_ticket is None or authorized_ticket.strip() == ''):
                raise BadRequestException('"authorized_ticket" is required')

            if not self.has_permission(request, ActionAuthority.BUILD.value):
                raise ActionUnAuthorizedException('not authorized to build')

            if destination_sub_state.is_production:
                if not self.has_permission(request, ActionAuthority.PUBLISH_PROD.value):
                    raise ActionUnAuthorizedException('not authorized to publish on production')
            elif destination_sub_state.is_pre_production:
                if not self.has_permission(request, ActionAuthority.PUBLISH_PRE_PROD.value):
                    raise ActionUnAuthorizedException('not authorized to publish on pre-production')
            else:
                if not self.has_permission(request, ActionAuthority.PUBLISH_NON_PROD.value):
                    raise ActionUnAuthorizedException('not authorized to publish on non-production')

            executed_by = self.current_username(request)
            console_output = ConsoleOutput.objects.create(
                title='Build and Publish Instance to "{}"'.format(destination_sub_state.name)
                , executed_by=executed_by
                , authorized_ticket=authorized_ticket)

            threading.Thread(target=lambda: self.process([instance_uuid]
                                                         , destination_sub_state
                                                         , console_output
                                                         , executed_by
                                                         , authorized_ticket)).start()

            response = self.response_meta.success('success', reference_id, {
                'console_output_id': console_output.id,
            })

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e), reference_id, str(exc_type), fname, str(exc_tb.tb_lineno))

            logger.error(
                'build and publish instance [reference id = {}] exception - {}'.format(reference_id, exception_message))

        finally:
            logger.debug('build and publish instance [reference id = {}] response = {}'.format(reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def process(self, instance_uuids, destination_sub_state, console_output, executed_by, authorized_ticket):
        try:
            success, error_list = CommonInstanceManager().build_and_publish(instance_uuids
                                                                            , destination_sub_state
                                                                            , console_output=console_output
                                                                            , executed_by=executed_by
                                                                            , authorized_ticket=authorized_ticket)
            console_output.append('complete')
            return success, error_list
        except Exception as e:
            console_output.append('fail with exception: {}'.format(str(e)))
            raise e
        finally:
            console_output.finish()


class RepublishView(CommonAPIView):
    serializer_class = AbstractSerializer
    response_meta = ResponseAPI()

    def post(self, request, *args, **kwargs):
        reference_id = request.session_id
        logger = Logger('Instance API', 'Republish')
        logger.set_session_id(reference_id)

        try:
            logger.set_user_id(self.current_userid(request))
            logger.debug('republish instance [reference id = {}] start'.format(reference_id))

            request_data = request.data
            logger.debug('republish instance [reference id = {}] request data = {}'.format(reference_id, request_data))

            instance_uuid = request_data.get('uuid')
            destination_sub_state_id = request_data.get('destination_sub_state_id')
            authorized_ticket = request_data.get('authorized_ticket')

            if instance_uuid is None:
                raise BadRequestException('"uuid" is required')
            if destination_sub_state_id is None:
                raise BadRequestException('"destination_sub_state_id" is required')

            destination_sub_state = SubState.objects.filter(id=int(destination_sub_state_id)).first()
            if destination_sub_state is None:
                raise BadRequestException('"destination_sub_state_id" is invalid')

            if destination_sub_state.need_authorized_ticket \
                    and (authorized_ticket is None or authorized_ticket.strip() == ''):
                raise BadRequestException('"authorized_ticket" is required')

            if destination_sub_state.is_production:
                if not self.has_permission(request, ActionAuthority.PUBLISH_PROD.value):
                    raise ActionUnAuthorizedException('not authorized to republish on production')
            elif destination_sub_state.is_pre_production:
                if not self.has_permission(request, ActionAuthority.PUBLISH_PRE_PROD.value):
                    raise ActionUnAuthorizedException('not authorized to republish on pre-production')
            else:
                if not self.has_permission(request, ActionAuthority.PUBLISH_NON_PROD.value):
                    raise ActionUnAuthorizedException('not authorized to republish on non-production')

            executed_by = self.current_username(request)
            console_output = ConsoleOutput.objects.create(
                title='Republish Instance on "{}"'.format(destination_sub_state.name)
                , executed_by=executed_by
                , authorized_ticket=authorized_ticket)

            threading.Thread(target=lambda: self.process([instance_uuid]
                                                         , destination_sub_state
                                                         , console_output
                                                         , executed_by
                                                         , authorized_ticket)).start()

            response = self.response_meta.success('success', reference_id, {
                'console_output_id': console_output.id,
            })

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e), reference_id, str(exc_type), fname, str(exc_tb.tb_lineno))

            logger.error(
                'republish instance [reference id = {}] exception - {}'.format(reference_id, exception_message))

        finally:
            logger.debug('republish instance [reference id = {}] response = {}'.format(reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def process(self, instance_uuids, destination_sub_state, console_output, executed_by, authorized_ticket):
        try:
            success, error_list = CommonInstanceManager().republish(instance_uuids
                                                                    , destination_sub_state
                                                                    , console_output=console_output
                                                                    , executed_by=executed_by
                                                                    , authorized_ticket=authorized_ticket)
            console_output.append('complete')
            return success, error_list
        except Exception as e:
            console_output.append('fail with exception: {}'.format(str(e)))
            raise e
        finally:
            console_output.finish()


class MoveView(CommonAPIView):
    serializer_class = AbstractSerializer
    response_meta = ResponseAPI()

    def post(self, request, *args, **kwargs):
        reference_id = request.session_id
        logger = Logger('Instance API', 'Move')
        logger.set_session_id(reference_id)

        try:
            logger.set_user_id(self.current_userid(request))
            logger.debug('move instance [reference id = {}] start'.format(reference_id))

            request_data = request.data
            logger.debug('move instance [reference id = {}] request data = {}'.format(reference_id, request_data))

            instance_uuid = request_data.get('uuid')
            source_sub_state_id = request_data.get('source_sub_state_id')
            destination_sub_state_id = request_data.get('destination_sub_state_id')
            authorized_ticket = request_data.get('authorized_ticket')

            if instance_uuid is None:
                raise BadRequestException('"uuid" is required')
            if source_sub_state_id is None:
                raise BadRequestException('"source_sub_state_id" is required')
            if destination_sub_state_id is None:
                raise BadRequestException('"destination_sub_state_id" is required')

            source_sub_state = SubState.objects.filter(id=int(source_sub_state_id)).first()
            if source_sub_state is None:
                raise BadRequestException('"source_sub_state_id" is invalid')

            destination_sub_state = SubState.objects.filter(id=int(destination_sub_state_id)).first()
            if destination_sub_state is None:
                raise BadRequestException('"destination_sub_state_id" is invalid')
            if destination_sub_state.id not in (source_sub_state.next_sub_state_ids or list()):
                raise BadRequestException('"destination_sub_state_id" is invalid')

            if destination_sub_state.need_authorized_ticket \
                    and (authorized_ticket is None or authorized_ticket.strip() == ''):
                raise BadRequestException('"authorized_ticket" is required')

            if destination_sub_state.is_production:
                if not self.has_permission(request, ActionAuthority.PUBLISH_PROD.value):
                    raise ActionUnAuthorizedException('not authorized to move to production')
            elif destination_sub_state.is_pre_production:
                if not self.has_permission(request, ActionAuthority.PUBLISH_PRE_PROD.value):
                    raise ActionUnAuthorizedException('not authorized to move to pre-production')
            else:
                if not self.has_permission(request, ActionAuthority.PUBLISH_NON_PROD.value):
                    raise ActionUnAuthorizedException('not authorized to move to non-production')

            executed_by = self.current_username(request)
            console_output = ConsoleOutput.objects.create(
                title='Move Instance from "{}" to "{}"'.format(source_sub_state.name, destination_sub_state.name)
                , executed_by=executed_by
                , authorized_ticket=authorized_ticket)

            threading.Thread(target=lambda: self.process([instance_uuid]
                                                         , source_sub_state
                                                         , destination_sub_state
                                                         , console_output
                                                         , executed_by
                                                         , authorized_ticket)).start()
            response = self.response_meta.success('success', reference_id, {
                'console_output_id': console_output.id,
            })

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e), reference_id, str(exc_type), fname, str(exc_tb.tb_lineno))

            logger.error('move instance [reference id = {}] exception - {}'.format(reference_id, exception_message))

        finally:
            logger.debug('move instance [reference id = {}] response = {}'.format(reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def process(self, instance_uuids, source_sub_state, destination_sub_state, console_output, executed_by,
                authorized_ticket):
        try:
            success, error_list = CommonInstanceManager().move(instance_uuids
                                                               , source_sub_state
                                                               , destination_sub_state
                                                               , console_output=console_output
                                                               , executed_by=executed_by
                                                               , authorized_ticket=authorized_ticket)
            console_output.append('complete')
            return success, error_list
        except Exception as e:
            console_output.append('fail with exception: {}'.format(str(e)))
            raise e
        finally:
            console_output.finish()


class RemoveView(CommonAPIView):
    serializer_class = AbstractSerializer
    response_meta = ResponseAPI()

    def post(self, request, *args, **kwargs):
        reference_id = request.session_id
        logger = Logger('Instance API', 'Remove')
        logger.set_session_id(reference_id)

        try:
            logger.set_user_id(self.current_userid(request))
            logger.debug('remove instance [reference id = {}] start'.format(reference_id))

            request_data = request.data
            logger.debug('remove instance [reference id = {}] request data = {}'.format(reference_id, request_data))

            instance_uuid = request_data.get('uuid')
            sub_state_id = request_data.get('destination_sub_state_id')
            authorized_ticket = request_data.get('authorized_ticket')

            if instance_uuid is None:
                raise BadRequestException('"uuid" is required')
            if sub_state_id is None:
                raise BadRequestException('"sub_state_id" is required')

            sub_state = SubState.objects.filter(id=int(sub_state_id)).first()
            if sub_state is None:
                raise BadRequestException('"sub_state_id" is invalid')

            if sub_state.need_authorized_ticket \
                    and (authorized_ticket is None or authorized_ticket.strip() == ''):
                raise BadRequestException('"authorized_ticket" is required')

            if sub_state.is_production:
                if not self.has_permission(request, ActionAuthority.REMOVE_PROD.value):
                    raise ActionUnAuthorizedException('not authorized to remove on production')
            elif sub_state.is_pre_production:
                if not self.has_permission(request, ActionAuthority.REMOVE_PRE_PROD.value):
                    raise ActionUnAuthorizedException('not authorized to remove on pre-production')
            else:
                if not self.has_permission(request, ActionAuthority.REMOVE_NON_PROD.value):
                    raise ActionUnAuthorizedException('not authorized to remove on non-production')

            executed_by = self.current_username(request)
            console_output = ConsoleOutput.objects.create(
                title='Remove Instance on "{}"'.format(sub_state.name) \
                , executed_by=executed_by
                , authorized_ticket=authorized_ticket)

            threading.Thread(target=lambda: self.process([instance_uuid]
                                                         , sub_state
                                                         , console_output
                                                         , executed_by
                                                         , authorized_ticket)).start()

            response = self.response_meta.success('success', reference_id, {
                'console_output_id': console_output.id,
            })

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e), reference_id, str(exc_type), fname, str(exc_tb.tb_lineno))

            logger.error('remove instance [reference id = {}] exception - {}'.format(reference_id, exception_message))

        finally:
            logger.debug('remove instance [reference id = {}] response = {}'.format(reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def process(self, instance_uuids, sub_state, console_output, executed_by, authorized_ticket):
        try:
            success, error_list = CommonInstanceManager().remove(instance_uuids
                                                                 , sub_state
                                                                 , console_output=console_output
                                                                 , executed_by=executed_by
                                                                 , authorized_ticket=authorized_ticket)
            console_output.append('complete')
            return success, error_list
        except Exception as e:
            console_output.append('fail with exception: {}'.format(str(e)))
            raise e
        finally:
            console_output.finish()


class PurgeView(CommonAPIView):
    serializer_class = AbstractSerializer
    response_meta = ResponseAPI()

    def post(self, request, *args, **kwargs):
        reference_id = request.session_id
        logger = Logger('Instance API', 'Purge')
        logger.set_session_id(reference_id)

        try:
            logger.set_user_id(self.current_userid(request))
            logger.debug('purge instances [reference id = {}] start'.format(reference_id))

            request_data = request.data
            logger.debug('purge instances [reference id = {}] request data = {}'.format(reference_id, request_data))

            instance_uuid = request_data.get('uuid')
            authorized_ticket = request_data.get('authorized_ticket')

            if instance_uuid is None:
                raise BadRequestException('"uuid" is required')

            if not self.has_permission(request, ActionAuthority.PURGE.value):
                raise ActionUnAuthorizedException('not authorized to purge')

            executed_by = self.current_username(request)
            console_output = ConsoleOutput.objects.create(
                title='Purge Instance'
                , executed_by=executed_by
                , authorized_ticket=authorized_ticket)

            threading.Thread(target=lambda: self.process([instance_uuid], console_output)).start()

            response = self.response_meta.success('success', reference_id, {
                'console_output_id': console_output.id,
            })

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e), reference_id, str(exc_type), fname, str(exc_tb.tb_lineno))

            logger.error('purge instance [reference id = {}] exception - {}'.format(reference_id, exception_message))

        finally:
            logger.debug('purge instance [reference id = {}] response = {}'.format(reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def process(self, instance_uuids, console_output):
        try:
            success, error_list = CommonInstanceManager().purge(instance_uuids, console_output=console_output)
            console_output.append('complete')
            return success, error_list
        except Exception as e:
            console_output.append('fail with exception: {}'.format(str(e)))
            raise e
        finally:
            console_output.finish()
