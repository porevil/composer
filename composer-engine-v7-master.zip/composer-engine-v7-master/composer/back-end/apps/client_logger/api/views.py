import uuid
import os
import sys

from rest_framework import status, mixins, views, generics
from rest_framework.response import Response

from apps.commons.error.exception import BadRequestException
from apps.client_logger.api.serializer import ClientLoggerSerializer
from apps.commons.utilities.log import Logger
from apps.commons.utilities.response import ResponseAPI, CustomResponseObject

from apps.commons.logger.views import ViewLogger


class ClientLoggerView(generics.CreateAPIView, ViewLogger):
    serializer_class = ClientLoggerSerializer
    queryset = {}

    def create(self, request, *args, **kwargs):
        response = {}
        try:
            message = request.data['message']
            log_type = request.data['type']
            if log_type == "debug":
                self.logger.debug(message)
            elif log_type == "error":
                self.logger.error(message)
            else:
                raise BadRequestException(f"log type '{log_type}' is not supported")
            response = CustomResponseObject(session_id=request.session_id).data
        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))
            self.logger.error(exception_message)
            response = CustomResponseObject(data=e, session=request.session_id).data
        finally:
            return Response(response, status=status.HTTP_200_OK)
