import json
import uuid
import os
import sys

from django.db import transaction
from rest_framework import viewsets
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.schemas import AutoSchema
from django.db import Error

from apps.commons.logger.views import ViewLogger
from apps.commons.utilities.log import Logger
from apps.commons.utilities.response import ResponseAPI
from apps.configurations.models import State, SubState
from apps.authorization.models import Menu
from apps.authorization.models import SubMenu
from apps.authorization.models import UserProfile
from apps.authorization.models import Action
from apps.authorization.api.serializers import MenuSerializer
from apps.authorization.api.serializers import MenuDetailSerializer
from apps.authorization.api.serializers import UserProfileSerializer
from apps.authorization.api.serializers import ActionSerializer
from apps.commons.error.exception import *


class MenuViewSet(viewsets.ModelViewSet, ViewLogger):
    response_meta = ResponseAPI()
    serializer_class = MenuDetailSerializer
    queryset = Menu.objects.all().order_by('sequence')

    def list(self, request):
        try:
            self.logger.debug('list menu [reference id = {}] start'.format(request.session_id))
            menus = Menu.objects.all().order_by('sequence')
            serializer = MenuSerializer(menus, many=True)
            response = self.response_meta.success("success", request.session_id, serializer.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , request.session_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error(
                'list menu [reference id = {}] exception - {}'.format(request.session_id, exception_message))

        finally:
            self.logger.debug('list menu [reference id = {}] response - {}'.format(request.session_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def retrieve(self, request, pk=None):
        try:
            self.logger.debug('retrieve menu [reference id = {}] start'.format(request.session_id))
            menu = Menu.objects.filter(id=pk).first()
            if menu is None:
                raise BadRequestException('"id" is invalid')

            serializer = MenuDetailSerializer(menu)
            response = self.response_meta.success("success", request.session_id, serializer.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , request.session_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error(
                'retrieve menu [reference id = {}] exception - {}'.format(request.session_id, exception_message))

        finally:
            self.logger.debug('retrieve menu [reference id = {}] response - {}'.format(request.session_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def create(self, request):
        try:
            with transaction.atomic():
                self.logger.debug('create menu [reference id = {}] start'.format(request.session_id))

                request_data = request.data or dict()
                self.logger.debug(
                    'create menu [reference id = {}] request data - {}'.format(request.session_id, request_data))

                sequence = request_data.get('sequence')
                is_active = request_data.get('is_active')
                code = request_data.get('code')
                display_label = request_data.get('display_label')
                link = request_data.get('link')

                if sequence is None:
                    raise BadRequestException('"menu sequence" is required')
                if code is None:
                    raise BadRequestException('"menu code" is required')

                menu = Menu.objects.create(**{
                    'sequence': sequence,
                    'is_active': is_active,
                    'code': code,
                    'display_label': display_label,
                    'link': link
                })

                sub_menus = request_data.get('sub_menus') or list()
                for sub_menu in sub_menus:
                    sequence = sub_menu.get('sequence')
                    is_active = sub_menu.get('is_active')
                    code = sub_menu.get('code')
                    display_label = sub_menu.get('display_label')
                    link = sub_menu.get('link')

                    if sequence is None:
                        raise BadRequestException('"sub menu sequence" is required')
                    if code is None:
                        raise BadRequestException('"sub menu code" is required')
                    if link is None:
                        raise BadRequestException('"sub menu link" is required')

                    sub_menu = SubMenu.objects.create(**{
                        'sequence': sequence,
                        'is_active': is_active,
                        'code': code,
                        'display_label': display_label,
                        'link': link,
                        'menu': menu
                    })

                response = self.response_meta.success('create success', request.session_id,
                                                      MenuDetailSerializer(menu).data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , request.session_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error(
                'create menu [reference id = {}] exception - {}'.format(request.session_id, exception_message))

        finally:
            self.logger.debug('create menu [reference id = {}] response - {}'.format(request.session_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def update(self, request, pk=None):
        try:
            with transaction.atomic():
                self.logger.debug('update menu [reference id = {}] start'.format(request.session_id))
                menu = Menu.objects.filter(id=pk).first()
                if menu is None:
                    raise BadRequestException('"id" is invalid')

                request_data = request.data
                self.logger.debug(
                    'update menu [reference id = {}] request data'.format(request.session_id, request_data))

                sequence = request_data.get('sequence')
                is_active = request_data.get('is_active')
                code = request_data.get('code')
                display_label = request_data.get('display_label')
                link = request_data.get('link')

                if sequence is None:
                    raise BadRequestException('"menu sequence" is required')
                if code is None:
                    raise BadRequestException('"menu code" is required')

                # update menu model
                menu.sequence = sequence
                menu.is_active = is_active
                menu.display_label = display_label
                menu.link = link
                menu.save()

                sub_menus = request_data.get('sub_menus') or list()
                # create or update 'sub menus model'
                _ids = list()
                for idx, sub_menu in enumerate(sub_menus):
                    _id = sub_menu.get('id')
                    sub_menu_sequence = sub_menu.get('sequence')
                    sub_menu_is_active = sub_menu.get('is_active')
                    sub_menu_code = sub_menu.get('code')
                    sub_menu_display_label = sub_menu.get('display_label')
                    sub_menu_link = sub_menu.get('link')
                    sub_menu_roles = sub_menu.get('roles') or list()
                    sub_menu = SubMenu.objects.filter(id=_id).first()

                    if sub_menu is None:
                        sub_menu = SubMenu.objects.create(**{
                            'sequence': sub_menu_sequence,
                            'is_active': sub_menu_is_active,
                            'code': sub_menu_code,
                            'display_label': sub_menu_display_label,
                            'link': sub_menu_link,
                            'menu': menu
                        })

                    else:
                        sub_menu.sequence = sub_menu_sequence
                        sub_menu.is_active = sub_menu_is_active
                        sub_menu.code = sub_menu_code
                        sub_menu.display_label = sub_menu_display_label
                        sub_menu.link = sub_menu_link
                        sub_menu.save()

                    _ids.append(sub_menu.id)

                # delete 'sub menu'
                deleted_sub_menus = SubMenu.objects.filter(menu=menu).exclude(id__in=_ids)
                deleted_sub_menus.delete()

                response = self.response_meta.success('update success', request.session_id,
                                                      MenuDetailSerializer(menu).data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , request.session_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error(
                'update menu [reference id = {}] exception - {}'.format(request.session_id, exception_message))

        finally:
            self.logger.debug('update menu [reference id = {}] response - {}'.format(request.session_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def destroy(self, request, *args, **kwargs):
        try:
            self.logger.debug('delete menu [reference id = {}] start'.format(request.session_id))
            menu = Menu.objects.filter(id=kwargs.get('pk')).first()
            if menu is None:
                raise BadRequestException('"id" is invalid')

            menu.delete()

            response = self.response_meta.success('delete success', request.session_id)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , request.session_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error(
                'delete menu [reference id = {}] exception - {}'.format(request.session_id, exception_message))

        finally:
            self.logger.debug('delete menu [reference id = {}] response - {}'.format(request.session_id, response))
            return Response(response, status=status.HTTP_200_OK)


class UserProfileViewSet(viewsets.ModelViewSet, ViewLogger):
    response_meta = ResponseAPI()
    serializer_class = UserProfileSerializer
    queryset = UserProfile.objects.all()

    def list(self, request):
        try:
            self.logger.debug('list user profile [reference id = {}] start'.format(request.session_id))
            user_profiles = UserProfile.objects.all().order_by('id')
            serializer = UserProfileSerializer(user_profiles, many=True)
            response = self.response_meta.success("success", request.session_id, serializer.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , request.session_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error(
                'list user profile [reference id = {}] exception - {}'.format(request.session_id, exception_message))

        finally:
            self.logger.debug('list user profile [reference id = {}] response - {}'.format(request.session_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def retrieve(self, request, pk=None):
        try:
            self.logger.debug('retrieve user profile [reference id = {}] start'.format(request.session_id))
            user_profile = UserProfile.objects.filter(id=pk).first()
            if user_profile is None:
                raise BadRequestException('"id" is invalid')

            serializer = UserProfileSerializer(user_profile)
            response = self.response_meta.success("success", request.session_id, serializer.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , request.session_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error(
                'retrieve user profile [reference id = {}] exception - {}'.format(request.session_id, exception_message))

        finally:
            self.logger.debug(
                'retrieve user profile [reference id = {}] response - {}'.format(request.session_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def create(self, request, **kwargs):
        try:
            with transaction.atomic():
                self.logger.debug('create user profile [reference id = {}] start'.format(request.session_id))

                request_data = request.data or dict()
                self.logger.debug(
                    'create user profile [reference id = {}] request data - {}'.format(request.session_id, request_data))

                name = request_data.get('name')
                role = request_data.get('role')

                if name is None:
                    raise BadRequestException('"name" is required')
                if role is None:
                    raise BadRequestException('"role" is required')

                user_profile = UserProfile.objects.create(**{
                    'name': name,
                    'role': role
                })

                response = self.response_meta.success('create success', request.session_id,
                                                      UserProfileSerializer(user_profile).data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , request.session_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error(
                'create user profile [reference id = {}] exception - {}'.format(request.session_id, exception_message))

        finally:
            self.logger.debug(
                'create user profile [reference id = {}] response - {}'.format(request.session_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def update(self, request, pk=None):
        try:
            with transaction.atomic():
                self.logger.debug('update user profile [reference id = {}] start'.format(request.session_id))

                request_data = request.data or dict()
                self.logger.debug(
                    'update user profile [reference id = {}] request data'.format(request.session_id, request_data))

                user_profile = UserProfile.objects.filter(id=pk).first()
                if user_profile is None:
                    raise BadRequestException('"id" is invalid')

                name = request_data.get('name')
                role = request_data.get('role')

                if name is None:
                    raise BadRequestException('"name" is required')
                if role is None:
                    raise BadRequestException('"role" is required')

                # update menu model
                user_profile.name = name
                user_profile.role = role
                user_profile.save()

                response = self.response_meta.success('update success', request.session_id,
                                                      UserProfileSerializer(user_profile).data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , request.session_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error(
                'update user profile [reference id = {}] exception - {}'.format(request.session_id, exception_message))

        finally:
            self.logger.debug(
                'update user profile [reference id = {}] response - {}'.format(request.session_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def destroy(self, request, *args, **kwargs):
        try:
            self.logger.debug('delete user profile [reference id = {}] start'.format(request.session_id))

            user_profile = UserProfile.objects.filter(id=kwargs.get('pk')).first()
            if user_profile is None:
                raise BadRequestException('"id" is invalid')

            user_profile.delete()

            response = self.response_meta.success('delete success', request.session_id)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , request.session_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error(
                'delete user profile [reference id = {}] exception - {}'.format(request.session_id, exception_message))

        finally:
            self.logger.debug(
                'delete user profile [reference id = {}] response - {}'.format(request.session_id, response))
            return Response(response, status=status.HTTP_200_OK)


class ActionViewSet(viewsets.ModelViewSet, ViewLogger):
    response_meta = ResponseAPI()
    serializer_class = ActionSerializer
    queryset = Action.objects.all().order_by('id')

    def list(self, request, *args, **kwargs):
        try:
            self.logger.debug('list action [reference id = {}] start'.format(request.session_id))

            actions = Action.objects.all().order_by('id')
            serializer = ActionSerializer(actions, many=True)
            response = self.response_meta.success("success", request.session_id, serializer.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , request.session_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error(
                'list action [reference id = {}] exception - {}'.format(request.session_id, exception_message))

        finally:
            self.logger.debug('list action [reference id = {}] response - {}'.format(request.session_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def retrieve(self, request, pk=None, *args, **kwargs):
        try:
            self.logger.debug('retrieve action [reference id = {}] start'.format(request.session_id))

            action = Action.objects.filter(id=pk).first()
            if action is None:
                raise BadRequestException('"id" is invalid')

            serializer = ActionSerializer(action)
            response = self.response_meta.success("success", request.session_id, serializer.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , request.session_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error(
                'retrieve action [reference id = {}] exception - {}'.format(request.session_id, exception_message))

        finally:
            self.logger.debug('retrieve action [reference id = {}] response - {}'.format(request.session_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def create(self, request, **kwargs):
        try:
            with transaction.atomic():
                self.logger.debug('create action [reference id = {}] start'.format(request.session_id))

                request_data = request.data or dict()
                self.logger.debug(
                    'create action [reference id = {}] request data - {}'.format(request.session_id, request_data))

                code = request_data.get('code')
                display_label = request_data.get('display_label')
                is_active = request_data.get('is_active') or True

                if code is None:
                    raise BadRequestException('"code" is required')
                if display_label is None:
                    raise BadRequestException('"display_label" is required')

                action = Action.objects.create(**{
                    'code': code,
                    'display_label': display_label,
                    'is_active': is_active
                })

                response = self.response_meta.success('create success', request.session_id,
                                                      ActionSerializer(action).data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , request.session_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error(
                'create action [reference id = {}] exception - {}'.format(request.session_id, exception_message))

        finally:
            self.logger.debug('create action [reference id = {}] response - {}'.format(request.session_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def update(self, request, pk=None, **kwargs):
        try:
            with transaction.atomic():
                self.logger.debug('update action [reference id = {}] start'.format(request.session_id))

                request_data = request.data
                self.logger.debug(
                    'update action [reference id = {}] request data'.format(request.session_id, request_data))

                action = Action.objects.filter(id=pk).first()
                if action is None:
                    raise BadRequestException('"id" is invalid')

                code = request_data.get('code')
                display_label = request_data.get('display_label')
                is_active = request_data.get('is_active')

                if display_label is None:
                    raise BadRequestException('"display_label" is required')

                # update action model
                action.display_label = display_label
                action.is_active = is_active
                action.save()

                response = self.response_meta.success('update success', request.session_id,
                                                      ActionSerializer(action).data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , request.session_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error(
                'update action [reference id = {}] exception - {}'.format(request.session_id, exception_message))

        finally:
            self.logger.debug('update action [reference id = {}] response - {}'.format(request.session_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def destroy(self, request, *args, **kwargs):
        try:
            self.logger.debug('delete action [reference id = {}] start'.format(request.session_id))

            action = Action.objects.filter(id=kwargs.get('pk')).first()
            if action is None:
                raise BadRequestException('"id" is invalid')

            action.delete()

            response = self.response_meta.success('delete success', request.session_id)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , request.session_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error(
                'delete action [reference id = {}] exception - {}'.format(request.session_id, exception_message))

        finally:
            self.logger.debug('delete action [reference id = {}] response - {}'.format(request.session_id, response))
            return Response(response, status=status.HTTP_200_OK)
