from rest_framework import serializers
from rest_framework.fields import JSONField

from apps.authorization.models import Menu, SubMenu, UserProfile, ProfileMapping, Action


class MenuSerializer(serializers.ModelSerializer):
    sub_menus = serializers.SerializerMethodField()

    class Meta:
        model = Menu
        fields = [
            'id',
            'sequence',
            'code',
            'display_label',
            'is_active',
            'link',
            'sub_menus'
        ]

    def get_sub_menus(self, obj):
        sub_menus = SubMenu.objects.filter(menu=obj).order_by('sequence')
        serializer = SubMenuSerializer(sub_menus, many=True)
        return serializer.data


class MenuDetailSerializer(serializers.ModelSerializer):
    type = serializers.SerializerMethodField()
    sub_menus = serializers.SerializerMethodField()

    class Meta:
        model = Menu
        fields = [
            'id',
            'sequence',
            'code',
            'type',
            'display_label',
            'link',
            'is_active',
            'sub_menus'
        ]

    def get_type(self, obj):
        sub_menus = SubMenu.objects.filter(menu=obj)
        if sub_menus:
            return 'dropdown'
        else:
            return 'simple'

    def get_sub_menus(self, obj):
        sub_menus = SubMenu.objects.filter(menu=obj).order_by('sequence')
        serializer = SubMenuDetailSerializer(sub_menus, many=True)
        return serializer.data


class SubMenuSerializer(serializers.ModelSerializer):
    class Meta:
        model = SubMenu
        fields = [
            'id',
            'sequence',
            'link',
            'code',
            'display_label',
            'is_active'
        ]


class SubMenuDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = SubMenu
        fields = [
            'id',
            'sequence',
            'code',
            'display_label',
            'link',
            'is_active'
        ]


class UserProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserProfile
        fields = [
            'id',
            'name',
            'role'
        ]


class ActionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Action
        fields = [
            'id',
            'is_active',
            'code',
            'display_label'
        ]


class ProfileMenuMappingSerializer(serializers.ModelSerializer):
    roles = serializers.SerializerMethodField()
    sub_menus = serializers.SerializerMethodField()

    class Meta:
        model = Menu
        fields = [
            'id',
            'sequence',
            'code',
            'display_label',
            'link',
            'is_active',
            'roles',
            'sub_menus'
        ]

    def get_roles(self, obj):
        profile_mappings = ProfileMapping.objects.filter(menu=obj)
        user_profiles = UserProfile.objects.all()
        profile_mapping_roles = list(map(lambda p: p.user_profile.role, profile_mappings))
        roles = list()

        for user_profile in user_profiles:
            roles.append({
                'role_name': user_profile.role,
                'label': user_profile.name,
                'value': True if user_profile.role in profile_mapping_roles else False
            })

        return roles

    def get_sub_menus(self, obj):
        sub_menus = SubMenu.objects.filter(menu=obj).order_by('sequence')
        sub_menus = SubMenuSerializer(sub_menus, many=True).data

        user_profiles = UserProfile.objects.all()

        for sub_menu in sub_menus:
            profile_mappings = ProfileMapping.objects.filter(sub_menu_id=sub_menu.get('id'))
            profile_mapping_roles = list(map(lambda p: p.user_profile.role, profile_mappings))
            roles = list()

            for user_profile in user_profiles:
                roles.append({
                    'role_name': user_profile.role,
                    'label': user_profile.name,
                    'value': True if user_profile.role in profile_mapping_roles else False
                })

            sub_menu['roles'] = roles
        return sub_menus


class ProfileActionMappingSerializer(serializers.ModelSerializer):
    roles = serializers.SerializerMethodField()

    class Meta:
        model = Action
        fields = [
            'id',
            'is_active',
            'code',
            'display_label',
            'roles'
        ]

    def get_roles(self, obj):
        profile_mappings = ProfileMapping.objects.filter(action=obj)
        user_profiles = UserProfile.objects.all()
        profile_mapping_roles = list(map(lambda p: p.user_profile.role, profile_mappings))

        roles = list()
        for user_profile in user_profiles:
            roles.append({
                'role_name': user_profile.role,
                'label': user_profile.name,
                'value': True if user_profile.role in profile_mapping_roles else False
            })

        return roles
