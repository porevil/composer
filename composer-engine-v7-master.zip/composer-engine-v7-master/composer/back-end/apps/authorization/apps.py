from django.apps import AppConfig


class Authorization(AppConfig):
    name = 'authorization'
