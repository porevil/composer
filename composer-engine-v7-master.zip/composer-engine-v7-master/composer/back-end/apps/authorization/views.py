import uuid
import traceback
import os
import sys

from rest_framework import status, generics
from rest_framework.response import Response
from django.db import transaction
from django.db import Error

from apps.authorization.models import Menu
from apps.authorization.models import SubMenu
from apps.authorization.models import UserProfile
from apps.authorization.models import ProfileMapping
from apps.commons.logger.views import ViewLogger
from apps.commons.utilities.log import Logger
from apps.authorization.models import Action
from apps.authorization.api.serializers import MenuDetailSerializer
from apps.authorization.api.serializers import ProfileMenuMappingSerializer
from apps.authorization.api.serializers import ProfileActionMappingSerializer
from apps.authorization.api.serializers import ActionSerializer
from apps.commons.utilities.response import ResponseAPI
from apps.commons.utilities.log import Logger
from apps.commons.error.exception import *


class ProfileMenuMappingView(generics.ListCreateAPIView, ViewLogger):
    response_meta = ResponseAPI()
    serializer_class = ProfileMenuMappingSerializer
    queryset = Menu.objects.filter(is_active=True).order_by('sequence')

    def get(self, request, *args, **kwargs):
        try:
            self.logger.debug('get profile Menu Mapping [reference id = {}] start'.format(request.session_id))

            menus = Menu.objects.filter(is_active=True).order_by('sequence')
            serializer = ProfileMenuMappingSerializer(menus, many=True)
            response = self.response_meta.success("success", request.session_id, serializer.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , request.session_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('get profile menu mapping [reference id = {}] exception - {}'.format(request.session_id, exception_message))

        finally:
            self.logger.debug('get profile menu mapping [reference id = {}] response - {}'.format(request.session_id, response))
            return Response(response, status=status.HTTP_200_OK)
    

    def post(self, request):
        try:
            with transaction.atomic():
                self.logger.debug('post profile Menu Mapping [reference id = {}] start'.format(request.session_id))
                request_data = request.data

                self.logger.debug('post profile Menu Mapping [reference id = {}] request data - {}'.format(request.session_id, request_data))

                # profile_mappings = request_data.get('profile_mappings') or list()
                for menu in request_data:
                    menu_id = menu.get('id')
                    menu_roles = menu.get('roles') or list()
                    menu_role_actives = list(map(lambda x: x.get('role_name'), list(filter(lambda m: m.get('value'), menu_roles))))
                    
                    # filter role name active
                    user_profiles = UserProfile.objects.filter(role__in=menu_role_actives)
                    if not user_profiles:
                        ProfileMapping.objects.filter(menu__id=menu_id).delete()
                    else:
                        for user_profile in user_profiles:
                            profile_mapping = ProfileMapping.objects.filter(menu__id=menu_id, user_profile=user_profile).first()
                            if profile_mapping is None:
                                menu_model = Menu.objects.filter(id=menu_id).first()
                                profile_mapping = ProfileMapping.objects.create(**{
                                    'user_profile': user_profile,
                                    'menu': menu_model
                                }) 

                        delete_profile_mappings = ProfileMapping.objects.filter(menu__id=menu_id) \
                                                    .exclude(user_profile__role__in=menu_role_actives)
                        delete_profile_mappings.delete()

                    sub_menus = menu.get('sub_menus') or list()
                    for sub_menu in sub_menus:
                        sub_menu_id = sub_menu.get('id')
                        sub_menu_roles = sub_menu.get('roles') or list()
                        sub_menu_role_actives = list(map(lambda y: y.get('role_name'), list(filter(lambda sm: sm.get('value'), sub_menu_roles))))

                        user_profiles = UserProfile.objects.filter(role__in=sub_menu_role_actives)
                        if not user_profiles:
                            ProfileMapping.objects.filter(sub_menu__id=sub_menu_id).delete()
                        else:
                            for user_profile in user_profiles:
                                profile_mapping = ProfileMapping.objects.filter(sub_menu__id=sub_menu_id, user_profile=user_profile).first()
                                if profile_mapping is None:
                                    sub_menu_model = SubMenu.objects.filter(id=sub_menu_id).first()

                                    profile_mapping = ProfileMapping.objects.create(**{
                                        'user_profile': user_profile,
                                        'sub_menu': sub_menu_model
                                    }) 

                            delete_profile_mappings = ProfileMapping.objects.filter(sub_menu__id=sub_menu_id) \
                                                        .exclude(user_profile__role__in=sub_menu_role_actives)
                            delete_profile_mappings.delete()

                result = dict()

                menus = Menu.objects.all().order_by('sequence')
                serializer = ProfileMenuMappingSerializer(menus, many=True)
                response = self.response_meta.success("success", request.session_id, serializer.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , request.session_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('post profile menu mapping [reference id = {}] exception - {}'.format(request.session_id, exception_message))

        finally:
            self.logger.debug('post profile menu mapping [reference id = {}] response - {}'.format(request.session_id, response))

            return Response(response, status=status.HTTP_200_OK)


class ProfileActionMappingView(generics.ListCreateAPIView, ViewLogger):
    reference_id = str(uuid.uuid4())
    response_meta = ResponseAPI()
    serializer_class = ProfileActionMappingSerializer
    logger = Logger("Profile Action Mapping")
    queryset = Action.objects.filter(is_active=True).order_by('id')

    def get(self, request):
        try:
            self.logger.debug('get profile action mapping [reference id = {}] start'.format(request.session_id))

            actions = Action.objects.filter(is_active=True).order_by('id')
            serializer = ProfileActionMappingSerializer(actions, many=True)
            response = self.response_meta.success("success", request.session_id, serializer.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , request.session_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('get profile action mapping [reference id = {}] exception - {}'.format(request.session_id, exception_message))

        finally:
            self.logger.debug('get profile action mapping [reference id = {}] response - {}'.format(request.session_id, response))

            return Response(response, status=status.HTTP_200_OK)
    

    def post(self, request):
        try:
            with transaction.atomic():
                self.logger.debug('post profile action mapping [reference id = {}] start'.format(request.session_id))

                request_data = request.data

                self.logger.debug('post profile action mapping [reference id = {}] request data - {}'.format(request.session_id, request_data))

                # profile_mappings = request_data.get('profile_mappings') or list()
                for action in request_data:
                    action_id = action.get('id')
                    action_roles = action.get('roles') or list()
                    action_role_actives = list(map(lambda x: x.get('role_name'), list(filter(lambda m: m.get('value'), action_roles))))
        
                    user_profiles = UserProfile.objects.filter(role__in=action_role_actives)
                    if not user_profiles:
                        ProfileMapping.objects.filter(action__id=action_id).delete()
                    else:
                        for user_profile in user_profiles:
                            profile_mapping = ProfileMapping.objects.filter(action__id=action_id, user_profile=user_profile).first()
                            if profile_mapping is None:
                                action_model = Action.objects.filter(id=action_id).first()
                                profile_mapping = ProfileMapping.objects.create(**{
                                    'user_profile': user_profile,
                                    'action': action_model
                                }) 

                        delete_profile_mappings = ProfileMapping.objects.filter(action__id=action_id) \
                                                    .exclude(user_profile__role__in=action_role_actives)
                        delete_profile_mappings.delete()

                result = dict()

                actions = Action.objects.all().order_by('id')
                serializer = ProfileActionMappingSerializer(actions, many=True)
                response = self.response_meta.success("success", request.session_id, serializer.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , request.session_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('post profile action mapping [reference id = {}] exception - {}'.format(request.session_id, exception_message))

        finally:
            self.logger.debug('post profile action mapping [reference id = {}] response - {}'.format(request.session_id, response))

            return Response(response, status=status.HTTP_200_OK)
