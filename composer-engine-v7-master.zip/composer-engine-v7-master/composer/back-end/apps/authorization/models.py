import reversion

from jsonfield import JSONField
from django.db import models
from django.utils.translation import ugettext_lazy as _
from django.contrib.postgres.fields import ArrayField


@reversion.register()
class Menu(models.Model):
    sequence = models.PositiveSmallIntegerField(db_index=True, verbose_name=_('Sequence'))
    is_active = models.BooleanField(default=False, verbose_name=_("Is Active"))
    code = models.CharField(max_length=100, unique=True)
    display_label = models.CharField(max_length=200, null=True)
    link = models.CharField(max_length=200, null=True, blank=True)

    def __str__(self):
        return "%s - %s" % (self.display_label, self.sequence)


@reversion.register()
class SubMenu(models.Model):
    sequence = models.PositiveSmallIntegerField(db_index=True, verbose_name=_('Sequence'))
    is_active = models.BooleanField(default=False, verbose_name=_("Is Active"))
    code = models.CharField(max_length=100)
    display_label = models.CharField(max_length=200, null=True)
    menu = models.ForeignKey(Menu, on_delete=models.CASCADE, verbose_name=_("Menu"))
    link = models.CharField(max_length=200, null=True, blank=True)

    class Meta:
        unique_together = ('menu', 'sequence')

    def __str__(self):
        return "%s - %s" % (self.display_label, self.sequence)


@reversion.register()
class Action(models.Model):
    is_active = models.BooleanField(default=False, verbose_name=_("Is Active"))
    code = models.CharField(max_length=100, unique=True)
    display_label = models.CharField(max_length=200, null=True)

    def __str__(self):
        return "%s - %s" % (self.code, self.is_active)


@reversion.register()
class UserProfile(models.Model):
    name = models.CharField(max_length=500, unique=True)
    role = models.CharField(max_length=100, unique=True)

    def __str__(self):
        return "%s - %s" % (self.name, self.role)


@reversion.register()
class ProfileMapping(models.Model):
    menu = models.ForeignKey(Menu, on_delete=models.CASCADE, null=True, blank=True, default=None, verbose_name=_("Menu"))
    sub_menu = models.ForeignKey(SubMenu, on_delete=models.CASCADE, null=True, blank=True, default=None,
                                 verbose_name=_("Sub Menu"))
    action = models.ForeignKey(Action, on_delete=models.CASCADE, null=True, blank=True, default=None,
                               verbose_name=_("Action"))
    user_profile = models.ForeignKey(UserProfile, on_delete=models.CASCADE, verbose_name=_("User Profile"))

    class Meta:
        unique_together = [('menu', 'user_profile'), ('sub_menu', 'user_profile'), ('action', 'user_profile')]

    def __str__(self):
        return "%s" % (self.user_profile)
