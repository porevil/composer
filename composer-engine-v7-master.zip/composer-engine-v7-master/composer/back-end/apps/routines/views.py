import uuid
import traceback
import os
import sys

from rest_framework.response import Response
from rest_framework import status

from apps.commons.utilities.log import Logger
from apps.commons.utilities.response import ResponseAPI
from apps.commons.generator.managers.configuration import ConfigurationManager
from apps.routines.models import Routine, LotRoutine
from apps.routines.api.serializers import RoutineSerializer
from apps.commons.utilities.common import CommonAPIView
from apps.commons.serializers import AbstractSerializer
from apps.commons.error.exception import *


class ListRoutineByLotView(CommonAPIView):
    serializer_class = AbstractSerializer
    response_meta = ResponseAPI()
    reference_id = str(uuid.uuid4())

    def post(self, request):
        try:
            logger = Logger('List Routine By Lot')
            logger.set_session_id(self.reference_id)
            logger.debug('list routine by lot [reference id = {}] start'.format(self.reference_id))

            request_data = request.data
            logger.debug(
                'list routine by lot [reference id = {}] request data: {}'.format(self.reference_id, request_data))

            lot_id = request_data.get('lot_id')

            lot_routines = LotRoutine.objects.filter(lot__id=lot_id)
            routine_uuids = list(map(lambda lr: lr.routine.uuid, lot_routines))

            routines = Routine.objects.filter(uuid__in=routine_uuids)

            serializer = RoutineSerializer(routines, many=True)
            response = self.response_meta.success('success', self.reference_id, serializer.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            logger.error('list routine by lot [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            logger.debug('list routine by lot [reference id = {}] response: {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)


class GetActivityConfigurationView(CommonAPIView):
    serializer_class = AbstractSerializer
    response_meta = ResponseAPI()
    reference_id = str(uuid.uuid4())

    def post(self, request):
        try:
            logger = Logger('Get Configuration')
            logger.set_session_id(self.reference_id)
            logger.debug('get routine configuration [reference id = {}] start'.format(self.reference_id))

            request_data = request.data or dict()

            uuid = request_data.get('uuid')
            if uuid is None:
                raise BadRequestException('"Routine UUID" is Required')

            configuration_manager = ConfigurationManager(self.reference_id)

            result = configuration_manager.get_activities_configuration(uuid)
            response = self.response_meta.success('success', self.reference_id, result)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            logger.error('get routine configuration [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            logger.debug(
                'get routine configuration [reference id = {}] response: {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)
