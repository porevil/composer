import json
import uuid
import os
import sys
import rest_framework_filters as filters

from django.db import transaction
from rest_framework import status
from rest_framework import viewsets
from rest_framework.response import Response
from rest_framework.views import APIView
from django_filters.rest_framework import DjangoFilterBackend

from apps.commons.utilities.response import ResponseAPI
from apps.routines.models import Lot, Routine
from apps.standard_process.models import StandardProcess
from apps.generator_setting.models import VirtualGroup
from apps.metadata.models import Dataset
from apps.routines.api.serializers import LotSerializer, LotDetailSerializer, RoutineSerializer
from apps.commons.utilities.log import Logger
from apps.commons.error.exception import *


def is_valid_uuid(request_uuid, version=4):
    try:
        uuid_obj = uuid.UUID(str(request_uuid), version=version)
    except ValueError:
        return False

    return str(uuid_obj) == request_uuid


class LotViewSet(viewsets.ModelViewSet):
    response_meta = ResponseAPI()
    reference_id = str(uuid.uuid4())
    serializer_class = LotSerializer
    logger = Logger('Lot')
    queryset = Lot.objects.all()

    def list(self, request):
        try:
            self.logger.debug('list lot [reference id = {}] start'.format(self.reference_id))

            lots = Lot.objects.all()
            serializer = LotSerializer(lots, many=True)
            response = self.response_meta.success("success", self.reference_id, serializer.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('list lot [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('list lot [reference id = {}] response = {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def retrieve(self, request, pk=None):
        try:
            self.logger.debug('retrieve lot [reference id = {}] start'.format(self.reference_id))

            if pk is None:
                raise BadRequestException('"id" is required')

            lot = Lot.objects.filter(id=pk).first()
            if lot is None:
                raise BadRequestException('"id" is invalid')

            serializer = LotDetailSerializer(lot)
            response = self.response_meta.success("success", self.reference_id, serializer.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('retrieve lot [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('retrieve lot [reference id = {}] response = {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def create(self, request):
        try:
            with transaction.atomic():
                self.logger.debug('create lot [reference id = {}] start'.format(self.reference_id))

                request_data = request.data or dict()
                self.logger.debug(
                    'create lot [reference id = {}] request data = {}'.format(self.reference_id, request_data))

                name = request_data.get('name')
                description = request_data.get('description')
                datasets = request_data.get('datasets') or list()
                standard_process_ids = request_data.get('standard_process_ids') or list()

                if name is None:
                    raise BadRequestException('"name" is required')
                if not datasets:
                    raise BadRequestException('"datasets" is required')
                if type(datasets) is not list:
                    raise BadRequestException('"datasets" must be array')
                if not standard_process_ids:
                    raise BadRequestException('"standard_process_ids" is required')
                if type(standard_process_ids) is not list:
                    raise BadRequestException('"standard_process_ids" must be array')

                dataset = Dataset.objects.filter(dataset_name__in=datasets) or list()
                virtual = VirtualGroup.objects.filter(name__in=datasets) or list()

                if len(dataset) + len(virtual) != len(datasets):
                    dataset_names = set(map(lambda d: d.dataset_name, dataset))
                    virutal_names = set(map(lambda v: v.name, virtual))
                    all_correct_names = dataset_names.union(virutal_names)
                    wrong_datasets = set(datasets).difference(all_correct_names)
                    raise BadRequestException('dataset_name({}) is invalid'.format(', '.join(wrong_datasets)))

                standard_process = StandardProcess.objects.filter(id__in=standard_process_ids)
                if len(standard_process) != len(standard_process_ids):
                    raise BadRequestException('"standard_process_ids" is invalid')

                lot = Lot.objects.create(**{
                    'name': name,
                    'description': description,
                    'datasets': datasets,
                    'standard_process_ids': standard_process_ids
                })

                response = self.response_meta.success('create success', self.reference_id,
                                                      LotDetailSerializer(lot).data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('create lot [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('create lot [reference id = {}] response = {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def update(self, request, pk=None):
        try:
            with transaction.atomic():
                self.logger.debug('update lot [reference id = {}] start'.format(self.reference_id))

                if pk is None:
                    raise BadRequestException('"id" is required')

                lot = Lot.objects.filter(id=pk).first()
                if lot is None:
                    raise BadRequestException('"id" is invalid')

                request_data = request.data or dict()
                self.logger.debug(
                    'update lot [reference id = {}] request data = {}'.format(self.reference_id, request_data))

                name = request_data.get('name')
                description = request_data.get('description')
                datasets = request_data.get('datasets') or list()
                standard_process_ids = request_data.get('standard_process_ids') or list()

                if name is None:
                    raise BadRequestException('"name" is required')
                if datasets is None or not datasets:
                    raise BadRequestException('"datasets" is required')
                if standard_process_ids is None or not standard_process_ids:
                    raise BadRequestException('"standard_process_ids" is required')

                # update menu model
                lot.name = name
                lot.description = description
                lot.datasets = datasets
                lot.standard_process_ids = standard_process_ids
                lot.save()

                response = self.response_meta.success('update success', self.reference_id,
                                                      LotDetailSerializer(lot).data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('update lot [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('update lot [reference id = {}] response = {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def destroy(self, request, *args, **kwargs):
        try:
            self.logger.debug('delete lot [reference id = {}] start'.format(self.reference_id))

            id = kwargs.get('pk')
            if id is None:
                raise BadRequestException('"id" is required')

            lot = Lot.objects.filter(id=id).first()
            if lot is None:
                raise BadRequestException('"id" is invalid')

            lot.delete()

            response = self.response_meta.success('delete success', self.reference_id)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('delete lot [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('delete lot [reference id = {}] response = {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)


class RoutineFilter(filters.FilterSet):
    class Meta:
        model = Routine
        fields = {
            'code': ['exact', 'startswith', 'icontains', ],
            'name': ['exact', 'startswith', 'icontains'],
            'dataset_name': ['exact'],
            'uuid': ['exact'],
            'generating_type': ['exact'],
        }


class RoutineViewSet(viewsets.ModelViewSet):
    http_method_names = ['get']
    response_meta = ResponseAPI()
    reference_id = str(uuid.uuid4())
    serializer_class = RoutineSerializer
    filter_class = RoutineFilter
    logger = Logger('Routine')
    queryset = Routine.objects.all()

    def list(self, request):
        try:
            self.logger.debug('list routines [reference id = {}] start'.format(self.reference_id))

            query_params = request.query_params
            request_uuid = query_params.get('uuid')
            if request_uuid is not None and request_uuid:
                is_valid = is_valid_uuid(request_uuid)
                
                if not is_valid:
                    raise BadRequestException('"uuid" is invalid')

            queryset = Routine.objects.all()
            queryset = DjangoFilterBackend().filter_queryset(self.request, queryset, self)
            serializer = RoutineSerializer(queryset, many=True)
            response = self.response_meta.success("success", self.reference_id, serializer.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('list routines [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('list routines [reference id = {}] response = {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)
