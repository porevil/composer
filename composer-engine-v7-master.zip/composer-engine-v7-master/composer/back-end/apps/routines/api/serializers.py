from rest_framework import serializers
from rest_framework.fields import JSONField

from apps.routines.models import Lot, LotRoutine, Routine, ActivityConfiguration
from apps.console_output.models import ConsoleOutput
from apps.node_repositories.models import NodeRepository
from apps.standard_process.api.serializers import StandardTemplateSerializer
from apps.node_repositories.api.serializers import NodeRepositorySerializer


class LotSerializer(serializers.ModelSerializer):
    class Meta:
        model = Lot
        fields = [
            'id',
            'name',
            'description',
        ]


class LotDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = Lot
        fields = [
            'id',
            'name',
            'description',
            'datasets',
            'standard_process_ids',
        ]


class RoutineSerializer(serializers.ModelSerializer):
    lot_id = serializers.SerializerMethodField()

    class Meta:
        model = Routine
        fields = [
            'id',
            'uuid',
            'name',
            'code',
            'description',
            'dataset_name',
            'dataset_version',
            'latest_build_no',
            'generating_type',
            'generating_tag',
            'adjusted',
            'lot_id',
        ]

    def get_lot_id(self, obj):
        lot_routine = LotRoutine.objects.filter(routine=obj).first()
        if lot_routine is None or lot_routine.lot is None:
            return None
        return lot_routine.lot.id


class ConsoleOutputSerializer(serializers.ModelSerializer):
    class Meta:
        model = ConsoleOutput
        fields = [
            'id',
            'title',
            'executed_by',
            'start_datetime',
            'end_datetime'
        ]


class ConsoleOutputDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = ConsoleOutput
        fields = [
            'id',
            'title',
            'output',
            'executed_by',
            'start_datetime',
            'end_datetime'
        ]


class AdjustActivitySerializer(serializers.ModelSerializer):
    information = serializers.SerializerMethodField()
    activities = serializers.SerializerMethodField()

    class Meta:
        model = Routine
        fields = [
            'information',
            'activities'
        ]

    def get_information(self, obj):
        data = {
            'code': obj.code,
            'uuid': obj.uuid,
            'name': obj.name,
            'description': obj.description,
            'dataset_name': obj.dataset_name,
            'dataset_version': obj.dataset_version,
        }

        return data

    def get_activities(self, obj):
        result = list()
        activity_configurations = ActivityConfiguration.objects.filter(routine=obj)
        for activity_configuration in activity_configurations:
            activity_configuration_data = activity_configuration.data
            sections = activity_configuration_data.get('sections') or list

            for section in sections:
                fields = section.get('fields') or list()
                for field in fields:
                    if field.get('meta_type') == 'master':
                        field['component_name'] = field.get('component', dict()).get('name')

            result.append({
                'name': activity_configuration.activity,
                'data': activity_configuration_data
            })

        return result
