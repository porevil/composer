import reversion

from uuid import uuid4
from django.db import models
from django.utils.translation import ugettext_lazy as _
from django.contrib.postgres.fields import ArrayField
from jsonfield import JSONField
from datetime import datetime

from apps.commons.generator.constants import GeneratingType
from apps.commons.generator.constants import Activity
from apps.commons.generator.constants import ActivitySection
from apps.standard_process.models import Template
from apps.standard_process.models import StandardProcess
from apps.console_output.models import ConsoleOutput


@reversion.register()
class Routine(models.Model):
    GENERATING_TYPE_CHOICES = (
        (GeneratingType.PreDefinedSingleDataset.value, _('pre-defined single dataset')),
        (GeneratingType.PreDefinedMultipleDataset.value, _('pre-defined multiple dataset')),
        (GeneratingType.UserDefined.value, _('user-defined')),
    )

    # This, for primary search
    uuid = models.UUIDField(db_index=True, default=uuid4, editable=False, unique=True)
    code = models.CharField(max_length=100, unique=False, verbose_name=_("Routine Code"))
    name = models.CharField(max_length=200, verbose_name=_("Routine Name"))
    description = models.TextField(blank=True, null=True, verbose_name=_("Description"))

    generating_type = models.PositiveSmallIntegerField(default=GeneratingType.PreDefinedSingleDataset.value
                                                       , choices=GENERATING_TYPE_CHOICES
                                                       , verbose_name=_('Generating Type'))

    template = models.ForeignKey(Template, on_delete=models.CASCADE, verbose_name=_("Channel Template"))
    standard_process = models.ForeignKey(StandardProcess, on_delete=models.CASCADE, null=True,
                                         verbose_name=_("StandardProcess"))

    data = JSONField(default=dict(), verbose_name=_("Data"))

    dataset_name = models.CharField(max_length=150, null=True, blank=True, verbose_name=_("Dataset Name"))
    dataset_version = models.CharField(max_length=25, null=True, blank=True, verbose_name=_("Dataset Version"))
    generating_tag = models.CharField(max_length=25, null=True, blank=True, verbose_name=_("Generating Tag"))
    adjusted = models.BooleanField(default=False, verbose_name=_("Is Adjusted (by uesr)"))
    latest_build_no = models.PositiveIntegerField(null=True, verbose_name=_("Latest_Build No"))
    build_with_generating_tag = models.BooleanField(default=False, verbose_name=_("Build with Generating Tag"))
    
    created_date = models.DateTimeField(auto_now_add=True)
    updated_date = models.DateTimeField(auto_now=True,)

    def __str__(self):
        return "%s - %s" % (self.code, self.name)


@reversion.register()
class RoutineTags(models.Model):
    version = models.CharField(db_index=True, max_length=100, unique=True, verbose_name="Version")
    running = models.IntegerField(editable=False)

    @staticmethod
    def next():
        obj, created = RoutineTags.objects.get_or_create(version="{:%Y%m}".format(datetime.now()), 
                                                            defaults={"running": 1})
        if not created:
            obj.running = obj.running + 1
            obj.save()

        return "{}{}".format(obj.version, "%03d" % obj.running)


@reversion.register()
class ActivityConfiguration(models.Model):
    ACTIVITY_CHOICES = (
        (Activity.CREATE.value, _('create')),
        (Activity.UPDATE.value, _('update')),
        (Activity.VIEW.value, _('view')),
        (Activity.SEARCH.value, _('search')),
    )

    routine = models.ForeignKey(Routine, on_delete=models.CASCADE, verbose_name=_("Routine"))
    data = JSONField(verbose_name=_("Configuration"), default=dict())
    activity = models.CharField(max_length=100, choices=ACTIVITY_CHOICES, verbose_name=_('Activity'))

    class Meta:
        unique_together = ('routine', 'activity')

    def __str__(self):
        return '{} - {}'.format(self.routine.code, self.activity.name)


@reversion.register()
class Lot(models.Model):
    name = models.CharField(max_length=150, unique=True, verbose_name=_("Lot Name"))
    description = models.CharField(max_length=150, verbose_name=_("Description"), null=True, blank=True)
    datasets = ArrayField(models.CharField(max_length=150), null=True)
    standard_process_ids = ArrayField(models.IntegerField(), null=True)

    def __str__(self):
        return "%s " % (self.name)


@reversion.register()
class LotRoutine(models.Model):
    lot = models.ForeignKey(Lot, on_delete=models.CASCADE, verbose_name=_("Lot"))
    routine = models.OneToOneField(Routine, on_delete=models.CASCADE, verbose_name=_("Routine"))
