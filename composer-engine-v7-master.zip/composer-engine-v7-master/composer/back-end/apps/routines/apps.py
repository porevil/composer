from django.apps import AppConfig


class RoutinesConfig(AppConfig):
    name = 'routines'
