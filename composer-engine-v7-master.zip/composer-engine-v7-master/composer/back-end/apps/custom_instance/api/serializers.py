import uuid
from abc import ABC

from django.core.exceptions import ValidationError
from rest_framework import serializers
from apps.custom_instance import models
from apps.configurations.models import State, SubState


class IntentSerializer(serializers.Serializer):
    label = serializers.CharField(required=False, allow_null=True, default=None)
    multiple = serializers.BooleanField()
    name = serializers.CharField(required=True)
    type = serializers.CharField(required=True)


class IntentDictSerializer(serializers.Serializer):
    ins = serializers.ListField(child=IntentSerializer())
    outs = serializers.ListField(child=IntentSerializer())


class CustomInstanceConfig(serializers.Serializer):
    intent = IntentDictSerializer()
    base_path = serializers.CharField(default="back-end")
    uwsgi_module = serializers.CharField(default="app:app")
    app_config_path = serializers.CharField(default="config/app.cfg")
    package_manage_path = serializers.CharField(default="requirements.txt")


class CustomEnvironmentVariableSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.CustomEnvironmentVariable
        fields = [
            'id',
            'state',
            'config',
        ]
        read_only_fields = ['id']


class CustomInstanceSerializer(serializers.ModelSerializer):
    environment_variables = CustomEnvironmentVariableSerializer(many=True)

    class Meta:
        model = models.CustomInstance
        fields = [
            'id',
            'uuid',
            'code',
            'name',
            'description',
            'config',
            # 'custom_element_tag',
            'environment_variables',
            'latest_version',
            'git_repository',
            'git_branch',
            'commit_hash',
            'created_date',
            'updated_date',
            'repositories',
            'build_no'
        ]
        read_only_fields = ['id',
                            'uuid',
                            'custom_element_tag',
                            'created_date',
                            'build_no',
                            'updated_date',
                            'repositories']

    def validate(self, data):
        if not data.get('commit_hash') and not data.get('git_branch'):
            raise ValidationError("'commit_hash' or 'git_branch' must not be null")
        return data

class CustomInstanceUpdateSerializer(CustomInstanceSerializer):
    config = CustomInstanceConfig()

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['environment_variables'].read_only = False

    def update(self, instance, validated_data):
        environment_variables = []
        config = validated_data.pop('config')
        if validated_data.get('environment_variables', []):
            validated_data.pop('environment_variables')
            environment_variables = self.initial_data.get('environment_variables')
        ids = []
        for env_var in environment_variables:
            env_id = env_var.get('id', None)
            if env_id and models.CustomEnvironmentVariable.objects.filter(id=env_id).count():
                print("update exist env var")
                models.CustomEnvironmentVariable.objects.filter(id=env_id).update(**env_var)
            else:
                print("create new env var")
                if env_var.get('id', None):
                    env_var.pop('id')
                env_var['state'] = State.objects.filter(pk=env_var['state']).first()
                env_id = instance.environment_variables.create(**env_var).id
            ids.append(env_id)

        instance.environment_variables.exclude(id__in=ids).delete()
        instance = super(CustomInstanceSerializer, self).update(instance, validated_data)
        instance.config = config
        instance.save()
        return instance


class CustomInstanceCreateSerializer(CustomInstanceSerializer):
    config = CustomInstanceConfig()

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['code'].read_only = False

    def create(self, validated_data):
        environment_variables = validated_data.pop('environment_variables')
        config = validated_data.pop('config')
        instance = super(CustomInstanceSerializer, self).create(validated_data)
        instance.config = config
        instance.save()
        for e in environment_variables:
            instance.environment_variables.create(**e)
        instance.refresh_from_db()
        return instance


class CustomInstanceRepositorySerializer(serializers.ModelSerializer):
    class Meta:
        model = models.CustomInstanceRepository
        fields = [
            'id',
            'uuid',
            'code',
            'name',
            'description',
            'url',
            'custom_instance',
            'sub_state',
            'build_no',
            'build_data',
            'load_balance_name',
            'node_name',
            'created_date',
            'updated_date',
        ]
        read_only_fields = ['id', 'uuid', 'created_date', 'updated_date']


class BaseExecutionSerializer(serializers.Serializer):
    authorized_ticket = serializers.CharField(required=False)
    uuids = serializers.ListField(child=serializers.UUIDField())
    destination_sub_state_id = serializers.IntegerField(required=True)

    def __init__(self, *args, **kwargs):
        super(BaseExecutionSerializer, self).__init__(*args, **kwargs)

    def validate_destination_sub_state_id(self, attrs):
        try:
            sub_state = SubState.objects.get(pk=attrs)
        except Exception as e:
            raise ValidationError(message="Sub state not found")

        if sub_state.need_authorized_ticket and not self.initial_data.get('authorized_ticket'):
            raise ValidationError(message="Sub state need authorized_ticket")

        return attrs

    def create(self, validated_data):
        return super().create(validated_data)

    def update(self, instance, validated_data):
        return super().update(instance, validated_data)


class CustomInstanceExecutionSerializer(BaseExecutionSerializer):
    pass


class MoveExecutionSerializer(BaseExecutionSerializer):
    pass

class RemoveExecutionSerializer(BaseExecutionSerializer):
    pass

class PurgeExecutionSerializer(BaseExecutionSerializer):
    pass
