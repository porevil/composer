import uuid
import threading

from django.core.exceptions import ObjectDoesNotExist
from django_filters import rest_framework as filters
from rest_framework import viewsets, mixins
from rest_framework.decorators import action, permission_classes

from apps.commons.error.exception import BadRequestException
from apps.commons.generator.constants import InstanceType
from apps.commons.logger.views import ViewLogger
from apps.commons.utilities.log import Logger
from apps.commons.utilities.permission import  ExecutionPermission
from apps.commons.utilities.response import CustomJsonResponse
from apps.custom_instance.api.serializers import CustomInstanceSerializer, \
    CustomInstanceRepositorySerializer, \
    CustomInstanceExecutionSerializer, MoveExecutionSerializer, CustomInstanceCreateSerializer, \
    CustomInstanceUpdateSerializer, RemoveExecutionSerializer
from apps.custom_instance.models import CustomInstance, CustomInstanceRepository
from apps.configurations.models import State, SubState
from apps.commons.managers.custom_instance import CustomInstanceManager
from apps.console_output.models import ConsoleOutput
from apps.flow.models import FlowInstance


class CustomInstanceFilterSet(filters.FilterSet):
    class Meta:
        model = CustomInstance
        fields = {
            'name': ['exact', 'icontains'],
            'code': ['exact', 'icontains'],
            'uuid': ['exact'],
        }

class CustomInstanceViewSets(
                            mixins.ListModelMixin,
                            mixins.CreateModelMixin,
                            mixins.RetrieveModelMixin,
                            mixins.UpdateModelMixin,
                            viewsets.GenericViewSet,
                            ViewLogger
                        ):
    module_name = 'CustomInstanceViewSets'
    serializer_class = CustomInstanceSerializer
    queryset = CustomInstance.objects.all()
    filter_class = CustomInstanceFilterSet
    filter_backends = (filters.DjangoFilterBackend,)

    def get_serializer_class(self):
        if self.action == 'create':
            return CustomInstanceCreateSerializer
        elif self.action == 'update':
            return CustomInstanceUpdateSerializer

        return CustomInstanceSerializer

    def list(self, request, *args, **kwargs):
        try:
            response = super().list(request, *args, **kwargs)
            return CustomJsonResponse(
                data=response.data,
                session_id=request.session_id,
                description="Success"
            )
        except Exception as e:
            return CustomJsonResponse(data=e)

    def retrieve(self, request, *args, **kwargs):
        try:
            response = super().retrieve(request, *args, **kwargs)
            return CustomJsonResponse(
                data=response.data,
                description="Get Data Success",
                session_id=request.session_id
            )
        except Exception as e:
            return CustomJsonResponse(data=e)

    def create(self, request, *args, **kwargs):
        try:
            response = super().create(request, args, kwargs)
            return CustomJsonResponse(
                data=response.data,
                description="Create Success",
                session_id=request.session_id
            )
        except Exception as e:
            return CustomJsonResponse(data=e)

    def update(self, request, *args, **kwargs):
        try:
            response = super().update(request, args, kwargs)
            return CustomJsonResponse(
                data=response.data,
                description="Update Success",
                session_id=request.session_id

            )
        except Exception as e:
            return CustomJsonResponse(description="Update Success", data=e)


class CustomInstanceRepositoryViewSets(viewsets.GenericViewSet,
                                       mixins.RetrieveModelMixin,
                                       mixins.ListModelMixin,
                                       ViewLogger):
    class CustomRepositoryFilterSet(filters.FilterSet):
        class Meta:
            model = CustomInstanceRepository
            fields = {
                'sub_state_id': ['exact'],
                'name': ['exact', 'icontains'],
                'code': ['exact', 'icontains'],
                'uuid': ['exact'],
            }

    serializer_class = CustomInstanceRepositorySerializer
    queryset = CustomInstanceRepository.objects.all()
    filter_class = CustomRepositoryFilterSet
    filter_backends = (filters.DjangoFilterBackend,)
    module_name = "CustomInstanceRepositoryViewSets"

    def list(self, request, *args, **kwargs):
        try:
            response = super().list(request, *args, **kwargs)
            return CustomJsonResponse(
                data=response.data,
                description="Success",
                session_id=request.session_id
            )
        except Exception as e:
            return CustomJsonResponse(data=e)

    def retrieve(self, request, *args, **kwargs):
        try:
            response = super().retrieve(request, *args, **kwargs)
            return CustomJsonResponse(
                data=response.data,
                description="Get Data Success",
                session_id=request.session_id
            )
        except Exception as e:
            return CustomJsonResponse(data=e)


class CustomInstanceExecutionViewSets(viewsets.ViewSet, viewsets.GenericViewSet, ViewLogger):
    module_name = "CustomInstanceExecutionViewSets"
    execution_permission = ExecutionPermission()

    def get_serializer_class(self):
        if self.action == 'move':
            return MoveExecutionSerializer
        return CustomInstanceExecutionSerializer

    @action(methods=['POST'], detail=False)
    def build_and_publish(self, request, *args, **kwargs):
        self.module_name = "Custom Instance Build and Publish"
        data = None
        console_output = ConsoleOutput.objects.create(
            title="Build and Publish Custom MBS",
            executed_by=request.oidc_user.preferred_username
        )
        instance_manager = CustomInstanceManager(console_output, logger=self.logger)
        try:
            self.execution_permission(request)
            serializer = CustomInstanceExecutionSerializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            self.logger.debug(serializer.validated_data)
            threading.Thread(
                target=instance_manager.build_and_publish,
                args=(serializer.validated_data.get('uuids'),)
            ).start()
            data = {
                'console_output_id': console_output.id,
            }
        except Exception as e:
            console_output.output = f"Error - {str(e)}\ncomplete"
            self.logger.error(e)
            data = e
        finally:
            return CustomJsonResponse(
                data=data,
                session_id=request.session_id
            )

    @action(methods=['POST'], detail=False)
    def move(self, request, *args, **kwargs):
        self.serializer_class = MoveExecutionSerializer
        console_output = ConsoleOutput.objects.create(
            title="Move Custom MBS",
            executed_by=request.oidc_user.preferred_username
        )
        instance_manager = CustomInstanceManager(console_output)
        data = None
        try:
            self.execution_permission(request)
            serializer = MoveExecutionSerializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            self.logger.debug(request.data)
            threading.Thread(
                target=instance_manager.move,
                args=(
                    serializer.data.get('uuids'),
                    serializer.data.get('destination_sub_state_id'),
                )
            ).start()
            data = {
                'console_output_id': console_output.id,
            }
        except Exception as e:
            self.logger.error(e)
            data = e
        finally:
            return CustomJsonResponse(
                data=data,
                session_id=request.session_id
            )

    @action(methods=['POST'], detail=False)
    def republish(self, request, *args, **kwargs):
        data = None
        console_output = ConsoleOutput.objects.create(
            title="Re-Publish Custom MBS",
            executed_by=request.oidc_user.preferred_username
        )
        instance_manager = CustomInstanceManager(console_output)
        try:
            self.execution_permission(request)
            serializer = CustomInstanceExecutionSerializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            self.logger.debug(serializer.validated_data)
            threading.Thread(
                target=instance_manager.re_publish,
                args=(serializer.validated_data.get('uuids'))
            ).start()
            data = {
                'console_output_id': console_output.id,
            }
        except Exception as e:
            self.logger.error(e)
            data = e
        finally:
            return CustomJsonResponse(
                data=data,
                session_id=request.session_id
            )

    @action(methods=['POST'], detail=False)
    def purge(self, request, *args, **kwargs):
        data = None
        console_output = ConsoleOutput.objects.create(
            title="Purge Custom MBS",
            executed_by=request.oidc_user.preferred_username
        )
        instance_manager = CustomInstanceManager(console_output)
        try:
            self.execution_permission(request)
            for _uuid in request.data.get('uuids'):
                if CustomInstance.objects.filter(uuid=_uuid).filter().count():
                    raise BadRequestException(f"Can not purge '{_uuid}' please check repository")
            serializer = CustomInstanceExecutionSerializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            self.logger.debug(serializer.validated_data)
            threading.Thread(
                target=instance_manager.purge,
                args=(serializer.validated_data.get('uuids'),)
            ).start()
            data = {
                'console_output_id': console_output.id
            }
        except Exception as e:
            self.logger.error(e)
            data = e
        finally:
            return CustomJsonResponse(
                data=data,
                session_id=request.session_id
            )

    @action(methods=['POST'], detail=False)
    def remove(self, request, *args, **kwargs):
        data = None
        console_output = ConsoleOutput.objects.create(
            title="Remove Custom MBS",
            executed_by=request.oidc_user.preferred_username
        )
        instance_manager = CustomInstanceManager(console_output)
        try:
            self.execution_permission(request)
            try:
                repository = CustomInstanceRepository.objects.get(uuid=uuid)
            except ObjectDoesNotExist:
                raise BadRequestException("CustomInstanceRepository not exist")

            flow = FlowInstance.objects.filter(instance_type=InstanceType.Custom.value,
                                               instance_uuid=repository.uuid).first()
            if flow:
                raise BadRequestException(
                    f"Repository ('{repository.uuid}') existing, please check flow ('{flow.uuid}') before delete", )

            serializer = RemoveExecutionSerializer(request.data)
            serializer.is_valid(raise_exception=True)
            self.logger.debug(serializer.validated_data)
            threading.Thread(
                target=instance_manager.remove,
                args=(serializer.validated_data.get('uuids'),)
            ).start()
            data = {
                'console_output_id': console_output.id
            }
        except Exception as e:
            self.logger.error(e)
            data = e
        finally:
            return CustomJsonResponse(
                data=data,
                session_id=request.session_id
            )
