from django.apps import AppConfig


class CustomInstanceConfig(AppConfig):
    name = 'custom_instance'
