from uuid import uuid4
from django.db import models
from django.utils.translation import ugettext_lazy as _

from django.contrib.postgres.fields import JSONField
from apps.configurations.models import SubState, State


def generate_tag():
    """
    generate unique tag for HTML element
    :return:
    """
    return f'mbs-custom-{uuid4()}'


def get_custom_instance_config_schema():
    """
    Validate config field in custom instance
    :return:
    """
    config_schema = {
        'type': 'object',
        'properties': {
            'app_path': {
                'type': 'string',
                'default': '',
            }

        }
    }
    return config_schema


class CustomInstance(models.Model):
    """
    Custom MBS blueprint
    """
    uuid = models.UUIDField(db_index=True, default=uuid4, editable=False, unique=True, verbose_name=_("Description"))
    code = models.CharField(max_length=100, unique=False, editable=False, verbose_name=_("Code"))
    name = models.CharField(max_length=150, verbose_name=_("Name"))
    # custom_element_tag = models.CharField(max_length=255, editable=False, null=False, default=generate_tag, unique=True,
    #                                       verbose_name=_("HTML tag"))
    description = models.TextField(blank=True, null=True, verbose_name=_("Description"))
    latest_version = models.CharField(max_length=100, blank=True, null=True, default=0,
                                      verbose_name=_("Latest Version"))
    build_no = models.PositiveSmallIntegerField(default=0, null=True, verbose_name=_("Build Number"))
    config = JSONField(default=dict, verbose_name=_("Configuration"))
    git_repository = models.URLField(max_length=255, verbose_name=_("Git Repository URL"))
    git_branch = models.CharField(max_length=255, null=True, blank=True, verbose_name=_("Git Branch"))
    commit_hash = models.CharField(max_length=255, null=True, blank=True, verbose_name=_("Git Commit Hash"))
    created_date = models.DateTimeField(auto_now_add=True)
    updated_date = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ("code", "latest_version")

    def __str__(self):
        return "%s - %s" % (self.code, self.name)


class CustomEnvironmentVariable(models.Model):
    custom_instance = models.ForeignKey(CustomInstance,
                                        related_name='environment_variables',
                                        on_delete=models.CASCADE,
                                        verbose_name=_("Custom Instance "))
    state = models.ForeignKey(State, related_name='state', on_delete=models.CASCADE, verbose_name=_("State"))
    config = JSONField(default=dict, verbose_name=_("Configuration"))


class CustomInstanceRepository(models.Model):
    """
    Custom MBS instance
    """
    uuid = models.UUIDField(db_index=True, verbose_name=_("ID"), default=uuid4)
    code = models.CharField(db_index=True, max_length=100, verbose_name=_("Code"))
    name = models.CharField(max_length=200, verbose_name=_("Name"))
    description = models.TextField(null=True, blank=True, verbose_name=_("Description"))
    url = models.CharField(max_length=255, verbose_name=_("Repository Url"))

    custom_instance = models.ForeignKey(
        CustomInstance,
        related_name="repositories",
        verbose_name=_("Custom Instance config"),
        on_delete=models.CASCADE
    )

    build_no = models.PositiveIntegerField(null=True, verbose_name=_("Build No"))
    build_data = JSONField(default=dict, verbose_name=_("Build Data"))

    load_balance_name = models.CharField(max_length=150, default=None, verbose_name=_("Target Load Balance Name"))
    node_name = models.CharField(max_length=150, default=None, verbose_name=_("Target Repository Name"))
    sub_state = models.ForeignKey(SubState, on_delete=models.CASCADE, null=True, verbose_name=_("Sub state"))

    created_date = models.DateTimeField(auto_now_add=True, verbose_name=_("Create date"))
    updated_date = models.DateTimeField(auto_now=True, blank=True, verbose_name=_("Update date"))

    @property
    def instance(self):
        return self.custom_instance

    def __str__(self):
        return "%s - %s" % (self.code, self.name)
