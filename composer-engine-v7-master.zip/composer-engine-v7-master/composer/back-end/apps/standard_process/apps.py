from django.apps import AppConfig


class MenuConfig(AppConfig):
    name = 'standard_process'
