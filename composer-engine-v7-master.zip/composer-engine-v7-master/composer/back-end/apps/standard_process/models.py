import reversion

from django.db import models
from django.utils.translation import ugettext_lazy as _

from jsonfield import JSONField
from apps.configurations.models import State
from apps.commons.generator.constants import StandardProcessType as StandardProcessTypeEnum


@reversion.register()
class Template(models.Model):
    code = models.CharField(max_length=50, verbose_name=_("Channel Template Code"))
    name = models.CharField(max_length=255, null=True, blank=True, verbose_name=_("Channel Template Name"))
    config = JSONField(default=dict(), verbose_name=_("Configuration"))
    version = models.CharField(max_length=50, null=True, blank=True, verbose_name=_("Version"))
    git_repository = models.URLField(max_length=255, verbose_name=_("Git Repository URL"))
    git_branch = models.CharField(max_length=255, null=True, verbose_name=_("Git Branch"))
    commit_hash = models.CharField(max_length=255, null=True, verbose_name=_("Git Commit Hash"))
    requirement = models.TextField(null=True, blank=True, verbose_name=_("Requirement"))
    created_date = models.DateTimeField(auto_now_add=True, verbose_name=_("Created date"))
    updated_date = models.DateTimeField(auto_now=True, blank=True, verbose_name=_("Updated date"))

    class Meta:
        unique_together = [('code', 'version', )]

    def __str__(self):
        return self.name


@reversion.register()
class TemplateEnvironmentVariable(models.Model):
    template = models.ForeignKey(Template, on_delete=models.CASCADE, verbose_name=_("Template"))
    state = models.ForeignKey(State, on_delete=models.CASCADE, verbose_name=_("State"))
    config = JSONField(null=True, verbose_name=_("Environment Variables"))

    class Meta:
        unique_together = ("template", "state",)

    def __str__(self):
        return '{} - {} (Environment Variable)'.format(self.core_template.code, self.state.name)


@reversion.register()
class StandardProcess(models.Model):
    code = models.CharField(max_length=50, null=True, unique=True, verbose_name=_("Standard Process Code"))
    name = models.CharField(max_length=50, null=True, verbose_name=_("Standard Process Name"))
    description = models.TextField(null=True, blank=True, verbose_name=_("Description"))
    template = models.ForeignKey(Template, on_delete=models.CASCADE, verbose_name=_("Template"))
    config = JSONField(default=dict(), verbose_name=_("Configuration"))

    def get_type(self):
        prefix = self.code[0:1]
        if prefix == 'I':
            return StandardProcessTypeEnum.INPUT
        if prefix == 'O':
            return StandardProcessTypeEnum.OUTPUT
        if prefix == 'C':
            return StandardProcessTypeEnum.CONTROL
        if prefix == 'E':
            return StandardProcessTypeEnum.EXECUTE
        return None

    def get_type_name(self):
        standard_process_type = self.get_type()
        if standard_process_type is not None:
            return standard_process_type.name
        return None

    def __str__(self):
        return "%s - %s" % (self.code, self.name)


# config example
# {
#     'attributes': [{
#         'code': 'default-value',
#         'display_label': 'Default Value',
#         'value': ''
#     }]
# }
@reversion.register()
class Component(models.Model):
    code = models.CharField(max_length=50, unique=True, verbose_name=_("Component Code"))
    name = models.CharField(max_length=255, verbose_name=_("Component Name"))
    config = JSONField(default=dict(), verbose_name=_("Configuration"))
    created_date = models.DateTimeField(auto_now_add=True, verbose_name=_("Created date"))
    updated_date = models.DateTimeField(auto_now=True, blank=True, verbose_name=_("Updated date"))

    def __str__(self):
        return self.name
