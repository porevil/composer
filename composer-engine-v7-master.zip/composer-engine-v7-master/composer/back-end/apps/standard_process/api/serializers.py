from django.db import models
from django.utils.translation import gettext as _
from django.core.validators import URLValidator
from django.contrib.postgres.fields import JSONField
from rest_framework import serializers
from django.core.validators import URLValidator

from apps.standard_process.models import Template, TemplateEnvironmentVariable, Component, StandardProcess


class ComponentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Component
        fields = [
            'id',
            'code',
            'name',
            'created_date',
            'updated_date',
        ]


class ComponentDetailSerializer(serializers.ModelSerializer):
    config = JSONField()

    class Meta:
        model = Component
        fields = [
            'id',
            'code',
            'name',
            'config',
            'created_date',
            'updated_date',
        ]


class StandardTemplateSerializer(serializers.ModelSerializer):
    config = JSONField()

    class Meta:
        model = Template
        fields = [
            'id',
            'name',
            'code',
            'version',
            'created_date',
            'updated_date',
        ]
        read_only_Fields = ('id',)

    def validate_git_repository(self, value):
        if URLValidator()(value):
            raise serializers.ValidationError("input url invalide")
        return value


class StandardTemplateDetailSerializer(serializers.ModelSerializer):
    environment_variables = serializers.SerializerMethodField()
    config = JSONField()

    class Meta:
        model = Template
        fields = [
            'id',
            'name',
            'code',
            'version',
            'config',
            'commit_hash',
            'git_repository',
            'git_branch',
            'requirement',
            'created_date',
            'updated_date',
            'environment_variables',
        ]
        read_only_Fields = ('id',)

    # def va

    def validate_git_repository(self, value):
        if URLValidator()(value):
            raise serializers.ValidationError("input url invalide")
        return value

    def get_environment_variables(self, obj):
        environment_variables = TemplateEnvironmentVariable.objects.filter(template=obj)
        serializer = StandardTemplateEnvironmentVariableSerializer(environment_variables, many=True)
        return serializer.data


class StandardTemplateEnvironmentVariableSerializer(serializers.ModelSerializer):
    config = JSONField()

    class Meta:
        model = TemplateEnvironmentVariable
        fields = [
            'id',
            'state_id',
            'config',
        ]


class StandardProcessSerializer(serializers.ModelSerializer):
    class Meta:
        model = StandardProcess
        fields = [
            'id',
            'code',
            'name',
            'description'
        ]


class StandardProcessDetailSerializer(serializers.ModelSerializer):
    config = JSONField()

    class Meta:
        model = StandardProcess
        fields = [
            'id',
            'code',
            'name',
            'description',
            'config',
            'template_id'
        ]
