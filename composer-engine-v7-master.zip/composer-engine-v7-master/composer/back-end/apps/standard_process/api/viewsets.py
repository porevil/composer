import uuid
import os
import sys

from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status, mixins, viewsets, generics
from django.db import transaction

from apps.commons.utilities.response import ResponseAPI, CustomJsonResponse, CustomResponseObject
from apps.standard_process.api.serializers import StandardTemplateSerializer, StandardTemplateDetailSerializer
from apps.standard_process.api.serializers import ComponentSerializer, ComponentDetailSerializer
from apps.standard_process.api.serializers import StandardProcessSerializer, StandardProcessDetailSerializer
from apps.standard_process.models import Template, TemplateEnvironmentVariable, Component, StandardProcess
from apps.configurations.models import State
from apps.commons.utilities.log import Logger
from apps.commons.error.exception import *


class ComponentViewSet(viewsets.ModelViewSet):
    serializer_class = ComponentDetailSerializer
    response_meta = ResponseAPI()
    reference_id = str(uuid.uuid4())
    logger = Logger('Component')
    response_data = None
    queryset = Component.objects.all()

    def list(self, request, **kwargs):
        try:
            self.logger.debug('list component [reference id = {}] start'.format(self.reference_id))

            components = Component.objects.all()
            serializer = ComponentSerializer(components, many=True)
            response = self.response_meta.success("success", self.reference_id, serializer.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('list component [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('list component [reference id = {}] response = {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def retrieve(self, request, pk=None, **kwargs):
        try:
            self.logger.debug('retrieve standard template [reference id = {}] start'.format(self.reference_id))

            if pk is None:
                raise BadRequestException('"id" is required')

            component = Component.objects.filter(id=pk).first()
            if component is None:
                raise BadRequestException('"id" is invalid')

            serializer = ComponentDetailSerializer(component)
            response = self.response_meta.success("success", self.reference_id, serializer.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('retrieve component [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug(
                'retrieve component [reference id = {}] response = {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def create(self, request, **kwargs):
        try:
            with transaction.atomic():
                self.logger.debug('create component [reference id = {}] start'.format(self.reference_id))

                request_data = request.data or dict()
                self.logger.debug(
                    'create component [reference id = {}] request data = {}'.format(self.reference_id, request_data))

                code = request_data.get('code')
                name = request_data.get('name')
                config = request_data.get('config') or dict()

                if code is None:
                    raise BadRequestException('"code" is required')

                component = Component.objects.create(**{
                    'code': code,
                    'name': name,
                    'config': config
                })

                response = self.response_meta.success('create success', self.reference_id,
                                                      ComponentDetailSerializer(component).data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('create component [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('create component [reference id = {}] response = {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def update(self, request, pk=None, **kwargs):
        try:
            with transaction.atomic():
                self.logger.debug('update component [reference id = {}] start'.format(self.reference_id))

                if pk is None:
                    raise BadRequestException('"id" is required')

                component = Component.objects.filter(id=pk).first()
                if component is None:
                    raise BadRequestException('"id" is invalid')

                request_data = request.data or dict()
                self.logger.debug(
                    'update component [reference id = {}] request data = {}'.format(self.reference_id, request_data))

                name = request_data.get('name')
                config = request_data.get('config') or dict()

                # update template model
                component.name = name
                component.config = config
                component.save()

                response = self.response_meta.success('update success', self.reference_id,
                                                      ComponentDetailSerializer(component).data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('update component [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('update component [reference id = {}] response = {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def destroy(self, request, *args, **kwargs):
        try:
            self.logger.debug('delete component [reference id = {}] start'.format(self.reference_id))

            id = kwargs.get('pk')
            if id is None:
                raise BadRequestException('"id" is required')

            component = Component.objects.filter(id=id).first()
            if component is None:
                raise BadRequestException('bad request : "id" is invalid')

            component.delete()

            response = self.response_meta.success('delete success', self.reference_id)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('delete component [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('delete component [reference id = {}] response = {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)


class StandardTemplateViewSet(viewsets.ModelViewSet):
    serializer_class = StandardTemplateDetailSerializer
    response_meta = ResponseAPI()
    reference_id = str(uuid.uuid4())
    logger = Logger('Standard Template')
    queryset = Template.objects.all()

    def list(self, request, **kwargs):
        try:
            self.logger.debug('list standard template [reference id = {}] start'.format(self.reference_id))

            standard_templates = Template.objects.all()
            serializer = StandardTemplateSerializer(standard_templates, many=True)
            response = self.response_meta.success("success", self.reference_id, serializer.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('list standard template [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug(
                'list standard template [reference id = {}] response = {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def retrieve(self, request, pk=None, **kwargs):
        try:
            self.logger.debug('retrieve standard template [reference id = {}] start'.format(self.reference_id))

            if pk is None:
                raise BadRequestException('"id" is required')

            standard_template = Template.objects.filter(id=pk).first()
            if standard_template is None:
                raise BadRequestException('"id" is invalid')

            serializer = StandardTemplateDetailSerializer(standard_template)
            response = self.response_meta.success("success", self.reference_id, serializer.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('retrieve standard template [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug(
                'retrieve standard template [reference id = {}] response = {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def create(self, request, **kwargs):
        try:
            with transaction.atomic():
                self.logger.debug('create standard template [reference id = {}] start'.format(self.reference_id))

                request_data = request.data or dict()
                self.logger.debug(
                    'create standard template [reference id = {}] request data = {}'.format(self.reference_id,
                                                                                            request_data))

                code = request_data.get('code')
                name = request_data.get('name')
                version = request_data.get('version')
                git_repository = request_data.get('git_repository')
                git_branch = request_data.get('git_branch')
                commit_hash = request_data.get('commit_hash')
                config = request_data.get('config') or dict()
                requirement = request_data.get('requirement')

                if code is None:
                    raise BadRequestException('"code" is required')
                if git_repository is None:
                    raise BadRequestException('"git_repository" is required')
                if git_branch is None and commit_hash is None:
                    raise BadRequestException('"git_branch" or "commit_hash" must exist')

                environment_variables = request_data.get('environment_variables') or list()

                template = Template.objects.create(**{
                    'code': code,
                    'name': name,
                    'version': version,
                    'git_repository': git_repository,
                    'git_branch': git_branch,
                    'commit_hash': commit_hash,
                    'config': config,
                    'requirement': requirement
                })

                for env in environment_variables:
                    state_id = env.get('state_id')
                    config = env.get('config') or dict()
                    state = State.objects.filter(id=state_id).first()

                    if state is None:
                        continue

                    environment_variable = TemplateEnvironmentVariable.objects.create(**{
                        'template': template,
                        'state': state,
                        'config': config
                    })

                response = self.response_meta.success('create success', self.reference_id,
                                                      StandardTemplateDetailSerializer(template).data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('create standard template [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug(
                'create standard template [reference id = {}] response = {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def update(self, request, pk=None, **kwargs):
        try:
            with transaction.atomic():
                self.logger.debug('update standard template [reference id = {}] start'.format(self.reference_id))

                if pk is None:
                    raise BadRequestException('"id" is required')

                template = Template.objects.filter(id=pk).first()
                if template is None:
                    raise BadRequestException('"id" is invalid')

                request_data = request.data or dict()
                self.logger.debug(
                    'update standard template [reference id = {}] request data = {}'.format(self.reference_id,
                                                                                            request_data))

                name = request_data.get('name')
                version = request_data.get('version')
                git_repository = request_data.get('git_repository')
                git_branch = request_data.get('git_branch')
                commit_hash = request_data.get('commit_hash')
                config = request_data.get('config') or dict()
                requirement = request_data.get('requirement')

                if git_repository is None:
                    raise BadRequestException('"git_repository" is required')
                if git_branch is None and commit_hash is None:
                    raise BadRequestException('"git_branch" or "commit_hash" must exist')

                environment_variables = request_data.get('environment_variables') or list()

                # update template model
                template.name = name
                template.version = version
                template.git_repository = git_repository
                template.git_branch = git_branch
                template.commit_hash = commit_hash
                template.config = config
                template.requirement = requirement
                template.save()

                _ids = list()
                for env in environment_variables:
                    _id = env.get('id')
                    state_id = env.get('state_id')
                    config = env.get('config') or dict()
                    state = State.objects.filter(id=state_id).first()

                    if state is None:
                        continue

                    environment_variable = TemplateEnvironmentVariable.objects.filter(id=_id).first()
                    if environment_variable is None:
                        environment_variable = TemplateEnvironmentVariable.objects.create(**{
                            'template': template,
                            'state': state,
                            'config': config
                        })
                    else:
                        environment_variable.state = state
                        environment_variable.config = config
                        environment_variable.save()

                    _ids.append(environment_variable.id)

                # delete 'environment_variable'
                deleted_environment_variables = TemplateEnvironmentVariable.objects.filter(template=template).exclude(
                    id__in=_ids)
                deleted_environment_variables.delete()

                response = self.response_meta.success('update success', self.reference_id,
                                                      StandardTemplateDetailSerializer(template).data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('update standard template [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug(
                'update standard template [reference id = {}] response = {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def destroy(self, request, *args, **kwargs):
        try:
            self.logger.debug('delete standard template [reference id = {}] start'.format(self.reference_id))

            id = kwargs.get('pk')
            if id is None:
                raise BadRequestException('"id" is required')

            template = Template.objects.filter(id=id).first()
            if template is None:
                raise Exception('bad request : "id" is invalid')

            template.delete()

            response = self.response_meta.success('delete success', self.reference_id)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('delete standard template [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug(
                'delete standard template [reference id = {}] response = {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)


class StandardProcessViewSet(viewsets.ModelViewSet):
    serializer_class = StandardProcessDetailSerializer
    response_meta = ResponseAPI()
    reference_id = str(uuid.uuid4())
    logger = Logger('Standard Process')
    queryset = StandardProcess.objects.all()

    def list(self, request):
        try:
            self.logger.debug('list standard process [reference id = {}] start'.format(self.reference_id))

            standard_processes = StandardProcess.objects.all()
            serializer = StandardProcessSerializer(standard_processes, many=True)
            response = self.response_meta.success("success", self.reference_id, serializer.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('list standard process [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug(
                'list standard process [reference id = {}] response = {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def retrieve(self, request, pk=None):
        try:
            self.logger.debug('retrieve standard template [reference id = {}] start'.format(self.reference_id))

            if pk is None:
                raise BadRequestException('"id" is required')

            standard_process = StandardProcess.objects.filter(id=pk).first()
            if standard_process is None:
                raise BadRequestException('"id" is invalid')

            serializer = StandardProcessDetailSerializer(standard_process)
            response = self.response_meta.success("success", self.reference_id, serializer.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('retrieve standard process [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug(
                'retrieve standard template [reference id = {}] response = {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def create(self, request):
        try:
            with transaction.atomic():
                self.logger.debug('create standard process [reference id = {}] start'.format(self.reference_id))

                request_data = request.data or dict()
                self.logger.debug(
                    'create standard process [reference id = {}] request data = {}'.format(self.reference_id,
                                                                                           request_data))

                code = request_data.get('code')
                name = request_data.get('name')
                description = request_data.get('description')
                config = request_data.get('config') or dict()
                template_id = request_data.get('template_id')
                template = Template.objects.filter(id=template_id).first()

                if code is None:
                    raise BadRequestException('"code" is required')
                if template is None:
                    raise BadRequestException('"template_id" is invalid')

                standard_process = StandardProcess.objects.create(**{
                    'code': code,
                    'name': name,
                    'description': description,
                    'config': config,
                    'template': template
                })

                response = self.response_meta.success('create success', self.reference_id,
                                                      StandardProcessDetailSerializer(standard_process).data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('create standard process [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug(
                'create standard process [reference id = {}] response = {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def update(self, request, pk=None):
        try:
            with transaction.atomic():
                self.logger.debug('update standard process [reference id = {}] start'.format(self.reference_id))

                if pk is None:
                    raise BadRequestException('"id" is required')

                standard_process = StandardProcess.objects.filter(id=pk).first()
                if standard_process is None:
                    raise BadRequestException('"id" is invalid')

                request_data = request.data or dict()
                self.logger.debug(
                    'update standard process [reference id = {}] request data = {}'.format(self.reference_id,
                                                                                           request_data))

                name = request_data.get('name')
                description = request_data.get('description')
                config = request_data.get('config') or dict()
                template_id = request_data.get('template_id')
                template = Template.objects.filter(id=template_id).first()

                # update template model
                standard_process.name = name
                standard_process.description = description
                standard_process.config = config
                standard_process.template = template
                standard_process.save()

                response = self.response_meta.success('update success', self.reference_id,
                                                      StandardProcessDetailSerializer(standard_process).data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('update standard process [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug(
                'update standard process [reference id = {}] response = {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def destroy(self, request, *args, **kwargs):
        try:
            self.logger.debug('delete standard process [reference id = {}] start'.format(self.reference_id))

            id = kwargs.get('pk')
            if id is None:
                raise BadRequestException('"id" is required')

            standard_process = StandardProcess.objects.filter(id=id).first()
            if standard_process is None:
                raise BadRequestException('"id" is invalid')

            standard_process.delete()

            response = self.response_meta.success('delete success', self.reference_id)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('delete standard process [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug(
                'delete standard process [reference id = {}] response = {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)
