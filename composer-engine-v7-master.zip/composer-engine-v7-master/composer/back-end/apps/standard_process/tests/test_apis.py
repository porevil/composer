from apps.standard_process.api.serializers import StandardTemplateSerializer
from apps.standard_process.models import Template
from rest_framework import status
from rest_framework.test import APIClient
from django.urls import reverse
from django.test import TestCase


# TEMPLATE_URL = reverse('template')


def sample_template(**params):
    default = {
        "name": "Input Template",
        "code": "I9",
        "version": "1",
        "git_repository": "https://github.com/Peelz/composer-v6-engine",
        "commit_hash": "AAAA-BBBB-CCCC"
    }
    default.update(params)

    return Template.objects.create(**default)


class StdTemplateAPITests(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.model = sample_template(name="Sample Std Temple", code="s1")

    def test_create_fail(self):
        payload = {
            'name': 'new template 245',
            'code': 'I18',
            'version': '1.0.0'
        }
        res = self.client.post("/api/std_templates/", payload)
        self.assertEqual(res.data['meta']['response_desc'], 'create fail')

    def test_get(self):
        queryset = Template.objects.all()
        serializer = StandardTemplateSerializer(queryset, many=True)

        response = self.client.get("/api/std_templates/")
        self.assertEqual(response.data['data'], serializer.data)

    def test_retrieve(self):
        template = self.model
        res = self.client.get(f"/api/std_templates/{template.id}/")
        self.assertEqual(template.id, res.data['data']['id'])

    def test_create_success(self):
        payload = {
            "name": "Test create",
            "code": "c9",
            "version": "1",
            "git_repository": "https://github.com/Peelz/composer-v6-engine",
            "commit_hash": "AAAA-BBBB-CCCC"
        }
        res = self.client.post("/api/std_templates/", payload)

        queryset = Template.objects.get(pk=res.data['data']['id'])
        serializer = StandardTemplateSerializer(queryset)

        self.assertEqual(res.data['meta']['response_desc'], 'create success')
        self.assertEqual(payload['code'], res.data['meta']['data']['code'])

    def test_update_success(self):
        template = sample_template(name="bla")
        payload = {
            "code": "I9",
            "version": "2",
            "git_repository": "https://github.com/Peelz/composer-v6-engine",
            "commit_hash": "AAAA-BBBB-CCCC"
        }

        res = self.client.put(f"/api/std_templates/{template.id}/", payload)
        template.refresh_from_db()
        self.assertEqual(res.status_code, 200)


class TestValidateRequestAPI(TestCase):
    """Test validate datarequset"""

    def setUp(self):
        self.client = APIClient()

    def test_missing_git_branch_and_hash_request(self):
        payload_1 = {
            "code": "I9",
            "name": "bla bla",
            "version": "1.0.0",
            "git_repository": "https://github.com/Peelz/composer-v6-engine",
            "git_branch": "AAAA-BBBB-CCCC"
        }

    def test_missing_commit_hash_request(self):
        """Invide data requset"""
        payload_1 = {
            "code": "I9",
            "name": "bla bla",
            "version": "1.0.0",
            "git_repository": "https://github.com/Peelz/composer-v6-engine",
            "git_branch": "AAAA-BBBB-CCCC"
        }

    def test_missing_branch_request(self):
        """Invide data requset"""
        payload_1 = {
            "code": "I9",
            "name": "bla bla",
            "version": "1.0.0",
            "git_repository": "https://github.com/Peelz/composer-v6-engine",
            "git_branch": "AAAA-BBBB-CCCC"
        }
