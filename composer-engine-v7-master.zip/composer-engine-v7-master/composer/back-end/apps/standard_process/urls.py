from django.conf.urls import url
from django.urls import path, include, re_path
from rest_framework.routers import DefaultRouter

from apps.standard_process.api import viewsets

router = DefaultRouter()
router.register('', viewsets.TemplateViewSet)

app_name = 'standard_template'

urlpatterns = [
    path('', include(router.urls)),
]
