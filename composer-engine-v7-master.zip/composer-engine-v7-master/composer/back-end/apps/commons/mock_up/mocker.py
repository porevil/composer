from django.test import TestCase
import tempfile
import uuid

from rest_framework.test import RequestsClient
from apps.custom_instance.models import CustomInstance, CustomInstanceRepository, CustomEnvironmentVariable
from apps.commons.generator.custom_instance import CustomInstanceBuild, \
    CustomInstancePublish, CustomInstanceDestroy, CustomInstancePurge
from apps.configurations.models import SubState, State, InstanceDeploymentSpecification
from apps.commons.connectors.s3 import S3Client

custom_instance_data = {
    "uuid": "de5d630d-b40c-4b9c-ae17-dd2b53f664b9",
    "code": "secret",
    "name": "ห้ามลบ นะ",
    "description": "ย้ำว่าห้ามลบ",
    "latest_version": "1.0",
    "config": {
        'app_config_path': 'config/app.cfg',
        'base_path': 'back-end',
        'package_manage_path': 'requirements.txt',
        'uwsgi_module': 'app:app',
    },
    "git_repository": "https://gitlab.com/MonoPeelz/mbs-custom-private",
    "git_branch": "master",
    "commit_hash": None,
    "created_date": "2020-06-01T02:29:49Z",
    "updated_date": "2020-06-01T02:29:49Z",
    "custom_element_tag": "mbs-custom-13cdd6b4-44b7-4f3d-9b3d-3761ccc58da5"
}

sub_state = {
    "name": "state2 (channelState1)",
    "virtual_name": "",
    "is_default": True,
    "is_advisor": False,
    "is_pre_production": False,
    "is_production": False,
    "need_authorized_ticket": False,
    "has_shelf": True,
    "next_sub_state_ids": None,
}

next_sub_state = {
    "name": "state3 (channelState2)",
    "virtual_name": "",
    "is_default": False,
    "is_advisor": False,
    "is_pre_production": False,
    "is_production": False,
    "need_authorized_ticket": True,
    "has_shelf": False,
}

state = {
    "name": "learning",
    "virtual_name": "learning",
    "config": {
        "aws": {
            "region": "ap-southeast-1",
            "access_key_id": "AKIAIYCL4KWIY3K2CQ3Q",
            "secret_access_key": "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"
        },
        "mule": {
            "client_id": "7d54f79fb17946678775205aab308619",
            "client_secret": "530d2e1111174443BFB01891E40BD091"
        },
        "ag_service": {
            "runtime_endpoint": "https://api-v1-service.c1-alpha-tiscogroup.com/public/accessgovern-v1-service/sep-ags",
            "management_endpoint": "https://api-v1-service.c1-alpha-tiscogroup.com/public/accessgovern-v1-app/mgt-ags"
        },
        "service_account": "00u6ilmd4qVBUfkMC0h7",
        "launcher_service": {
            "endpoint": "https://launcher-v7-state1-app.c1-alpha-tiscogroup.com/api"
        },
        "metadata_service": {
            "endpoint": "https://api-v1-service.c1-alpha-tiscogroup.com/public/data-v3-service/dep-api/GetMetaData"
        },
        "notification_service": {
            "endpoint": "https://api-v1-service.c1-alpha-tiscogroup.com/public/notification-v2-service/sep-notification"
        }
    }
}

deploy_spec = {
    "config": {
        "notification": {
            "recipients": ["zanucha@tisco.co.th"],
            "carbon_copy": ["tanasit@tisco.co.th"],
            "template_id": "xxxx",
            "blind_carbon_copy": ["tanasit@tisco.co.th"],
            "warning_threshold": 50,
            "critical_threshold": 20
        },
        "load_balances": [
            {
                "url": "https://node-v7-state1-lb01.c1-alpha-tiscogroup.com",
                "name": "node-v7-state1-lb01",
                "nodes": [
                    {
                        "name": "node-v7-state1-lb01-tg1",
                        "port": "80",
                        "context_path": "tg1",
                        "limit_instance": 120,
                        "create_datetime": 1591256401312
                    }
                ]
            }
        ],
        "deployment_app": "node-v51-state1-app",
        "package_bucket": "tisco.alpha.composer.state1",
        "service_role_arn": "arn:aws:iam::935529356946:role/Alpha-CodeDeploy-Service-Role",
        "package_name_prefix": "mbs/deployment"
    },
}

next_deploy_spec = {
    'config': {
        "notification": {
            "recipients": [
                "tanasit@tisco.co.th"
            ],
            "carbon_copy": [
                "tanasit@tisco.co.th"
            ],
            "template_id": "xxxx",
            "blind_carbon_copy": [
                "tanasit@tisco.co.th"
            ],
            "warning_threshold": 50,
            "critical_threshold": 20
        },
        "load_balances": [
            {
                "url": "https://node-v7-state2-lb01.c1-alpha-tiscogroup.com",
                "name": "node-v7-state2-lb01",
                "nodes": [
                    {
                        "name": "node-v7-state2-lb01-tg1",
                        "port": "80",
                        "context_path": "tg1",
                        "limit_instance": 120,
                        "create_datetime": 1592970280481
                    }
                ]
            }
        ],
        "deployment_app": "node-v7-state2-app",
        "package_bucket": "tisco.alpha.composer.state2",
        "service_role_arn": "arn:aws:iam::935529356946:role/Alpha-CodeDeploy-Service-Role",
        "package_name_prefix": "mbs/deployment"
    }
}

env_var = {
    "config": {

    },
}
