import requests
from requests.auth import HTTPBasicAuth
from django.conf import settings
from django.http import JsonResponse

from apps.commons.error.exception import ExternalServerErrorException


def generate_json_endpoint():  # not used
    data = {
        'data': [{
            'client_id': settings.OKTA_CLIENT_ID,
            'redirect_uri': settings.OKTA_REDIRECT_URI,
            'response_type': settings.OKTA_RESPONSE_TYPE,
            'state': settings.OKTA_STATE,
            'nonce': settings.NONCE,
            'scope': settings.OKTA_SCOPE
        }]
    }
    return JsonResponse(data)


def generate_authen_endpoint():
    query_string_in_list_format = [
        'client_id=' + settings.OKTA_CLIENT_ID,
        'redirect_uri=' + settings.OKTA_REDIRECT_URI,
        'response_type=' + settings.OKTA_RESPONSE_TYPE,
        'state=' + settings.OKTA_STATE,
        'nonce=' + settings.NONCE,
        'scope=' + settings.OKTA_SCOPE
    ]

    authen_endpoint = settings.OKTA_SERVICE_ENDPOINT + '/oauth2/default/v1/authorize?' + '&'.join(query_string_in_list_format)
    return authen_endpoint


def verify_okta_token(token):
    """
    token : this is from okta
    :return:
    """
    endpoint = settings.OKTA_SERVICE_ENDPOINT + '/oauth2/default/v1/token'
    body = {
        'grant_type': 'authorization_code',
        'redirect_uri': settings.OKTA_REDIRECT_URI,  # 'http://localhost:3200/verifycode'
        'client_id': settings.OKTA_CLIENT_ID,  # '0oaajfqpqu9kYwL971t7'
        'client_secret': settings.OKTA_CLIENT_SECRET,  # 'NshhQRqkWihYBIGyk3mCtzvb_i1tcW68YxwAP1Q7'
        'code': token
    }

    try:
        response = requests.post(endpoint, data=body, verify=not settings.IS_LOCAL)
        if response.status_code != 200:
            raise Exception('OKTA Service Error (status code - {})'.format(response.status_code))

        try:
            response = response.json()
        except Exception:
            response = response.text
            raise Exception('OKTA Service Error (response - {})'.format(response))

    except Exception as e:
        raise ExternalServerErrorException(str(e))
        
    return response


def refresh_token(token):
    endpoint = settings.IDENTITY_SERVICE_ENDPOINT + '/refreshToken'
    body = {
        'data': {
            'grant_type': 'refresh_token',
            'refresh_token': token,
        }
    }

    # :success response
    # {
    #     "data": {
    #         "token_type": "Bearer",
    #         "id_token": "XXXXXXX",
    #         "expires_in": 3600,
    #         "access_token": "XXXXX",
    #         "refresh_token": "XXXXXX"
    #     },
    #     "meta": {
    #         "response_desc": "Success",
    #         "response_ref": "x-x-x-x-x",
    #         "response_code": "20000",
    #         "response_datetime": "07-05-2020 02:37:52"
    #     }
    # }

    try:
        response = requests.post(endpoint, json=body, auth=HTTPBasicAuth(settings.OKTA_CLIENT_ID, settings.OKTA_CLIENT_SECRET), verify=not(settings.IS_LOCAL))
        if response.status_code != 200:
            raise Exception('Identity Service Error (status code - {})'.format(response.status_code))

        try:
            response = response.json()

            response_meta = response.get('meta') or dict()
            if response_meta.get('response_code') != '20000':
                raise Exception('Identity Service Error ({} - {})'.format(response_meta.get('response_code'), response_meta.get('response_desc')))
        
        except Exception:
            response = response.text
            raise Exception('Identity Service Error (response - {})'.format(response))

    except Exception as e:
        raise ExternalServerErrorException(str(e))
        
    return response['data']
