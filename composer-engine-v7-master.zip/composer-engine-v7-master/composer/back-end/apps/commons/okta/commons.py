from datetime import datetime
import uuid

from django.conf import settings
from rest_framework.utils import json


def generate_tisco_service_header(log_session_id=None):
    log_session_id = log_session_id or uuid.uuid4()
    app_meta = {
            'user_id': settings.USER_ID_AG,
            'user_name': settings.USER_NAME_AG,
            'request_date_time': str(datetime.now()),
            'log_session_id': str(log_session_id)
        }
    if settings.MODE == 'beta':
        app_meta.update(sub_state='state3')
    header = {
        'Content-Type': 'application/json',
        'client_id': settings.CLIENT_ID_MULE,
        'client_secret': settings.CLIENT_SECRET_MULE,
        'app-meta': json.dumps(app_meta)
    }
    return header
