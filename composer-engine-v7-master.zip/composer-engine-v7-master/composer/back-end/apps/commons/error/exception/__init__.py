import traceback

from rest_framework.exceptions import APIException
from apps.commons.error.exception import error_code


class StandardException(Exception):
    error_code = error_code.DEFAULT
    error_message = "Something is wrong"

    def __init__(self, message=None, code=None):
        if code:
            self.error_code = code
        if message:
            self.error_message = message
        super().__init__(self.error_message)

    def __getattr__(self, item):
        if item == 'error_stack':
            return traceback.extract_stack()

class AuthorizationError(StandardException):
    error_message = "Unauthorized"
    error_code = error_code.UNAUTHORIZED


class InvalidAppCodeError(StandardException):
    error_message = "Invalid application code"
    error_code = error_code.INVALID_APP_CODE


class PermissionDeniedError(StandardException):
    error_message = "Permission denied"
    error_code = error_code.PERMISSION_DENIED


class LoginFailedException(Exception):
    error_code = '10001'
    error_message = 'Login failed'


class UnAuthorizedException(Exception):
    error_code = '10002'
    error_message = 'UnAuthorized'


class InvalidAppCodeException(Exception):
    error_code = '10001'
    error_message = 'Invalid Application Code'


class ExternalServerErrorException(Exception):
    error_code = '30001'
    error_message = 'External server error'


class BadRequestException(Exception):
    error_code = '40002'
    error_message = 'Bad request'


class ConfigurationErrorException(Exception):
    error_code = '40003'
    error_message = 'Configuration error'


class ActionUnAuthorizedException(Exception):
    error_code = '40004'
    error_message = 'Action unauthorized'
