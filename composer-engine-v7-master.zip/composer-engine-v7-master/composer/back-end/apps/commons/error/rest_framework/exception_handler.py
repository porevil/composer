import uuid
import traceback

from datetime import datetime

from django.http.response import JsonResponse
from rest_framework.views import exception_handler as base_exception_handler

from apps.commons.error.exception import StandardException
from apps.commons.utilities.log import Logger
from apps.commons.utilities.response import get_error_response
from apps.commons.utilities.log import Logger

def exception_handler(exc: Exception, context):
    logger = Logger("Exception Handler")
    response = get_error_response(exc, ref=context['request'].session_id, filename=str(context['view']))
    logger.error(f"Error Response {response}")
    return JsonResponse(data=response)
