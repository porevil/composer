import json
import re
import traceback
import uuid

from datetime import datetime
from django.db import transaction

from apps.commons.connectors.metadata import Metadata
from apps.commons.utilities.log import Logger
from apps.commons.generator.constants import GeneratingType, InstanceRole, Activity
from apps.routines.models import Routine, ActivityConfiguration, RoutineTags
from apps.metadata.models import Dataset
from apps.rules.models import TemplateRule
from apps.generator_setting.models import VirtualGroup
from apps.commons.generator.configuration.pre_defined_single_dataset import PreDefinedSingleDatasetActivities
from apps.commons.generator.configuration.pre_defined_multiple_dataset import PreDefinedMultipleDatasetActivities
from apps.commons.generator.configuration.user_defined import UserDefinedActivities


class ConfigurationManager:
    LOGGER = Logger('Configuration Manager')

    def __init__(self, reference_id=None):
        try:
            self.dataset_cache = dict()
            self.reference_id = reference_id or uuid.uuid4()
        except Exception as e:
            ConfigurationManager.LOGGER.error('initial exception: {}'.format(str(e)))
            raise e


    def generate(self, standard_process, dataset_name, generating_type, generating_tag=None, additional_config=dict(), executed_by=None):
        try:
            ConfigurationManager.LOGGER.debug(
                'Generate Routine [reference id = {}] standard process id = {}, dataset name = {}' \
                .format(self.reference_id, standard_process.id, dataset_name))

            virtual_name = dataset_name

            if generating_type == GeneratingType.PreDefinedMultipleDataset.value:
                virtual_group = VirtualGroup.objects.filter(name=dataset_name).first()
                dataset_name = virtual_group.main_dataset_name

            dataset_repository = Dataset.objects.filter(dataset_name=dataset_name).first()
            if dataset_repository is None:
                raise Exception('dataset name - {} not found in dataset'.format(dataset_name))

            dataset_repository_version = dataset_repository.version            

            # Get dataset metadata
            dataset_metadata = self._get_dataset_metadata(dataset_name)
            dataset_version = dataset_metadata.get('version')
            dataset_description = dataset_metadata.get('description')
            datalist_name = dataset_metadata.get('datalist_name')

            if datalist_name is None or datalist_name == '':
                raise Exception('datalist name not found')
            if dataset_repository_version != dataset_version:
                raise Exception('dataset model is old version ({} - {}), please refresh'.format(dataset_version, dataset_repository_version))

            if generating_type == GeneratingType.PreDefinedMultipleDataset.value:
                routine_code = '{}_{}'.format(standard_process.code, virtual_name)
                routine_name = virtual_group.description
                routine_description = '{} {}'.format(standard_process.name, routine_name)

            else:
                routine_code = '{}_{}'.format(standard_process.code, datalist_name)
                routine_name = dataset_description

                if generating_type == GeneratingType.UserDefined.value:
                    routine_code = '{}_{}'.format(routine_code, dataset_name)

                routine_name_prefix = standard_process.name
                if routine_name_prefix is not None and routine_name_prefix != '':
                    routine_name = '{} {}'.format(routine_name_prefix, routine_name)
                routine_description = routine_name

            ConfigurationManager.LOGGER.debug('Generate Routine [reference id = {}] routine code = {}, name = {}' \
                                            .format(self.reference_id, routine_code, routine_name))

            # Generate configuration
            common_configuration, activities_configuration = self.generate_configuration(standard_process, \
                                                                                        virtual_name, \
                                                                                        generating_type, \
                                                                                        additional_config)

            if generating_type == GeneratingType.PreDefinedMultipleDataset.value:
                common_configuration['virtual_name'] = virtual_name 
                
            # Get generating tag
            if generating_tag is None:
                generating_tag = RoutineTags.next()

            # Create or Update routine, document narrative, activity configuration
            with transaction.atomic():
                # routine
                routine_data = {
                    'code': routine_code,
                    'name': routine_name,
                    'description': routine_description,
                    'dataset_version': dataset_version,
                    'data': common_configuration,
                    'template': standard_process.template,
                    'generating_type': generating_type,
                    'generating_tag': generating_tag,
                    'adjusted': False,
                    'build_with_generating_tag': False,
                }

                routine, created = Routine.objects.update_or_create(
                    dataset_name=virtual_name,
                    generating_type=generating_type,
                    standard_process=standard_process,
                    defaults=routine_data)

                ConfigurationManager.LOGGER.debug('Generate Routine [reference id = {}] create routine success' \
                                                  .format(self.reference_id))

                for activity in Activity:
                    activity_data = activities_configuration.get(activity.value) or dict()
                    ActivityConfiguration.objects.update_or_create(routine=routine, activity=activity.value, defaults={
                        'data': activity_data,
                    })

                    ConfigurationManager.LOGGER.debug(
                        'Generate Routine [reference id = {}] create activity = {} success' \
                        .format(self.reference_id, activity.value))

            ConfigurationManager.LOGGER.debug('Generate Routine [reference id = {}] success, Code = {}, UUID = {}' \
                                              .format(self.reference_id, routine.code, str(routine.uuid)))

            return routine

        except Exception as e:
            ConfigurationManager.LOGGER.error(
                'Generate Routine [reference id = {}] exception: {}'.format(self.reference_id, str(e)))
            traceback.print_exc()
            raise e


    def _get_dataset_metadata(self, dataset_name):
        try:
            if self.dataset_cache.get(dataset_name) is None:
                self.dataset_cache[dataset_name] = Metadata.get(None, dataset_name)
            return self.dataset_cache.get(dataset_name)
        except Exception as e:
            ConfigurationManager.LOGGER.error('get dataset metadata | exception: {}'.format(str(e)))
            raise e

    def generate_configuration(self, standard_process, dataset_name, generating_type, additional_config=dict()):
        try:
            virtual_name = dataset_name
            standard_process_code = standard_process.code

            if generating_type == GeneratingType.PreDefinedMultipleDataset.value:
                virtual_group = VirtualGroup.objects.filter(name=dataset_name).first()
                dataset_name = virtual_group.main_dataset_name

            # Get dataset metadata
            dataset_metadata = self._get_dataset_metadata(dataset_name)

            ConfigurationManager.LOGGER.debug(
                'Generate configuration [reference id = {}] standard process: {}'.format(self.reference_id,
                                                                                         standard_process_code))
            ConfigurationManager.LOGGER.debug(
                'Generate configuration [reference id = {}] dataset name: {}'.format(self.reference_id, virtual_name))
            ConfigurationManager.LOGGER.debug(
                'Generate configuration [reference id = {}] generating type: {}'.format(self.reference_id,
                                                                                        generating_type))

            # Generate common configuration
            dataset_description = dataset_metadata['description'] if generating_type != GeneratingType.PreDefinedMultipleDataset.value else dataset_metadata['description'] + ' แบบ multiple dataset'
            common_configuration = {
                'dataset': {
                    'dataset_name': dataset_metadata['dataset_name'],
                    'description':  dataset_description,
                    'haveJournal': dataset_metadata['journal'],
                    'table_type': dataset_metadata['table_type'],
                    'group_type': dataset_metadata['group_type'],
                    'dataset_type': dataset_metadata.get('dataset_type') or '',
                    'journal': {
                        'key': 1,
                        'desc': 'Present',
                    }
                },
                'template_attributes': self._template_predict(generating_type, standard_process_code,
                                                              dataset_name) or dict(),
            }

            # Generate activity configuration
            activities_configuration, additional_configuration = self._get_activities_configuration(standard_process,
                                                                                                    virtual_name,
                                                                                                    generating_type,
                                                                                                    additional_config)

            common_configuration.update(additional_configuration)

            return common_configuration, activities_configuration

        except Exception as e:
            ConfigurationManager.LOGGER.error(
                'Generate configuration [reference id = {}] exception: {}'.format(self.reference_id, str(e)))
            raise e

    def _get_activities_configuration(self, standard_process, dataset_name, generating_type, additional_config=dict()):
        try:
            if generating_type == GeneratingType.PreDefinedSingleDataset.value:
                return PreDefinedSingleDatasetActivities(standard_process, generating_type, dataset_name, self.reference_id).generate(
                    additional_config)

            elif generating_type == GeneratingType.PreDefinedMultipleDataset.value:
                return PreDefinedMultipleDatasetActivities(standard_process, generating_type, dataset_name, self.reference_id).generate(
                additional_config)

            elif generating_type == GeneratingType.UserDefined.value:
                return UserDefinedActivities(standard_process, generating_type, dataset_name, self.reference_id).generate(
                    additional_config)
            
            else:
                raise Exception('Generating type invalid ({})'.format(generating_type))
        except Exception as e:
            ConfigurationManager.LOGGER.error(
                'get activities configuration [reference id = {}] exception: {}'.format(self.reference_id, str(e)))
            raise e


    def _template_predict(self, generating_type, standard_process_code, dataset_name):
        try:
            # set up rule configuration
            decision_model = dict()
            template_rules = TemplateRule.objects.all()
            for template_rule in template_rules:
                template_rule_generating_type = template_rule.generating_type or 'default'
                template_rule_standard_process_code = template_rule.standard_process_code or 'default'
                template_rule_dataset_name = template_rule.dataset_name or 'default'
                template_rule_attributes = template_rule.attributes

                if template_rule_generating_type not in decision_model:
                    decision_model[template_rule_generating_type] = dict()

                if template_rule_standard_process_code not in decision_model[template_rule_generating_type]:
                    decision_model[template_rule_generating_type][template_rule_standard_process_code] = dict()

                decision_model[template_rule_generating_type][template_rule_standard_process_code][template_rule_dataset_name] = template_rule_attributes

            # decision
            generating_type = str(generating_type) if generating_type is not None else None
            output = None

            try:
                if generating_type in decision_model and standard_process_code in decision_model[generating_type] \
                        and dataset_name in decision_model[generating_type][standard_process_code]:
                    output = decision_model[generating_type][standard_process_code][dataset_name]

                elif generating_type in decision_model and standard_process_code in decision_model[generating_type] \
                        and 'default' in decision_model[generating_type][standard_process_code]:
                    output = decision_model[generating_type][standard_process_code]['default']

                elif generating_type in decision_model and 'default' in decision_model[generating_type] \
                        and dataset_name in decision_model[generating_type][standard_process_code]:
                    output = decision_model[generating_type]['default'][dataset_name]

                elif 'default' in decision_model and standard_process_code in decision_model[generating_type] \
                        and dataset_name in decision_model[generating_type][standard_process_code]:
                    output = decision_model['default'][standard_process_code][dataset_name]

                elif generating_type in decision_model and 'default' in decision_model[generating_type] \
                        and 'default' in decision_model[generating_type][standard_process_code]:
                    output = decision_model[generating_type]['default']['default']

                elif 'default' in decision_model and standard_process_code in decision_model[generating_type] \
                        and 'default' in decision_model[generating_type][standard_process_code]:
                    output = decision_model['default'][standard_process_code]['default']

                elif 'default' in decision_model and 'default' in decision_model[generating_type] \
                        and dataset_name in decision_model[generating_type][standard_process_code]:
                    output = decision_model['default']['default'][dataset_name]

                elif 'default' in decision_model and 'default' in decision_model[generating_type] \
                        and 'default' in decision_model[generating_type][standard_process_code]:
                    output = decision_model['default']['default']['default']

                if output is None:
                    raise Exception('Not found')

                return output
            except:
                return None

        except Exception as e:
            ConfigurationManager.LOGGER.error('template predict | exception: {}'.format(str(e)))
            raise e


    def get_activities_configuration(self, routine_uuid):
        try:
            ConfigurationManager.LOGGER.debug('Get Activity Configuration [reference id = {}] uuid = {}' \
                                              .format(self.reference_id, routine_uuid))

            result = dict()
            routine = Routine.objects.filter(uuid=routine_uuid).first()
            routine_data = routine.data

            # env in front
            # result['template_attributes'] = routine_data.get('template_attributes') or dict()

            # constants in back
            # result['dataset_information'] = routine_data.get('datasets') or list()
            # result['additional_attributes'] = routine_data.get('additional_attributes') or dict()
            result['activities'] = dict()

            activities = ActivityConfiguration.objects.filter(routine=routine)
            for activity in activities:
                result['activities'][activity.activity] = dict()
                result['activities'][activity.activity]['sections'] = list()

                activity_sections = activity.data.get('sections') or list()
                for activity_section in activity_sections:
                    fields = activity_section.get('fields') or list()
                    if activity.activity == 'search' and activity_section['type'] == 'data':
                        fields = self._create_component(fields, True)
                    else:
                        fields = self._create_component(fields)

                    data = {
                        'section_type': activity_section.get('type'),
                        'section_name': activity_section.get('section_name'),
                        'fields': fields,
                    }
                    result['activities'][activity.activity]['sections'].append(data)

            return result

        except Exception as e:
            raise e

    def _create_component(self, fields, search_data_section=False):
        try:
            component = list()
            element = list()
            is_field_set = False

            for field in fields:
                if field.get('enable') == False:
                    continue

                if field.get('meta_type') in ['master', 'dummy']:
                    component_attribues = dict()
                    attributes = field.get('component', dict()).get('attributes') or list()
                    for attribute in attributes:
                        component_attribues[attribute.get('code')] = attribute.get('value') or ''

                    element.append({
                        'field_name': field.get('field_name'),
                        'field_type': field.get('field_type'),
                        'label': field.get('caption_th') or field.get('caption_eng'),
                        'editable': field.get('editable') or False,
                        'mandatory': field.get('mandatory') or False,
                        'component': {
                            'code': field.get('component', dict()).get('code'),
                            'attributes': component_attribues,
                        },
                        'collapse': field.get('collapse') or False,
                    })

                elif field.get('meta_type') == 'enter':
                    if is_field_set == False:
                        component.append(element)
                        element = list()
                    else:
                        component[len(component) - 1][0]['component']['fields'].append(element)
                        element = list()

                elif field.get('meta_type') == 'field_set':
                    is_field_set = True
                    element.append({
                        'field_name': field.get('field_name'),
                        'field_type': field.get('field_type'),
                        'label': field.get('caption_th') or field.get('caption_eng') or field.get('field_name'),
                        'editable': field.get('editable') or False,
                        'mandatory': field.get('mandatory') or False,
                        'component': {
                            'code': 'widget_field_set',
                            'fields': list()
                        },
                        'collapse': field.get('collapse'),
                    })

                    component.append(element)
                    element = list()

                elif field.get('meta_type') == 'multiple':
                    element.append({
                        'field_name': field.get('field_name'),
                        'field_type': field.get('field_type'),
                        'label': field.get('caption_th') or field.get('caption_eng') or field.get('field_name'),
                        'editable': field.get('editable') or False,
                        'mandatory': field.get('mandatory') or False,
                        'component': {
                            'code': 'widget_field_set',
                            'fields': self._create_component(field.get('fields') or list()),
                        },
                        'collapse': field.get('collapse'),
                    })

                    component.append(element)
                    element = list()

            if search_data_section:
                component.append([{
                    'field_name': None,
                    'field_type': 'table',
                    'label': '',
                    'editable': False,
                    'mandatory': False,
                    'component': {
                        'code': 'widget_table',
                        'fields': [element],
                    },
                    'collapse': False,
                }])

            return component

        except Exception as e:
            raise e
