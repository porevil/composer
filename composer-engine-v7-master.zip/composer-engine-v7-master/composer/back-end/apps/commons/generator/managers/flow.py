import json, re
import traceback
import copy

from django.db import transaction

from apps.commons.utilities.log import Logger
from apps.commons.generator.constants import InstanceType
from apps.commons.connectors.launcher_flow import LauncherFlow
from apps.commons.managers.role import RoleManager

from apps.flow.models import Flow, FlowInstance, FlowPackage, FlowRepository
from apps.node_repositories.models import NodeRepository
from apps.service_instance.models import ServiceInstance, ServiceInstanceRepository
from apps.combined_instance.models import CombinedInstanceRepository
from apps.custom_instance.models import CustomInstanceRepository


class FlowManager:
    LOGGER = Logger('Flow Manager')

    def generate_single_instance_flow(self, code, name, description, label, instance_uuid,
                                      instance_type=InstanceType.Common, system_generated=True, **kwargs):
        try:
            FlowManager.LOGGER.debug('Generate Single Instance Flow')
            executed_by = kwargs.get('executed_by')

            with transaction.atomic():
                flow, created = Flow.objects.update_or_create(uuid=instance_uuid, defaults={
                    'code': code,
                    'name': name,
                    'description': description,
                    'label': label,
                    'system_generated': system_generated,
                })

                # if created:
                #     FlowActionLog.log_create(flow, executed_by)

                config_data = {}
                if instance_type == InstanceType.Common:
                    instance = NodeRepository.objects.filter(uuid=instance_uuid, sub_state__is_default=True).first()
                    if instance is None:
                        raise Exception('invalid instance uuid')

                    config_data = {
                        'code': instance.code,
                        'name': instance.name,
                        'version': str(instance.build_no),
                        'label': None,
                        'intent': instance.build_data.get('intent'),
                        'dataset': instance.build_data.get('dataset'),
                        'datafields': instance.build_data.get('datafields'),
                    }
                elif instance_type == InstanceType.Service:
                    raise Exception('unsupport instance type')
                elif instance_type == InstanceType.Combined:
                    raise Exception('unsupport instance type')
                elif instance_type == InstanceType.Custom:
                    raise Exception('unsupport instance type')
                elif instance_type == InstanceType.Virtual:
                    raise Exception('unsupport instance type')
                else:
                    raise Exception('invalid instance type')

                flow_instance = FlowInstance.objects.update_or_create(flow=flow
                                                                      , sequence=1
                                                                      , sub_sequence=1
                                                                      , instance_uuid=instance_uuid
                                                                      , instance_type=instance_type.value
                                                                      , defaults={
                        'config': config_data,
                    })

                return flow

        except Exception as e:
            FlowManager.LOGGER.error('Generate Single Instance Flow | exception: {}'.format(str(e)))
            traceback.print_exc()
            raise e

    def build(self, uuid):
        try:
            FlowManager.LOGGER.debug('Build Flow')
            with transaction.atomic():
                flow = Flow.objects.filter(uuid=uuid).first()
                if flow is None:
                    raise Exception('invalid flow uuid')

                instances = FlowInstance.objects.filter(flow=flow).order_by('sequence', 'sub_sequence')
                build_no = (flow.latest_build_no or 0) + 1

                # create flow package
                build_data = dict()
                build_data['instances'] = list()

                for instance in instances:
                    instance_data = instance.config
                    instance_data.update({
                        'sequence': instance.sequence,
                        'sub_sequence': instance.sub_sequence,
                        'type': instance.instance_type,
                        'uuid': str(instance.instance_uuid),
                    }, )
                    build_data['instances'].append(instance_data)

                package, created = FlowPackage.objects.update_or_create(
                    uuid=uuid,
                    build_no=build_no,
                    defaults={
                        'build_data': build_data,
                    })

                # update flow (latest_build_no, build_with_latest_adjustment)
                flow.latest_build_no = build_no
                flow.build_with_latest_adjustment = True
                flow.save()

                return package

        except Exception as e:
            FlowManager.LOGGER.error('Build Flow | exception: {}'.format(str(e)))
            traceback.print_exc()
            raise e

    def publish(self, flow_uuids, destination_sub_state, **kwargs):
        try:
            FlowManager.LOGGER.debug('Publish Flow')

            console_output = kwargs.get('console_output')
            executed_by = kwargs.get('executed_by')
            authorized_ticket = kwargs.get('authorized_ticket')

            error_list = list()
            total = len(flow_uuids)
            count = 0
            for flow_uuid in flow_uuids:
                error_message = None
                try:
                    with transaction.atomic():
                        flow = Flow.objects.filter(uuid=flow_uuid).first()
                        if flow is None:
                            raise Exception('invalid flow uuid')

                        repository = self.deploy_and_launch(flow_uuid
                                                            , flow.latest_build_no
                                                            , destination_sub_state
                                                            , flow.code
                                                            , flow.name
                                                            , flow.description
                                                            , flow.label
                                                            , flow.system_generated
                                                            , **kwargs)

                except Exception as ie:
                    error_message = str(ie)
                    error_list.append({
                        'uuid': flow_uuid,
                        'message': error_message,
                    })

                finally:
                    count = count + 1
                    if console_output is not None:
                        message = 'success' if error_message is None else error_message
                        code = flow.code if flow is not None else '-'
                        console_output.append('({}/{}) "{}" (code={}) : {}' \
                                              .format(count, total, flow_uuid, code, message))

            success_all = (len(error_list) == 0)
            return success_all, error_list

        except Exception as e:
            FlowManager.LOGGER.error('Publish Flow | exception: {}'.format(str(e)))
            traceback.print_exc()
            raise e

    def build_and_publish(self, flow_uuids, destination_sub_state, **kwargs):
        try:
            FlowManager.LOGGER.debug('Build and Publish Flow')

            console_output = kwargs.get('console_output')
            executed_by = kwargs.get('executed_by')
            authorized_ticket = kwargs.get('authorized_ticket')

            error_list = list()
            total = len(flow_uuids)
            count = 0
            for flow_uuid in flow_uuids:
                error_message = None
                try:
                    with transaction.atomic():
                        flow = Flow.objects.filter(uuid=flow_uuid).first()
                        if flow is None:
                            raise Exception('invalid flow uuid')

                        self.build(flow_uuid)
                        success_all, error_list = self.publish([flow_uuid], destination_sub_state)

                except Exception as ie:
                    error_message = str(ie)
                    error_list.append({
                        'uuid': flow_uuid,
                        'message': error_message,
                    })

                finally:
                    count = count + 1
                    if console_output is not None:
                        message = 'success' if error_message is None else error_message
                        code = flow.code if flow is not None else '-'
                        console_output.append('({}/{}) "{}" (code={}) : {}' \
                                              .format(count, total, flow_uuid, code, message))

            success_all = (len(error_list) == 0)
            return success_all, error_list

        except Exception as e:
            FlowManager.LOGGER.error('Build and Publish Flow | exception: {}'.format(str(e)))
            traceback.print_exc()
            raise e

    def republish(self, flow_uuids, destination_sub_state, **kwargs):
        try:
            FlowManager.LOGGER.debug('Republish Flow')

            console_output = kwargs.get('console_output')
            executed_by = kwargs.get('executed_by')
            authorized_ticket = kwargs.get('authorized_ticket')

            error_list = list()
            total = len(flow_uuids)
            count = 0
            for flow_uuid in flow_uuids:
                error_message = None
                try:
                    with transaction.atomic():
                        repository = FlowRepository.objects.filter(uuid=flow_uuid,
                                                                   sub_state=destination_sub_state).first()
                        if repository is None:
                            raise Exception('invalid flow uuid')

                        repository = self.deploy_and_launch(flow_uuid
                                                            , repository.build_no
                                                            , destination_sub_state
                                                            , repository.code
                                                            , repository.name
                                                            , repository.description
                                                            , repository.label
                                                            , repository.flow.system_generated
                                                            , **kwargs)

                except Exception as ie:
                    error_message = str(ie)
                    error_list.append({
                        'uuid': flow_uuid,
                        'message': error_message,
                    })

                finally:
                    count = count + 1
                    if console_output is not None:
                        message = 'success' if error_message is None else error_message
                        code = repository.code if repository is not None else '-'
                        console_output.append('({}/{}) "{}" (code={}) : {}' \
                                              .format(count, total, flow_uuid, code, message))

            success_all = (len(error_list) == 0)
            return success_all, error_list

        except Exception as e:
            FlowManager.LOGGER.error('Republish Flow | exception: {}'.format(str(e)))
            traceback.print_exc()
            raise e

    def move(self, flow_uuids, source_sub_state, destination_sub_state, **kwargs):
        try:
            FlowManager.LOGGER.debug('Move Flow')

            console_output = kwargs.get('console_output')
            executed_by = kwargs.get('executed_by')
            authorized_ticket = kwargs.get('authorized_ticket')

            error_list = list()
            total = len(flow_uuids)
            count = 0
            for flow_uuid in flow_uuids:
                error_message = None
                try:
                    with transaction.atomic():
                        source_repository = FlowRepository.objects.filter(uuid=flow_uuid,
                                                                          sub_state=source_sub_state).first()
                        if source_repository is None:
                            raise Exception('invalid flow uuid')

                        destination_repository = self.deploy_and_launch(flow_uuid
                                                                        , source_repository.build_no
                                                                        , destination_sub_state
                                                                        , source_repository.code
                                                                        , source_repository.name
                                                                        , source_repository.description
                                                                        , source_repository.label
                                                                        , source_repository.flow.system_generated
                                                                        , **kwargs)

                except Exception as ie:
                    error_message = str(ie)
                    error_list.append({
                        'uuid': flow_uuid,
                        'message': error_message,
                    })

                finally:
                    count = count + 1
                    if console_output is not None:
                        message = 'success' if error_message is None else error_message
                        code = source_repository.code if source_repository is not None else '-'
                        console_output.append('({}/{}) "{}" (code={}) : {}' \
                                              .format(count, total, flow_uuid, code, message))

            success_all = (len(error_list) == 0)
            return success_all, error_list

        except Exception as e:
            FlowManager.LOGGER.error('Move Flow | exception: {}'.format(str(e)))
            traceback.print_exc()
            raise e

    def remove(self, flow_uuids, destination_sub_state, **kwargs):
        try:
            FlowManager.LOGGER.debug('Remove Flow')
            console_output = kwargs.get('console_output')
            executed_by = kwargs.get('executed_by')
            authorized_ticket = kwargs.get('authorized_ticket')

            error_list = list()
            total = len(flow_uuids)
            count = 0
            for flow_uuid in flow_uuids:
                error_message = None
                try:
                    with transaction.atomic():
                        # R1 check flow in procedure

                        repository = FlowRepository.objects.filter(uuid=flow_uuid,
                                                                   sub_state=destination_sub_state).first()
                        if repository is None:
                            raise Exception('invalid flow uuid')

                        repository.delete()

                        # flow action log (publish)
                        # FlowActionLog.log_displace(repository.flow
                        #                             , destination_sub_state
                        #                             , authorized_ticket
                        #                             , executed_by)

                        # deregister flow from Launcher
                        response = LauncherFlow.list(destination_sub_state, **{
                            'uuid': flow_uuid,
                        })

                        launcher_flows = response['data']

                        if len(launcher_flows) > 0:
                            LauncherFlow.delete(destination_sub_state, flow_uuid)

                except Exception as ie:
                    error_message = str(ie)
                    error_list.append({
                        'uuid': flow_uuid,
                        'message': error_message,
                    })

                finally:
                    count = count + 1
                    if console_output is not None:
                        message = 'success' if error_message is None else error_message
                        code = repository.code if repository is not None else '-'
                        console_output.append('({}/{}) "{}" (code={}) : {}' \
                                              .format(count, total, flow_uuid, code, message))

            success_all = (len(error_list) == 0)
            return success_all, error_list

        except Exception as e:
            FlowManager.LOGGER.error('Remove Flow | exception: {}'.format(str(e)))
            traceback.print_exc()
            raise e

    def purge(self, flow_uuids, **kwargs):
        try:
            FlowManager.LOGGER.debug('Purge Flow')

            console_output = kwargs.get('console_output')
            executed_by = kwargs.get('executed_by')
            authorized_ticket = kwargs.get('authorized_ticket')

            error_list = list()
            total = len(flow_uuids)
            count = 0
            for flow_uuid in flow_uuids:
                error_message = None
                try:
                    with transaction.atomic():
                        flow = Flow.objects.filter(uuid=flow_uuid).first()
                        if flow is None:
                            raise Exception('invalid flow uuid')

                        repositories = FlowRepository.objects.filter(uuid=flow_uuid)
                        if len(repositories) > 0:
                            raise Exception('this flow is still in use, cannot purge')

                        FlowInstance.objects.filter(flow=flow).delete()
                        FlowPackage.objects.filter(uuid=flow_uuid).delete()
                        # FlowActionLog.objects.filter(flow=flow).delete()
                        flow.delete()

                except Exception as ie:
                    error_message = str(ie)
                    error_list.append({
                        'uuid': flow_uuid,
                        'message': error_message,
                    })

                finally:
                    count = count + 1
                    if console_output is not None:
                        message = 'success' if error_message is None else error_message
                        code = repositories.code if repositories is not None else '-'
                        console_output.append('({}/{}) "{}" (code={}) : {}' \
                                              .format(count, total, flow_uuid, code, message))

            success_all = (len(error_list) == 0)
            return success_all, error_list

        except Exception as e:
            FlowManager.LOGGER.error('Purge Flow | exception: {}'.format(str(e)))
            traceback.print_exc()
            raise e

    def deploy_and_launch(self, uuid, build_no, destination_sub_state, code=None, name=None, description=None,
                          label=None, system_generated=False, **kwargs):
        try:
            FlowManager.LOGGER.debug('Deploy and Launch Flow')
            executed_by = kwargs.get('executed_by')
            authorized_ticket = kwargs.get('authorized_ticket')

            with transaction.atomic():
                flow = Flow.objects.filter(uuid=uuid).first()
                if flow is None:
                    raise Exception('invalid flow uuid')

                package = FlowPackage.objects.filter(uuid=uuid, build_no=build_no).first()
                if package is None:
                    raise Exception('build package not found')

                package_build_data = package.build_data

                # create or update flow repository
                code = code or flow.code
                name = name or flow.name

                instances = package_build_data.get('instances') or list()
                instance_uuids = set()
                for instance in instances:
                    instance_uuids.add(instance.get('uuid'))
                    if instance.get('base_instance_uuid'):
                        instance_uuids.add(instance.get('base_instance_uuid'))

                role = dict()
                if not system_generated:
                    repository = FlowRepository.objects.filter(uuid=uuid, sub_state=destination_sub_state).first()
                    if repository is None or not repository.role or repository.code != code:
                        role_code = '{}_access'.format(code)
                        role_name = 'access flow {}'.format(code)
                        role_description = 'access flow {} ({})'.format(code, name)
                        role = RoleManager().create_flow_authorization(role_code, role_name, role_description,
                                                                       destination_sub_state)
                    else:
                        role = repository.role

                repository_data = {
                    'code': code,
                    'name': name,
                    'description': description,
                    'label': label,
                    'role': role,
                    'instance_uuids': list(instance_uuids),
                    'build_no': build_no,
                    'flow': flow,
                }

                repository, created = FlowRepository.objects.update_or_create(
                    uuid=uuid,
                    sub_state=destination_sub_state,
                    defaults=repository_data)

                # prepare flow data to register to Launcher (package build data + environment variable (url))
                flow_config = copy.deepcopy(package_build_data)
                flow_config_instances = flow_config.pop('instances')

                nodes = list()
                _node_sequence = list()
                for instance in flow_config_instances or list():
                    instance_type = instance.get('type')
                    instance_uuid = instance.get('uuid')
                    instance_code = instance.get('code')
                    instance_label = instance.get('label')

                    del instance['type']
                    del instance['label']

                    instance['display_label'] = instance_label

                    # R2 for support virtual
                    if instance_type == InstanceType.Common.value:
                        instance_repository = NodeRepository.objects.filter(uuid=instance_uuid
                                                                            , sub_state=destination_sub_state).first()
                        if instance_repository is None:
                            raise Exception('there is no common instance "{}" (code={}) on sub state "{}"' \
                                            .format(instance_uuid, instance_code, destination_sub_state.name))
                        instance['url'] = instance_repository.url
                        instance['instance_type'] = 'common'

                    elif instance_type == InstanceType.Custom.value:
                        instance_repository = CustomInstanceRepository.objects.filter(uuid=instance_uuid
                                                                                        , sub_state=destination_sub_state).first()
                        if instance_repository is None:
                            raise Exception('there is no custom instance "{}" (code={}) on sub state "{}"' \
                                                .format(instance_uuid, instance_code, destination_sub_state.name))
                        instance['url'] = instance_repository.url
                        instance['type'] = 'screen'
                        instance['custom'] = True

                    elif instance_type == InstanceType.Service.value:
                        instance_repository = ServiceInstanceRepository.objects.filter(service_instance__uuid=instance_uuid
                                                                                        , sub_state=destination_sub_state).first()
                        if instance_repository is None:
                            raise Exception('there is no service instance "{}" (code={}) on sub state "{}"' \
                                                .format(instance_uuid, instance_code, destination_sub_state.name))
                        instance['url'] = instance_repository.service_endpoint
                        instance['type'] = 'service'
                        if 'tracking' in instance: # case: 'async/json' 
                            instance['tracking']['url'] = instance_repository.tracking_endpoint

                    elif instance_type == InstanceType.Combined.value:
                        base_instance_uuid = instance.get('base_instance_uuid')
                        base_instance_code = instance.get('base_instance_code')
                        instance_repository = NodeRepository.objects.filter(uuid=base_instance_uuid
                                                                            , sub_state=destination_sub_state).first()
                        if instance_repository is None:
                            raise Exception('there is no combined base instance "{}" (code={}) on sub state "{}"' \
                                                .format(base_instance_uuid, base_instance_code, destination_sub_state.name))
                        instance['url'] = instance_repository.url
                        instance['type'] = 'screen'

                        for pre_submit_service in (instance.get('pre_submit_services') or list()):
                            service_uuid = pre_submit_service.get('uuid')
                            service_code = pre_submit_service.get('code')
                            service_repository = ServiceInstanceRepository.objects.filter(service_instance__uuid=service_uuid
                                                                                            , sub_state=destination_sub_state).first()
                            if service_repository is None:
                                raise Exception('there is no pre-submit service instance "{}" (code={}) on sub state "{}"' \
                                                    .format(service_uuid, service_code, destination_sub_state.name))
                            pre_submit_service['url'] = service_repository.service_endpoint

                    else:
                        raise Exception('not support instance_type - {}'.format(instance_type))

                    # construct nodes
                    instance_sequence = instance.get('sequence')
                    instance['sequence'] = instance.pop('sub_sequence') or 1

                    if instance_sequence not in _node_sequence:
                        node_data = dict()
                        node_data['sequence'] = instance_sequence
                        node_data['instances'] = [instance]
                        nodes.append(node_data)

                    else:
                        for node in nodes:
                            if instance_sequence == node.get('sequence'):
                                node['instances'].append(instance)
                                break

                    _node_sequence.append(instance_sequence)

                flow_config.update({
                    'nodes': nodes,
                    'role_id': role.get('id'),
                    'role_group_code': role.get('group_code'),
                }, )

                # flow action log (publish)
                # FlowActionLog.log_publish(flow
                #                             , build_no
                #                             , destination_sub_state
                #                             , authorized_ticket
                #                             , executed_by)

                # register flow to Launcher
                LauncherFlow.create_or_update(destination_sub_state
                                              , uuid
                                              , code=code
                                              , name=name
                                              , display_label=label
                                              , system_data=system_generated
                                              , config=flow_config)

                return repository

        except Exception as e:
            FlowManager.LOGGER.error('Deploy and Launch Flow | exception: {}'.format(str(e)))
            traceback.print_exc()
            raise e
