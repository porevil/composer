import json
import uuid

from django.db import transaction
from django.conf import settings

from apps.commons.generator.builder.common_instance import CommonInstanceBuilder as Builder
from apps.commons.generator.publisher.common_instance import CommonInstancePublisher as Publisher
from apps.commons.connectors.launcher_procedure import LauncherProcedure
from apps.commons.connectors.launcher_application import LauncherApplication
from apps.commons.notification.mailer import DeploymentMailer
from apps.commons.utilities.log import Logger
from apps.commons.generator.managers.flow import FlowManager
from apps.commons.utilities.s3utils import s3_clean_package

from apps.routines.models import Routine, LotRoutine, ActivityConfiguration
from apps.flow.models import Flow, FlowInstance, FlowPackage, FlowRepository
from apps.node_repositories.models import NodeRepository
from apps.standard_process.models import TemplateEnvironmentVariable
from apps.combined_instance.models import CombinedInstance


class CommonInstanceManager:
    LOGGER = Logger('Common Instance Manager')

    def _get_instance_name(self, instance_uuid):
        return instance_uuid

    # TODO: add remove non use package from s3
    def build_and_publish(self, instance_uuids, destination_sub_state, **kwargs):
        try:
            CommonInstanceManager.LOGGER.debug('Build and Publish Common Instance')
            console_output = kwargs.get('console_output')
            executed_by = kwargs.get('executed_by')
            authorized_ticket = kwargs.get('authorized_ticket')

            builder = Builder()
            error_list = list()
            total = len(instance_uuids)
            count = 0

            for instance_uuid in instance_uuids:
                error_message = None
                try:
                    with transaction.atomic():
                        routine = Routine.objects.filter(uuid=instance_uuid).first()
                        if routine is None:
                            raise Exception('invalid instance uuid')

                        instance_name = self._get_instance_name(instance_uuid)
                        instance_tag = (routine.latest_build_no or 0) + 1

                        # wait build step
                        builder.build(instance_name, instance_tag, routine)
                        routine.latest_build_no = instance_tag
                        routine.build_with_generating_tag = True
                        routine.save()

                        # instance action log (publish)
                        # RoutineActionLog.log_publish(instance
                        #                             , instance.latest_build_no
                        #                             , destination_sub_state
                        #                             , authorized_ticket
                        #                             , executed_by)
                        # wait build step
                        publisher = Publisher(destination_sub_state)
                        # publish = None
                        instance_repository = self._publish(publisher,
                                                            instance_uuid,
                                                            destination_sub_state,
                                                            routine.latest_build_no, {
                                                                'code': routine.code,
                                                                'name': routine.name,
                                                                'description': routine.description,
                                                                'build_no': routine.latest_build_no,
                                                                'generating_type': routine.generating_type,
                                                                'routine': routine,
                                                                'build_data': {
                                                                    'datafields': routine.data.get(
                                                                        'datafields') or list(),
                                                                    'intent': routine.data.get('intent') or dict(),
                                                                    'dataset': {
                                                                        'name': routine.dataset_name,
                                                                        'version': routine.dataset_version,
                                                                        'description': routine.data.get('dataset',
                                                                                                        dict()).get(
                                                                            'description'),
                                                                    }
                                                                }
                                                            })

                        # wait build step
                        # build and publish on shelf
                        if destination_sub_state.has_shelf:
                            self._build_and_publish_on_shelf(instance_uuid, destination_sub_state, **kwargs)

                except Exception as ie:
                    error_message = str(ie)
                    error_list.append({
                        'uuid': instance_uuid,
                        'message': error_message,
                    })

                finally:
                    count = count + 1
                    if console_output is not None:
                        message = 'success' if error_message is None else error_message
                        code = routine.code if routine is not None else '-'
                        console_output.append('({}/{}) "{}" (code={}) : {}' \
                                              .format(count, total, instance_uuid, code, message))

            success_all = (len(error_list) == 0)
            return success_all, error_list
        except Exception as e:
            CommonInstanceManager.LOGGER.error('Build and Publish Common Instance | exception: {}'.format(str(e)))
            raise e

    def publish(self, instance_uuids, destination_sub_state, **kwargs):
        try:
            CommonInstanceManager.LOGGER.debug('Publish Common Instance')
            console_output = kwargs.get('console_output')
            executed_by = kwargs.get('executed_by')
            authorized_ticket = kwargs.get('authorized_ticket')

            builder = Builder()
            error_list = list()
            total = len(instance_uuids)
            count = 0

            for instance_uuid in instance_uuids:
                error_message = None
                try:
                    with transaction.atomic():
                        routine = Routine.objects.filter(uuid=instance_uuid).first()
                        if routine is None:
                            raise Exception('invalid instance uuid')

                        build_no = routine.latest_build_no

                        # instance action log (publish)
                        # RoutineActionLog.log_publish(instance
                        #                             , build_no
                        #                             , destination_sub_state
                        #                             , authorized_ticket
                        #                             , executed_by)

                        # wait build step
                        publisher = Publisher(destination_sub_state)
                        # publisher = None
                        instance_repository = self._publish(publisher,
                                                            instance_uuid,
                                                            destination_sub_state,
                                                            routine.latest_build_no, {
                                                                'code': routine.code,
                                                                'name': routine.name,
                                                                'description': routine.description,
                                                                'build_no': build_no,
                                                                'generating_type': routine.generating_type,
                                                                'routine': routine,
                                                                'build_data': {
                                                                    'datafields': routine.data.get(
                                                                        'datafields') or list(),
                                                                    'intent': routine.data.get('intent') or dict(),
                                                                    'dataset': {
                                                                        'name': routine.dataset_name,
                                                                        'version': routine.dataset_version,
                                                                        'description': routine.data.get('dataset',
                                                                                                        dict()).get(
                                                                            'description'),
                                                                    }
                                                                }
                                                            })

                        # wait build step
                        # build and publish on shelf
                        if destination_sub_state.has_shelf:
                            self._publish_on_shelf(instance_uuid, destination_sub_state, **kwargs)

                except Exception as ie:
                    error_message = str(ie)
                    error_list.append({
                        'uuid': instance_uuid,
                        'message': error_message,
                    })

                finally:
                    count = count + 1
                    if console_output is not None:
                        message = 'success' if error_message is None else error_message
                        code = routine.code if routine is not None else '-'
                        console_output.append('({}/{}) "{}" (code={}) : {}'.format(count, total, instance_uuid, code, message))

            success_all = (len(error_list) == 0)
            return success_all, error_list

        except Exception as e:
            CommonInstanceManager.LOGGER.error('Build and Publish Common Instance | exception: {}'.format(str(e)))
            raise e

    def republish(self, instance_uuids, destination_sub_state, **kwargs):
        try:
            CommonInstanceManager.LOGGER.debug('Republish Common Instance')
            console_output = kwargs.get('console_output')
            executed_by = kwargs.get('executed_by')
            authorized_ticket = kwargs.get('authorized_ticket')

            builder = Builder()
            error_list = list()
            total = len(instance_uuids)
            count = 0

            for instance_uuid in instance_uuids:
                error_message = None
                try:
                    with transaction.atomic():
                        instance_repository = NodeRepository.objects.filter(uuid=instance_uuid,
                                                                            sub_state=destination_sub_state).first()
                        if instance_repository is None:
                            raise Exception('invalid instance uuid')

                        instance = instance_repository.routine
                        build_no = instance_repository.build_no

                        # instance action log (publish)
                        # RoutineActionLog.log_publish(instance
                        #                                 , build_no
                        #                                 , destination_sub_state
                        #                                 , authorized_ticket
                        #                                 , executed_by)

                        # wait build step
                        publisher = Publisher(destination_sub_state)
                        # publisher = None
                        instance_repository = self._publish(publisher, instance_uuid, destination_sub_state, build_no,
                                                            dict())

                        # republish on shelf
                        if destination_sub_state.has_shelf:
                            self._republish_on_shelf(instance_uuid, destination_sub_state, **kwargs)

                except Exception as ie:
                    error_message = str(ie)
                    error_list.append({
                        'uuid': instance_uuid,
                        'message': error_message,
                    })

                finally:
                    count = count + 1
                    if console_output is not None:
                        message = 'success' if error_message is None else error_message
                        code = instance.code if instance is not None else '-'
                        console_output.append('({}/{}) "{}" (code={}) : {}' \
                                              .format(count, total, instance_uuid, code, message))

            success_all = (len(error_list) == 0)
            return success_all, error_list

        except Exception as e:
            CommonInstanceManager.LOGGER.error('Republish Common Instance | exception: {}'.format(str(e)))
            raise e

    # TODO: add remove non use package from s3
    def move(self, instance_uuids, source_sub_state, destination_sub_state, **kwargs):
        try:
            CommonInstanceManager.LOGGER.debug('Move Common Instance | from sub state: {}, to sub state: {}'
                                               .format(source_sub_state.name, destination_sub_state.name))
            console_output = kwargs.get('console_output')
            executed_by = kwargs.get('executed_by')
            authorized_ticket = kwargs.get('authorized_ticket')

            # wait build step
            builder = Builder()
            error_list = list()
            total = len(instance_uuids)
            count = 0

            for instance_uuid in instance_uuids:
                error_message = None
                try:
                    with transaction.atomic():
                        instance_repository = NodeRepository.objects.filter(uuid=instance_uuid,
                                                                            sub_state=source_sub_state).first()
                        if instance_repository is None:
                            raise Exception('invalid instance uuid')

                        instance = instance_repository.routine
                        build_no = instance_repository.build_no
                        build_data = instance_repository.build_data

                        # instance action log (publish)
                        # RoutineActionLog.log_publish(instance
                        #                                 , build_no
                        #                                 , destination_sub_state
                        #                                 , authorized_ticket
                        #                                 , executed_by)

                        # wait build step
                        publisher = Publisher(destination_sub_state)
                        # publisher = None
                        new_instance_repository = self._publish(publisher, instance_uuid, destination_sub_state, build_no, {
                            'code': instance_repository.code,
                            'name': instance_repository.name,
                            'description': instance_repository.description,
                            'build_no': build_no,
                            'build_data': build_data,
                            'generating_type': instance_repository.generating_type,
                            'routine': instance,
                        })
                        # Todo: clean s3
                        try:
                            s3_clean_package(
                                instance_repository.routine.uuid,
                                source_sub_state.state.access_aws_config,
                                NodeRepository.objects.filter(
                                    routine=instance_repository.routine
                                ).values_list('build_no')
                            )
                        
                        except Exception as e:
                            CommonInstanceManager.LOGGER.error('Clean s3 fail | exception: {}'.format(str(e)))
                            
                        # move on shelf
                        if destination_sub_state.has_shelf:
                            self._move_on_shelf(instance_uuid, source_sub_state, destination_sub_state, **kwargs)

                except Exception as ie:
                    error_message = str(ie)
                    error_list.append({
                        'uuid': instance_uuid,
                        'message': error_message,
                    })

                finally:
                    count = count + 1
                    if console_output is not None:
                        message = 'success' if error_message is None else error_message
                        code = instance.code if instance is not None else '-'
                        console_output.append('({}/{}) "{}" (code={}) : {}' \
                                              .format(count, total, instance_uuid, code, message))

            success_all = (len(error_list) == 0)
            return success_all, error_list

        except Exception as e:
            CommonInstanceManager.LOGGER.error('Move Common Instance | exception: {}'.format(str(e)))
            raise e

    def remove(self, instance_uuids, destination_sub_state, **kwargs):
        try:
            CommonInstanceManager.LOGGER.debug('Remove Common Instance')
            console_output = kwargs.get('console_output')
            executed_by = kwargs.get('executed_by')
            authorized_ticket = kwargs.get('authorized_ticket')

            error_list = list()
            total = len(instance_uuids)
            count = 0

            for instance_uuid in instance_uuids:
                error_message = None
                instance = None
                try:
                    with transaction.atomic():
                        instance_repository = NodeRepository.objects.filter(uuid=instance_uuid,
                                                                            sub_state=destination_sub_state).first()
                        if instance_repository is None:
                            raise Exception('invalid instance uuid')

                        instance = instance_repository.routine

                        # wait build step
                        # validate instance using on runtime
                        flow_repositories = FlowRepository.objects.filter(instance_uuids__contains=[instance_uuid]
                                                                          , sub_state=destination_sub_state
                                                                          , flow__system_generated=False)
                        if len(flow_repositories) > 0:
                            raise Exception('this instance has been a component of flows (runtime), cannot remove')

                        if destination_sub_state.is_default:
                            combined_instances = CombinedInstance.objects.filter(base_instance_uuid=instance_uuid)
                            if len(combined_instances) > 0:
                                raise Exception(
                                    'this instance has been a component of other instances (combined), cannot remove')

                            flow_instances = FlowInstance.objects.filter(instance_uuid=instance_uuid,
                                                                         flow__system_generated=False)
                            if len(flow_instances) > 0:
                                raise Exception('this instance has been a component of flows, cannot remove')

                        # displace
                        instance_name = self._get_instance_name(instance_uuid)

                        # wait build step
                        publisher = Publisher(destination_sub_state)
                        # publisher = None
                        publisher.displace(instance_name)

                        # delete node repository
                        instance_repository.delete()

                        # instance action log (displace)
                        # RoutineActionLog.log_displace(instance, destination_sub_state, authorized_ticket, executed_by)

                        # remove on shelf
                        if destination_sub_state.has_shelf:
                            self._remove_on_shelf(instance_uuid, destination_sub_state, **kwargs)

                except Exception as ie:
                    error_message = str(ie)
                    error_list.append({
                        'uuid': instance_uuid,
                        'message': error_message,
                    })

                finally:
                    count = count + 1
                    if console_output is not None:
                        message = 'success' if error_message is None else error_message
                        code = instance.code if instance is not None else '-'
                        console_output.append('({}/{}) "{}" (code={}) : {}' \
                                              .format(count, total, instance_uuid, code, message))

            success_all = (len(error_list) == 0)
            return success_all, error_list

        except Exception as e:
            CommonInstanceManager.LOGGER.error('Remove Common Instance | exception: {}'.format(str(e)))
            raise e

    def purge(self, instance_uuids, **kwargs):
        try:
            CommonInstanceManager.LOGGER.debug('Purge Common Instance')
            console_output = kwargs.get('console_output')

            builder = Builder()
            error_list = list()
            total = len(instance_uuids)
            count = 0

            for instance_uuid in instance_uuids:
                error_message = None
                try:
                    routine = Routine.objects.filter(uuid=instance_uuid).first()
                    if routine is None:
                        raise Exception('invalid instance uuid')

                    instance_repositories = NodeRepository.objects.filter(uuid=instance_uuid)
                    if len(instance_repositories) > 0:
                        raise Exception('this instance is still in use, cannot purge')

                    with transaction.atomic():
                        # wait build step
                        # delete shelf flow if exist
                        shelf_flow = Flow.objects.filter(uuid=instance_uuid).first()
                        if shelf_flow is not None:
                            FlowInstance.objects.filter(flow_id=shelf_flow.id).delete()
                            FlowPackage.objects.filter(uuid=shelf_flow.uuid).delete()
                            # FlowActionLog.objects.filter(flow_id=shelf_flow.id).delete()
                            shelf_flow.delete()

                        # delete instance from group
                        LotRoutine.objects.filter(routine_id=routine.id).delete()

                        # delete instance
                        ActivityConfiguration.objects.filter(routine_id=routine.id).delete()
                        # RoutineActionLog.objects.filter(routine_id=instance.id).delete()
                        routine.delete()

                        # delete image repository
                        instance_name = self._get_instance_name(instance_uuid)
                        builder.delete_repository(instance_name)

                except Exception as ie:
                    error_message = str(ie)
                    error_list.append({
                        'uuid': instance_uuid,
                        'message': error_message,
                    })

                finally:
                    count = count + 1
                    if console_output is not None:
                        message = 'success' if error_message is None else error_message
                        console_output.append('({}/{}) "{}" : {}'.format(count, total, instance_uuid, message))

            success_all = (len(error_list) == 0)
            return success_all, error_list

        except Exception as e:
            CommonInstanceManager.LOGGER.error('Purge Common Instance | exception: {}'.format(str(e)))
            raise e

    # puiblish
    def _publish(self, publisher, instance_uuid, destination_sub_state, build_no, instance_data=dict()):
        try:
            instance_name = self._get_instance_name(instance_uuid)
            instance_tag = build_no

            routine = Routine.objects.filter(uuid=instance_uuid).first()
            environment_variable = TemplateEnvironmentVariable.objects.filter(template=routine.template,
                                                                              state=destination_sub_state.state).first()
            if environment_variable is None:
                additional_environment_variable = dict()
            else:
                additional_environment_variable = environment_variable.config or dict()

            # wait build step
            deployment_environment = publisher.publish(instance_name, instance_tag, additional_environment_variable)

            # wait build step
            # deployment_environment = dict()
            # deployment_environment['url'] = 'https://{}'.format(instance_tag)
            # deployment_environment['load_balance_name'] = 'lb01'
            # deployment_environment['node_name'] = 'tg1'

            instance_data['url'] = '{}/home'.format(deployment_environment['url'])
            instance_data['load_balance_name'] = deployment_environment['load_balance_name']
            instance_data['node_name'] = deployment_environment['node_name']

            instance_repository, _ = NodeRepository.objects.update_or_create(
                sub_state=destination_sub_state,
                uuid=instance_uuid,
                defaults=instance_data)
            # Mail alert after create node repository / deployed
            try:
                DeploymentMailer(
                    destination_sub_state,
                    instance_data['load_balance_name'],
                    instance_data['node_name']
                ).async_send()

            except Exception as e:
                CommonInstanceManager.LOGGER.error('Send Email Failed: {}'.format(str(e)))

            return instance_repository

        except Exception as e:
            raise Exception('_publish error: {}'.format(str(e)))

    def _build_and_publish_on_shelf(self, instance_uuid, destination_sub_state, **kwargs):
        try:
            flow = self._get_shelf_flow(instance_uuid, **kwargs)
            if kwargs.get('console_output') is not None:
                del kwargs['console_output']

            FlowManager().build_and_publish([str(flow.uuid)], destination_sub_state, **kwargs)
            self._assign_flow_to_shelf(instance_uuid, destination_sub_state)

        except Exception as e:
            raise Exception('_build_and_publish_on_shelf error: {}'.format(str(e)))

    def _publish_on_shelf(self, instance_uuid, destination_sub_state, **kwargs):
        try:
            flow = self._get_shelf_flow(instance_uuid, **kwargs)
            if kwargs.get('console_output') is not None:
                del kwargs['console_output']

            if flow.latest_build_no is None:
                FlowManager().build_and_publish([str(flow.uuid)], destination_sub_state, **kwargs)
            else:
                FlowManager().publish([str(flow.uuid)], destination_sub_state, **kwargs)

            self._assign_flow_to_shelf(instance_uuid, destination_sub_state)

        except Exception as e:
            raise Exception('_publish_on_shelf error: {}'.format(str(e)))

    def _republish_on_shelf(self, instance_uuid, destination_sub_state, **kwargs):
        try:
            flow_uuid = instance_uuid
            repository = FlowRepository.objects.filter(uuid=flow_uuid, sub_state=destination_sub_state).first()
            if repository is None:
                self._publish_on_shelf(instance_uuid, destination_sub_state, **kwargs)
            else:
                if kwargs.get('console_output') is not None:
                    del kwargs['console_output']

                FlowManager().republish([flow_uuid], destination_sub_state, **kwargs)
                self._assign_flow_to_shelf(instance_uuid, destination_sub_state)
        except Exception as e:
            raise Exception('_republish_on_shelf error: {}'.format(str(e)))

    def _move_on_shelf(self, instance_uuid, source_sub_state, destination_sub_state, **kwargs):
        try:
            flow_uuid = instance_uuid
            repository = FlowRepository.objects.filter(uuid=flow_uuid, sub_state=source_sub_state).first()
            if repository is not None:
                if kwargs.get('console_output') is not None:
                    del kwargs['console_output']

                FlowManager().move([flow_uuid], source_sub_state, destination_sub_state, **kwargs)
                self._assign_flow_to_shelf(instance_uuid, destination_sub_state)
            else:
                self._publish_on_shelf(instance_uuid, destination_sub_state, **kwargs)

        except Exception as e:
            raise Exception('_move_on_shelf error: {}'.format(str(e)))

    def _remove_on_shelf(self, instance_uuid, destination_sub_state, **kwargs):
        try:
            flow_uuid = instance_uuid
            repository = FlowRepository.objects.filter(uuid=flow_uuid, sub_state=destination_sub_state).first()
            if repository is not None:
                if kwargs.get('console_output') is not None:
                    del kwargs['console_output']

                FlowManager().remove([flow_uuid], destination_sub_state, **kwargs)

        except Exception as e:
            raise Exception('_publish_on_shelf error: {}'.format(str(e)))

    # Register and Deregister on Shelf Automatically
    def _get_shelf_flow(asdfjself, instance_uuid, **kwargs):
        try:
            flow_uuid = instance_uuid
            flow = Flow.objects.filter(uuid=flow_uuid).first()

            if flow is None:
                default_instance_repository = NodeRepository.objects.filter(uuid=instance_uuid,
                                                                            sub_state__is_default=True).first()
                if default_instance_repository is None:
                    raise Exception('default instance does not exist')

                # create flow
                flow_code = 'ShelfFlow_{}'.format(default_instance_repository.code)
                flow_name = default_instance_repository.name
                flow_description = 'auto-generagted flow for {}'.format(default_instance_repository.code)
                flow_label = (default_instance_repository.build_data.get('dataset') or dict()).get('description')
                flow = FlowManager().generate_single_instance_flow(flow_code, flow_name, flow_description, flow_label,
                                                                   instance_uuid, **kwargs)

            return flow

        except Exception as e:
            raise Exception('_get_shelf_flow error: {}'.format(str(e)))

    def _assign_flow_to_shelf(self, instance_uuid, destination_sub_state):
        try:
            routine = Routine.objects.filter(uuid=instance_uuid).first()
            if routine is None:
                raise Exception('instance configuration not found')

            standard_process = routine.standard_process

            procedure_code = 'ShelfProcedure_{}'.format(standard_process.code)
            procedure_name = 'procedure {}'.format(standard_process.code)
            procedure_description = 'auto-generagted procedure for {}'.format(standard_process.code)
            procedure_label = standard_process.name

            response = LauncherProcedure.list(destination_sub_state, **{
                'code': procedure_code,
                'system_data': True,
            })

            response_meta = response.get('meta') or dict()
            if response_meta.get('response_code') != '10000':
                raise Exception('Cannot list procedure ({} - {})'.format(response_meta.get('response_code'),
                                                                         response_meta.get('response_desc')))

            procedures = response.get('data') or dict()

            if len(procedures) > 0:
                procedure_uuid = procedures[0]['uuid']
            else:
                procedure_uuid = str(uuid.uuid4())
                LauncherProcedure.create_or_update(destination_sub_state, procedure_uuid, **{
                    'code': procedure_code,
                    'name': procedure_name,
                    'description': procedure_description,
                    'display_label': procedure_label,
                    'system_data': True,
                })

            flow_uuid = instance_uuid
            LauncherProcedure.assign_flows(destination_sub_state, procedure_uuid, [flow_uuid])
            LauncherApplication.assign_procedures(destination_sub_state, settings.SHELF_APPLICATION_CODE,
                                                  [procedure_uuid])

        except Exception as e:
            raise Exception('_assign_flow_to_shelf error: {}'.format(str(e)))
