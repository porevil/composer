import uuid
import tempfile
import os

from apps.commons.generator.systemconfig import CentralizedPackageRepositoryConfig
from apps.commons.utilities.log import Logger
from apps.commons.connectors.s3 import S3Client
from apps.commons.utilities.file import FileManagement

class AbstractInstanceManager:

    work_dir = None
    """
    On process path to create for each building, preparation etc.
    """

    lookup_fields = {
        'id': 'uuid',
        'build_no': 'build_no',
    }
    """
    Mapping key lookup for app value
    """

    s3_package_key = None

    s3_deployment_key = None

    def __init__(self, **kwargs):
        self.logger = Logger(self.__str__())
        if 'work_dir' in kwargs:
            self.work_dir = kwargs['work_dir']
        session_id = kwargs.get('session_id', str(uuid.uuid4()))
        self.logger.set_session_id(session_id)

        package_repository_config = CentralizedPackageRepositoryConfig.get()
        self.s3_bucket = package_repository_config.get('bucket')
        self.s3_package_key = package_repository_config.get('name_prefix')
        self.s3_client = S3Client(**package_repository_config)

    def get_s3_package_key(self, instance, build_no=None):
        instance_id = getattr(instance, self.lookup_fields['id'])
        instance_build_no = getattr(instance, self.lookup_fields['build_no'])
        if build_no is None:
            build_no = instance_build_no
        return f"{self.s3_package_key}/{instance_id}/{build_no}.zip"

    def get_s3_deployment_key(self, instance, build_no=None):
        instance_id = getattr(instance, self.lookup_fields['id'])
        instance_build_no = getattr(instance, self.lookup_fields['build_no'])
        if build_no is None:
            build_no = instance_build_no
        return f"{self.s3_deployment_key}/{instance_id}/{build_no}.zip"

    def get_work_dir_path(self, postfix=""):
        """
        Return working path on process runtime

        :return: str
        """
        if not self.work_dir:
            __temp_dir = tempfile.gettempdir()
            self.work_dir = __temp_dir
        return os.path.join(self.work_dir, postfix)

    def clear(self):
        FileManagement.remove_folder(self.get_work_dir_path())
