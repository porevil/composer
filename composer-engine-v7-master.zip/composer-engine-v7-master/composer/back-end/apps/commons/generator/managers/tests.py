from django.test import TestCase

from apps.commons.generator.managers.common_instance import CommonInstanceManager
from apps.commons.mock_up.mocker import next_sub_state, sub_state


class CustomManagerTestCase(TestCase):
    def setUp(self) -> None:
        self.instance = None
        self.repository = None
        self.sub_state = None

    def test_move(self):
        old_repository = None

        new_repository = None

        instance_uuids = []
        source_sub_state = sub_state
        destination_sub_state = next_sub_state
        success, error_list = CommonInstanceManager().move(instance_uuids
                                                           , source_sub_state
                                                           , destination_sub_state)
