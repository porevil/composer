import json, re
import traceback

from django.db import transaction

from apps.commons.utilities.log import Logger
from apps.combined_instance.models import CombinedInstance
from apps.combined_instance.models import CombinedInstancePreSubmit
from apps.combined_instance.models import CombinedInstancePackage
from apps.combined_instance.models import CombinedInstanceRepository
from apps.flow.models import FlowInstance
from apps.flow.models import FlowRepository
from apps.commons.error.exception import *


class CombinedInstanceManager:

    LOGGER = Logger('Combined Instance Manager')


    def __init__(self):
        pass
    

    def build(self, instance_uuid):
        try:
            CombinedInstanceManager.LOGGER.debug('Build Combined Instance')
            with transaction.atomic():
                instance = CombinedInstance.objects.filter(uuid=instance_uuid).first()
                if instance is None:
                    raise BadRequestException('invalid instance uuid')

                pre_submits = CombinedInstancePreSubmit.objects.filter(combined_instance=instance).order_by('sequence')
                build_no = (instance.latest_build_no or 0) + 1
                instance_data = json.loads(instance.data)

                # Create combined instance package
                build_data = {
                    'dataset': {
                        'name': instance.dataset_name,
                        'version': instance_data.get('version'),
                        'description': instance_data.get('description'),
                    },
                    'datafields': instance_data.get('datafields') or list(),
                    'intent':  instance_data.get('intent') or dict(),
                    'verify': instance_data.get('verify', False),
                    'base_instance': {
                        'uuid': str(instance.base_instance_uuid),
                        'code': instance.base_instance_code,
                        'name': instance.base_instance_name,
                        'build_no': instance.base_instance_build_no,
                    },
                    'pre_submit_services': list(),
                }

                pre_submit_instance_uuids = list()
                for pre_submit in pre_submits:
                    pre_submit_data = json.loads(pre_submit.data)
                    pre_submit_data.update({
                        'sequence': pre_submit.sequence,
                        'uuid': str(pre_submit.uuid),
                    })
                    build_data['pre_submit_services'].append(pre_submit_data)
                    pre_submit_instance_uuids.append(pre_submit.uuid)

                package, created = CombinedInstancePackage.objects.update_or_create(
                                                    uuid=instance_uuid, 
                                                    build_no=build_no, 
                                                    defaults={
                                                        'build_data': build_data,
                                                    })
                
                # Create or Update combined instance repository
                repository_data = {
                    'code': instance.code,
                    'name': instance.name,
                    'description': instance.description,
                    'base_instance_uuid': instance.base_instance_uuid,
                    'pre_submit_instance_uuids': pre_submit_instance_uuids,
                    'build_no': build_no,
                    'combined_instance': instance,
                }

                repository, created = CombinedInstanceRepository.objects.update_or_create(
                                                    uuid=instance_uuid, 
                                                    defaults=repository_data)

                # Update combined instance (latest_build_no, build_with_latest_adjustment)
                instance.latest_build_no = build_no
                instance.build_with_latest_adjustment = True
                instance.save()

            return package

        except Exception as e:
            CombinedInstanceManager.LOGGER.error('Build Combined Instance | exception: {}'.format(str(e)))
            traceback.print_exc()
            raise e



    def purge(self, instance_uuid):
        try:
            CombinedInstanceManager.LOGGER.debug('Purge Combined Instance')
            with transaction.atomic():
                instance = CombinedInstance.objects.filter(uuid=instance_uuid).first()
                if instance is None:
                    raise BadRequestException('invalid instance uuid')

                # validate instance using on runtime
                flow_repositories = FlowRepository.objects.filter(instance_uuids__contains=[instance_uuid], flow__system_generated=False)
                if len(flow_repositories) > 0:
                    raise BadRequestException('this instance has been a component of flows (runtime), cannot remove')

                # validate instance using on composing time
                flow_instances = FlowInstance.objects.filter(instance_uuid=instance_uuid, flow__system_generated=False)
                if len(flow_instances) > 0:
                    raise BadRequestException('this instance has been a component of flows, cannot remove')
                    
                CombinedInstancePreSubmit.objects.filter(combined_instance=instance).delete()
                CombinedInstancePackage.objects.filter(uuid=instance_uuid).delete()
                CombinedInstanceRepository.objects.filter(uuid=instance_uuid).delete()
                instance.delete()

        except Exception as e:
            CombinedInstanceManager.LOGGER.error('Purge Combined Instance | exception: {}'.format(str(e)))
            traceback.print_exc()
            raise e
