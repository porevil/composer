from django.conf import settings

from apps.configurations.models import State, SubState, InstanceDeploymentSpecification, InstanceEnvironmentVariable


class MetadataServiceConfig:
    @staticmethod
    def get(state):
        return {
            'endpoint': state.config['metadata_service']['endpoint'],
            'service_account': state.config['service_account'],
            'mule_client_id': state.config['mule']['client_id'],
            'mule_client_secret': state.config['mule']['client_secret'],
        }


class AGServiceConfig:
    @staticmethod
    def get(state):
        return {
            'management_endpoint': state.config['ag_service']['management_endpoint'],
            'runtime_endpoint': state.config['ag_service']['runtime_endpoint'],
            'service_account': state.config['service_account'],
            'mule_client_id': state.config['mule']['client_id'],
            'mule_client_secret': state.config['mule']['client_secret'],
        }


class LauncherServiceConfig:
    @staticmethod
    def get(state):
        return {
            'endpoint': state.config['launcher_service']['endpoint'],
            'service_account': state.config['service_account'],
            'mule_client_id': state.config['mule']['client_id'],
            'mule_client_secret': state.config['mule']['client_secret'],
        }


class CollaborationServiceConfig:
    @staticmethod
    def get(state):
        return {
            'endpoint': state.config['notification_service']['endpoint'],
            'service_account': state.config['service_account'],
            'mule_client_id': state.config['mule']['client_id'],
            'mule_client_secret': state.config['mule']['client_secret'],
        }


class CentralizedPackageRepositoryConfig:
    @staticmethod
    def get():
        return {
            'bucket': settings.INSTANCE_PACKAGE_REPOSITORY_BUCKET,
            'name_prefix': settings.INSTANCE_PACKAGE_NAME_PREFIX,
            'aws_access_key_id': settings.INSTANCE_PACKAGE_REPOSITORY_ACCESS_KEY_ID,
            'aws_secret_access_key': settings.INSTANCE_PACKAGE_REPOSITORY_SECRET_ACCESS_KEY,
            'aws_region': settings.INSTANCE_PACKAGE_REPOSITORY_REGION,
        }


class InstanceEnvironmentVariableConfig:

    @staticmethod
    def get(state):
        instance_env = InstanceEnvironmentVariable.objects.filter(state=state).first()

        return {
            'service_account': instance_env.config['service_account'],
            'mule': {
                'client_id': instance_env.config['mule']['client_id'],
                'client_secret': instance_env.config['mule']['client_secret'],
            },
            'launcher_service': {
                'endpoint': instance_env.config['launcher_service']['endpoint'],
            },
            'redis_url': instance_env.config['redis_url'],
            'aws': {
                'access_key_id': instance_env.config['aws']['access_key_id'],
                'secret_access_key': instance_env.config['aws']['secret_access_key'],
                'region': instance_env.config['aws']['region'],
            },
        }


class InstanceDeploymentConfig:

    @staticmethod
    def get(sub_state):
        """
        new implement :class:`apps.configurations.models.InstanceDeploymentSpecification`

        :param sub_state: sub_state object
        :return:
        """
        instance_deployment = InstanceDeploymentSpecification.objects.filter(sub_state=sub_state).first()
        return {
            'package_bucket': instance_deployment.config['package_bucket'],
            'package_name_prefix': instance_deployment.config['package_name_prefix'],
            'load_balances': instance_deployment.config['load_balances'],
            'deployment_app': instance_deployment.config['deployment_app'],
            'service_role_arn': instance_deployment.config['service_role_arn'],
        }


class AccessEnvironmentConfig:
    @staticmethod
    def get(state):
        return {
            'aws_access_key_id': state.config['aws']['access_key_id'],
            'aws_secret_access_key': state.config['aws']['secret_access_key'],
            'aws_region': state.config['aws']['region'],
        }
