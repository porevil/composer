from git import Repo
import os
import uuid

from apps.commons.utilities.file import FileManagement
from apps.commons.generator.managers.abstract import AbstractInstanceManager

class CustomInstanceBuild(AbstractInstanceManager):

    def __init__(self, instance, **kwargs):
        super(CustomInstanceBuild, self).__init__(**kwargs)
        self.instance_obj = instance

    def build(self):
        try:
            instance = self.instance_obj
            working_uuid = str(uuid.uuid4())
            working_path = self.get_work_dir_path(working_uuid)
            checkout_dest = instance.commit_hash or instance.git_branch or 'master'
            Repo.clone_from(instance.git_repository, working_path, branch=checkout_dest)  # git clone
            self.logger.debug(f"Clone project success {working_path}")
            package_build_no = instance.build_no + 1
            bundled_file = f'{working_path}/{instance.uuid}_{package_build_no}.zip'  # path
            FileManagement.remove_folder(os.path.join(working_path, '.git'))
            # assert instance.config.get("base_path", None) is not None, "CustomInstance.config 'base_path'"
            FileManagement.zip(os.path.join(working_path, instance.config.get("base_path", '')), bundled_file)
            self.logger.debug(f"Building {bundled_file} to {self.get_s3_package_key(instance, build_no=package_build_no)}")
            self.s3_client.upload_file(bundled_file, self.s3_bucket, self.get_s3_package_key(instance, build_no=package_build_no))

            FileManagement.remove_folder(working_path)
            instance.build_no = package_build_no
            instance.save()
            self.logger.debug(f"Build success")
            return True
        except Exception as e:
            raise Exception(f"CustomInstanceBuild.build error: {str(e)}")
