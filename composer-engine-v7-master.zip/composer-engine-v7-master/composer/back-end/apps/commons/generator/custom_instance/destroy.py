import uuid
import os
import threading

from django.db import transaction
from django.template.loader import render_to_string

from apps.commons.generator.managers.abstract import AbstractInstanceManager
from apps.commons.utilities.file import FileManagement
from apps.commons.connectors.code_deploy import CodeDeployClient
from apps.commons.generator.systemconfig import InstanceDeploymentConfig
from apps.commons.generator.systemconfig import AccessEnvironmentConfig
from apps.configurations.models import State, SubState, InstanceDeploymentSpecification, InstanceEnvironmentVariable


class CustomInstanceDestroy(AbstractInstanceManager):
    """
    Remove custom instance and and un deploy service
    """
    instance = None

    def __init__(self, repository_obj, **kwargs):
        super().__init__(**kwargs)
        self.repository_obj = repository_obj
        self.deployment_config = InstanceDeploymentSpecification.objects.get(sub_state=repository_obj.sub_state).config
        self.access_environment_config = AccessEnvironmentConfig.get(repository_obj.sub_state.state)
        deployment_configuration = InstanceDeploymentConfig.get(repository_obj.sub_state)
        self.service_role_arn = deployment_configuration.get('service_role_arn')
        self.s3_deployment_key = deployment_configuration.get('package_name_prefix')
        self.code_deploy_client = CodeDeployClient(**self.access_environment_config)

    # TODO: validate parameters
    def validate(self):
        return True

    def destroy(self):
        # TODO: check repo is existing in flow
        try:
            self.validate()
            working_uuid = str(uuid.uuid4())
            working_path = self.get_work_dir_path(working_uuid)
            FileManagement.create_folder(working_path + '/deployment')
            # Generating app_spec file for un deploy service
            self.__generate_un_deployment_file(working_path)
            # Making archive (package)
            self.logger.debug('Undeploy (EC2) | making archive (package)')
            archived_package_file = '{}/undeployment.zip'.format(working_path)
            self.logger.debug(f'Undeploy (EC2) | archived_package_file {archived_package_file}')

            FileManagement.zip(working_path, archived_package_file)

            # Pushing package
            self.logger.debug('Undeploy (EC2) | pushing package')
            un_deployment_package_name = '{}/{}/undeployment.zip'.format(self.s3_deployment_key,
                                                                         self.repository_obj.custom_instance.uuid)
            self.s3_client.upload_file(archived_package_file,
                                       self.deployment_config.get('package_bucket'),
                                       un_deployment_package_name)
            deployment_group_name = str(uuid.uuid4())
            # Un publishing
            self.logger.debug('Undeploy (EC2) | unpublishing (using codedeploy)')
            self.code_deploy_client.create_deployment_group(self.deployment_config.get('deployment_app'),
                                                            deployment_group_name,
                                                            self.repository_obj.node_name,
                                                            self.service_role_arn)
            deployment_id = self.code_deploy_client.create_deployment(self.deployment_config.get('deployment_app'),
                                                                      deployment_group_name,
                                                                      self.deployment_config.get('package_bucket'),
                                                                      un_deployment_package_name)
            # get service storage
            self.logger.debug(f"Start code deploy: code id {deployment_id}")
            # get use code deploy to un deploy
            try:
                waiter = self.code_deploy_client.get_waiter('deployment_successful')
                waiter.wait(deploymentId=deployment_id)
                self.__remove_repository_data()
            except Exception as e:
                raise Exception('Undeploy Failure on DeploymentID = {}'.format(deployment_id))

            threading.Thread(
                target=self.code_deploy_client.delete_deployment_group,
                args=(self.deployment_config.get('deployment_app'), deployment_group_name)
            ).start()
            return True

        except Exception as e:
            self.logger.error('Undeploy (EC2) | exception: {}'.format(str(e)))
            raise e

    def _delete_deployment_group_process(self, deployment_group):
        self.code_deploy_client.delete_deployment_group(self.deployment_config.get('deployment_app'), deployment_group)

    def __remove_repository_data(self):
        self.repository_obj.delete()
        self.logger.debug("Removed Repository Object")

    def __generate_un_deployment_file(self, working_path):
        try:
            instance_obj = self.repository_obj.custom_instance
            deployment_dir = '{}/deployment'.format(working_path)

            context = {
                'instance_name': instance_obj.uuid
            }

            FileManagement.create_file(working_path, 'appspec.yml',
                                       render_to_string('undeployment_appspec.yml.template', context=context))
            FileManagement.create_file(deployment_dir, 'undeployment_server.sh',
                                       render_to_string('deployment/undeployment_server.sh.template', context=context))

        except Exception as e:
            self.logger.error('generate un deployment file error: {}'.format(str(e)))
            raise e
