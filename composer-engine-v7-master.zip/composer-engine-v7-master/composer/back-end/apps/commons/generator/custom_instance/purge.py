import uuid
import os
import threading

from django.db import transaction
from django.template.loader import render_to_string

from apps.commons.generator.managers.abstract import AbstractInstanceManager
from apps.commons.utilities.file import FileManagement
from apps.commons.connectors.code_deploy import CodeDeployClient
from apps.commons.generator.systemconfig import InstanceDeploymentConfig
from apps.commons.generator.systemconfig import AccessEnvironmentConfig
from apps.configurations.models import State, SubState, InstanceDeploymentSpecification, InstanceEnvironmentVariable


class CustomInstancePurge(AbstractInstanceManager):
    """
    Remove Custom Instance config
    """

    instance = None

    def __init__(self, instance, **kwargs):
        super().__init__(**kwargs)
        self.instance = instance

    def validate(self):
        repository = getattr(self.instance, 'repositories')
        if repository.count() != 0:
            raise ValueError("Repository must be empty before purge")

    def purge(self):
        try:
            self.validate()
            # TODO: Remove file from s3
            self.instance.delete()
        except Exception as e:
            self.logger.error("Purge Failure | {}".format(str(e)))
            raise e
