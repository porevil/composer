import tempfile
import uuid
import os

from colorlog import logging
from django.template.loader import render_to_string
from django.conf import settings

from apps.commons.utilities.file import FileManagement
from apps.commons.generator.managers.abstract import AbstractInstanceManager
from apps.custom_instance.models import CustomEnvironmentVariable, \
    CustomInstanceRepository, CustomInstance
from apps.configurations.models import State, SubState, InstanceDeploymentSpecification, InstanceEnvironmentVariable
from apps.commons.connectors.s3 import S3Client
from apps.commons.connectors.code_deploy import CodeDeployClient
from apps.commons.managers.load_balance_manager import LoadBalanceManager

from .util import generate_app_config_file, generate_app_deployment_file


class CustomInstancePublish(AbstractInstanceManager):
    """
    Publish is using for create bundle file from source code + application config
    """

    deployment_group_name = None

    app_path = ''

    app_config_path = './configuration.ini'

    instance_obj = None

    repository_obj = None

    repository_class = CustomInstanceRepository

    instance_class = CustomInstance

    sub_state = None

    service_info = {}

    available_node = None

    build_no = 0

    instance_field_name = 'custom_instance'

    def __init__(self, instance=None, repository=None, **kwargs):
        super(CustomInstancePublish, self).__init__(**kwargs)
        self.sub_state = kwargs.get('sub_state', None)
        # logging.debug(f"CustomInstancePublish initial sub state {self.sub_state}")
        if repository is not None:
            self.instance_obj = repository.instance
            self.build_no = repository.build_no
            self.sub_state = self.sub_state or repository.sub_state
        elif instance is not None:
            self.instance_obj = instance
            self.build_no = instance.build_no
            self.sub_state = self.sub_state or SubState.objects.filter(is_default=True).first()
        else:
            raise Exception("Args Error: instance or repository not assigned")
        _deployment_config = self.sub_state.deployment_specification
        assert _deployment_config is not None, f"InstanceDeploymentSpecification not found in sub_state id = {self.sub_state.id}"
        self.deployment_config = _deployment_config.config
        self.load_balance_manager = LoadBalanceManager(
            InstanceDeploymentSpecification.objects.get(sub_state=self.sub_state))

        self.access_environment_config = self.sub_state.state.access_aws_config
        # deployment_configuration = InstanceDeploymentConfig.get(self.sub_state)
        self.service_role_arn = _deployment_config.config.get('service_role_arn')
        self.s3_deployment_key = _deployment_config.config.get('package_name_prefix')

        self.code_deploy_client = CodeDeployClient(**self.access_environment_config)
        self.s3_client = S3Client(**self.access_environment_config)
        self.available_node = self.load_balance_manager.get_available_node(self.get_repository_class())

    def get_repository_class(self):
        return self.repository_class

    def after_deploy(self, build_no=None):
        """
        Execute after deployment success to update repository data
        :param build_no:
        :return: CustomInstanceRepository
        """

        try:
            if not self.service_info:
                raise ValueError("self.service_info is None please publish before execute")
            identifier = {
                self.instance_field_name: self.instance_obj,
                'sub_state': self.sub_state,
            }
            insert_data = {
                'build_no': build_no or self.build_no,
                'load_balance_name': self.service_info['load_balance_name'],
                'node_name': self.service_info.get('node_name'),
                'url': self.service_info.get('url'),
                'build_data': self.instance_obj.config,
                'name': self.instance_obj.name,
                'code': self.instance_obj.code,
            }
            return self.get_repository_class().objects.update_or_create(**identifier, defaults=insert_data)[0]
        except Exception as e:
            self.logger.error("After deploy Fail")
            raise e

    def publish(self, additional_env=None, **kwargs):
        """
        Create package with config and upload to s3

        :param additional_env:
        :param kwargs:
        :return:
        """

        try:
            self.logger.debug("Start Publish")

            if 'app_config_path' in kwargs:
                self.app_config_path = kwargs.get('app_config_path')
            if additional_env is None:
                additional_env = dict()

            env_var = CustomEnvironmentVariable.objects.filter(custom_instance=self.instance_obj,
                                                               state=self.sub_state.state).first()
            if env_var is None:
                raise Exception(
                    f"instance environment variable not exist: state={self.sub_state.state} custom_instance={self.instance_obj}")
            env_var_config = env_var.config

            # get project directory
            with tempfile.TemporaryDirectory() as dest_path:
                self.logger.debug(f"Publish work dir {dest_path}")
                zip_file_path = f"{tempfile.gettempdir()}/{str(uuid.uuid4())}_{self.build_no}.zip"
                self.logger.debug(
                    f"Downloading file from s3 key: [{self.get_s3_package_key(self.instance_obj)}] To: [{zip_file_path}]")
                self.s3_client.download_file(self.s3_bucket, self.get_s3_package_key(self.instance_obj), zip_file_path)
                self.logger.debug(f"Download Success")
                FileManagement.unzip(zip_file_path, f"{dest_path}")
                FileManagement.remove_file(zip_file_path)
                # generate app config file
                config_file_path = os.path.join(dest_path, self.instance_obj.config.get('app_config_path', ''))
                self.logger.debug(f"Unzip Success")

                if not os.path.exists(config_file_path):
                    self.logger.error("Publish list dir {}".format(os.listdir(dest_path)))
                    raise FileExistsError(f"config_file_path='{config_file_path}' not exist")

                generate_app_config_file(config_file_path,
                                         env_var_config,
                                         additional_env)

                # generate app deployment file
                generate_app_deployment_file(
                    app_path=os.path.join(dest_path, self.app_path),
                    instance_name=self.instance_obj.uuid,
                    context_path=self.available_node.get('context_path'),
                    addition_config=self.instance_obj.config
                )
                FileManagement.zip(dest_path, zip_file_path)
                self.logger.debug(
                    f"Uploading deployment to s3 bucket {self.deployment_config.get('package_bucket')}/{self.get_s3_deployment_key(self.instance_obj, build_no=self.build_no)}")
                self.s3_client.upload_file(zip_file_path,
                                           self.deployment_config.get('package_bucket'),
                                           self.get_s3_deployment_key(self.instance_obj, build_no=self.build_no))
                self.logger.debug("Upload Success")

                if kwargs.get('auto_deploy', False):
                    self.logger.debug("Auto Deploy: enabled")
                    return self.deploy()
                else:
                    self.logger.debug("Auto Deploy: disabled")

                self.logger.debug("Publish Success")

        except Exception as e:
            self.logger.error(f"Publish custom instance fail: {str(e)}")
            raise e

    def deploy(self, **kwargs):
        """
        Deploy file package from instance data model to machine (ec2, ec2 or service instance)
        :return:
        """
        try:
            self.logger.debug("Start Deploy")
            build_no = kwargs.get('build_no', None) or self.build_no
            if 'repository' in kwargs:  # existing repo alive
                repository = kwargs.get('repository')
                if self.sub_state is None and 'sub_state' not in kwargs:
                    raise Exception("sub_state must not be None")
                self.logger.debug(f"Use old load balance from repository settings")
                self.logger.debug(f"{repository}")
                self.available_node = self.load_balance_manager.get_node_info(repository.load_balance_name,
                                                                              repository.node_name)
                self.logger.debug(f"{self.available_node}")
                self.available_node = self.load_balance_manager.get_available_node(self.get_repository_class())

            group_name = self.get_deployment_group_name()

            if not self.service_info:
                repository_url = f"{self.available_node['load_balance']['url']}/{self.available_node['context_path']}/{self.instance_obj.uuid}"
                self.service_info = {
                    'url': repository_url,
                    'load_balance_name': self.available_node['load_balance']['name'],
                    'node_name': self.available_node['name']
                }

            self.code_deploy_client.create_deployment_group(self.deployment_config.get('deployment_app'),
                                                            group_name,
                                                            self.available_node['name'],
                                                            self.service_role_arn)
            deployment_id = self.code_deploy_client.create_deployment(self.deployment_config.get('deployment_app'),
                                                                      group_name,
                                                                      self.deployment_config.get('package_bucket'),
                                                                      self.get_s3_deployment_key(self.instance_obj,
                                                                                                 build_no=build_no))
            self.logger.debug(
                f"Deployment ID: {deployment_id}, deployment key: {self.deployment_config.get('package_bucket')}/{self.s3_deployment_key}")
            try:
                waiter = self.code_deploy_client.get_waiter('deployment_successful')
                waiter.wait(deploymentId=deployment_id)
            except Exception as e:
                raise Exception('Deploy Failure on DeploymentID = {}\nMessage Error = {}'.format(deployment_id, str(e)))
            self.code_deploy_client.delete_deployment_group(self.deployment_config.get('deployment_app'), group_name)
            self.logger.debug("Deploy Success")
        except Exception as e:
            self.logger.error("Deploy Fail")
            raise e

    def get_deployment_group_name(self):
        if self.deployment_group_name is None:
            self.deployment_group_name = str(uuid.uuid4())
        return self.deployment_group_name
