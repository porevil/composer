import os

from django.template.loader import render_to_string
from django.conf import settings

from apps.commons.utilities.file import FileManagement

def generate_app_config_file(app_config_path, environment_variable, additional_env):
    template_conf_file = os.path.join(settings.DEPLOYMENT_TEMPLATE_PATH, "config/app.cfg.template")
    __config_content = render_to_string(
        template_conf_file,
        context={
            'env': environment_variable,
            'additional_env': additional_env,
        })
    path, file = os.path.split(app_config_path)
    FileManagement.create_file(path,
                               file,
                               __config_content)

def generate_app_deployment_file(app_path, instance_name, context_path, is_new=True, **kwargs):
    deployment_dir = '{}/deployment'.format(app_path)
    FileManagement.create_folder(deployment_dir)
    context = {
        'context_path': context_path,
        'instance_name': instance_name,
        'is_new': is_new
    }
    if 'addition_config' in kwargs:
        for k, v in kwargs.get('addition_config').items():
            if k not in context:
                context[k] = v

    template_dir = settings.DEPLOYMENT_TEMPLATE_PATH
    FileManagement.create_file(app_path,
                               'appspec.yml',
                               render_to_string(f'{template_dir}/deployment_appspec.yml.template',
                                                context=context))
    FileManagement.create_file(deployment_dir,
                               'location.conf',
                               render_to_string(f'{template_dir}/deployment/location.conf.template',
                                                context=context))
    FileManagement.create_file(deployment_dir, 'prepare_environment.sh',
                               render_to_string(f'{template_dir}/deployment/prepare_environment.sh.template',
                                                context=context))
    FileManagement.create_file(deployment_dir,
                               'reload_server.sh',
                               render_to_string(f'{template_dir}/deployment/reload_server.sh.template',
                                                context=context))
    FileManagement.create_file(deployment_dir,
                               'start_new_server.sh',
                               render_to_string(f'{template_dir}/deployment/start_new_server.sh.template',
                                                context=context))
    FileManagement.create_file(deployment_dir,
                               'uwsgi_configuration.ini',
                               render_to_string(f'{template_dir}/deployment/uwsgi_configuration.ini.template',
                                                context=context))
