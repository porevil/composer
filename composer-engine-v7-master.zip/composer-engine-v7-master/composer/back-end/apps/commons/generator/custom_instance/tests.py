from django.test import TestCase
import tempfile
import uuid

from rest_framework.test import RequestsClient

from apps.commons.mock_up.mocker import state, custom_instance_data, sub_state, deploy_spec, next_deploy_spec, \
    next_sub_state
from apps.custom_instance.models import CustomInstance, CustomInstanceRepository, CustomEnvironmentVariable
from apps.commons.generator.custom_instance import CustomInstanceBuild, \
    CustomInstancePublish, CustomInstanceDestroy, CustomInstancePurge
from apps.configurations.models import SubState, State, InstanceDeploymentSpecification
from apps.commons.connectors.s3 import S3Client

def create_custom_instance(**kwargs):
    return CustomInstance.objects.create(**custom_instance_data)


def create_state(**kwargs):
    data = dict(state)
    for k, v in kwargs.items():
        data[k] = v
    return State.objects.create(**data)


def create_sub_state(**kwargs):
    data = dict(sub_state)
    for k, v in kwargs.items():
        data[k] = v
    return SubState.objects.create(**data)


def create_deploy_spec(**kwargs):
    data = dict(deploy_spec)
    for k, v in kwargs.items():
        data[k] = v
    return InstanceDeploymentSpecification.objects.create(**data)


def create_custom_instance_env_var(**kwargs):
    data = dict(deploy_spec)
    for k, v in kwargs.items():
        data[k] = v
    return CustomEnvironmentVariable.objects.create(**data)


client = RequestsClient()


class BaseCustomInstanceTestCase(TestCase):
    # multi_db = True

    def setUp(self) -> None:
        create_state()
        self.assertEqual(State.objects.count(), 1)
        sub_state_object = create_sub_state(state=State.objects.first())
        next_sub_state_object = create_sub_state(state=State.objects.first(), **next_sub_state)
        sub_state_object.next_sub_state_ids = [next_sub_state_object.id]
        sub_state_object.save()
        create_deploy_spec(sub_state=sub_state_object)
        # creat next sub state config
        create_deploy_spec(sub_state=next_sub_state_object, **next_deploy_spec)
        create_custom_instance(latest_version='1.0.1')
        self.instance = CustomInstance.objects.first()
        create_custom_instance_env_var(custom_instance=self.instance, state=State.objects.first())
        self.repository = None


class CustomInstanceBuildTestCase(BaseCustomInstanceTestCase):

    def test_build(self):
        instance = CustomInstance.objects.first()
        builder = CustomInstanceBuild(instance)
        # Build
        self.assertTrue(builder.build())
        instance = CustomInstance.objects.first()
        self.assertEqual(instance.build_no, 1)


class CustomInstanceBuildAndPublishTestCase(BaseCustomInstanceTestCase):

    def test_build_and_publish(self):
        # Build
        builder = CustomInstanceBuild(self.instance)
        self.assertTrue(builder.build())
        self.assertEqual(self.instance.build_no, 1)

        # Initial test zero member
        self.assertEqual(CustomInstanceRepository.objects.count(), 0)

        # Publish and deploy
        publisher = CustomInstancePublish(self.instance, sub_state=SubState.objects.first())
        publisher.publish()
        publisher.deploy()
        repository = publisher.after_deploy()
        self.assertEqual(repository.name, self.instance.name)
        self.assertEqual(repository.code, self.instance.code)
        self.assertEqual(CustomInstanceRepository.objects.count(), 1)
        self.instance.refresh_from_db()

        builder = CustomInstanceBuild(self.instance)
        self.assertTrue(builder.build())

        publisher = CustomInstancePublish(self.instance, sub_state=SubState.objects.first())
        publisher.publish()
        publisher.deploy()
        repository = publisher.after_deploy()

        self.assertEqual(CustomInstance.objects.first().build_no, 2)
        self.assertEqual(CustomInstanceRepository.objects.count(), 1)
        self.assertEqual(repository.build_no, 2)


class CustomInstanceRePublishTestCase(BaseCustomInstanceTestCase):
    def test_republish(self):
        # Build
        builder_1 = CustomInstanceBuild(self.instance)
        self.assertTrue(builder_1.build())
        self.assertEqual(self.instance.build_no, 1)

        # Initial test zero member
        self.assertEqual(CustomInstanceRepository.objects.count(), 0)
        self.instance.refresh_from_db()
        # Publish and deploy
        publisher = CustomInstancePublish(self.instance, sub_state=SubState.objects.first())
        publisher.publish()
        publisher.deploy()
        publisher.after_deploy()

        # Re-Publish
        repository = CustomInstanceRepository.objects.first()
        self.assertEqual(repository.build_no, 1)
        publisher = CustomInstancePublish(repository=repository)
        publisher.publish()
        publisher.deploy()

        self.assertEqual(CustomInstanceRepository.objects.count(), 1)
        res = client.get(f'{repository.url}/HealthCheck')
        self.assertEqual(res.status_code, 200)
        # Republish and deploy
        # repo = CustomInstanceRepository.objects.first()
        publisher_2 = CustomInstancePublish(CustomInstanceRepository.objects.first().custom_instance,
                                            sub_state=SubState.objects.first())
        publisher_2.publish(repository=CustomInstanceRepository.objects.first())

        res = client.get(f'{repository.url}/HealthCheck')
        self.assertEqual(res.status_code, 200)


class MultiThreadingTestCase(BaseCustomInstanceTestCase):
    def test_multi_thread(self):
        import threading

        def __local_task():
            # Build
            builder = CustomInstanceBuild(self.instance)
            self.assertTrue(builder.build())
            self.assertEqual(self.instance.build_no, 1)

            # Initial test zero member
            self.assertEqual(CustomInstanceRepository.objects.count(), 0)

            # Publish and deploy
            publisher = CustomInstancePublish(self.instance, sub_state=SubState.objects.first())
            publisher.publish()
            publisher.deploy()
            self.assertEqual(CustomInstanceRepository.objects.count(), 1)
            self.instance.refresh_from_db()

        th = threading.Thread(target=__local_task())
        th.start()
        print("Waiting for process. . .")
        th.join()
        print("Done")


class CustomInstanceRemoveTestCase(BaseCustomInstanceTestCase):
    def test_remove(self):
        # Build
        builder = CustomInstanceBuild(self.instance)
        self.assertTrue(builder.build())
        self.assertEqual(self.instance.build_no, 1)

        # Initial test zero member
        self.assertEqual(CustomInstanceRepository.objects.count(), 0)

        # Publish and deploy
        publisher = CustomInstancePublish(self.instance, sub_state=SubState.objects.first())
        publisher.publish()
        publisher.deploy()
        self.assertEqual(CustomInstanceRepository.objects.count(), 1)

        # Remover
        destroyer = CustomInstanceDestroy(CustomInstanceRepository.objects.first())
        destroyer.destroy()

        self.assertEqual(CustomInstanceRepository.objects.count(), 0)


class CustomInstancePurgeTestCase(BaseCustomInstanceTestCase):
    def test_purge(self):
        # Build
        builder = CustomInstanceBuild(self.instance)
        self.assertTrue(builder.build())
        self.assertEqual(self.instance.build_no, 1)

        # Initial test zero member
        self.assertEqual(CustomInstanceRepository.objects.count(), 0)

        # Publish and deploy
        publisher = CustomInstancePublish(self.instance, sub_state=SubState.objects.first())
        publisher.publish()
        publisher.deploy()
        publisher.after_deploy()
        self.assertEqual(CustomInstanceRepository.objects.count(), 1)

        # Purge
        destroyer = CustomInstanceDestroy(CustomInstanceRepository.objects.first())
        destroyer.destroy()

        purge_worker = CustomInstancePurge(CustomInstance.objects.first())
        purge_worker.purge()
        self.assertEqual(CustomInstance.objects.count(), 0)


class CustomInstanceMoveTestCase(BaseCustomInstanceTestCase):

    def __build_instance(self):
        builder = CustomInstanceBuild(self.instance)
        self.assertTrue(builder.build())
        self.assertEqual(self.instance.build_no, 1)
        self.instance.refresh_from_db()

    def __publish_instance(self):
        publisher = CustomInstancePublish(self.instance, sub_state=SubState.objects.first())
        publisher.publish()
        publisher.deploy()
        publisher.after_deploy()
        self.repository = CustomInstanceRepository.objects.first()
        self.assertIsNotNone(self.repository)

    def test_move(self):
        # TODO: implement move repo here
        self.__build_instance()
        self.__publish_instance()
        next_state = SubState.objects.get(pk=self.repository.sub_state.next_sub_state_ids[0])
        publisher = CustomInstancePublish(repository=self.repository, sub_state=next_state)
        publisher.publish()
        publisher.deploy()
        publisher.after_deploy()

        new_repository = CustomInstanceRepository.objects.filter(sub_state=next_state).first()
        self.assertIsNotNone(new_repository)
        print(new_repository.url)
        res = client.get(f'{new_repository.url}/HealthCheck')
        self.assertEqual(res.status_code, 200)


class MultipleTimeBuildTestCase(BaseCustomInstanceTestCase):

    def test_build_multiple_time(self):
        s3_client = S3Client()

        builder1 = CustomInstanceBuild(self.instance)
        builder1.build()
        self.assertEqual(self.instance.build_no, 1)

        builder2 = CustomInstanceBuild(self.instance)
        builder2.build()
        self.assertEqual(self.instance.build_no, 2)

        builder3 = CustomInstanceBuild(self.instance)
        builder3.build()
        self.assertEqual(self.instance.build_no, 3)
        s3_client.delete_object('tisco.alpha.composer', f'mbs/package/{str(self.instance.uuid)}/*.zip')
