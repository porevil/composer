import enum

class StandardProcess(enum.Enum):
    I1 = 'I1'
    I2 = 'I2'
    I3 = 'I3'
    I4 = 'I4'
    I9 = 'I9'
    I10 = 'I10'
    I12 = 'I12'
    I13 = 'I13'
    O1 = 'O1'
    O2 = 'O2'
    O3 = 'O3'
    O4 = 'O4'
    C2 = 'C2'
    C3 = 'C3'
    C4 = 'C4'
    T1 = 'T1'


class GeneratingType(enum.Enum):
    PreDefinedSingleDataset = 1
    PreDefinedMultipleDataset = 2
    UserDefined = 3


class StandardProcessType(enum.Enum):
    INPUT = 1
    OUTPUT = 2
    CONTROL = 3
    EXECUTE = 4


class Activity(enum.Enum):
    CREATE = 'create'
    UPDATE = 'update'
    VIEW = 'view'
    SEARCH = 'search'


class ActivitySection(enum.Enum):
    CRITERIA = 'criteria'
    DATA = 'data'


class InstanceType(enum.Enum):
    Common = 1
    Service = 2
    Combined = 3
    Custom = 4
    Virtual = 5
    Pass = 98
    End = 99


class ElementType(enum.Enum):
    COMMON_INSTANCE = 1
    CUSTOM_INSTANCE = 2
    FLOW = 3


class ElementAction(enum.Enum):
    REGENERATION = 1
    BUILD_AND_PUBLISH = 2
    REPUBLISH = 3
    MOVE = 4
    REMOVE = 5
    PURGE = 6

class InstanceRole(enum.Enum):
    CREATE = 'เข้าข้อมูล'
    UPDATE = 'แก้ไขข้อมูล'
    DELETE = 'ลบข้อมูล'
    VIEW = 'แสดงข้อมูล'
    SEARCH = 'ค้นหาข้อมูล'
    VERIFIED = 'ตรวจสอบข้อมูล'
    NOTIFICATION = 'แจ้งเตือน'


class ActionAuthority(enum.Enum):
    GENERATE_CONFIG = 'generate_config'
    ADJUST = 'adjust'
    BUILD = 'build'
    PURGE = 'purge'
    PUBLISH_NON_PROD = 'publish_nprod'
    PUBLISH_PRE_PROD = 'publish_pprod'
    PUBLISH_PROD = 'publish_prod'
    REMOVE_NON_PROD = 'remove_nprod'
    REMOVE_PRE_PROD = 'remove_pprod'
    REMOVE_PROD = 'remove_prod'
    REMOVE_CONSOLE = 'remove_console'


class Component(enum.Enum):
    TEXTBOX = 'widget_textbox'
    NUMBER = 'widget_number'
    HIDDEN = 'widget_hidden'
    DATETIME = 'widget_date_time'
    # DATEPICKER = 'widget_datepicker'
    # TIMEPICKER = 'widget_timepicker'
    # DATETIMEPICKER = 'widget_datetimepicker'
    DATE_BETWEEN = 'widget_date_between'
    DROPDOWN = 'widget_dropdown'
    DROPDOWN_MULTIPLE_VALUE = 'widget_multi_select'
    TEXT_AREA = 'widget_textarea'
    RICH_TEXT = 'widget_richtext'
    AUTO_GENERATE_UCID = 'auto_generate_ucid'
    MASTER = 'widget_master'
    # SEARCH_ANY_FIELD = 'widget_search_any_field'
    # SEARCH_ANY_FIELD_MULTIPLE_VALUE = 'widget_multi_search_any_field'
    # REFERENCE = 'widget_reference'
    # REFERENCE_MULTIPLE_VALUE = 'widget_multi_reference'
    # CREATABLE_SEARCH_ANY_FIELD = 'widget_search_create_any_field'
    RATING = 'widget_rating'
    RANKING = 'widget_ranking'
    RADIO_BUTTON = 'widget_radio_button'
    RADIO_GROUP = 'widget_radio_group'
    CHECKBOX_GROUP = 'widget_checkbox_group'
    CAMERA_UPLOAD = 'widget_camera_upload'
    FILE_UPLOAD = 'widget_upload_file'
    MAP = 'widget_maps'
    SIGNATURE = 'widget_signature'
    TOGGLE = 'widget_toggle'
    EMBEDDED_DISPLAY = 'widget_display'
    DISPLAY = 'widget_display'
    PREFORMATTED_TEXT = 'widget_preformatted_text'
