import os
import uuid
import traceback
import threading

from multiprocessing import Process
from abc import abstractmethod
from django.conf import settings
from django.db import transaction
from django.template.loader import render_to_string
from datetime import datetime

from apps.commons.generator.systemconfig import CentralizedPackageRepositoryConfig
from apps.commons.generator.systemconfig import InstanceEnvironmentVariableConfig
from apps.commons.generator.systemconfig import InstanceDeploymentConfig
from apps.commons.generator.systemconfig import AccessEnvironmentConfig
from apps.commons.generator.managers.configuration import ConfigurationManager
from apps.commons.connectors.s3 import S3Client
from apps.commons.connectors.code_deploy import CodeDeployClient
from apps.commons.utilities.file import FileManagement
from apps.commons.utilities.log import Logger
from apps.configurations.models import SubState
from apps.node_repositories.models import NodeRepository


class CommonInstancePublisher:
    LOGGER = Logger('Core Publisher')

    MODULE_DIR_PATH = os.path.dirname(os.path.realpath(__file__))
    WORKING_DIR_PATH = os.path.join(MODULE_DIR_PATH, 'working')

    def __init__(self, sub_state):
        try:
            start_init = datetime.now()
            self.sub_state = sub_state
            self.environment_variable = InstanceEnvironmentVariableConfig.get(self.sub_state.state)
            self.environment_variable.update({
                'service_account_group': settings.COMPOSER_GROUP_CODE,
                'current_state': self.sub_state.state.virtual_name,
                'current_sub_state': '' if self.sub_state.virtual_name is None else self.sub_state.virtual_name,
            }, )
            self.configuration_manager = ConfigurationManager()

            package_repository_config = CentralizedPackageRepositoryConfig.get()
            self.repository_bucket = package_repository_config.get('bucket')
            self.package_name_prefix = package_repository_config.get('name_prefix')

            CommonInstancePublisher.LOGGER.activity('init: {}'.format(datetime.now() - start_init))

            connect_init = datetime.now()
            self.s3_client = S3Client(**package_repository_config)
            CommonInstancePublisher.LOGGER.activity('connect s3 for package: {}'.format(datetime.now() - connect_init))

            start_deploy = datetime.now()
            deployment_configuration = InstanceDeploymentConfig.get(sub_state)
            self.deployment_package_bucket = deployment_configuration.get('package_bucket')
            self.deployment_package_name_prefix = deployment_configuration.get('package_name_prefix')
            self.deployment_load_balances = deployment_configuration.get('load_balances') or list()
            self.deployment_nodes = dict()
            self.deployment_sort_nodes = list()
            for load_balance in self.deployment_load_balances:
                load_balance_name = load_balance['name']
                self.deployment_nodes[load_balance_name] = dict()
                for node in load_balance.get('nodes') or list():
                    node_name = node['name']
                    self.deployment_nodes[load_balance_name][node_name] = {
                        'load_balance_url': load_balance['url'],
                        'context_path': node['context_path'],
                        'url': '{}/{}'.format(load_balance['url'], node['context_path']),
                        'limit_instance': node.get('limit_instance', 120)
                    }

                    self.deployment_sort_nodes.append({
                        'load_balance_name': load_balance_name,
                        'node_name': node_name,
                        'create_datetime': node.get('create_datetime')
                    })

            self.deployment_sort_nodes = sorted(self.deployment_sort_nodes,
                                                key=lambda f: f.get('create_datetime') or 9999999999999)
            self.deployment_app = deployment_configuration.get('deployment_app')
            self.service_role_arn = deployment_configuration.get('service_role_arn')

            if (not self.deployment_package_bucket) or (not self.deployment_package_name_prefix) \
                    or (not self.deployment_load_balances) or (not self.deployment_app) or (not self.service_role_arn):
                raise Exception('deployment config is incommplete')

            CommonInstancePublisher.LOGGER.activity('loop deployment: {}'.format(datetime.now() - start_deploy))

            access_environment_config = AccessEnvironmentConfig.get(sub_state.state)
            start_s3 = datetime.now()
            self.deployment_s3_client = S3Client(**access_environment_config)
            CommonInstancePublisher.LOGGER.activity('connect s3 for env: {}'.format(datetime.now() - start_s3))

            start_codedeploy = datetime.now()
            self.deployment_code_deploy_client = CodeDeployClient(**access_environment_config)
            CommonInstancePublisher.LOGGER.activity('connect code deploy: {}'.format(datetime.now() - start_codedeploy))

        except Exception as e:
            CommonInstancePublisher.LOGGER.error('Initial | exception: {}'.format(str(e)))
            traceback.print_exc()
            raise e

    def publish(self, instance_name, instance_tag, additional_environment_variable=dict()):
        package_dir = None
        archived_package_file = None

        try:
            CommonInstancePublisher.LOGGER.debug(
                'Publish | instance name = {}, instance tag = {}'.format(instance_name, instance_tag))
            CommonInstancePublisher.LOGGER.debug('Publish | creating working directory')
            working_uuid = str(uuid.uuid4())
            package_dir = os.path.join(self.WORKING_DIR_PATH, working_uuid)

            CommonInstancePublisher.LOGGER.debug('Publish | pulling package from s3')
            package_name = self.get_package_name(instance_name, instance_tag)
            archived_package_file = '{}/{}.zip'.format(self.WORKING_DIR_PATH, working_uuid)

            start_download = datetime.now()
            self.s3_client.download_file(self.repository_bucket, package_name, archived_package_file)
            CommonInstancePublisher.LOGGER.activity('download: {}'.format(datetime.now() - start_download))

            CommonInstancePublisher.LOGGER.debug('Publish | unpacking archive (package)')
            start_unzip = datetime.now()
            FileManagement.unzip(archived_package_file, package_dir)
            CommonInstancePublisher.LOGGER.activity('unzip: {}'.format(datetime.now() - start_unzip))

            CommonInstancePublisher.LOGGER.debug('Publish | deploying')
            return self._deploy(instance_name, instance_tag, package_dir, self.environment_variable,
                                additional_environment_variable)

        except Exception as e:
            CommonInstancePublisher.LOGGER.error('Publish | exception: {}'.format(str(e)))
            traceback.print_exc()
            raise e

        finally:
            try:
                CommonInstancePublisher.LOGGER.debug('Publish | destroying working directory')
                Process(target=lambda: self._remove_file_process(package_dir, archived_package_file)).start()

            except Exception as fe:
                CommonInstancePublisher.LOGGER.error('Publish | exception: {}'.format(str(fe)))

    def _remove_file_process(self, package_dir, archived_package_file):
        if package_dir: FileManagement.remove_folder(package_dir)
        if archived_package_file: FileManagement.remove_file(archived_package_file)

    def get_package_path(self, instance_name):
        return '{}/{}'.format(self.package_name_prefix, instance_name)

    def get_package_name(self, instance_name, instance_tag):
        return '{}/{}.zip'.format(self.get_package_path(instance_name), instance_tag)

    def displace(self, instance_name):
        try:
            CommonInstancePublisher.LOGGER.debug('Displace | instance name = {}'.format(instance_name))
            CommonInstancePublisher.LOGGER.debug('Displace | undeploying')
            self._undeploy(instance_name)

        except Exception as e:
            CommonInstancePublisher.LOGGER.error('Displace | exception: {}'.format(str(e)))
            raise e

    def _deploy(self, instance_name, instance_tag, package_dir, environment_variable, additional_environment_variable):
        archived_package_file = None
        deployment_package_name = None

        try:
            with transaction.atomic():
                instance_uuid = instance_name

                # Selecting node (EC2)
                CommonInstancePublisher.LOGGER.debug('Deploy (EC2) | selecting node')
                selected_load_balance_name = None
                selected_node_name = None

                node_repository = NodeRepository.objects.filter(uuid=instance_uuid, sub_state=self.sub_state).first()
                if node_repository:
                    selected_load_balance_name = node_repository.load_balance_name
                    selected_node_name = node_repository.node_name

                else:
                    selected_load_balance_name, selected_node_name = self._get_available_node()
                    if not selected_node_name:
                        raise Exception('There is not enough space available on deployment nodes (EC2).')

                CommonInstancePublisher.LOGGER.debug(' - load balance = {}'.format(selected_load_balance_name))
                CommonInstancePublisher.LOGGER.debug(' - node = {}'.format(selected_node_name))

                # Getting instance URL
                CommonInstancePublisher.LOGGER.debug('Deploy (EC2) | getting instance URL')
                node_info = (self.deployment_nodes.get(selected_load_balance_name) or dict()).get(
                    selected_node_name) or dict()
                if not node_info:
                    raise Exception('Invalid node (EC2) info.')

                instance_url = '{}/{}/{}'.format(node_info.get('load_balance_url'), node_info.get('context_path'),
                                                 instance_name)
                CommonInstancePublisher.LOGGER.debug(' - instance URL = {}'.format(instance_url))

                # Generating 'application config' and 'deployment' files
                CommonInstancePublisher.LOGGER.debug('Deploy (EC2) | generating app config  file')
                environment_variable.update({
                    'instance_url': instance_url,
                }, )

                self._generate_app_config_file(package_dir, environment_variable, additional_environment_variable)

                CommonInstancePublisher.LOGGER.debug('Deploy (EC2) | generating deployment file')
                self._generate_deployment_file(package_dir, instance_name, node_info.get('context_path'),
                                               (node_repository is None))

                # Making archive (package)
                CommonInstancePublisher.LOGGER.debug('Deploy (EC2) | making archive (package)')
                working_uuid = str(uuid.uuid4())
                archived_package_file = '{}/{}.zip'.format(self.WORKING_DIR_PATH, working_uuid)
                FileManagement.zip(package_dir, archived_package_file)

                # Pushing package
                CommonInstancePublisher.LOGGER.debug('Deploy (EC2) | pushing package to s3')
                deployment_package_name = '{}/{}/{}.zip'.format(self.deployment_package_name_prefix, instance_name,
                                                                instance_tag)

                start_upload = datetime.now()
                self.deployment_s3_client.upload_file(archived_package_file, self.deployment_package_bucket,
                                                      deployment_package_name)

                CommonInstancePublisher.LOGGER.activity('upload: {}'.format(datetime.now() - start_upload))

                # Publishing
                CommonInstancePublisher.LOGGER.debug('Deploy (EC2) | publishing (using codedeploy)')
                deployment_group = working_uuid
                start_create = datetime.now()
                self.deployment_code_deploy_client.create_deployment_group(self.deployment_app, deployment_group,
                                                                           selected_node_name, self.service_role_arn)

                CommonInstancePublisher.LOGGER.activity('create group: {}'.format(datetime.now() - start_create))

                start_create = datetime.now()
                deployment_id = self.deployment_code_deploy_client.create_deployment(self.deployment_app,
                                                                                     deployment_group,
                                                                                     self.deployment_package_bucket,
                                                                                     deployment_package_name)

                CommonInstancePublisher.LOGGER.activity('create deployment: {}'.format(datetime.now() - start_create))

                start_deploy = datetime.now()
                try:
                    waiter = self.deployment_code_deploy_client.get_waiter('deployment_successful')
                    waiter.wait(deploymentId=deployment_id)
                    CommonInstancePublisher.LOGGER.activity('deploy success: {}'.format(datetime.now() - start_deploy))

                except Exception as e:
                    CommonInstancePublisher.LOGGER.activity('deploy failed: {}'.format(datetime.now() - start_deploy))

                    raise Exception('Deploy Failure on DeploymentID = {}'.format(deployment_id))

                start_delete = datetime.now()
                Process(target=lambda: self._delete_deployment_group_process(deployment_group)).start()
                CommonInstancePublisher.LOGGER.activity('delete group: {}'.format(datetime.now() - start_delete))

                return {
                    'url': instance_url,
                    'load_balance_name': selected_load_balance_name,
                    'node_name': selected_node_name
                }

        except Exception as e:
            CommonInstancePublisher.LOGGER.error('Deploy (EC2) | exception: {}'.format(str(e)))
            raise e

        finally:
            try:
                CommonInstancePublisher.LOGGER.debug(
                    'Deploy (EC2) | destroying working directory and deployment package (on S3)')
                if archived_package_file: FileManagement.remove_file(archived_package_file)
                self.deployment_s3_client.delete_object(self.deployment_package_bucket, deployment_package_name)

            except Exception as fe:
                CommonInstancePublisher.LOGGER.error('Deploy (EC2) | exception: {}'.format(str(fe)))

    def _undeploy(self, instance_name):
        archived_package_file = None
        undeployment_package_name = None

        try:
            with transaction.atomic():
                CommonInstancePublisher.LOGGER.debug(
                    'Undeploy using codedeploy (EC2) | instance name = {}'.format(instance_name))

                instance_uuid = instance_name
                node_repository = NodeRepository.objects.filter(uuid=instance_uuid, sub_state=self.sub_state).first()
                if not node_repository:
                    raise Exception('{} is not exist'.format(instance_uuid))

                working_uuid = str(uuid.uuid4())
                package_dir = os.path.join(self.WORKING_DIR_PATH, working_uuid)

                # Generating 'deployment' file
                CommonInstancePublisher.LOGGER.debug('Undeploy (EC2) | generating deployment file')
                self._generate_undeployment_file(package_dir, instance_name)

                # Making archive (package)
                CommonInstancePublisher.LOGGER.debug('Undeploy (EC2) | making archive (package)')
                archived_package_file = '{}/{}/undeplyment.zip'.format(self.WORKING_DIR_PATH, working_uuid)
                FileManagement.zip(package_dir, archived_package_file)

                # Pushing package
                CommonInstancePublisher.LOGGER.debug('Undeploy (EC2) | pushing package')
                undeployment_package_name = '{}/{}/undeplyment.zip'.format(self.deployment_package_name_prefix,
                                                                           instance_name)
                self.deployment_s3_client.upload_file(archived_package_file, self.deployment_package_bucket,
                                                      undeployment_package_name)

                # Unpublishing
                CommonInstancePublisher.LOGGER.debug('Undeploy (EC2) | unpublishing (using codedeploy)')
                deployment_group = working_uuid
                self.deployment_code_deploy_client.create_deployment_group(self.deployment_app, deployment_group,
                                                                           node_repository.node_name,
                                                                           self.service_role_arn)
                deployment_id = self.deployment_code_deploy_client.create_deployment(self.deployment_app,
                                                                                     deployment_group,
                                                                                     self.deployment_package_bucket,
                                                                                     undeployment_package_name)
                try:
                    waiter = self.deployment_code_deploy_client.get_waiter('deployment_successful')
                    waiter.wait(deploymentId=deployment_id)
                except Exception as e:
                    raise Exception('Undeploy Failure on DeploymentID = {}'.format(deployment_id))

                threading.Thread(target=lambda: self._delete_deployment_group_process(deployment_group)).start()

                return True

        except Exception as e:
            CommonInstancePublisher.LOGGER.error('Undeploy (EC2) | exception: {}'.format(str(e)))
            raise e

        finally:
            try:
                CommonInstancePublisher.LOGGER.debug(
                    'Undeploy (EC2) | destroying working directory and undeployment package (on S3)')
                if package_dir: FileManagement.remove_folder(package_dir)
                self.deployment_s3_client.delete_object(self.deployment_package_bucket, undeployment_package_name)

            except Exception as fe:
                CommonInstancePublisher.LOGGER.error('Undeploy (EC2) | exception: {}'.format(str(fe)))

    def _delete_deployment_group_process(self, deployment_group):
        self.deployment_code_deploy_client.delete_deployment_group(self.deployment_app, deployment_group)

    def _generate_app_config_file(self, package_dir, environment_variable, additional_environment_variable):
        try:
            app_config_dir = '{}/config'.format(package_dir)
            FileManagement.create_folder(app_config_dir)
            FileManagement.create_file(app_config_dir, 'app.cfg', render_to_string('config/app.cfg.template', context={
                'env': environment_variable,
                'additional_env': additional_environment_variable,
            }))

        except Exception as e:
            CommonInstancePublisher.LOGGER.error('generate app config file error: {}'.format(str(e)))
            raise e

    def _generate_deployment_file(self, package_dir, instance_name, context_path, is_new=True):
        try:
            deployment_dir = '{}/deployment'.format(package_dir)
            FileManagement.create_folder(deployment_dir)

            context = {
                'context_path': context_path,
                'instance_name': instance_name,
                'is_new': is_new
            }

            FileManagement.create_file(package_dir, 'appspec.yml',
                                       render_to_string('deployment_appspec.yml.template', context=context))
            FileManagement.create_file(deployment_dir, 'location.conf',
                                       render_to_string('deployment/location.conf.template', context=context))
            FileManagement.create_file(deployment_dir, 'prepare_environment.sh',
                                       render_to_string('deployment/prepare_environment.sh.template', context=context))
            FileManagement.create_file(deployment_dir, 'reload_server.sh',
                                       render_to_string('deployment/reload_server.sh.template', context=context))
            FileManagement.create_file(deployment_dir, 'start_new_server.sh',
                                       render_to_string('deployment/start_new_server.sh.template', context=context))
            FileManagement.create_file(deployment_dir, 'uwsgi_configuration.ini',
                                       render_to_string('deployment/uwsgi_configuration.ini.template', context=context))

        except Exception as e:
            CommonInstancePublisher.LOGGER.error('generate deployment file error: {}'.format(str(e)))
            raise e

    def _generate_undeployment_file(self, package_dir, instance_name):
        try:
            deployment_dir = '{}/deployment'.format(package_dir)
            FileManagement.create_folder(deployment_dir)

            context = {
                'instance_name': instance_name
            }

            FileManagement.create_file(package_dir, 'appspec.yml',
                                       render_to_string('undeployment_appspec.yml.template', context=context))
            FileManagement.create_file(deployment_dir, 'undeployment_server.sh',
                                       render_to_string('deployment/undeployment_server.sh.template', context=context))

        except Exception as e:
            CommonInstancePublisher.LOGGER.error('generate undeployment file error: {}'.format(str(e)))
            raise e

    def _get_available_node(self):
        try:
            for deployment_sort_node in self.deployment_sort_nodes:
                load_balance_name = deployment_sort_node.get('load_balance_name')
                node_name = deployment_sort_node.get('node_name')
                limit_instance = self.deployment_nodes[load_balance_name][node_name]['limit_instance']

                common_existing_instance = NodeRepository.objects.filter(sub_state=self.sub_state,
                                                                         load_balance_name=load_balance_name,
                                                                         node_name=node_name).count()

                # custom_existing_instance = CustomRepository.objects.filter(sub_state=self.sub_state,
                #                                                     load_balance_name=load_balance_name,
                #                                                     node_name=node_name).count()

                # virtual_existing_instance = VirtualRepository.objects.filter(sub_state=self.sub_state,
                #                                                     load_balance_name=load_balance_name,
                #                                                     node_name=node_name).count()

                existing_instance = common_existing_instance
                if existing_instance < limit_instance:
                    return load_balance_name, node_name

            return None, None

        except Exception as e:
            CommonInstancePublisher.LOGGER.error('get available node error: {}'.format(str(e)))
            raise e
