import os
import uuid
import json
import traceback

from multiprocessing import Process
from abc import abstractmethod
from datetime import datetime

from apps.commons.generator.systemconfig import CentralizedPackageRepositoryConfig
from apps.commons.utilities.file import FileManagement
from apps.commons.utilities.log import Logger
from apps.commons.connectors.s3 import S3Client
def get_size(start_path='.'):
    total_size = 0
    for dirpath, dirnames, filenames in os.walk(start_path):
        for f in filenames:
            fp = os.path.join(dirpath, f)
            total_size += os.path.getsize(fp)
    return total_size

class AbstractBuilder:
    LOGGER = Logger('Core Builder')

    MODULE_DIR_PATH = os.path.dirname(os.path.abspath(__file__))
    WORKING_DIR_PATH = os.path.join(MODULE_DIR_PATH, 'working')
    TEMP_DIR_PATH = os.path.join(MODULE_DIR_PATH, 'temp')

    def __init__(self):
        try:
            package_repository_config = CentralizedPackageRepositoryConfig.get()
            self.repository_bucket = package_repository_config.get('bucket')
            self.package_name_prefix = package_repository_config.get('name_prefix')
            self.s3_client = S3Client(**package_repository_config)
            self.working_uuid = str(uuid.uuid4())

        except Exception as e:
            AbstractBuilder.LOGGER.error('Initial | exception: {}'.format(str(e)))
            raise e

    def build(self, instance_name, instance_tag, instance):
        generated_package_dir = None
        archived_package_file = None

        try:
            AbstractBuilder.LOGGER.debug(
                'Build | instance name = {}, instance tag = {}'.format(instance_name, instance_tag))
            AbstractBuilder.LOGGER.debug('Build | creating working directory')
            generated_package_dir = os.path.join(self.WORKING_DIR_PATH, self.working_uuid)
            FileManagement.create_folder(generated_package_dir)

            AbstractBuilder.LOGGER.debug('Build | generating package')
            AbstractBuilder.LOGGER.debug(' - generated package directory : {}'.format(generated_package_dir))
            self._generate_package(instance, generated_package_dir)

            AbstractBuilder.LOGGER.debug('Build | making archive (package)')
            archived_package_file = '{}/{}.zip'.format(self.WORKING_DIR_PATH, self.working_uuid)
            AbstractBuilder.LOGGER.debug(' - archived package file : {}'.format(archived_package_file))

            start_zip = datetime.now()
            FileManagement.zip(generated_package_dir, archived_package_file)
            AbstractBuilder.LOGGER.activity('size: {}M'.format(get_size(generated_package_dir)/(1024*1024)))
            AbstractBuilder.LOGGER.activity('zip: {} size: {}M'.format(datetime.now() - start_zip, os.path.getsize(archived_package_file)/(1024*1024)))

            AbstractBuilder.LOGGER.debug('Build | pushing package')
            package_name = self.get_package_name(instance_name, instance_tag)

            start_s3 = datetime.now()
            self.s3_client.upload_file(archived_package_file, self.repository_bucket, package_name)
            AbstractBuilder.LOGGER.activity('push s3: {}'.format(datetime.now() - start_s3))

        except Exception as e:
            AbstractBuilder.LOGGER.error('Build | exception: {}'.format(str(e)))
            traceback.print_exc()
            raise e

        finally:
            try:
                AbstractBuilder.LOGGER.debug('Build | destroying working directory')
                remove_start = datetime.now()

                Process(target=lambda: self._remove_file_process(generated_package_dir, archived_package_file)).start()

                AbstractBuilder.LOGGER.debug('remove temp folder: {}'.format(datetime.now() - remove_start))
            except Exception as fe:
                AbstractBuilder.LOGGER.error('Build | exception: {}'.format(str(fe)))

    def _remove_file_process(self, generated_package_dir, archived_package_file):
        if generated_package_dir: FileManagement.remove_folder(generated_package_dir)
        FileManagement.remove_folder(os.path.join(self.TEMP_DIR_PATH, self.working_uuid))
        if archived_package_file: FileManagement.remove_file(archived_package_file)


    def unbuild(self, instance_name, instance_tags):
        try:
            AbstractBuilder.LOGGER.debug(
                'Unbuild | instance name = {}, instance tags = {}'.format(instance_name, instance_tags))
            for instance_tag in instance_tags:
                package_name = self.get_package_name(instance_name, instance_tag)
                self.s3_client.delete_object(self.repository_bucket, package_name)

        except Exception as e:
            AbstractBuilder.LOGGER.error('Unbuild | exception: {}'.format(str(e)))
            raise e

    def list_built_instance_tags(self, instance_name):
        try:
            AbstractBuilder.LOGGER.debug('List Built Instance Tags | instance name = {}'.format(instance_name))
            prefix = '{}/'.format(self.get_package_path(instance_name))
            package_contents = self.s3_client.list_objects(self.repository_bucket, prefix)
            instance_tags = list(
                map(lambda content: content['Key'].replace(prefix, '', 1).replace('.zip', ''), package_contents))
            return instance_tags

        except Exception as e:
            AbstractBuilder.LOGGER.error('List Built Instance Tags | exception: {}'.format(str(e)))
            raise e

    def delete_repository(self, instance_name):
        try:
            AbstractBuilder.LOGGER.debug('Delete Package Repository | instance name = {}'.format(instance_name))
            instance_tags = self.list_built_instance_tags(instance_name)
            self.unbuild(instance_name, instance_tags)

        except Exception as e:
            AbstractBuilder.LOGGER.error('Delete Package Repository | exception: {}'.format(str(e)))
            raise e

    def get_package_path(self, instance_name):
        return '{}/{}'.format(self.package_name_prefix, instance_name)

    def get_package_name(self, instance_name, instance_tag):
        return '{}/{}.zip'.format(self.get_package_path(instance_name), instance_tag)

    @abstractmethod
    def _generate_package(self, instance, generated_package_dir):
        pass
