import os
import re
import json
import uuid
import subprocess

from copy import deepcopy
from functools import reduce
from django.template import Context, Template
from django.template.loader import render_to_string
from git import Repo
from datetime import datetime

from apps.commons.utilities.file import FileManagement
from apps.commons.generator.builder.abstract import AbstractBuilder
from apps.routines.models import Routine, ActivityConfiguration
from apps.commons.generator.managers.configuration import ConfigurationManager
from apps.commons.utilities.log import Logger
from apps.commons.generator.constants import GeneratingType


class CommonInstanceBuilder(AbstractBuilder):
    TEMPLATE_FOLDER = 'templates'
    logger = Logger("Build")

    def _generate_package(self, routine, generated_package_dir):
        try:
            dependencies = dict()
            routine_uuid = str(routine.uuid)
            standard_template = routine.template

            start_clone = datetime.now()
            self.__clone_repository(standard_template, generated_package_dir)
            self.logger.activity("Clone repository {}".format(datetime.now() - start_clone))

            activities = self.__get_activities(routine)
            instance_properties = self.__get_instance_properties(routine, activities)

            self.__generate_constants_dependencies(dependencies, instance_properties)
            self.__generate_requirement_dependencies(dependencies, standard_template)
            self.__generate_javascript_dependencies(routine_uuid, generated_package_dir)

            for key, value in dependencies.items():
                FileManagement.create_file(generated_package_dir, key, value)

        except Exception as e:
            raise e

    def __clone_repository(self, standard_template, generated_package_dir):
        try:
            temp_path = os.path.join(self.TEMP_DIR_PATH, self.working_uuid)

            repository_location = standard_template.git_repository
            repository_branch = standard_template.git_branch or 'master'
            repository_hash = standard_template.commit_hash

            if repository_hash is not None and repository_hash:
                repo = Repo.clone_from(repository_location, temp_path)
                repo.git.checkout(repository_hash)
            else:
                repo = Repo.clone_from(repository_location, temp_path, branch=repository_branch)

            FileManagement.copy_folder(os.path.join(temp_path, 'back-end'), generated_package_dir)
            FileManagement.remove_file(os.path.join(generated_package_dir, 'app/requirements.txt'))
            FileManagement.remove_file(os.path.join(generated_package_dir, 'config/app.cfg'))
            FileManagement.remove_file(os.path.join(generated_package_dir, 'app/commons/constants.py'))
            FileManagement.remove_folder(os.path.join(generated_package_dir, 'app/js'))

        except Exception as e:
            raise Exception('clone repository error: {}'.format(str(e)))

    def __get_activities(self, routine):
        try:
            activities = {}
            activity_configurations = ActivityConfiguration.objects.filter(routine_id=routine.id)
            for activity_configuration in activity_configurations:
                activities[activity_configuration.activity] = activity_configuration.data

            return activities

        except Exception as e:
            raise e

    def __get_instance_properties(self, routine, activities):
        try:
            dataset_detail = routine.data['dataset']
            default_sorting = dict()

            for section in activities['search']['sections']:
                if section.get('type') == 'data':
                    for field in section.get('fields'):
                        if field.get('enable'):
                            if field.get('sortable') or None:
                                default_sorting[field.get('field_name')] = field.get('sortable')

            standard_process_name = None
            standard_process_type = None

            if routine.standard_process is not None:
                standard_process_name = routine.standard_process.code
                standard_process_type = routine.standard_process.get_type_name()

            configuration_manager = ConfigurationManager()
            activity_configuration = configuration_manager.get_activities_configuration(routine.uuid)

            return {
                'instance_code': routine.code,
                'instance_name': routine.name,
                'instance_uuid': str(routine.uuid),
                'standard_process_name': standard_process_name,
                'standard_process_type': standard_process_type,
                'dataset': dataset_detail.get('dataset_name'),
                'ds_description': dataset_detail.get('description'),
                'journal': dataset_detail.get('journal'),
                'group_type': dataset_detail.get('group_type'),
                'table_type': dataset_detail.get('table_type') or {'code': 'MASTER', 'desc': 'Master'},
                'parameter_dataset': True if dataset_detail.get('dataset_type') == 'PARAMETER' else False,
                'intent': routine.data.get('intent'),
                'template_attributes': routine.data.get('template_attributes') or dict(),
                'additional_attributes': routine.data.get('additional_attributes') or dict(),
                'default_sorting': default_sorting,
                'activity_configuration': activity_configuration,
                'is_virtual': True if routine.generating_type == GeneratingType.PreDefinedMultipleDataset.value else False
            }

        except Exception as e:
            raise e

    def __generate_constants_dependencies(self, dependencies, instance_properties):
        try:
            # Get Activities Roles
            template_path = os.path.join(self.MODULE_DIR_PATH, 'templates')
            data = render_to_string('{}/app/commons/constants.py.template'.format(template_path),
                                    context=instance_properties)

            dependencies.update({
                'app/commons/constants.py': data,
            }, )

        except Exception as e:
            raise Exception('generate constants file error: {}'.format(str(e)))

    def __generate_requirement_dependencies(self, dependencies, standard_template):
        try:
            requirement = standard_template.requirement or ''
            dependencies.update({
                'app/requirements.txt': requirement
            }, )

        except Exception as e:
            raise Exception('generate requirement file error: {}'.format(str(e)))

    def __generate_javascript_dependencies(self, routine_uuid, destination_path):
        try:
            front_end_path = os.path.join(self.TEMP_DIR_PATH, self.working_uuid, 'front-end')

            with open(os.path.join(front_end_path, 'package.json'), 'r') as file:
                data = file.read()
                dest = os.path.join(destination_path, 'app/js')
                FileManagement.create_folder(dest)

                if os.name == 'nt':
                    data_format = '"el-package-task": "jscat ./dist/front-end/runtime-es2015.js ./dist/front-end/main-es2015.js > ' + dest + '/mbs-' + routine_uuid + '.js"'
                    result = re.sub('"el-package-task":.*', data_format, data)
                else:
                    data_format = '"el-package-task": "cat ./dist/front-end/{runtime-es2015,main-es2015}.js > ' + dest + '/mbs-' + routine_uuid + '.js"'
                    result = re.sub('"el-package-task":.*', data_format, data)

                result = re.sub(r'file:.*custom-lib/', f'file:{front_end_path}/custom-lib/', result)

                FileManagement.create_file(front_end_path, 'package.json', result)

            
            start_install = datetime.now()
            command = 'npm install --prefix {}'.format(front_end_path)
            process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                       universal_newlines=True)
            stdout, stderr = process.communicate()

            self.logger.activity("npm install {}".format(datetime.now() - start_install))

            if process.returncode != 0:
                raise Exception('install error | {}'.format(stderr))

            with open(os.path.join(front_end_path, 'src/app/app.module.ts'), 'r') as file:
                data = file.read()
                data = re.sub(r'bootstrap:( ?)\[AppComponent\](\,?)', '', data)

                data_format = "ngDoBootstrap() {\n    const customElement = createCustomElement(MbsElementComponent, { injector: this.injector });\n    customElements.define('mbs-" + routine_uuid + "', customElement);\n  }\n"
                result = re.sub('ngDoBootstrap\(\) \{((.|\n)*)\}', '{}{}'.format(data_format, '}'), data)

                FileManagement.create_file(os.path.join(front_end_path, 'src/app'), 'app.module.ts', result)

            with open(os.path.join(front_end_path, 'src/app/mbs-element/mbs-element.component.scss'), 'r') as file:
                data = file.read()
                data = data.replace('mbs-mbs-element,', 'mbs-mbs-element,\nmbs-{},'.format(routine_uuid))

                FileManagement.create_file(os.path.join(front_end_path, 'src/app/mbs-element'),
                                           'mbs-element.component.scss', data)

            start_build = datetime.now()
            command = 'npm run el-build --prefix {}'.format(front_end_path)
            process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                       universal_newlines=True)
            stdout, stderr = process.communicate()

            self.logger.activity("npm build {}".format(datetime.now() - start_build))

            if process.returncode != 0:
                error = stderr
                error_list = re.findall('ERROR in (.+)', stderr)

                if error_list:
                    # remove ansi escape (color)
                    ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
                    error_list = list(map(lambda er: ansi_escape.sub('', er), error_list))
                    error = ', '.join(error_list)

                raise Exception('build error | {}'.format(error))

        except Exception as e:
            raise Exception('generate javascript file error: {}'.format(str(e)))
