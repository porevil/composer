import copy

from apps.commons.generator.configuration.abstract import AbstractActivities
from apps.commons.generator.configuration.constants import ActivityConstants
from apps.commons.generator.constants import StandardProcessType as StandardProcessTypeEnum
from apps.commons.generator.constants import Activity as ActivityEnum
from apps.commons.generator.constants import ActivitySection as SectionEnum
from apps.commons.generator.constants import StandardProcess as StandardProcessEnum


class PreDefinedSingleDatasetActivities(AbstractActivities):
    COMPONENT_PER_ROW = 2

    def _create_active_fields(self, activity_name, section_type):
        fields = list()
        active_datafields = self._get_active_datafields(activity_name, section_type)
        component_count = 0

        for idx, datafield in enumerate(active_datafields, 1):
            field_name = datafield.get('name')
            parameter_type = datafield.get('parameter_type')
            is_multiple = datafield.get('multiple_value') or False
            is_multiple_embedded_field = (parameter_type == ActivityConstants.PARAMETER_TYPE_EMBEDDED and is_multiple)
            can_enter = (len(fields) > 0 and fields[len(fields)-1].get('field_type') != 'new_line')

            if not is_multiple_embedded_field:
                component_name, attributes = self._get_common_component_with_attributes(activity_name, section_type, datafield)
                attributes = attributes or dict()
                attributes = self._adjust_common_attributes(activity_name, section_type, datafield, component_name, attributes)
                mandatory = self._get_standard_mandatory(activity_name, section_type, field_name)
                label = (datafield.get('pre_setting') or dict()).get('label')
                sorting = 'asc' if (activity_name == ActivityEnum.SEARCH.value and section_type == SectionEnum.DATA.value and idx == 1) else None

                if datafield.get('fieldset') is not None:
                    if can_enter:
                        fields.append(self._create_enter_field())
                    fields.append(self._create_fieldset(datafield['fieldset'], True))
                    component_count = 0

                if self._is_whole_line_component(component_name) and can_enter:
                    fields.append(self._create_enter_field())
                    component_count = 0

                field = self._create_field(datafield, component_name, True, attributes, mandatory, label, None, sorting)
                fields.append(field)

                component_count = component_count + 1
                is_enter = ( (component_count == PreDefinedSingleDatasetActivities.COMPONENT_PER_ROW) \
                                    or ((datafield.get('pre_setting') or dict()).get('end_line') or False) \
                                    or (activity_name == ActivityEnum.SEARCH.value and section_type == SectionEnum.CRITERIA.value) \
                                    or (self._is_whole_line_component(component_name)) ) \
                                and (not (activity_name == ActivityEnum.SEARCH.value and section_type == SectionEnum.DATA.value))

                if is_enter:
                    fields.append(self._create_enter_field())
                    component_count = 0
                
            else:
                active_embedded_fields = list()
                
                multiple_embedded_datafields = datafield.get('fields') or list()
                active_multiple_embedded_datafields = self._get_active_multiple_embedded_datafields(activity_name, section_type, multiple_embedded_datafields)
                active_multiple_embedded_datafields = list(filter(lambda f: f is not None, active_multiple_embedded_datafields))
                embedded_component_count = 0

                for multiple_embedded_datafield in active_multiple_embedded_datafields:
                    embedded_component_name, embedded_attributes = self._get_common_component_with_attributes(activity_name, section_type, multiple_embedded_datafield)
                    embedded_attributes = embedded_attributes or dict()
                    embedded_attributes = self._adjust_common_attributes(activity_name, section_type, multiple_embedded_datafield, embedded_component_name, embedded_attributes)
                    embedded_field = self._create_field(multiple_embedded_datafield, embedded_component_name, True, embedded_attributes)
                    active_embedded_fields.append(embedded_field)
                    embedded_component_count = embedded_component_count + 1
                    if (embedded_component_count == PreDefinedSingleDatasetActivities.COMPONENT_PER_ROW) \
                            or ((multiple_embedded_datafield.get('pre_setting') or dict()).get('end_line') or False):
                        active_embedded_fields.append(self._create_enter_field())
                        embedded_component_count = 0
                
                field = self._create_multiple_embedded_field(datafield, active_embedded_fields)

                if can_enter:
                    fields.append(self._create_enter_field())
                fields.append(field)
                component_count = 0

        return fields


    def _get_active_datafields(self, activity_name, section_type):
        datafields = list()
        if activity_name == ActivityEnum.CREATE.value:
            if section_type == SectionEnum.DATA.value:
                # datafields = list(filter(lambda f: ((f.get('pre_setting') or dict()).get('sequence') is not None 
                #                                         or ((f.get('pre_setting') or dict()).get('top_field') or False)
                #                                         or (f.get('pre_setting') or dict()).get('default_value'))
                #                                     and not (f.get('business_keygen') or dict()).get('id')
                #                                     and not (f.get('auto_gen') or False)
                #                             , self.datafields))
                datafields = list(filter(lambda f: (f.get('pre_setting') or dict()).get('sequence') is not None 
                                                    and not (f.get('business_keygen') or dict()).get('id')
                                                    and not (f.get('auto_gen') or False)
                                            , self.datafields))
                datafields = sorted(datafields, key=lambda f: (f.get('pre_setting') or dict()).get('sequence') or 999)

        elif activity_name == ActivityEnum.UPDATE.value:
            if section_type == SectionEnum.DATA.value:
                # datafields = list(filter(lambda f: ((f.get('pre_setting') or dict()).get('sequence') is not None
                #                                         or ((f.get('pre_setting') or dict()).get('top_field') or False))
                #                                     and not (f.get('business_keygen') or dict()).get('id')
                #                                     and not (f.get('auto_gen') or False)
                #                                     and not ((f.get('pre_setting') or dict()).get('uneditable') or False)
                #                             , self.datafields))
                datafields = list(filter(lambda f: ((f.get('pre_setting') or dict()).get('sequence') is not None)
                                                    and not (f.get('business_keygen') or dict()).get('id')
                                                    and not (f.get('auto_gen') or False)
                                                    and not ((f.get('pre_setting') or dict()).get('auto_create') or False)
                                                    and not ((f.get('pre_setting') or dict()).get('uneditable') or False)
                                            , self.datafields))
                datafields = list(filter(lambda f: (f.get('name') == ActivityConstants.TECHNICAL_FIELD_EFFECTIVE_DATE 
                                                        and self.standard_process.code in (StandardProcessEnum.I9.value
                                                                                            , StandardProcessEnum.I12.value
                                                                                            , StandardProcessEnum.I13.value))
                                                    or f.get('name') not in ActivityConstants.TECHNICAL_FIELDS
                                            , datafields))
                datafields = sorted(datafields, key=lambda f: (f.get('pre_setting') or dict()).get('sequence') or 999)
                
        elif activity_name == ActivityEnum.SEARCH.value:
            if section_type == SectionEnum.CRITERIA.value:
                datafields = list(filter(lambda f: (f.get('pre_setting') or dict()).get('search_field') or False, self.datafields))
                datafields = sorted(datafields, key=lambda f: (f.get('pre_setting') or dict()).get('sequence') or 999)
            elif section_type == SectionEnum.DATA.value:
                datafields = list(filter(lambda f: (f.get('pre_setting') or dict()).get('result_field') or False, self.datafields))
                datafields = sorted(datafields, key=lambda f: (f.get('pre_setting') or dict()).get('sequence') or 999)

        elif activity_name == ActivityEnum.VIEW.value:
            if section_type == SectionEnum.DATA.value:
                # datafields = list(filter(lambda f: (f.get('pre_setting') or dict()).get('sequence') is not None
                #                                         or ((f.get('pre_setting') or dict()).get('top_field') or False)
                #                                 , self.datafields))
                datafields = list(filter(lambda f: (f.get('pre_setting') or dict()).get('sequence') is not None, self.datafields))
                datafields = sorted(datafields, key=lambda f: (f.get('pre_setting') or dict()).get('sequence') or 999)
                
        datafields = self._adjust_standard_datafields(activity_name, section_type, datafields)
        
        return datafields


    def _get_active_multiple_embedded_datafields(self, activity_name, section_type, embedded_datafields):
        datafields = list()

        if activity_name == ActivityEnum.CREATE.value or activity_name == ActivityEnum.UPDATE.value \
                or activity_name == ActivityEnum.VIEW.value:
            if section_type == SectionEnum.DATA.value:
                datafields = list(filter(lambda f: (f.get('pre_setting') or dict()).get('sequence') is not None, embedded_datafields))
                datafields = sorted(datafields, key=lambda f: (f.get('pre_setting') or dict()).get('sequence'))

        return datafields
