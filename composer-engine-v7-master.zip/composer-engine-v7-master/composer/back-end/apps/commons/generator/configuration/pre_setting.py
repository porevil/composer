from apps.generator_setting.models import DatafieldSetting, DatasetSetting, DatasetConfiguration

class PreSettingManager:

    def __init__(self):
        self.dataset_setting_cache = dict()


    def get(self, dataset_name):
        if dataset_name not in self.dataset_setting_cache:
            self.dataset_setting_cache[dataset_name] = self._load(dataset_name)
        return self.dataset_setting_cache[dataset_name]
        

    def _load(self, dataset_name):
        # declare inner method
        def get_key(datafield):
            name = datafield.field_id.field_name
            reference_name = datafield.field_id.ref_name
            return '{}.{}'.format(reference_name, name) if reference_name is not None else name

        def override_datafield_setting(datafield):
            field_name = datafield.field_id.field_name
            datafield_setting = DatafieldSetting.objects.filter(name=field_name).first()

            if datafield_setting is None or datafield_setting.config is None:
                return

            if datafield.config is None:
                datafield.config = dict()

            datafield_config = datafield_setting.config
            for key, value in datafield_config.items():
                if datafield.config.get(key) is None:
                    datafield.config[key] = value

        # process
        pre_setting = dict()
        dataset_settings = DatasetSetting.objects.filter(dataset_configuration_id__dataset_id__dataset_name=dataset_name)
        if not dataset_settings:
            return dict()

        for datafield in dataset_settings:
            reference_name = datafield.field_id.ref_name
            # not embedded field
            for key, value in datafield.config.items():
                if type(value) is dict:
                    if 'overridden' in value:
                        datafield.config[key] = None
                        if value.get('overridden'):
                            datafield.config[key] = value.get('value')

            if reference_name is None:
                override_datafield_setting(datafield)
                key = get_key(datafield)
                pre_setting[key] = datafield.config
                pre_setting[key]['sequence'] = datafield.sequence
            else:
                pre_setting_embedded = dict()
                multiple_embedded_config_fields = DatasetSetting.objects.filter(
                    dataset_configuration_id__dataset_id__dataset_name=dataset_name, \
                    field_id__ref_name=reference_name)
                
                for embedded_config_field in multiple_embedded_config_fields:
                    override_datafield_setting(embedded_config_field)
                    embedded_key = get_key(embedded_config_field)
                    pre_setting_embedded[embedded_key] = embedded_config_field.config
                    pre_setting_embedded[embedded_key]['sequence'] = embedded_config_field.sequence

                dataset_setting = DatasetSetting.objects.filter(dataset_configuration_id__dataset_id__dataset_name=dataset_name, \
                                                                field_id__field_name=reference_name).first()

                pre_setting[key] = dataset_setting.config
                pre_setting[key]['fields'] = pre_setting_embedded
                pre_setting[key]['sequence'] = dataset_setting.sequence

        return pre_setting

        