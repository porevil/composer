import copy

from apps.commons.generator.configuration.pre_setting import PreSettingManager
from apps.commons.generator.configuration.constants import ActivityConstants
from apps.generator_setting.models import VirtualDatafieldConfig
from apps.generator_setting.models import DatasetSetting
from apps.commons.connectors.metadata import Metadata
from apps.metadata.models import Datafield


class Singleton:
    __instance = None
    __dataset_cache = dict()

    @staticmethod
    def get_dataset_metadata(dataset_name, dataset_version):
        try:
            if Singleton.__instance == None:
                Singleton()

            if Singleton.__dataset_cache.get(dataset_name+dataset_version) is None:
                Singleton.__dataset_cache[dataset_name+dataset_version] = Metadata.get(None, dataset_name)

            return Singleton.__dataset_cache.get(dataset_name+dataset_version)
        except Exception as e:
            raise e

    def __init__(self):
        if Singleton.__instance != None:
            raise Exception("This class is a singleton!")
        else:
            Singleton.__instance = self


class ActivityUtilities:

    @staticmethod
    def get_flat_datafields_by_dataset_metadata(dataset_metadata):
        dataset_metadata = copy.deepcopy(dataset_metadata)
        dataset_name = dataset_metadata['dataset_name']
        datafields = dataset_metadata['fields']

        pre_setting_fields = PreSettingManager().get(dataset_name)
        extended_datafields = list()
        delete_idxes = list()

        for idx, datafield in enumerate(datafields):
            field_name = datafield.get('name')
            parameter_type = datafield.get('parameter_type')
            is_multiple = datafield.get('multiple_value') or False
            
            if not (parameter_type == ActivityConstants.PARAMETER_TYPE_EMBEDDED and is_multiple):
                if parameter_type == ActivityConstants.PARAMETER_TYPE_TISCO:
                    delete_idxes.append(idx)
                    tisco_param_metadata = datafield['parameter_ref']['dataset']
                    tisco_param_dataset = tisco_param_metadata['dataset_name']
                    tisco_param_datafields = tisco_param_metadata['fields']
                    for tisco_param_datafield in tisco_param_datafields:
                        tisco_param_datafield['reference_name'] = field_name
                        tisco_param_datafield['reference_dataset'] = tisco_param_dataset
                        tisco_param_datafield['tisco_param'] = True

                        # Add attributes (from pre-setting)
                        if tisco_param_datafield.get('name') not in ActivityConstants.TECHNICAL_FIELDS:
                            ActivityUtilities.add_pre_setting_attributes(tisco_param_datafield, pre_setting_fields)
                            
                        # Remove de unused attributes
                        ActivityUtilities.remove_de_unused_attributes(tisco_param_datafield)

                    extended_datafields = extended_datafields + tisco_param_datafields
                elif parameter_type == ActivityConstants.PARAMETER_TYPE_EMBEDDED:
                    delete_idxes.append(idx)
                    single_embedded_datafields = datafield['fields']
                    for single_embedded_datafield in single_embedded_datafields:
                        single_embedded_datafield['reference_name'] = field_name
                        single_embedded_datafield['reference_dataset'] = None
                        single_embedded_datafield['tisco_param'] = False
                        
                        # Add attributes (from pre-setting)
                        if single_embedded_datafield.get('name') not in ActivityConstants.TECHNICAL_FIELDS:
                            ActivityUtilities.add_pre_setting_attributes(single_embedded_datafield, pre_setting_fields)
                            
                        # Remove de unused attributes
                        ActivityUtilities.remove_de_unused_attributes(single_embedded_datafield)
                        
                    extended_datafields = extended_datafields + single_embedded_datafields
                else:
                    datafield['tisco_param'] = False

                    # Add attributes (from pre-setting)
                    ActivityUtilities.add_pre_setting_attributes(datafield, pre_setting_fields)

                    # Remove de unused attributes
                    ActivityUtilities.remove_de_unused_attributes(datafield)
            else:
                pre_setting_embedded_fields = (pre_setting_fields.get(field_name) or dict()).get('fields') or dict()
                multiple_embedded_datafields = datafield['fields']
                for idx, embedded_datafield in enumerate(multiple_embedded_datafields):
                    embedded_datafield['reference_name'] = field_name
                    embedded_field_name = embedded_datafield.get('name')

                    # Add attributes (from pre-setting)
                    if embedded_field_name not in ActivityConstants.TECHNICAL_FIELDS:
                        ActivityUtilities.add_pre_setting_attributes(embedded_datafield, pre_setting_embedded_fields)

                    # Remove de unused attributes
                    ActivityUtilities.remove_de_unused_attributes(embedded_datafield)

                datafield['pre_setting'] = dict()
                datafield['pre_setting']['sequence'] = (pre_setting_fields.get(field_name) or dict()).get('sequence')
                datafield['tisco_param'] = False
           
        for idx, delete_idx in enumerate(delete_idxes):
            del datafields[delete_idx - idx]

        datafields = datafields + extended_datafields
        return datafields


    @staticmethod
    def get_flat_datafields_by_virtual_name(virtual_name, main_dataset_name, parent_field_id=None):
        try:
            virtual_configurations = VirtualDatafieldConfig.objects.filter(element_id__group_id__name=virtual_name)
            
            if parent_field_id is not None:
               virtual_configurations = list(filter(lambda vc: (vc.parent_virtual_config is not None) and 
                    (vc.parent_virtual_config.field_id_id == parent_field_id), virtual_configurations)) 

            else:
                virtual_configurations = list(filter(lambda vc: vc.parent_virtual_config is None 
                    , virtual_configurations))

            results = list()
            for virtual_configuration in virtual_configurations:
                dataset_name = virtual_configuration.field_id.dataset_id.dataset_name
                dataset_version = virtual_configuration.field_id.dataset_id.version
                field_id = virtual_configuration.field_id_id
                field_name = virtual_configuration.field_id.field_name
                element_id = virtual_configuration.element_id_id

                if field_id in list(map(lambda r: r.get('field_id'), results)) or virtual_configuration.sequence is None:
                    continue
                
                pre_setting_field = dict()
                for key, value in virtual_configuration.config.items():
                    if type(value) is dict:
                        if 'overridden' in value:
                            virtual_configuration.config[key] = None
                            if value.get('overridden'):
                                virtual_configuration.config[key] = value.get('value')
                
                pre_setting_field[field_name] = virtual_configuration.config
                pre_setting_field[field_name]['sequence'] = virtual_configuration.sequence

                dataset_metadata = Singleton.get_dataset_metadata(dataset_name, dataset_version)
                datafields = dataset_metadata['fields']

                for datafield in datafields:
                    if field_name == datafield.get('name'):
                        parameter_type = datafield.get('parameter_type')
                        parameter_ref_metadata = (datafield.get('parameter_ref') or dict()).get('dataset')

                        if parameter_type in [ActivityConstants.PARAMETER_TYPE_MASTER, ActivityConstants.PARAMETER_TYPE_PUBLIC] \
                                and parameter_ref_metadata:
                            parameter_ref_dataset = (parameter_ref_metadata or dict()).get('dataset_name')

                            reference_name = ActivityUtilities.find_reference_field(field_id, parameter_ref_dataset, main_dataset_name, True)
                            if reference_name is not None:
                                datafield['reference_name'] = reference_name
                                print('########################## field_name: {}, reference_name: {}'.format(field_name, reference_name))
                        
                        # datafield['name'] = '{}.{}'.format(datafield['reference_name'], datafield['name']) if datafield.get('reference_name') is not None else datafield['name']
                        datafield['tisco_param'] = False    
                        datafield['element_id'] = element_id
                        datafield['field_id'] = field_id

                        # Add attributes (from pre-setting)
                        ActivityUtilities.add_pre_setting_attributes(datafield, pre_setting_field, True)

                        # Remove de unused attributes
                        ActivityUtilities.remove_de_unused_attributes(datafield)

                        results.append(datafield)
                        break

            return results

        except Exception as e:
            raise e


    @staticmethod
    def find_reference_field(field_id, child_dataset_name, main_dataset_name, first_level=False):
        if field_id is None or child_dataset_name is None:
            return None

        meta_datafields = Datafield.objects.filter(id=field_id)
        if not meta_datafields:
            return None

        for meta_datafield in meta_datafields:
            if meta_datafield.dataset_id.dataset_name == main_dataset_name and meta_datafield.id == field_id:
                if not first_level:
                    return '{}'.format(meta_datafield.field_name)
                else:
                    return None

        else:
            parent_meta_datafields = Datafield.objects.filter(child_dataset_id__dataset_name=meta_datafield.dataset_id.dataset_name)
            for parent_meta_datafield in parent_meta_datafields:
                embed_field = ActivityUtilities.find_reference_field(parent_meta_datafield.id, parent_meta_datafield.dataset_id.dataset_name, main_dataset_name)
                if embed_field is not None:
                    print('##################### field_name: {}, embed_field: {}'.format(parent_meta_datafield.field_name, embed_field))
                    return '{}'.format(embed_field)
            else:
                return None


    @staticmethod
    def add_pre_setting_attributes(datafield, pre_setting_fields=dict(), ignore_reference_name=False):
        key_function = lambda f: '{}.{}'.format(f['reference_name'], f['name']) \
                                        if f.get('reference_name') is not None else f['name']
        
        if ignore_reference_name == False:
            pre_setting_field = pre_setting_fields.get(key_function(datafield)) or dict()
        else:
            pre_setting_field = pre_setting_fields.get(datafield['name']) or dict()
            datafield['name'] = '{}.{}'.format(datafield['reference_name'], datafield['name']) if datafield.get('reference_name') is not None else datafield['name']


        datafield['pre_setting'] = {
            'sequence': pre_setting_field.get('sequence'),
            'placeholder': pre_setting_field.get('placeholder'),
            # 'top_field': pre_setting_field.get('top_field'),
            'auto_create': pre_setting_field.get('auto_create'),
            'search_field': pre_setting_field.get('search_field'),
            'result_field': pre_setting_field.get('result_field'),
            'business_reference': pre_setting_field.get('business_reference'),
            'uneditable': pre_setting_field.get('uneditable'),
            'end_line': pre_setting_field.get('end_line'),
            'data_dependency': pre_setting_field.get('data_dependency'),
            'dependency_filter': pre_setting_field.get('dependency_filter'),
            'autofill': pre_setting_field.get('autofill'),
            'autofill_field': pre_setting_field.get('autofill_field'),
            'label': pre_setting_field.get('label'),
            'hint': pre_setting_field.get('hint'),
            'hint_search': pre_setting_field.get('hint_search'),
            'default_value': pre_setting_field.get('default_value'),
            'text_component': pre_setting_field.get('text_component'),
            'number_format': pre_setting_field.get('number_format'),
            'text_format': pre_setting_field.get('text_format'),
            'number_unit': pre_setting_field.get('number_unit'),
            'datetime_display_type': pre_setting_field.get('datetime_display_type'),
            'datetime_year_format': pre_setting_field.get('datetime_year_format'),
            'toggle_desc': pre_setting_field.get('toggle_desc'),
            'toggle_hide_unassigned': pre_setting_field.get('toggle_hide_unassigned'),
            'relative_data_component': pre_setting_field.get('relative_data_component'),
            'relative_data_condition': pre_setting_field.get('relative_data_condition'),
        }


    @staticmethod
    def remove_de_unused_attributes(datafield):
        datafield.pop('sequence', None)
        datafield.pop('mark_search_field', None)
        datafield.pop('show_in_result_screen', None)
        datafield.pop('reference', None)
        datafield.pop('top', None)
        datafield.pop('end_line', None)
