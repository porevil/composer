import json

from apps.commons.generator.configuration.abstract import AbstractActivities
from apps.commons.generator.configuration.constants import ActivityConstants
from apps.commons.generator.configuration.components import *
from apps.commons.generator.constants import Activity as ActivityEnum
from apps.commons.generator.constants import ActivitySection as SectionEnum
from apps.commons.generator.constants import StandardProcess as StandardProcessEnum


class UserDefinedActivities(AbstractActivities):

    def _create_active_fields(self, activity_name, section_type):
        returned_fields = list()
        section_body = self.additional_config.get('section_body') or list()
        footnote = self.additional_config.get('footnote') or list()

        # Relation Fields
        if (activity_name in (ActivityEnum.CREATE.value, ActivityEnum.UPDATE.value, ActivityEnum.VIEW.value) \
                    and section_type == SectionEnum.DATA.value) \
                or (activity_name == ActivityEnum.SEARCH.value and section_type == SectionEnum.CRITERIA.value):
            relation_datafields = self._get_relation_datafields()
            for datafield in relation_datafields:
                relation_field_info = datafield.get('dataset_relations_info')
                if relation_field_info is not None \
                        and len(relation_field_info) > 0 and 'dataset_name' in relation_field_info[0] \
                        and 'field_name' in relation_field_info[0]:
                    relation_field_name = relation_field_info[0]['field_name']
                    relation_dataset_name = relation_field_info[0]['dataset_name']
                    ref_metadata = self._get_related_dataset_metadata(relation_dataset_name)
                    relation_field_type = datafield.get('type')
                    component_name = ComponentMaster.name
                    ref_metadata['creatable'] = False
                    attributes = ComponentMaster.attributes_by_ref_metadata(relation_field_name, relation_field_type, ref_metadata)
                    attributes = self._adjust_common_attributes(activity_name, section_type, datafield, component_name, attributes)
                    returned_field = self._create_field(datafield, component_name, True, attributes)
                    returned_fields.append(returned_field)
                    returned_fields.append(self._create_enter_field()) 

        # Section Body
        if activity_name in (ActivityEnum.CREATE.value, ActivityEnum.UPDATE.value, ActivityEnum.VIEW.value) \
                and section_type == SectionEnum.DATA.value:
            for fieldset in section_body:
                legend = fieldset.get('title') or '-'
                fields = fieldset.get('fields') or list()
                returned_fields.append(self._create_fieldset(legend))

                for field_detail in fields:
                    field_name = field_detail.get('field_name')
                    field_seq = field_detail.get('seq_no') or ''
                    field_title = field_detail.get('title') or ''
                    field_meta = self._get_datafield(field_name, None, True)

                    if field_name is None or field_meta is None:
                        continue

                    label = '{}. {}'.format(field_seq, field_title)
                    component_name, attributes = self._get_component_with_attributes(activity_name, section_type, field_meta, field_detail)
                    attributes = self._adjust_common_attributes(activity_name, section_type, field_meta, component_name, attributes)
                    returned_field = self._create_field(field_meta, component_name, True, attributes, None, label)
                    returned_fields.append(returned_field)
                    returned_fields.append(self._create_enter_field())

        # Footnote
        if (activity_name in (ActivityEnum.CREATE.value, ActivityEnum.UPDATE.value, ActivityEnum.VIEW.value) \
                    and section_type == SectionEnum.DATA.value):
            for fieldset in footnote:
                legend = fieldset.get('title') or '-'
                contents = fieldset.get('contents') or list()
                returned_fields.append(self._create_fieldset(legend))

                for content in contents:
                    returned_fields.append(self._create_information_field(content))
                    returned_fields.append(self._create_enter_field())

        # Custom Fields
        datafields = list()

        if activity_name == ActivityEnum.SEARCH.value and section_type == SectionEnum.DATA.value:
            datafields = datafields + [self._get_datafield(ActivityConstants.TECHNICAL_FIELD_EFFECTIVE_DATE)]

        datafields = self._adjust_standard_datafields(activity_name, section_type, datafields)
        datafields = list(filter(lambda f: f is not None, datafields))

        component_per_row = 2
        component_count = 0
        for idx, datafield in enumerate(datafields, 1):
            field_name = datafield['name']
            parameter_type = datafield.get('parameter_type')
            can_enter = (len(returned_fields) > 0 and returned_fields[len(returned_fields)-1].get('field_type') != 'new_line')

            component_name, attributes = self._get_common_component_with_attributes(activity_name, section_type, datafield)
            attributes = attributes or dict()
            attributes = self._adjust_common_attributes(activity_name, section_type, datafield, component_name, attributes)
            mandatory = self._get_standard_mandatory(activity_name, section_type, field_name)
            sorting = 'asc' if (activity_name == ActivityEnum.SEARCH.value and section_type == SectionEnum.DATA.value and idx == 1) else None

            if datafield.get('fieldset') is not None:
                if can_enter:
                    returned_fields.append(self._create_enter_field())
                returned_fields.append(self._create_fieldset(datafield['fieldset'], True))
                component_count = 0
            
            field = self._create_field(datafield, component_name, True, attributes, mandatory, None, None, sorting)
            returned_fields.append(field)

            component_count = component_count + 1
            is_enter = (component_count == component_per_row) \
                            and not (activity_name == ActivityEnum.SEARCH.value and section_type == SectionEnum.DATA.value)

            if is_enter:
                returned_fields.append(self._create_enter_field())
                component_count = 0

        return returned_fields


    def _get_component_with_attributes(self, activity_name, section_type, field_meta, field_detail):
        # Get Widget Type
        widget_type = field_detail.get('widget_type')

        # Get Field Name and Field Type
        field_name = field_meta.get('name')
        field_type = field_meta.get('type')

        # Case: Simple Widgets
        if widget_type in (1, 7):
            if field_type in ('integer', 'decimal'):
                number_format = field_detail.get('number_format')
                return ComponentNumber.name, ComponentNumber.attributes(format=number_format)
            return ComponentTextbox.name, ComponentTextbox.attributes(type=field_type)

        if widget_type == 2:
            return ComponentDatePicker.name, ComponentDatePicker.attributes()

        # Case: Complex Widgets
        widget_options = field_detail.get('widget_options') or list()
        limit_selected_items = field_detail.get('limit_selected_items')
        limit_displayed_items = field_detail.get('limit_displayed_items')
        other_option_field_name = field_detail.get('other_option_field_name')

        is_parameter_option = False
        custom_options = []
        allow_other = False
        other_field_name = None
        parameter_dataset_name = None
        parameter_display_field = None
        parameter_value_field = None

        for idx, option in enumerate(widget_options, 1):
            value = idx
            display = option.get('text', '')

            if display.startswith('@'): # case parameter
                is_parameter_option = True
                parameter_dataset_name = display[1:]
                parameter_value_field = option.get('field_value')
                parameter_display_field = option.get('field_display')
                break

            if display.startswith('$'): # case custom with other
                allow_other = True
                model_prefix = ActivityEnum.UPDATE.value if activity_name == ActivityEnum.VIEW.value else activity_name
                other_field_name = model_prefix + '.' + other_option_field_name
                value = 0
                display = display[1:]

            custom_options.append({
                'value': value,
                'display': display
            })

        if is_parameter_option == True:
            parameter_reference = field_meta.get('parameter_ref')
            parameter_ref_metadata = (parameter_reference or dict()).get('dataset')
            if widget_type in (3, 5):
                return ComponentDropdown.name, ComponentDropdown.attributes_by_parameter_reference(field_name, parameter_reference)
            if widget_type == 4:
                show_reference_code = not (activity_name == ActivityEnum.VIEW.value)
                return ComponentDropdownMultipleValue.name, ComponentDropdownMultipleValue.attributes_by_parameter_reference(field_name
                                                                                                                            , parameter_reference
                                                                                                                            , show_reference_code=show_reference_code)
                                                                                                                            
        if widget_type == 3:
            options = json.dumps(custom_options, ensure_ascii=False)
            return ComponentRadioGroup.name, ComponentRadioGroup.attributes(options, show_other=allow_other
                                                                                    , other_field_name=other_field_name)

        if widget_type == 4:
            options = json.dumps(custom_options, ensure_ascii=False)
            return ComponentCheckboxGroup.name, ComponentCheckboxGroup.attributes(options, number_of_selected=limit_selected_items
                                                                                            , show_other=allow_other
                                                                                            , other_field_name=other_field_name)

        if widget_type == 5:
            options = json.dumps(custom_options, ensure_ascii=False)
            return ComponentRanking.name, ComponentRanking.attributes(options, number_of_selected=limit_selected_items)

        if widget_type == 6:
            min_indicator_text = None
            max_indicator_text = None

            if len(custom_options) >= 2:
                min_indicator_text = custom_options[0]['display']
                max_indicator_text = custom_options[1]['display']

            return ComponentRating.name, ComponentRating.attributes(number_of_selected=limit_displayed_items
                                                                        , min_indicator_text=min_indicator_text
                                                                        , max_indicator_text=max_indicator_text)

        return self.default_component_name, dict()

    
    def _get_relation_datafields(self):
        relation_datafields = list(filter(lambda f: (f.get('dataset_relations') or False) \
                                                    and f.get('name') not in ActivityConstants.TECHNICAL_FIELDS , self.datafields))
        return relation_datafields
