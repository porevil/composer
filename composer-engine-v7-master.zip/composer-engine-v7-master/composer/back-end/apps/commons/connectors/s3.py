from botocore.exceptions import ClientError
from boto3.session import Session

from apps.commons.utilities.log import Logger


class S3Client:
    LOGGER = Logger('S3 Client')

    def __init__(self, **kwargs):
        try:
            S3Client.LOGGER.activity('connect s3')
            self.client = Session(
                aws_access_key_id=kwargs.get('aws_access_key_id'),
                aws_secret_access_key=kwargs.get('aws_secret_access_key'),
                region_name=kwargs.get('aws_region'),
            ).client('s3')
        except Exception as e:
            S3Client.LOGGER.error('Initial | exception: {}'.format(str(e)))
            raise e

    def upload_file(self, filename, bucket, key):
        try:
            self.client.upload_file(filename, bucket, key)
        except ClientError as e:
            S3Client.LOGGER.error('Upload File | exception: {}'.format(str(e)))
            raise e

    def download_file(self, bucket, key, filename):
        try:
            self.client.download_file(bucket, key, filename)
        except ClientError as e:
            S3Client.LOGGER.error('Download File | exception: {}'.format(str(e)))
            raise e

    def list_objects(self, bucket, prefix=None):
        try:
            response = self.client.list_objects(
                Bucket=bucket,
                Prefix=prefix or '',
            )
            return [] if 'Contents' not in response else response['Contents']
        except ClientError as e:
            S3Client.LOGGER.error('List Objects | exception: {}'.format(str(e)))
            raise e

    def delete_object(self, bucket, key):
        try:
            self.client.delete_object(
                Bucket=bucket,
                Key=key,
            )
        except ClientError as e:
            S3Client.LOGGER.error('Delete Object | exception: {}'.format(str(e)))
            raise e
