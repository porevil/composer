from botocore.exceptions import ClientError
from boto3.session import Session

from apps.commons.utilities.log import Logger


class CodeDeployClient:
    LOGGER = Logger('CodeDeploy Client')

    def __init__(self, **kwargs):
        try:
            CodeDeployClient.LOGGER.activity('connect code deploy')
            self.client = Session(
                aws_access_key_id=kwargs.get('aws_access_key_id'),
                aws_secret_access_key=kwargs.get('aws_secret_access_key'),
                region_name=kwargs.get('aws_region'),
            ).client('codedeploy')
        except Exception as e:
            CodeDeployClient.LOGGER.error('Initial | exception: {}'.format(str(e)))
            raise e

    def create_deployment_group(self, application_name, deployment_group_name, ec2_name, service_role_arn):
        try:
            return self.client.create_deployment_group(
                applicationName=application_name,
                deploymentGroupName=deployment_group_name,
                ec2TagFilters=[{
                    'Key': 'Name',
                    'Value': ec2_name,
                    'Type': 'KEY_AND_VALUE'
                }],
                serviceRoleArn=service_role_arn,
                deploymentStyle={
                    'deploymentType': 'IN_PLACE',
                    'deploymentOption': 'WITHOUT_TRAFFIC_CONTROL'
                }
            )
        except ClientError as e:
            CodeDeployClient.LOGGER.error('Create Deployment Group | exception: {}'.format(str(e)))
            raise e

    def delete_deployment_group(self, application_name, deployment_group_name):
        try:
            return self.client.delete_deployment_group(
                applicationName=application_name,
                deploymentGroupName=deployment_group_name,
            )
        except ClientError as e:
            CodeDeployClient.LOGGER.error('Delete Deployment Group | exception: {}'.format(str(e)))
            raise e

    def create_deployment(self, application_name, deployment_group_name, bucket_name, key):
        """

        :param application_name: string
        :param deployment_group_name: group
        :param bucket_name: s3-bucket name
        :param key: simulate path in s3 ex. packages/{{instance.uuid}}/{{build_no}}.zip
        :return:
        """
        try:
            deployment = self.client.create_deployment(
                applicationName=application_name,
                deploymentGroupName=deployment_group_name,
                fileExistsBehavior='OVERWRITE',
                revision={
                    'revisionType': 'S3',
                    's3Location': {
                        'bucket': bucket_name,
                        'key': key,
                        'bundleType': 'zip'
                    }
                }
            )

            return deployment['deploymentId']
        except ClientError as e:
            CodeDeployClient.LOGGER.error('Create Deployment | exception: {}'.format(str(e)))
            raise e

    def get_waiter(self, waiter_name):
        try:
            return self.client.get_waiter(waiter_name)
        except ClientError as e:
            CodeDeployClient.LOGGER.error('Get Waiter | exception: {}'.format(str(e)))
            raise e
