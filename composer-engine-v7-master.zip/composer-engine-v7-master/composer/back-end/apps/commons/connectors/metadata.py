import sys
import json
import requests
import os

from django.conf import settings
from apps.configurations.models import SubState
from apps.commons.generator.systemconfig import MetadataServiceConfig
from apps.commons.utilities.log import Logger
from apps.commons.error.exception import ExternalServerErrorException, ConfigurationErrorException


class Metadata:

    LOGGER = Logger('Core Connector', 'Metadata')
    RESPONSE_CODE_SUCCESS = "30000"


    @staticmethod
    def list(sub_state=None):
        try:
            return Metadata.get(sub_state, None)

        except Exception as e:
            raise e


    @staticmethod
    def get(sub_state=None, dataset_name=None):
        try:
            if sub_state is None:
                sub_state = SubState.default()

            Metadata.LOGGER.debug('get metadata | dataset name: {}'.format(dataset_name))
            Metadata.LOGGER.debug('get metadata | sub state: {}'.format(sub_state.name))

            endpoint, header = Metadata._get_endpoint_and_header(sub_state)
            request_body = { 'dataset_name': dataset_name } if dataset_name else dict()
            response = requests.post(endpoint, headers=header, data=json.dumps(request_body))

            Metadata.LOGGER.debug('get metadata | status code: {}'.format(response.status_code))
            if response.status_code != 200:
                raise ExternalServerErrorException('data engine service error (status code - {})'.format(response.status_code))

            try:
                response = response.json()
            except Exception:
                raise ExternalServerErrorException('data engine service error (response - {})'.format(response.text))

            if response["msg_code"] != Metadata.RESPONSE_CODE_SUCCESS:
                raise ExternalServerErrorException("data engine service error ({} - {})".format(response["msg_code"], response["msg_detail"]))

            return response["response_data"]

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            Metadata.LOGGER.error('get metadata | exception: {}'.format(exception_message))
            raise e

    
    @staticmethod
    def _get_endpoint_and_header(sub_state):
        try:
            virtual_name = sub_state.virtual_name or None
            service_config = MetadataServiceConfig.get(sub_state.state)

            if service_config is None:
                raise ConfigurationErrorException("Metadata service is not configured")

            endpoint = service_config.get('endpoint')
            service_account = service_config.get('service_account')
            mule_client_id = service_config.get('mule_client_id')
            mule_client_secret = service_config.get('mule_client_secret')

            app_meta = {
                'user_id': service_account,
                'user_name': 'channel service account',
            }

            # app_meta['env'] = virtual_name
            app_meta['sub_state'] = virtual_name

            return endpoint, { 
                'content-Type': 'application/json',
                'app-meta': json.dumps(app_meta),
                'client_id': mule_client_id,
                'client_secret': mule_client_secret,
            }

        except Exception as e:
            raise e
