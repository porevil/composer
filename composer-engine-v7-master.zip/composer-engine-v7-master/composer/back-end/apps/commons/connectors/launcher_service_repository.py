import json
import requests
import traceback
import os
import sys

from apps.configurations.models import State
from apps.commons.utilities.log import Logger
from apps.commons.generator.systemconfig import LauncherServiceConfig
from apps.commons.error.exception import *


class LauncherServiceRepository():
    LOGGER = Logger('Core Connector', 'Launcher')
    RESPONSE_CODE_SUCCESS = "10000"

    @staticmethod
    def list(state):
        try:
            LauncherServiceRepository.LOGGER.debug('list service respository | sub state: {}'.format(state.name))

            endpoint, header = LauncherServiceRepository._get_endpoint_and_header(state)
            endpoint = '{}{}/'.format(endpoint, 'service_repository')

            response = requests.get(endpoint, headers=header)

            LauncherServiceRepository.LOGGER.debug('list service respository | response status: {}'.format(response.status_code))
            if response.status_code != 200:
                raise ExternalServerErrorException('launcher service error (status code - {})'.format(response.status_code))

            LauncherServiceRepository.LOGGER.debug('list service respository | response data: {}'.format(response.text))

            try:
                response = response.json()
            except Exception:
                raise ExternalServerErrorException('launcher service error (response - {})'.format(response.text))

            if response['meta']['response_code'] != LauncherServiceRepository.RESPONSE_CODE_SUCCESS:
                raise ExternalServerErrorException('launcher service error ({} - {})'.format(response['meta']['response_code'], response['meta']['response_desc']))
            
            return response
        
        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            LauncherServiceRepository.LOGGER.error('list service respository | exception: {}'.format(exception_message))
            raise e



    @staticmethod
    def retrieve(state, service_repository_id):
        try:
            LauncherServiceRepository.LOGGER.debug('retrieve service repository | sub state: {}'.format(state.name))
            LauncherServiceRepository.LOGGER.debug('retrieve service repository | service repository id: {}'.format(service_repository_id))

            if service_repository_id is None:
                raise Exception('service repository id is required')

            endpoint, header = LauncherServiceRepository._get_endpoint_and_header(state)
            endpoint = '{}{}/{}/'.format(endpoint, 'service_repository', service_repository_id)

            response = requests.get(endpoint, headers=header)

            LauncherServiceRepository.LOGGER.debug('retrieve service repository | response status: {}'.format(response.status_code))
            if response.status_code != 200:
                raise ExternalServerErrorException('launcher service error (status code - {})'.format(response.status_code))

            LauncherServiceRepository.LOGGER.debug('retrieve service repository | response data: {}'.format(response.text))

            try:
                response = response.json()
            except Exception:
                raise ExternalServerErrorException('launcher service error (response - {})'.format(response.text))

            if response['meta']['response_code'] != LauncherServiceRepository.RESPONSE_CODE_SUCCESS:
                raise ExternalServerErrorException('launcher service error ({} - {})'.format(response['meta']['response_code'], response['meta']['response_desc']))
            
            return response
        
        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            LauncherServiceRepository.LOGGER.error('retrieve service repository | exception: {}'.format(exception_message))
            raise e


    @staticmethod
    def create(state, **kwargs):
        try:
            LauncherServiceRepository.LOGGER.debug('create service repository | sub state: {}'.format(state.name))

            endpoint, header = LauncherServiceRepository._get_endpoint_and_header(state)
            endpoint = '{}{}/'.format(endpoint, 'service_repository')

            name = kwargs.get('name')
            url = kwargs.get('url')
            request = kwargs.get('request') or dict()

            request_body = {
                'name': name,
                'url': url,
                'request': request
            }

            response = requests.post(endpoint, headers=header, data=json.dumps(request_body))

            LauncherServiceRepository.LOGGER.debug('create service repository | response status: {}'.format(response.status_code))
            if response.status_code != 200:
                raise ExternalServerErrorException('launcher service error (status code - {})'.format(response.status_code))

            LauncherServiceRepository.LOGGER.debug('create service repository | response data: {}'.format(response.text))

            try:
                response = response.json()
            except Exception:
                raise ExternalServerErrorException('launcher service error (response - {})'.format(response.text))

            if response['meta']['response_code'] != LauncherServiceRepository.RESPONSE_CODE_SUCCESS:
                raise ExternalServerErrorException('launcher service error ({} - {})'.format(response['meta']['response_code'], response['meta']['response_desc']))
            
            return response
        
        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            LauncherServiceRepository.LOGGER.error('create service repository | exception: {}'.format(exception_message))
            raise e


    @staticmethod
    def update(state, service_repository_id, **kwargs):
        try:
            LauncherServiceRepository.LOGGER.debug('update service repository | sub state: {}'.format(state.name))
            LauncherServiceRepository.LOGGER.debug('update service repository | service repository id: {}'.format(service_repository_id))

            if service_repository_id is None:
                raise Exception('service repository id is required')

            endpoint, header = LauncherServiceRepository._get_endpoint_and_header(state)
            endpoint = '{}{}/{}/'.format(endpoint, 'service_repository', service_repository_id)

            name = kwargs.get('name')
            url = kwargs.get('url')
            request = kwargs.get('request') or dict()

            request_body = {
                'name': name,
                'url': url,
                'request': request
            }

            response = requests.put(endpoint, headers=header, data=json.dumps(request_body))

            LauncherServiceRepository.LOGGER.debug('update service repository | response status: {}'.format(response.status_code))
            if response.status_code != 200:
                raise ExternalServerErrorException('launcher service error (status code - {})'.format(response.status_code))

            LauncherServiceRepository.LOGGER.debug('update service repository | response data: {}'.format(response.text))

            try:
                response = response.json()
            except Exception:
                raise ExternalServerErrorException('launcher service error (response - {})'.format(response.text))

            if response['meta']['response_code'] != LauncherServiceRepository.RESPONSE_CODE_SUCCESS:
                raise ExternalServerErrorException('launcher service error ({} - {})'.format(response['meta']['response_code'], response['meta']['response_desc']))
            
            return response
        
        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            LauncherServiceRepository.LOGGER.error('update service repository | exception: {}'.format(exception_message))
            raise e


    @staticmethod
    def delete(state, service_repository_id):
        try:
            LauncherServiceRepository.LOGGER.debug('delete service repository | sub state: {}'.format(state.name))
            LauncherServiceRepository.LOGGER.debug('delete service repository | service repository id: {}'.format(service_repository_id))

            if service_repository_id is None:
                raise Exception('service repository id is required')

            endpoint, header = LauncherServiceRepository._get_endpoint_and_header(state)
            endpoint = '{}{}/{}/'.format(endpoint, 'service_repository', service_repository_id)

            response = requests.delete(endpoint, headers=header)

            LauncherServiceRepository.LOGGER.debug('delete service repository | response status: {}'.format(response.status_code))
            if response.status_code != 200:
                raise ExternalServerErrorException('launcher service error (status code - {})'.format(response.status_code))

            LauncherServiceRepository.LOGGER.debug('update service repository | response data: {}'.format(response.text))

            try:
                response = response.json()
            except Exception:
                raise ExternalServerErrorException('launcher service error (response - {})'.format(response.text))

            if response['meta']['response_code'] != LauncherServiceRepository.RESPONSE_CODE_SUCCESS:
                raise ExternalServerErrorException('launcher service error ({} - {})'.format(response['meta']['response_code'], response['meta']['response_desc']))
            
            return response
        
        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            LauncherServiceRepository.LOGGER.error('delete service repository | exception: {}'.format(exception_message))
            raise e


    @staticmethod
    def _get_endpoint_and_header(state):
        try:
            service_config = LauncherServiceConfig.get(state)

            if service_config is None:
                raise ConfigurationErrorException("Launcher service is not configured")

            endpoint = service_config.get('endpoint')
            if endpoint[-1] != '/':
                endpoint += '/'

            service_account = service_config.get('service_account')
            mule_client_id = service_config.get('mule_client_id')
            mule_client_secret = service_config.get('mule_client_secret')

            app_meta = {
                'user_id': service_account,
                'user_name': 'channel service account',
            }

            # app_meta['env'] = virtual_name
            # app_meta['sub_state'] = virtual_name

            return endpoint, {
                'content-Type': 'application/json',
                'app-meta': json.dumps(app_meta),
                'client_id': mule_client_id,
                'client_secret': mule_client_secret,
            }

        except Exception as e:
            raise e