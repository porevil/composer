import sys
import os
import json
import requests

from apps.commons.generator.systemconfig import LauncherServiceConfig
from apps.commons.utilities.log import Logger
from apps.commons.error.exception import ExternalServerErrorException, ConfigurationErrorException


class LauncherFlow:
    LOGGER = Logger('Core Connector', 'Launcher Flow')
    RESPONSE_CODE_SUCCESS = "10000"

    @staticmethod
    def list(sub_state, **criteria):
        try:
            LauncherFlow.LOGGER.debug('list launcher flow | sub state: {}'.format(sub_state.name))
            LauncherFlow.LOGGER.debug('list launcher flow | criteria: {}'.format(criteria))

            endpoint, header = LauncherFlow._get_endpoint_and_header(sub_state)
            query_list = list()
            for k, v in criteria.items():
                query_list.append('{}={}'.format(k, v))

            endpoint = '{}?{}'.format(endpoint, '&'.join(query_list))

            response = requests.get(endpoint, headers=header)

            LauncherFlow.LOGGER.debug('list launcher flow | response status: {}'.format(response.status_code))
            if response.status_code != 200:
                raise ExternalServerErrorException('launcher service error (status code - {})'.format(response.status_code))

            LauncherFlow.LOGGER.debug('list launcher flow | response data: {}'.format(response.text))

            try:
                response = response.json()
            except Exception:
                raise ExternalServerErrorException('launcher service error (response - {})'.format(response.text))

            if response['meta']['response_code'] != LauncherFlow.RESPONSE_CODE_SUCCESS:
                raise ExternalServerErrorException('launcher service error ({} - {})'.format(response['meta']['response_code'], response['meta']['response_desc']))
            
            return response
        
        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            LauncherFlow.LOGGER.error('list launcher flow | exception: {}'.format(exception_message))
            raise e

            
    @staticmethod
    def get(sub_state, uuid):
        try:
            LauncherFlow.LOGGER.debug('get launcher flow | sub state: {}'.format(sub_state.name))
            LauncherFlow.LOGGER.debug('get launcher flow | uuid: {}'.format(uuid))

            endpoint, header = LauncherFlow._get_endpoint_and_header(sub_state)
            endpoint = '{}{}/'.format(endpoint, uuid)
            response = requests.get(endpoint, headers=header)

            LauncherFlow.LOGGER.debug('get launcher flow | response status: {}'.format(response.status_code))
            if response.status_code != 200:
                raise ExternalServerErrorException('launcher service error (status code - {})'.format(response.status_code))

            LauncherFlow.LOGGER.debug('get launcher flow | response data: {}'.format(response.text))

            try:
                response = response.json()
            except Exception:
                raise ExternalServerErrorException('launcher service error (response - {})'.format(response.text))

            if response['meta']['response_code'] != LauncherFlow.RESPONSE_CODE_SUCCESS:
                raise ExternalServerErrorException('launcher service error ({} - {})'.format(response['meta']['response_code'], response['meta']['response_desc']))
            
            return response

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            LauncherFlow.LOGGER.error('get launcher flow | exception: {}'.format(exception_message))
            raise e

    @staticmethod
    def create_or_update(sub_state, uuid, **kwargs):
        try:
            LauncherFlow.LOGGER.debug('create or update launcher flow | sub state: {}'.format(sub_state.name))
            LauncherFlow.LOGGER.debug('create or update launcher flow | uuid: {}'.format(uuid))
            code = kwargs.get('code')
            name = kwargs.get('name')
            display_label = kwargs.get('display_label')
            system_data = kwargs.get('system_data') or False
            config = kwargs.get('config') or dict()

            endpoint, header = LauncherFlow._get_endpoint_and_header(sub_state)
            request_body = {
                'uuid': uuid,
                'code': code,
                'name': name,
                'display_label': display_label,
                'system_data': system_data,
                'config': config,
            }

            LauncherFlow.LOGGER.debug('create or update launcher flow | request: {}'.format(request_body))

            response = requests.post(endpoint, headers=header, data=json.dumps(request_body))

            LauncherFlow.LOGGER.debug('create or update launcher flow | response status: {}'.format(response.status_code))
            if response.status_code != 200:
                raise ExternalServerErrorException('launcher service error (status code - {})'.format(response.status_code))

            LauncherFlow.LOGGER.debug('create or update launcher flow | response data: {}'.format(response.text))

            try:
                response = response.json()
            except Exception:
                raise ExternalServerErrorException('launcher service error (response - {})'.format(response.text))

            if response['meta']['response_code'] != LauncherFlow.RESPONSE_CODE_SUCCESS:
                raise ExternalServerErrorException('launcher service error ({} - {})'.format(response['meta']['response_code'], response['meta']['response_desc']))
            
            return response

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            LauncherFlow.LOGGER.error('create or update launcher flow | exception: {}'.format(exception_message))
            raise e

    @staticmethod
    def delete(sub_state, uuid):
        try:
            LauncherFlow.LOGGER.debug('delete launcher flow | sub state: {}'.format(sub_state.name))
            LauncherFlow.LOGGER.debug('delete launcher flow | uuid: {}'.format(uuid))

            endpoint, header = LauncherFlow._get_endpoint_and_header(sub_state)
            endpoint = '{}{}/'.format(endpoint, uuid)

            response = requests.delete(endpoint, headers=header, data={})
            status_code = response.status_code

            LauncherFlow.LOGGER.debug('delete launcher flow | response status: {}'.format(response.status_code))
            LauncherFlow.LOGGER.debug('delete launcher flow | response data: {}'.format(response.text))

            LauncherFlow.LOGGER.debug('delete launcher flow | response status: {}'.format(response.status_code))
            if response.status_code < 200 or response.status_code >= 300:
                raise ExternalServerErrorException('launcher service error (status code - {})'.format(response.status_code))

            try:
                response = response.json()
            except Exception:
                raise ExternalServerErrorException('launcher service error (response - {})'.format(response.text))

            if response['meta']['response_code'] != LauncherFlow.RESPONSE_CODE_SUCCESS:
                raise ExternalServerErrorException('launcher service error ({} - {})'.format(response['meta']['response_code'], response['meta']['response_desc']))
            
            return response

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            LauncherFlow.LOGGER.error('delete launcher flow | exception: {}'.format(exception_message))
            raise e

    @staticmethod
    def _get_endpoint_and_header(sub_state):
        try:
            virtual_name = sub_state.virtual_name or None
            service_config = LauncherServiceConfig.get(sub_state.state)

            if service_config is None:
                raise ConfigurationErrorException("Launcher service is not configed")

            endpoint = service_config.get('endpoint')
            if endpoint[-1] != '/':
                endpoint = endpoint + '/'

            endpoint = '{}flow/'.format(endpoint)

            service_account = service_config.get('service_account')
            mule_client_id = service_config.get('mule_client_id')
            mule_client_secret = service_config.get('mule_client_secret')
            
            app_meta = {
                'user_id': service_account,
                'user_name': 'channel service account',
                'sub_state': virtual_name,
            }

            return endpoint, { 
                'content-Type': 'application/json',
                'app-meta': json.dumps(app_meta),
                'client_id': mule_client_id,
                'client_secret': mule_client_secret,
            }
        
        except Exception as e:
            raise e
