from unittest import TestCase
from . import Notification

COLLABORATION_SERVICE_ENDPOINT = 'https://api-v1-service.c1-alpha-tiscogroup.com/public/notification-v2-service/sep-notification'
EMAIL_TEMPLATE_ID = 6565
APPLICATION_CODE = 65
BASE_URL = COLLABORATION_SERVICE_ENDPOINT

user_id = "ComposerEngine"
user_name = "ComposerEngine"


def get_receivers():
    return [
        'zanucha@tisco.co.th'
    ]


def get_cc():
    return [
        'zanucha@gmail.co.th'
    ]


def get_bcc():
    return [
        'zanucha@tisco.co.th'
    ]


class CollaboratorTest(TestCase):

    def test_get_settings(self):
        self.assertEqual(EMAIL_TEMPLATE_ID, 6565)

    def test_send_email(self):
        sender = Notification(BASE_URL,
                              client_id='7d54f79fb17946678775205aab308619',
                              client_secret='530d2e1111174443BFB01891E40BD091',
                              user_name=user_name,
                              user_id=user_id)

        res = sender.send_mail(
            application_code=APPLICATION_CODE,
            template_id=EMAIL_TEMPLATE_ID,
            recipient=get_receivers(),
            cc=get_cc(),
            bcc=get_bcc(),
            template_variable={
                'status': 'normal',
                'subject': "Hello World"
            })
        # assert request is json object
        self.assertTrue(res.json())
        # assert request response code
        self.assertEqual((res.json()['meta']['response_code']), '20000')
