import uuid
from datetime import datetime, tzinfo
import pytz
import requests
import traceback
import json


class Notification:
    session_id = None
    user_name = None
    user_id = None

    request_data = None
    request_header = None
    response = None

    request_timeout = 5  # default is 5 sec

    def __init__(self, service_endpoint, client_id, client_secret, *args, **kwargs):
        """
        Initial service request config
        Args:
            service_endpoint: service url
            client_id: application code
            client_secret: template to sending email
        Optional Args:
            session_id: session id for logger
        """
        self.service_endpoint = service_endpoint
        self.client_id = client_id
        self.client_secret = client_secret

        self.session_id = kwargs.get('session_id', str(uuid.uuid4()))
        self.user_id = kwargs.get('user_id', "")
        self.user_name = kwargs.get('user_name', "")

        self.__set_request_header()

    def __set_request_header(self):
        app_meta = {
            'request_datetime': str(datetime.now(pytz.timezone("Asia/Bangkok"))),
            'user_id': self.user_id,
            'user_name': self.user_name,
            'log_session_id': self.session_id
        }

        self.request_header = {
            'app-meta': json.dumps(app_meta),
            'client_id': self.client_id,
            'client_secret': self.client_secret
        }

    def __set_request_data(self, application_code, template_id, **kwargs):
        template_data = {
            'send_to': {}
        }

        if kwargs.get('recipient', []):
            template_data['send_to']['recipient'] = kwargs['recipient']
        if kwargs.get('cc', []) and kwargs['cc'] is not None:
            template_data['send_to']['cc'] = kwargs['cc']
        if kwargs.get('bcc', []) and kwargs['bcc'] is not None:
            template_data['send_to']['bcc'] = kwargs['bcc']

        if kwargs.get('template_variable', {}):
            template_data['template_variable'] = kwargs['template_variable']

        data = {
            'template_id': str(template_id),
            'application_code': str(application_code),
            'noti_type': [5],  # 5 is email
            'template_data': [template_data]
        }
        self.request_data = {'data': data}

    def get_data(self):
        return self.request_data

    def get_header(self):
        return self.request_header

    def send_mail(self, application_code, template_id, recipient=None, **kwargs):
        """
        option:
            cc: carbon copy
            bcc: hidden carbon copy
        """
        try:
            if len(recipient) < 1:
                raise Exception("Can not send email, empty recipient")
            self.__set_request_data(application_code, template_id, recipient=recipient, **kwargs)
            timeout = kwargs.get('timeout', self.request_timeout)
            res = requests.post(url=self.service_endpoint + f'/sendNotification?log_session_id={self.session_id}',
                                json=self.request_data,
                                headers=self.request_header,
                                timeout=timeout)
            return res

        except Exception as e:
            traceback.print_stack()
            raise e
