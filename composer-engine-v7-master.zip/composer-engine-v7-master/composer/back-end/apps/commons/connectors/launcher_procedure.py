import sys
import os 
import json
import requests

from apps.commons.generator.systemconfig import LauncherServiceConfig
from apps.commons.utilities.log import Logger
from apps.commons.error.exception import ExternalServerErrorException, ConfigurationErrorException


class LauncherProcedure:
    LOGGER = Logger('Core Connector', 'Launcher Procedure')
    RESPONSE_CODE_SUCCESS = "10000"
    RESPONSE_CODE_SUCCESS_WITH_WARNING = "12000"

    @staticmethod
    def list(sub_state, **kwargs):
        try:
            LauncherProcedure.LOGGER.debug('list launcher procedure | sub state: {}'.format(sub_state.name))
            LauncherProcedure.LOGGER.debug('list launcher procedure | criteria: {}'.format(kwargs))

            endpoint, header = LauncherProcedure._get_endpoint_and_header(sub_state)
            query_list = list()
            for k, v in kwargs.items():
                query_list.append('{}={}'.format(k, v))

            endpoint = '{}?{}'.format(endpoint, '&'.join(query_list))

            response = requests.get(endpoint, headers=header)

            LauncherProcedure.LOGGER.debug('list launcher procedure | response status: {}'.format(response.status_code))
            if response.status_code != 200:
                raise ExternalServerErrorException('launcher service error (status code - {})'.format(response.status_code))

            LauncherProcedure.LOGGER.debug('list launcher procedure | response data: {}'.format(response.text))

            try:
                response = response.json()
            except Exception:
                raise ExternalServerErrorException('launcher service error (response - {})'.format(response.text))

            if response['meta']['response_code'] != LauncherProcedure.RESPONSE_CODE_SUCCESS:
                raise ExternalServerErrorException('launcher service error ({} - {})'.format(response['meta']['response_code'], response['meta']['response_desc']))

            return response

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            LauncherProcedure.LOGGER.error('list launcher procedure | exception: {}'.format(exception_message))
            raise e

    @staticmethod
    def get(sub_state, uuid):
        try:
            LauncherProcedure.LOGGER.debug('get launcher procedure | sub state: {}'.format(sub_state.name))
            LauncherProcedure.LOGGER.debug('get launcher procedure | uuid: {}'.format(uuid))

            endpoint, header = LauncherProcedure._get_endpoint_and_header(sub_state)
            endpoint = '{}{}/'.format(endpoint, uuid)
            response = requests.get(endpoint, headers=header)

            LauncherProcedure.LOGGER.debug('get launcher procedure | response status: {}'.format(response.status_code))
            if response.status_code != 200:
                raise ExternalServerErrorException('launcher service error (status code - {})'.format(response.status_code))

            LauncherProcedure.LOGGER.debug('get launcher procedure | response data: {}'.format(response.text))

            try:
                response = response.json()
            except Exception:
                raise ExternalServerErrorException('launcher service error (response - {})'.format(response.text))

            if response['meta']['response_code'] != LauncherProcedure.RESPONSE_CODE_SUCCESS:
                raise ExternalServerErrorException('launcher service error ({} - {})'.format(response['meta']['response_code'], response['meta']['response_desc']))

            return response

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            LauncherProcedure.LOGGER.error('get launcher procedure | exception: {}'.format(exception_message))
            raise e

    @staticmethod
    def create_or_update(sub_state, uuid, **kwargs):
        try:
            LauncherProcedure.LOGGER.debug('create or update launcher procedure | sub state: {}'.format(sub_state.name))
            LauncherProcedure.LOGGER.debug('create or update launcher procedure | uuid: {}'.format(uuid))

            code = kwargs.get('code')
            name = kwargs.get('name')
            description = kwargs.get('description')
            display_label = kwargs.get('display_label')
            system_data = kwargs.get('system_data') or False
            flow_uuids = kwargs.get('flow_uuids') or list()

            endpoint, header = LauncherProcedure._get_endpoint_and_header(sub_state)
            request_body = {
                'code': code,
                'name': name,
                'uuid': uuid or str(uuid.uuid4()),
                'description': description,
                'display_label': display_label,
                'system_data': system_data,
                'flow_uuids': flow_uuids
            }

            # if uuid is not None:
            #     request_body['uuid'] = uuid

            LauncherProcedure.LOGGER.debug('create or update launcher procedure | request: {}'.format(request_body))

            response = requests.post(endpoint, headers=header, data=json.dumps(request_body))

            LauncherProcedure.LOGGER.debug('create or update launcher procedure | response status: {}'.format(response.status_code))
            if response.status_code != 200:
                raise ExternalServerErrorException('launcher service error (status code - {})'.format(response.status_code))

            LauncherProcedure.LOGGER.debug('create or update launcher procedure | response data: {}'.format(response.text))

            try:
                response = response.json()
            except Exception:
                raise ExternalServerErrorException('launcher service error (response - {})'.format(response.text))

            if response['meta']['response_code'] not in [LauncherProcedure.RESPONSE_CODE_SUCCESS, LauncherProcedure.RESPONSE_CODE_SUCCESS_WITH_WARNING]:
                raise ExternalServerErrorException('launcher service error ({} - {})'.format(response['meta']['response_code'], response['meta']['response_desc']))

            return response

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            LauncherProcedure.LOGGER.error('create or update launcher procedure | exception: {}'.format(exception_message))
            raise e

    @staticmethod
    def delete(sub_state, uuid):
        try:
            LauncherProcedure.LOGGER.debug('delete launcher procedure | sub state: {}'.format(sub_state.name))
            LauncherProcedure.LOGGER.debug('delete launcher procedure | uuid: {}'.format(uuid))

            endpoint, header = LauncherProcedure._get_endpoint_and_header(sub_state)
            endpoint = '{}{}/'.format(endpoint, uuid)

            response = requests.delete(endpoint, headers=header, data={})

            LauncherProcedure.LOGGER.debug('delete launcher procedure | response status: {}'.format(response.status_code))
            if response.status_code < 200 or response.status_code >= 300:
                raise ExternalServerErrorException('launcher service error (status code - {})'.format(response.status_code))

            LauncherProcedure.LOGGER.debug('delete launcher procedure | response data: {}'.format(response.text))
 
            try:
                response = response.json()
            except Exception:
                raise ExternalServerErrorException('launcher service error (response - {})'.format(response.text))

            if response['meta']['response_code'] != LauncherProcedure.RESPONSE_CODE_SUCCESS:
                raise ExternalServerErrorException('launcher service error ({} - {})'.format(response['meta']['response_code'], response['meta']['response_desc']))

            return response

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            LauncherProcedure.LOGGER.error('delete launcher procedure | exception: {}'.format(exception_message))
            raise e

    @staticmethod
    def assign_flows(sub_state, uuid, flow_uuids):
        try:
            LauncherProcedure.LOGGER.debug('assign Flows | sub state: {}'.format(sub_state.name))
            LauncherProcedure.LOGGER.debug('Assign Flows | uuid: {}, flow uuids: {}'.format(uuid, flow_uuids))

            endpoint, header = LauncherProcedure._get_endpoint_and_header(sub_state, True)
            request_body = {
                'procedure_uuid': uuid,
                'flow_uuids': flow_uuids,
            }

            LauncherProcedure.LOGGER.debug('Assign Flows | request: {}'.format(request_body))

            response = requests.post(endpoint, headers=header, data=json.dumps(request_body))

            LauncherProcedure.LOGGER.debug('Assign Flows | response status: {}'.format(response.status_code))
            if response.status_code != 200:
                raise ExternalServerErrorException('launcher service error (status code - {})'.format(response.status_code))

            LauncherProcedure.LOGGER.debug('Assign Flows | response data: {}'.format(response.text))
            
            try:
                response = response.json()
            except Exception:
                raise ExternalServerErrorException('launcher service error (response - {})'.format(response.text))

            if response['meta']['response_code'] != LauncherProcedure.RESPONSE_CODE_SUCCESS:
                raise ExternalServerErrorException('launcher service error ({} - {})'.format(response['meta']['response_code'], response['meta']['response_desc']))

            return response
            
        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            LauncherProcedure.LOGGER.error('Assign Flows | exception: {}'.format(exception_message))
            raise e

    @staticmethod
    def unassign_flows(sub_state, uuid, flow_uuids):
        try:
            LauncherProcedure.LOGGER.debug('Unassign Flows | sub state: {}'.format(sub_state.name))
            LauncherProcedure.LOGGER.debug('Unassign Flows | uuid: {}, flow uuids: {}'.format(uuid, flow_uuids))

            endpoint, header = LauncherProcedure._get_endpoint_and_header(sub_state, True)
            endpoint = '{}{}/'.format(endpoint, uuid)
            request_body = {
                'flow_uuids': flow_uuids,
            }

            LauncherProcedure.LOGGER.debug('Unassign Flows | request: {}'.format(request_body))

            response = requests.delete(endpoint, headers=header, data=json.dumps(request_body))

            LauncherProcedure.LOGGER.debug('Unassign Flows | response status: {}'.format(response.status_code))
            if response.status_code != 200:
                raise ExternalServerErrorException('launcher service error (status code - {})'.format(response.status_code))

            LauncherProcedure.LOGGER.debug('Unassign Flows | response data: {}'.format(response.text))

            try:
                response = response.json()
            except Exception:
                raise ExternalServerErrorException('launcher service error (response - {})'.format(response.text))

            if response['meta']['response_code'] != LauncherProcedure.RESPONSE_CODE_SUCCESS:
                raise ExternalServerErrorException('launcher service error ({} - {})'.format(response['meta']['response_code'], response['meta']['response_desc']))

            return response
                    
        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            LauncherProcedure.LOGGER.error('Unassign Flows | exception: {}'.format(exception_message))
            raise e

    @staticmethod
    def _get_endpoint_and_header(sub_state, is_mapping=False):
        try:
            virtual_name = sub_state.virtual_name or None
            service_config = LauncherServiceConfig.get(sub_state.state)

            if service_config is None:
                raise Exception("Launcher service is not configed")

            endpoint = service_config.get('endpoint')
            if endpoint[-1] != '/':
                endpoint = endpoint + '/'

            endpoint = '{}{}/'.format(endpoint, 'procedure' if not is_mapping else 'procedure_flow_mapping')
            service_account = service_config.get('service_account')
            mule_client_id = service_config.get('mule_client_id')
            mule_client_secret = service_config.get('mule_client_secret')
            
            app_meta = {
                'user_id': service_account,
                'user_name': 'channel service account',
                'sub_state': virtual_name,
            }

            return endpoint, { 
                'content-Type': 'application/json',
                'app-meta': json.dumps(app_meta),
                'client_id': mule_client_id,
                'client_secret': mule_client_secret,
            }

        except Exception as e:
            raise e
