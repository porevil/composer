import json
import requests
import traceback
import os
import sys

from apps.configurations.models import SubState
from apps.commons.generator.systemconfig import AGServiceConfig
from apps.commons.utilities.log import Logger
from apps.commons.error.exception import ExternalServerErrorException, ConfigurationErrorException

class AccessGovernance:

    LOGGER = Logger('Core Connector', 'AccessGovernance')
    RESPONSE_CODE_SUCCESS = "20000"


    @staticmethod
    def create_roles(request_roles=[], sub_state=None):
        try:
            if sub_state is None:
                sub_state = SubState.default()

            AccessGovernance.LOGGER.debug('Create Engine Roles | request roles: {}'.format(request_roles))

            endpoint, header = AccessGovernance._get_endpoint_and_header(sub_state)
            endpoint = '{}/engineRoles?checkDup=true'.format(endpoint)
            request_body = { 'data': request_roles }

            AccessGovernance.LOGGER.debug('Create Engine Roles | request body: {}'.format(request_body))
            response = requests.post(endpoint, headers=header, data=json.dumps(request_body))
            
            AccessGovernance.LOGGER.debug('Create Engine Roles | response status: {}'.format(response.status_code))
            if response.status_code != 200:
                raise ExternalServerErrorException('access governance service error (status code - {})'.format(response.status_code))

            AccessGovernance.LOGGER.debug('Create Engine Roles | response data: {}'.format(response.text))

            try:
                response = response.json()
            except Exception:
                raise ExternalServerErrorException('access governance service error (response - {})'.format(response.text))

            if response['meta']['response_code'] != AccessGovernance.RESPONSE_CODE_SUCCESS:
                raise ExternalServerErrorException('access governance service error ({} - {})'.format(response['meta']['response_code'], response['meta']['response_desc']))

            return response["data"]
        
        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            AccessGovernance.LOGGER.error('Create Engine Roles | exception: {}'.format(exception_message))
            raise e



    @staticmethod
    def get_role(role_code, sub_state=None):
        try:
            if sub_state is None:
                sub_state = SubState.default()

            AccessGovernance.LOGGER.debug('Get Engine Role | role code: {}'.format(role_code))

            endpoint, header = AccessGovernance._get_endpoint_and_header(sub_state)
            endpoint = '{}/engineRoles?code={}'.format(endpoint, role_code)
            response = requests.get(endpoint, headers=header)

            AccessGovernance.LOGGER.debug('Get Engine Role | response status: {}'.format(response.status_code))
            if response.status_code != 200:
                raise ExternalServerErrorException('access governance service error (status code - {})'.format(response.status_code))

            AccessGovernance.LOGGER.debug('Get Engine Role | response data: {}'.format(response.text))

            try:
                response = response.json()
            except Exception:
                raise ExternalServerErrorException('access governance service error (response - {})'.format(response.text))

            if response['meta']['response_code'] != AccessGovernance.RESPONSE_CODE_SUCCESS:
                raise ExternalServerErrorException('access governance service error ({} - {})'.format(response['meta']['response_code'], response['meta']['response_desc']))

            return response["data"][0]
        
        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            AccessGovernance.LOGGER.error('Get Engine Role | exception: {}'.format(exception_message))
            raise e



    @staticmethod
    def create_groups(request_groups=[], sub_state=None):
        try:
            if sub_state is None:
                sub_state = SubState.default()

            AccessGovernance.LOGGER.debug('Create Group Roles | request groups: {}'.format(request_groups))

            endpoint, header = AccessGovernance._get_endpoint_and_header(sub_state)
            endpoint = '{}/groups'.format(endpoint)
            request_body = { 'data': request_groups }

            AccessGovernance.LOGGER.debug('Create Group Roles | request body: {}'.format(request_body))
            response = requests.post(endpoint, headers=header, data=json.dumps(request_body))
            
            AccessGovernance.LOGGER.debug('Create Group Roles | response status: {}'.format(response.status_code))
            if response.status_code != 200:
                raise ExternalServerErrorException('access governance service error (status code - {})'.format(response.status_code))

            AccessGovernance.LOGGER.debug('Create Group Roles | response data: {}'.format(response.text))

            try:
                response = response.json()
            except Exception:
                raise ExternalServerErrorException('access governance service error (response - {})'.format(response.text))

            if response['meta']['response_code'] != AccessGovernance.RESPONSE_CODE_SUCCESS:
                for data in response["data"]:
                    if 'error_desc' not in data \
                            or 'duplicate' in data['error_desc'].lower():
                        continue

                    raise ExternalServerErrorException('access governance service error ({} - {})'.format(response['meta']['response_code'], response['meta']['response_desc']))

            return response['data']

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            AccessGovernance.LOGGER.error('Create Group Roles | exception: {}'.format(exception_message))
            raise e



    @staticmethod
    def assign_roles_to_group(group_code, role_ids, sub_state=None):
        try:
            if sub_state is None:
                sub_state = SubState.default()

            AccessGovernance.LOGGER.debug('Assign Engine Roles to Group | group: code {}'.format(group_code))

            endpoint, header = AccessGovernance._get_endpoint_and_header(sub_state)
            endpoint = '{}/groups/{}/engineRoles'.format(endpoint, group_code)
            request_body = { 'data': { "id": role_ids } }

            AccessGovernance.LOGGER.debug('Assign Engine Roles to Group | request body: {}'.format(request_body))
            response = requests.put(endpoint, headers=header, data=json.dumps(request_body))

            AccessGovernance.LOGGER.debug('Assign Engine Roles to Group | response status: {}'.format(response.status_code))
            if response.status_code != 200:
                raise ExternalServerErrorException('access governance service error (status code - {})'.format(response.status_code))

            AccessGovernance.LOGGER.debug('Assign Engine Roles to Group | response data: {}'.format(response.text))
            
            try:
                response = response.json()
            except Exception:
                raise ExternalServerErrorException('access governance service error (response - {})'.format(response.text))

            if response['meta']['response_code'] != AccessGovernance.RESPONSE_CODE_SUCCESS:
                raise ExternalServerErrorException('access governance service error ({} - {})'.format(response['meta']['response_code'], response['meta']['response_desc']))

            return True

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            AccessGovernance.LOGGER.error('Assign Engine Roles to Group | exception: {}'.format(exception_message))
            raise e



    @staticmethod
    def approve_roles_assignment(group_code, role_ids, sub_state=None):
        try:
            if sub_state is None:
                sub_state = SubState.default()

            AccessGovernance.LOGGER.debug('Approve Engine Roles to Group Assignment | group: code {}'.format(group_code))

            endpoint, header = AccessGovernance._get_endpoint_and_header(sub_state)
            endpoint = '{}/groups/{}/engineRoles/approve'.format(endpoint, group_code)
            request_body = { 'data': { "id": role_ids } }

            AccessGovernance.LOGGER.debug('Approve Engine Roles to Group Assignment | request body: {}'.format(request_body))
            response = requests.put(endpoint, headers=header, data=json.dumps(request_body))

            AccessGovernance.LOGGER.debug('Approve Engine Roles to Group Assignment | response status: {}'.format(response.status_code))
            if response.status_code != 200:
                raise ExternalServerErrorException('access governance service error (status code - {})'.format(response.status_code))

            AccessGovernance.LOGGER.debug('Approve Engine Roles to Group Assignment | response data: {}'.format(response.text))
            
            try:
                response = response.json()
            except Exception:
                raise ExternalServerErrorException('access governance service error (response - {})'.format(response.text))

            if response['meta']['response_code'] != AccessGovernance.RESPONSE_CODE_SUCCESS:
                raise ExternalServerErrorException('access governance service error ({} - {})'.format(response['meta']['response_code'], response['meta']['response_desc']))

            return True

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            AccessGovernance.LOGGER.error('Approve Engine Roles to Group Assignment | exception: {}'.format(exception_message))
            raise e


    
    @staticmethod
    def check_authorization(user_id, role_ids, sub_state=None):
        try:
            if sub_state is None:
                sub_state = SubState.default()

            AccessGovernance.LOGGER.debug('Check Authorization | start')

            endpoint, header = AccessGovernance._get_endpoint_and_header(sub_state, False)
            endpoint = '{}/authorize/users/{}'.format(endpoint, user_id)
            request_body = { 'data': { "id": role_ids } }

            AccessGovernance.LOGGER.debug('Check Authorization | request body: {}'.format(request_body))
            response = requests.post(endpoint, headers=header, data=json.dumps(request_body))

            AccessGovernance.LOGGER.debug('Check Authorization | response status: {}'.format(response.status_code))
            if response.status_code != 200:
                raise ExternalServerErrorException('access governance service error (status code - {})'.format(response.status_code))

            AccessGovernance.LOGGER.debug('Check Authorization | response data: {}'.format(response.text))
            try:
                response = response.json()
            except Exception:
                raise ExternalServerErrorException('access governance service error (response - {})'.format(response.text))
            
            if response['meta']['response_code'] != AccessGovernance.RESPONSE_CODE_SUCCESS:
                raise ExternalServerErrorException('access governance service error ({} - {})'.format(response['meta']['response_code'], response['meta']['response_desc']))

            return response['data']

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            AccessGovernance.LOGGER.error('Check Authorization | exception: {}'.format(exception_message))
            raise e
            
        
        
    @staticmethod
    def _get_endpoint_and_header(sub_state, management=True):
        try:
            virtual_name = sub_state.virtual_name or None
            service_config = AGServiceConfig.get(sub_state.state)

            if service_config is None:
                raise ConfigurationErrorException("access governance service is not configured")

            management_endpoint = service_config.get('management_endpoint')
            runtime_endpoint = service_config.get('runtime_endpoint')
            service_account = service_config.get('service_account')
            mule_client_id = service_config.get('mule_client_id')
            mule_client_secret = service_config.get('mule_client_secret')

            app_meta = {'user_id': service_account, 'user_name': 'channel service account', 'sub_state': virtual_name}

            # app_meta['env'] = virtual_name

            endpoint = management_endpoint if management else runtime_endpoint
            return endpoint, { 
                'content-Type': 'application/json',
                'app-meta': json.dumps(app_meta),
                'client_id': mule_client_id,
                'client_secret': mule_client_secret,
            }

        except Exception as e:
            raise e
