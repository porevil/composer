import sys
import json
import requests
import os
import sys

from apps.commons.generator.systemconfig import LauncherServiceConfig
from apps.commons.utilities.log import Logger
from apps.commons.error.exception import ExternalServerErrorException, ConfigurationErrorException


class LauncherApplication:
    LOGGER = Logger('Core Connector', 'Launcher Application')
    RESPONSE_CODE_SUCCESS = "10000"
    RESPONSE_CODE_SUCCESS_WITH_WARNING = "12000"

    @staticmethod
    def get(sub_state, code):
        try:
            LauncherApplication.LOGGER.debug('get launcher application | sub state: {}'.format(sub_state.name))
            LauncherApplication.LOGGER.debug('get launcher application | code: {}'.format(code))

            endpoint, header = LauncherApplication._get_endpoint_and_header(sub_state)
            endpoint = '{}{}/'.format(endpoint, code)
            response = requests.get(endpoint, headers=header)

            LauncherApplication.LOGGER.debug('get launcher application | response status: {}'.format(response.status_code))
            if response.status_code != 200:
                raise ExternalServerErrorException('launcher service error (status code - {})'.format(response.status_code))

            LauncherApplication.LOGGER.debug('get launcher application | response data: {}'.format(response.text))

            try:
                response = response.json()
            except Exception:
                raise ExternalServerErrorException('launcher service error (response - {})'.format(response.text))

            if response['meta']['response_code'] != LauncherApplication.RESPONSE_CODE_SUCCESS:
                raise ExternalServerErrorException('launcher service error ({} - {})'.format(response['meta']['response_code'], response['meta']['response_desc']))
            
            return response

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            LauncherApplication.LOGGER.error('get launcher application | exception: {}'.format(exception_message))
            raise e

    @staticmethod
    def list(sub_state, **kwargs):
        try:
            LauncherApplication.LOGGER.debug('list launcher application | sub state: {}'.format(sub_state.name))
            LauncherApplication.LOGGER.debug('list launcher application | criteria: {}'.format(kwargs))

            endpoint, header = LauncherApplication._get_endpoint_and_header(sub_state)
            query_list = list()
            for k, v in kwargs.items():
                query_list.append('{}={}'.format(k, v))

            endpoint = '{}?{}'.format(endpoint, '&'.join(query_list))

            response = requests.get(endpoint, headers=header)
            LauncherApplication.LOGGER.debug('list launcher application | response status: {}'.format(response.status_code))
            
            if response.status_code != 200:
                raise ExternalServerErrorException('launcher service error (status code - {})'.format(response.status_code))

            LauncherApplication.LOGGER.debug('list launcher application | response data: {}'.format(response.text))

            try:
                response = response.json()
            except Exception:
                raise ExternalServerErrorException('launcher service error (response - {})'.format(response.text))

            if response['meta']['response_code'] != LauncherApplication.RESPONSE_CODE_SUCCESS:
                raise ExternalServerErrorException('launcher service error ({} - {})'.format(response['meta']['response_code'], response['meta']['response_desc']))
            
            return response

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            LauncherApplication.LOGGER.error('list launcher application | exception: {}'.format(exception_message))
            raise e

    @staticmethod
    def create_or_update(sub_state, code, **kwargs):
        try:
            LauncherApplication.LOGGER.debug('create or update launcher application | sub state: {}'.format(sub_state.name))
            LauncherApplication.LOGGER.debug('create or update launcher application | code: {}'.format(code))
            name = kwargs.get('name')
            description = kwargs.get('description')
            config = kwargs.get('config')
            system_data = kwargs.get('system_data') or False
            procedure_uuids = kwargs.get('procedure_uuids') or list()

            endpoint, header = LauncherApplication._get_endpoint_and_header(sub_state)
            request_body = {
                'code': code,
                'name': name,
                'description': description,
                'config': config,
                'system_data': system_data,
                'procedure_uuids': procedure_uuids,
            }

            LauncherApplication.LOGGER.debug('create or update launcher application | request: {}'.format(request_body))

            response = requests.post(endpoint, headers=header, data=json.dumps(request_body))

            LauncherApplication.LOGGER.debug('create or update launcher application | response status: {}'.format(response.status_code))
            if response.status_code != 200:
                raise ExternalServerErrorException('launcher service error (status code - {})'.format(response.status_code))

            LauncherApplication.LOGGER.debug('create or update launcher application | response data: {}'.format(response.text))

            try:
                response = response.json()
            except Exception:
                raise ExternalServerErrorException('launcher service error (response - {})'.format(response.text))

            if response['meta']['response_code'] not in [LauncherApplication.RESPONSE_CODE_SUCCESS, LauncherApplication.RESPONSE_CODE_SUCCESS_WITH_WARNING]:
                raise ExternalServerErrorException('launcher service error ({} - {})'.format(response['meta']['response_code'], response['meta']['response_desc']))

            return response

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            LauncherApplication.LOGGER.error('create or update launcher application | exception: {}'.format(exception_message))
            raise e

    @staticmethod
    def delete(sub_state, code):
        try:
            LauncherApplication.LOGGER.debug('delete launcher application | sub state: {}'.format(sub_state.name))
            LauncherApplication.LOGGER.debug('delete launcher application | code: {}'.format(code))

            endpoint, header = LauncherApplication._get_endpoint_and_header(sub_state)
            endpoint = '{}{}/'.format(endpoint, code)

            response = requests.delete(endpoint, headers=header, data={})

            LauncherApplication.LOGGER.debug('delete launcher application | response status: {}'.format(response.status_code))
            if response.status_code < 200 or response.status_code >= 300:
                raise ExternalServerErrorException('launcher service error (status code - {})'.format(response.status_code))

            LauncherApplication.LOGGER.debug('delete launcher application | response data: {}'.format(response.text))

            try:
                response = response.json()
            except Exception:
                raise ExternalServerErrorException('launcher service error (response - {})'.format(response.text))

            if response['meta']['response_code'] != LauncherApplication.RESPONSE_CODE_SUCCESS:
                raise ExternalServerErrorException('launcher service error ({} - {})'.format(response['meta']['response_code'], response['meta']['response_desc']))

            return response

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            LauncherApplication.LOGGER.error('delete launcher application | exception: {}'.format(exception_message))
            raise e

    @staticmethod
    def assign_procedures(sub_state, code, procedure_uuids):
        try:
            LauncherApplication.LOGGER.debug('Assign Procedures | sub state: {}'.format(sub_state.name))
            LauncherApplication.LOGGER.debug(
                'Assign Procedures | code: {}, procedure uuids: {}'.format(code, procedure_uuids))

            endpoint, header = LauncherApplication._get_endpoint_and_header(sub_state, True)
            request_body = {
                'application_code': code,
                'procedure_uuids': procedure_uuids,
            }

            LauncherApplication.LOGGER.debug('Assign Procedures | request: {}'.format(request_body))

            response = requests.post(endpoint, headers=header, data=json.dumps(request_body))

            LauncherApplication.LOGGER.debug('Assign Procedures | response status: {}'.format(response.status_code))
            if response.status_code != 200:
                raise ExternalServerErrorException('launcher service error (status code - {})'.format(response.status_code))

            LauncherApplication.LOGGER.debug('Assign Procedures | response data: {}'.format(response.text))

            try:
                response = response.json()
            except Exception:
                raise ExternalServerErrorException('launcher service error (response - {})'.format(response.text))

            if response['meta']['response_code'] != LauncherApplication.RESPONSE_CODE_SUCCESS:
                raise ExternalServerErrorException('launcher service error ({} - {})'.format(response['meta']['response_code'], response['meta']['response_desc']))
        
        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            LauncherApplication.LOGGER.error('Assign Procedures | exception: {}'.format(exception_message))
            raise e



    @staticmethod
    def unassign_procedures(sub_state, code, procedure_uuids):
        try:
            LauncherApplication.LOGGER.debug('Unassign Procedures | sub state: {}'.format(sub_state.name))
            LauncherApplication.LOGGER.debug(
                'Unassign Procedures | code: {}, procedures uuids: {}'.format(code, procedure_uuids))

            endpoint, header = LauncherApplication._get_endpoint_and_header(sub_state, True)

            endpoint = '{}{}/'.format(endpoint, code)
            request_body = {
                'procedure_uuids': procedure_uuids,
            }

            LauncherApplication.LOGGER.debug('Unassign Procedures | request: {}'.format(request_body))

            response = requests.delete(endpoint, headers=header, data=json.dumps(request_body))
            status_code = response.status_code

            LauncherApplication.LOGGER.debug('Unassign Procedures | response status: {}'.format(response.status_code))
            if response.status_code != 200:
                raise ExternalServerErrorException('launcher service error (status code - {})'.format(response.status_code))

            LauncherApplication.LOGGER.debug('Unassign Procedures | response data: {}'.format(response.text))

            try:
                response = response.json()
            except Exception:
                raise ExternalServerErrorException('launcher service error (response - {})'.format(response.text))

            if response['meta']['response_code'] != LauncherApplication.RESPONSE_CODE_SUCCESS:
                raise ExternalServerErrorException('launcher service error ({} - {})'.format(response['meta']['response_code'], response['meta']['response_desc']))

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            LauncherApplication.LOGGER.error('Unassign Procedures | exception: {}'.format(exception_message))
            raise e

    @staticmethod
    def _get_endpoint_and_header(sub_state, is_mapping=False):
        try:
            virtual_name = sub_state.virtual_name or None
            service_config = LauncherServiceConfig.get(sub_state.state)

            if service_config is None:
                raise ConfigurationErrorException("Launcher service is not configed")

            endpoint = service_config.get('endpoint')
            if endpoint[-1] != '/':
                endpoint = endpoint + '/'

            endpoint = '{}{}/'.format(endpoint, 'application' if not is_mapping else 'application_procedure_mapping')
            service_account = service_config.get('service_account')
            mule_client_id = service_config.get('mule_client_id')
            mule_client_secret = service_config.get('mule_client_secret')
            
            app_meta = {
                'user_id': service_account,
                'user_name': 'channel service account',
                'sub_state': virtual_name,
            }

            return endpoint, { 
                'content-Type': 'application/json',
                'app-meta': json.dumps(app_meta),
                'client_id': mule_client_id,
                'client_secret': mule_client_secret,
            }
        except Exception as e:
            raise e
