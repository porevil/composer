from apps.commons.utilities.cache import Cache
from unittest import TestCase
import time


class CacheTestCase(TestCase):

    def setUp(self):
        self.cache = Cache()

    def test_put(self):
        self.cache.put('test_put', 'value', 60)
        time.sleep(1.5)
        self.assertEqual(Cache().get('test_put'), 'value')
        self.cache.delete('test_put')

    def test_put_with_expired_time(self):
        self.cache.put('test_expired', 'value', 1)
        self.assertEqual(self.cache.get('test_expired'), 'value')
        time.sleep(1.5)
        self.assertEqual(self.cache.get('test_expired'), '')
