import os

from django.conf import settings
from django.test import TestCase

from apps.commons.utilities.s3utils import s3_clean_package, get_uploaded_list
from apps.commons.connectors.s3 import S3Client
from apps.configurations.models import SubState

cfg = {
    "region": "ap-southeast-1",
    "access_key_id": "AKIAIYCL4KWIY3K2CQ3Q",
    "secret_access_key": "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"
}

s3_prefix_key = settings.INSTANCE_PACKAGE_NAME_PREFIX
s3_bucket = settings.INSTANCE_PACKAGE_REPOSITORY_BUCKET
test_project_uuid = 'test-1234'
root_path = settings.ROOT_DIR


class FunctionTestCase(TestCase):
    def test_get_non_use_package(self):
        res = get_uploaded_list(
            cfg,
            s3_prefix_key,
            f'{s3_prefix_key}/{test_project_uuid}/')
        self.assertTrue(isinstance(res, set))

    def test_upload(self):
        for i in range(1, 7):
            S3Client(**cfg).upload_file(
                os.path.join(root_path, f'test_file/{i}.zip'),
                s3_bucket,
                f'{s3_prefix_key}/{test_project_uuid}/{i}.zip')


class CleanerTestCase(TestCase):
    def test_clean(self):
        for i in range(1, 7):
            S3Client(**cfg).upload_file(
                os.path.join(root_path, f'test_file/{i}.zip'),
                s3_bucket,
                f'{s3_prefix_key}/{test_project_uuid}/{i}.zip')

        r = get_uploaded_list(cfg, s3_bucket, f"{s3_prefix_key}/{test_project_uuid}")
        active_no = {1, 5}
        self.assertEqual(r, {1, 2, 3, 4, 5, 6})
        s3_clean_package('test-1234', cfg, active_no)
        self.assertEqual(get_uploaded_list(cfg, s3_bucket, f"{s3_prefix_key}/{test_project_uuid}"), active_no)
