import codecs
import os
import shutil
import zipfile


class FileManagement:

    @staticmethod
    def create_file(path, file_name, content=None):
        with codecs.open(os.path.join(path, file_name), "w+", "utf-8") as file:
            file.write(content)

    @staticmethod
    def remove_file(file):
        if os.path.exists(file):
            os.remove(file)

    @staticmethod
    def create_folder(path):
        if not os.path.exists(path):
            os.makedirs(path, exist_ok=True)

    @staticmethod
    def copy_folder(src_path, dest_path):
        FileManagement.remove_folder(dest_path)
        shutil.copytree(src_path, dest_path)

    @staticmethod
    def remove_folder(path):
        if os.path.exists(path):
            shutil.rmtree(path)

    @staticmethod
    def zip(src_path, dest_file):
        with zipfile.ZipFile(dest_file, 'w', zipfile.ZIP_DEFLATED) as ziph:
            for root, dirs, files in os.walk(src_path):
                for filename in files:
                    ziph.write(os.path.join(root, filename), os.path.join(root, filename).replace(src_path, '', 1))

    @staticmethod
    def unzip(src_file, dest_path, debug=False):
        with zipfile.ZipFile(src_file, 'r') as zip_ref:
            if debug:
                print(zip_ref.filelist)
            zip_ref.extractall(dest_path)
