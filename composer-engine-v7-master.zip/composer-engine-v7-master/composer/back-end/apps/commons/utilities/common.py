import uuid

from rest_framework.views import APIView
from rest_framework import generics
from datetime import datetime
from apps.authorization.models import ProfileMapping

class CommonAPIView(generics.ListCreateAPIView):
    http_method_names = ['post']

    def current_user(self, request):
        return request.oidc_user

    def current_username(self, request):
        return request.oidc_user.preferred_username

    def current_userid(self, request):
        return request.oidc_user.email

    def has_permission(self, request, action_code):
        profile_mapping = ProfileMapping.objects.filter(action__code=action_code,
                                                        user_profile__role=request.oidc_user.permission).first()
        if profile_mapping:
            return True
        return False

    def get_success_response(self, response_data=None, response_reference=None):
        return self.get_response(True, None, response_data, response_reference)

    def get_error_response(self, error_message, response_data=None, response_reference=None):
        return self.get_response(False, error_message, response_data, response_reference)

    def get_response(self, success, error_message, response_data=None, response_reference=None):
        response_code = '10000' if success else '11000'
        response_desc = 'success' if success else error_message
        response_ref = response_reference if response_reference is not None else str(uuid.uuid4())
        response_datetime = datetime.now().strftime("%d-%m-%Y %H:%M:%S")
        response = {
            'meta': {
                'response_code': response_code,
                'response_desc': response_desc,
                'response_ref': response_ref,
                'response_datetime': response_datetime,
            }
        }

        if response_data is not None:
            response['data'] = response_data

        return response

