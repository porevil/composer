import os

from django.conf import settings

from apps.commons.connectors.s3 import S3Client


def get_uploaded_list(aws_config, bucket, key):
    client = S3Client(**aws_config)
    items = client.list_objects(bucket, key)
    res = map(lambda x: int(os.path.basename(x['Key']).replace(".zip", "")),
              (filter(lambda r: 'zip' in r['Key'], items)))
    return set(res)


def s3_clean_package(package_id, aws_config, active_nos=None, **kwargs):
    prefix = settings.INSTANCE_PACKAGE_NAME_PREFIX + f"/{package_id}"
    uploaded_nos = get_uploaded_list(
        aws_config,
        settings.INSTANCE_PACKAGE_REPOSITORY_BUCKET,
        prefix
    )
    inactive_nos = uploaded_nos - active_nos
    client = S3Client(**aws_config)
    success, fails = 0, []
    for no in inactive_nos:
        _full_obj_path = os.path.join(prefix, f"{str(no)}.zip")
        try:
            client.delete_object(settings.INSTANCE_PACKAGE_REPOSITORY_BUCKET, _full_obj_path)
            success += 1
        except Exception as e:
            fails.append((_full_obj_path, str(e)))
    return success, fails
