from rest_framework import permissions

from apps.commons.generator.constants import ActionAuthority
from apps.configurations.models import SubState


class ExecutionPermission:

    def __call__(self, request):
        authorized_ticket = request.data.get('authorized_ticket', None)
        destination_sub_state = SubState.objects.filter(pk=request.data.get('destination_sub_state_id')).first()
        if destination_sub_state is None:
            raise Exception('bad request : "destination_sub_state_id" is invalid')

        if destination_sub_state.need_authorized_ticket \
                and (authorized_ticket is None or authorized_ticket.strip() == ''):
            raise Exception('bad request : "authorized_ticket" is required')

        if not request.oidc_user.has_permission(ActionAuthority.BUILD.value):
            raise Exception('not authorized : build')

        if destination_sub_state.is_production:
            if not request.oidc_user.has_permission(ActionAuthority.PUBLISH_PROD.value):
                raise Exception('not authorized : publish on production')
        elif destination_sub_state.is_pre_production:
            if not request.oidc_user.has_permission(ActionAuthority.PUBLISH_PRE_PROD.value):
                raise Exception('not authorized : publish on pre-production')
        else:
            if not request.oidc_user.has_permission(ActionAuthority.PUBLISH_NON_PROD.value):
                raise Exception('not authorized : publish on non-production')


# class ExecutionAccessPermission(permissions.BasePermission):
#     def has_permission(self, request, view):
#         # return False
#         authorized_ticket = request.get('authorized_ticket')
#         destination_sub_state = SubState.objects.get(pk=request.get('destination_sub_state_id'))
#         if destination_sub_state is None:
#             raise Exception('bad request : "destination_sub_state_id" is invalid')
#
#         if destination_sub_state.need_authorized_ticket \
#                 and (authorized_ticket is None or authorized_ticket.strip() == ''):
#             raise Exception('bad request : "authorized_ticket" is required')
#
#         if not request.oidc_user.has_permission(ActionAuthority.BUILD.value):
#             raise Exception('not authorized : build')
#
#         if destination_sub_state.is_production:
#             if not request.oidc_user.has_permission(ActionAuthority.PUBLISH_PROD.value):
#                 raise Exception('not authorized : publish on production')
#         elif destination_sub_state.is_pre_production:
#             if not request.oidc_user.has_permission(ActionAuthority.PUBLISH_PRE_PROD.value):
#                 raise Exception('not authorized : publish on pre-production')
#         else:
#             if not request.oidc_user.has_permission(ActionAuthority.PUBLISH_NON_PROD.value):
#                 raise Exception('not authorized : publish on non-production')
