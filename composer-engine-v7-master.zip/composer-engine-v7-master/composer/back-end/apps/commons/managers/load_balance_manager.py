from django.db.models.base import Model
from apps.node_repositories.models import NodeRepository
from apps.custom_instance.models import CustomInstanceRepository


class LoadBalanceManager(object):
    def __init__(self, deployment_spec):
        """

        :param deployment_spec
        """
        self.deployment_spec = deployment_spec
        self.sub_state = deployment_spec.sub_state

    def get_node_info(self, lb_name, node_name):
        return self.deployment_spec.get_node(lb_name, node_name)

    # TODO: implement more checking exist both custom and common
    def get_available_node(self, repository_class, **kwargs):
        """
        Get working machine to deployment`
        :param repository_class: Model class valid Repository Interface
        :param kwargs:
        :return:
        """
        try:
            if not isinstance(repository_class(), Model):
                raise TypeError("repository must extends from django.db.models.Model")

            for node in self.deployment_spec.get_all_available_node():
                existing_instance = repository_class.objects.filter(sub_state=self.sub_state,
                                                                    load_balance_name=node['load_balance']['name'],
                                                                    node_name=node['name']).count()
                if existing_instance < node['limit_instance']:
                    return node
            return None
        except Exception as e:
            raise e


def get_total_instance_deploy(sub_state, load_balance_name, node_name):
    common_existing_instance = NodeRepository.objects.filter(sub_state=sub_state,
                                                             load_balance_name=load_balance_name,
                                                             node_name=node_name).count()

    custom_existing_instance = CustomInstanceRepository.objects.filter(sub_state=sub_state,
                                                                       load_balance_name=load_balance_name,
                                                                       node_name=node_name).count()

    return common_existing_instance + custom_existing_instance
