import traceback
import os
import sys

from django.conf import settings

from apps.configurations.models import SubState
from apps.commons.utilities.log import Logger
from apps.commons.connectors.ag import AccessGovernance
from apps.commons.generator.constants import InstanceRole
from apps.commons.error.exception import ExternalServerErrorException


class RoleManager:
    LOGGER = Logger('Role Manager')

    ROLE_TYPE_MICROSERVICE = 2
    GROUP_TYPE_MAPPING = 4

    def grant_metadata_access_roles(self, dataset_names, sub_state=None):
        try:
            if sub_state is None:
                sub_state = SubState.default()

            RoleManager.LOGGER.debug('Grant Metadata Access Roles | dataset names = {}'.format(dataset_names))
            service_account = sub_state.state.config['service_account']
            role_ids = list()
            for dataset_name in dataset_names:
                role_code = '{}_1'.format(dataset_name)
                response_role = AccessGovernance.get_role(role_code, sub_state)
                role_ids.append(response_role['id'])

            response_authorization = AccessGovernance.check_authorization(service_account, role_ids, sub_state)

            roles_id_assignments = [d['id'] for d in response_authorization if d['result'] == False]

            RoleManager.LOGGER.debug(
                'Grant Metadata Access Roles | roles_id_assignments= {}'.format(roles_id_assignments))

            if roles_id_assignments:
                group_code = settings.COMPOSER_GROUP_CODE
                AccessGovernance.assign_roles_to_group(group_code, roles_id_assignments, sub_state)
                AccessGovernance.approve_roles_assignment(group_code, roles_id_assignments, sub_state)

        except Exception as e:
            RoleManager.LOGGER.error('Grant Metadata Access Roles | exception: {}'.format(str(e)))
            raise e

    def create_flow_authorization(self, code, name, description, sub_state=None):
        try:
            # Create flow role
            roles = AccessGovernance.create_roles([{
                'type': RoleManager.ROLE_TYPE_MICROSERVICE,
                'code': code,
                'name': name,
                'description': description,
            }], sub_state)

            # Create flow group
            groups = AccessGovernance.create_groups([{
                'type': RoleManager.GROUP_TYPE_MAPPING,
                'code': 'G_{}'.format(code),
                'name': 'group: {}'.format(name),
                'description': 'group: {}'.format(description),
            }], sub_state)

            # Mapping
            role = roles[0]
            group = groups[0]
            AccessGovernance.assign_roles_to_group(group['code'], [role['id']], sub_state)
            AccessGovernance.approve_roles_assignment(group['code'], [role['id']], sub_state)

            # Return
            return {
                'id': role['id'],
                'code': role['code'],
                'group_code': group['code'],
            }

        except Exception as e:
            RoleManager.LOGGER.error('Create Flow Authorization | exception: {}'.format(str(e)))
            raise e

    def create_instance_roles(self, code_prefix, description, sub_state=None):
        try:
            role_configuration = {'activities': list()}
            request_roles = list()
            for role in InstanceRole:
                request_roles.append({
                    'type': RoleManager.ROLE_TYPE_MICROSERVICE,
                    'code': '{}_{}'.format(code_prefix, role.name.lower()),
                    'name': '{} {}'.format(role.value, description),
                    'description': '{} {}'.format(role.value, description),
                })

            response = AccessGovernance.create_roles(request_roles, sub_state)
            for role in response:
                role_configuration['activities'].append({
                    'role': role['id'],
                    'label': role['name'].capitalize(),
                    'action': role['name'],
                })
            return role_configuration

        except Exception as e:
            RoleManager.LOGGER.error('Create instance roles | exception: {}'.format(str(e)))
            raise e
