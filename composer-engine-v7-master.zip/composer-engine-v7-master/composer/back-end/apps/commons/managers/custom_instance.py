from django.core.exceptions import ObjectDoesNotExist
from django.utils.timezone import now

from apps.commons.generator.constants import InstanceType
from apps.commons.generator.custom_instance import CustomInstanceBuild, CustomInstancePublish, CustomInstancePurge, \
    CustomInstanceDestroy
from apps.commons.notification.mailer import DeploymentMailer
from apps.commons.utilities.s3utils import s3_clean_package
from apps.custom_instance.models import CustomInstanceRepository, CustomInstance
from apps.configurations.models import SubState, State, InstanceDeploymentSpecification
from apps.commons.utilities.log import Logger
from apps.flow.models import FlowInstance


class CustomInstanceManager:
    """
    Instance action manager. Integration many features for instance management such as
    build, publish, remove, mail alert, and etc.
    """

    def __init__(self, console_output, *args, **kwargs):
        self.sub_state = kwargs.get('sub_state', None)
        self.logger = kwargs.get('logger', Logger("CustomInstanceManager"))
        self.console_output = console_output
        self.messages = []

    def __exit(self):
        self.messages.append("complete")
        self.console_output.output = "\n".join(str(x) for x in self.messages)
        self.console_output.end_datetime = now()
        self.console_output.save()
        self.logger.debug("CustomInstanceManager Done")

    def build_and_publish(self, uuids):
        size = len(uuids)
        code = None

        for idx, uuid in enumerate(uuids):
            try:
                instance = CustomInstance.objects.get(uuid=uuid)
                code = instance.code
                # Builder
                builder = CustomInstanceBuild(instance)
                builder.build()
                # Publish and deploy
                publisher = CustomInstancePublish(instance)
                publisher.publish()
                publisher.deploy()
                repository = publisher.after_deploy()
                self.messages.append(f'({idx + 1}/{size}) "{uuid}" (code={code}) : success')
                load_balance_name = repository.load_balance_name
                node_name = repository.node_name

                try:
                    s3_clean_package(
                        instance.uuid,
                        repository.sub_state.state.access_aws_config,
                        set(CustomInstanceRepository.objects.filter(
                            custom_instance=instance
                        ).values_list('build_no', flat=True))
                    )
                    DeploymentMailer(repository.sub_state,
                                    load_balance_name,
                                    node_name
                                    ).async_send()
                except Exception as e:
                    self.logger.error('Clean S3 or Send email Fail - {}'.format(str(e))) 

            except ObjectDoesNotExist as e:
                self.logger.error(str(e))
                self.messages.append(f'({idx + 1}/{size}) "{uuid}" (code=?) : error UUID not existing')
            except Exception as e:
                self.logger.error(str(e))
                self.messages.append(f'({idx + 1}/{size}) "{uuid}" (code={code}) : error {str(e)}')
        self.__exit()

    def re_publish(self, uuids):
        size = len(uuids)
        code = None
        for idx, uuid in enumerate(uuids):
            try:
                repository = CustomInstanceRepository.objects.get(uuid=uuid)
                # Publish and deploy
                publisher = CustomInstancePublish(repository=repository)
                publisher.publish()
                publisher.deploy()
                publisher.after_deploy()
                self.messages.append(f'({idx + 1}/{size}) "{uuid}" (repo_code={code}) : success')
            except ObjectDoesNotExist as e:
                self.logger.error(str(e))
                self.messages.append(f'({idx + 1}/{size}) "{uuid}" (code=?) : error UUID not existing')
            except Exception as e:
                self.logger.error(str(e))
                self.messages.append(f'({idx + 1}/{size}) "{uuid}" (repo_code={code}) : error {str(e)}')
        self.__exit()

    def remove(self, uuids):
        size = len(uuids)
        for idx, uuid in enumerate(uuids):
            try:
                try:
                    repository = CustomInstanceRepository.objects.get(uuid=uuid)
                except ObjectDoesNotExist:
                    raise Exception("CustomInstanceRepository not exist")

                flow = FlowInstance.objects.filter(instance_type=InstanceType.Custom.value,
                                                   instance_uuid=repository.uuid).first()
                if flow:
                    raise Exception(
                        f"Repository ('{repository.uuid}') existing, please check flow ('{flow.uuid}') before delete", )
                destroyer = CustomInstanceDestroy(repository)
                destroyer.destroy()
                s3_clean_package(
                    repository.custom_instance.uuid,
                    repository.sub_state.state.access_aws_config,
                    set(CustomInstanceRepository.objects.filter(
                        custom_instance=repository.custom_instance
                    ).values_list('build_no', flat=True))
                )
                self.messages.append(f'({idx + 1}/{size}) "{uuid}" (code={repository.code}) : success')
            except ObjectDoesNotExist as e:
                self.logger.error(str(e))
                self.messages.append(f"({idx + 1}/{size}) [{uuid}] :Error UUID not existing")
            except Exception as e:
                self.logger.error(str(e))
                self.messages.append(f"({idx + 1}/{size}) [{uuid}] :Error {str(e)}")
        self.__exit()

    def purge(self, uuids):
        size = len(uuids)
        for idx, uuid in enumerate(uuids):
            try:
                instance = CustomInstance.objects.get(uuid=uuid)
                purger = CustomInstancePurge(instance)
                purger.purge()
                self.messages.append(f'({idx + 1}/{size}) "{uuid}" (code={instance.code}) : success')
            except ObjectDoesNotExist as e:
                self.logger.error(str(e))
                self.messages.append(f"({idx + 1}/{size}) [{uuid}] :Error UUID not existing")
            except Exception as e:
                self.logger.error(str(e))
                self.messages.append(f"({idx + 1}/{size}) [{uuid}] :Error {str(e)}")
        self.__exit()

    def move(self, uuids, dest_sub_state_id):
        size = len(uuids)
        code = None
        for idx, uuid in enumerate(uuids):
            try:
                repository = CustomInstanceRepository.objects.filter(uuid=uuid).first()
                if not repository:
                    raise Exception("CustomInstanceRepository not exist")
                old_sub_state = repository.sub_state
                code = repository.code

                try:
                    next_sub_state = SubState.objects.get(pk=dest_sub_state_id)
                except ObjectDoesNotExist:
                    raise Exception(f"Sub State {dest_sub_state_id} not exist")
                print("1")
                publisher = CustomInstancePublish(repository=repository, sub_state=next_sub_state)
                print("2")
                publisher.publish()
                publisher.deploy()
                publisher.after_deploy()
                print("b")
                self.messages.append(f'({idx + 1}/{size}) "{uuid}" (code={code}) : success')
                load_balance_name = repository.load_balance_name
                node_name = repository.node_name
                try:
                    DeploymentMailer(repository.sub_state,
                                    load_balance_name,
                                    node_name
                                    ).async_send()
                    s3_clean_package(
                        repository.custom_instance.uuid,
                        old_sub_state.state.access_aws_config,
                        set(CustomInstanceRepository.objects.filter(
                            custom_instance=repository.custom_instance
                        ).values_list('build_no', flat=True)))

                except Exception as e:
                    self.logger.error('Clean S3 or Send email Fail - {}'.format(str(e))) 

            except ObjectDoesNotExist as e:
                self.logger.error(str(e))
                self.messages.append(f'({idx + 1}/{size}) "{uuid}" (code=?) : error UUID not existing')
            except Exception as e:
                self.logger.error(str(e))
                self.messages.append(f'({idx + 1}/{size}) "{uuid}" (code={code}) : error {str(e)}')
        self.__exit()
