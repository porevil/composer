from unittest import TestCase

from apps.commons.managers.load_balance_manager import get_total_instance_deploy
from apps.commons.notification.mailer import DeploymentMailer
from apps.commons.utilities.cache import Cache
from apps.configurations.models import SubState
from apps.custom_instance.models import CustomInstanceRepository
from apps.node_repositories.models import NodeRepository
# template_id = '47_2'
# mail_content = "This is content"
# mail_subject = "Test Content"
# mail_template = MailAlertTemplate(mail_content, 2, subject_status=mail_subject)

class AbsMailerTest(TestCase):
    def setUp(self) -> None:
        self.sub_state = SubState.objects.first()
        self.deploy_spec = self.sub_state.deployment_specification
        self.load_balance = self.deploy_spec.config.get('load_balances')[0]
        self.instance_count = get_total_instance_deploy(
            self.sub_state,
            self.load_balance['name'],
            self.load_balance['nodes'][0]['name'],
        )
        self.mailer = DeploymentMailer(
            self.sub_state,
            self.load_balance['name'],
            self.load_balance['nodes'][0]['name'],
            deployed_instance=60
        )


class SyncTest(AbsMailerTest):

    def test_sync_mail(self):
        mailer = DeploymentMailer(
            self.sub_state,
            self.load_balance['name'],
            self.load_balance['nodes'][0]['name'],
            deployed_instance=4
        )
        mailer.send()

        mailer2 = DeploymentMailer(
            self.sub_state,
            self.load_balance['name'],
            self.load_balance['nodes'][0]['name'],
            deployed_instance=80
        )
        mailer2.send()

        mailer2 = DeploymentMailer(
            self.sub_state,
            self.load_balance['name'],
            self.load_balance['nodes'][0]['name'],
            deployed_instance=88
        )
        mailer2.send()

        mailer3 = DeploymentMailer(
            self.sub_state,
            self.load_balance['name'],
            self.load_balance['nodes'][0]['name'],
            deployed_instance=100
        )
        mailer3.send()
        self.assertTrue(True)
        Cache().delete(self.mailer.cache_prefix_name)

class AsyncTest(AbsMailerTest):

    def test_async_mail(self):
        self.mailer.async_send()
        self.assertTrue(True)
        Cache().delete(self.mailer.cache_prefix_name)


class ForceSentTest(AbsMailerTest):

    def test_force_send_mail(self):
        """
        Test send email by ignore time gap
        """
        self.mailer.send(check_latest=False)
        self.assertTrue(True)
        Cache().delete(self.mailer.cache_prefix_name)

