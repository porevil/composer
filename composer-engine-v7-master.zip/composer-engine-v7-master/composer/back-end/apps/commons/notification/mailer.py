import enum

from django.conf import settings
import threading
import uuid
import datetime

from json import JSONDecodeError
from django.conf import settings
from apps.commons.connectors.collaborator import Notification
from apps.commons.managers.load_balance_manager import get_total_instance_deploy
from apps.configurations.models import SubState
from apps.commons.utilities.log import Logger
from apps.commons.utilities.cache import Cache
from apps.commons.generator.systemconfig import CollaborationServiceConfig


class EmailStatus:
    NORMAL = ("Normal", 1)
    WARNING = ("Warning", 2)
    CRITICAL = ("Critical", 3)


class DeploymentMailer:
    cache_prefix_name = settings.MAIL_CACHE_PREFIX_NAME

    time_gap = settings.MAIL_ALERT_TIME_GAP  # seconds

    application_code = settings.APPLICATION_CODE

    logger = Logger("DeploymentMailer")

    sender = None

    limit_instance = None

    deployed_instance = None

    warning_threshold = None

    critical_threshold = None

    free_slot = None

    def __init__(self, sub_state: SubState, load_balance_name, node_name, **kwargs):
        """
        Config
        :param sub_state:
        :param kwargs:
        """
        self.sub_state = sub_state
        self.deployment_spec = sub_state.deployment_specification
        self.node_info = self.deployment_spec.get_node(load_balance_name, node_name)
        self.notification_config = self.deployment_spec.config['notification']
        self.recipients = self.notification_config['recipients']
        self.cc = self.notification_config.get('cc', [])
        self.bcc = self.notification_config.get('bcc', [])
        self.collaborator_service = CollaborationServiceConfig.get(sub_state.state)
        session_id = kwargs.get('session_id', str(uuid.uuid4()))
        sender_params = {
            'service_endpoint': self.collaborator_service.get('endpoint'),
            'client_id': self.collaborator_service.get('mule_client_id'),
            'client_secret': self.collaborator_service.get('mule_client_secret'),
            'user_id': self.collaborator_service.get('service_account'),
            'user_name': settings.ENGINE_NAME,
            'session_id': session_id
        }
        self.sender = Notification(**sender_params)
        self.deployed_instance = kwargs.get('deployed_instance',
                                            get_total_instance_deploy(sub_state, load_balance_name, node_name))
        self.free_slot = self.node_info["limit_instance"] - self.deployed_instance
        self.logger.set_session_id(session_id=session_id)

    @property
    def email_status(self):
        """

        :return: EmailStatus
        """
        if self.free_slot <= self.deployment_spec.config['notification']["critical_threshold"]:
            return EmailStatus.CRITICAL
        elif self.free_slot <= self.deployment_spec.config['notification']["warning_threshold"]:
            return EmailStatus.WARNING
        else:
            return EmailStatus.NORMAL

    @property
    def template_id(self):
        """

        :return: TemplateID
        """
        if self.email_status == EmailStatus.NORMAL:
            return self.notification_config.get('normal_template_id')
        return self.notification_config.get('warning_template_id')

    def async_send(self, **kwargs):
        """
        Send email with threading (do not need to wait for result)
        """
        t = threading.Thread(self.send(**kwargs))
        t.start()

    def send(self, check_latest=True, **kwargs):
        """
        Send email and waiting for result
        """
        # print(f"free_slot: {self.free_slot} mail status: {self.email_status}")

        self.__validate_before_send()

        if check_latest and not self.__is_schedule():
            self.logger.debug("Email not sent because different less than time gap setting")
            return

        template_variable = kwargs.get('template_variable', {})
        template_variable['subject'] = self.__get_subject()
        template_variable['free_slot'] = str(self.free_slot)
        template_variable['node_name'] = self.node_info['name']
        # template_variable['content'] = self.__get_content()

        res = self.sender.send_mail(
            application_code=self.application_code,
            template_id=self.template_id,
            recipient=self.recipients,
            cc=self.cc,
            bcc=self.bcc,
            template_variable=template_variable
        )

        if res.status_code != 200:
            message = {
                'url': self.sender.service_endpoint,
                'request_data': self.sender.request_data,
                'request_header': self.sender.request_header,
            }
            if 'json' in res.headers.get('Content-Type', ''):
                message['data'] = res.json()

            self.logger.error(f"session_id: {self.sender.session_id} Error Response: {message}")
            self.logger.error(f"session_id: {self.sender.session_id} Error Request data: {self.sender.request_data}")
            self.logger.error(
                f"session_id: {self.sender.session_id} Error Request header: {self.sender.request_header}")
            raise Exception(message)

        try:
            res_json = res.json()
        except JSONDecodeError as e:
            self.logger.error("Cannot decode as JSON from response")
            raise e

        if res_json.get('meta', None) and int(res_json['meta'].get('response_code', 1)) % 10000 == 0:
            self.logger.debug("Send mail success")
            self.__set_latest_sent()
            return
        else:  # json response error (error with desc)
            message = {
                'message': "Fail meta code",
                'response': res_json,
                'request_data': self.sender.request_data,
                'request_header': self.sender.request_header,
            }
            self.logger.error(f"session_id: {self.sender.session_id} Error Response: {res_json}")
            self.logger.error(f"session_id: {self.sender.session_id} Error Request data: {self.sender.request_data}")
            self.logger.error(
                f"session_id: {self.sender.session_id} Error Request header: {self.sender.request_header}")
            raise Exception(message)

    def __validate_before_send(self):
        """
        Validate and raise Exception if validate fail
        :return: boolean
        """
        self.logger.debug("Validating before send")
        try:
            if not self.recipients:
                raise ValueError("recipients must not empty")
            elif not self.template_id:
                raise ValueError("template_id must not empty")
            elif self.cc is None or self.bcc is None:
                raise ValueError("bcc and cc must be empty array not null")
            else:
                return True
        except Exception as e:
            self.logger.debug(f"session_id: {self.sender.session_id} Validate fail {str(e)}")
            raise e

    def __get_latest_sent(self):
        latest = Cache().get_json(self.cache_prefix_name)
        return latest

    def __set_latest_sent(self):
        try:
            data = {
                'timestamp': str(datetime.datetime.now()),
                'status': self.email_status[1]
            }
            Cache().put_json(self.cache_prefix_name, data, self.time_gap)
            return True
        except Exception as e:
            self.logger.error(f"Set Latest Sent Fail: {str(e)}")
            return False

    def __is_schedule(self):
        cache_latest = self.__get_latest_sent()
        cache_status = cache_latest.get('status', 0)
        self.logger.debug(f"cache_latest: {cache_latest}")
        if cache_latest:
            cache_date = datetime.datetime.strptime(cache_latest.get('timestamp', datetime.datetime.now()),
                                                    '%Y-%m-%d %H:%M:%S.%f')
            now = datetime.datetime.now()
            diff = now - cache_date
            self.logger.debug(
                f"Cache date: [{cache_date}], current status: {self.email_status[1]} cache status: {cache_status}")

            if self.email_status[1] > cache_status:
                return True
            elif diff.seconds <= self.time_gap:  # no need to sent again
                return False
            else:
                return False
        return True

    def __get_subject(self):
        subject = F"[{self.email_status[0]}] MBS Resources at {self.node_info['name']}"
        return subject
    

    # def __get_content(self):

    #     if self.email_status == EmailStatus.NORMAL:
    #         content = F"Dear All,<br\\>" \
    #                   f"&nbsp;MBS Service have deployed at {self.node_info['name']}.<br\\>" \
    #                   f"Space remaining {self.free_slot} MBS"
    #     else:
    #         content = f"Dear All,<br\\>" \
    #                   f"&nbsp;MBS Resources at {self.node_info['name']} is a little of space (less than {self.free_slot} MBS)." \
    #                   f"Please, create machine instance and contact composer team"
    #     return content
