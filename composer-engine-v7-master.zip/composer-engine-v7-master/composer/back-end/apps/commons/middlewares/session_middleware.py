from apps.commons.utilities.log import Logger
from tisco.core.tfg_log.logger import TfgLogger
from uuid import uuid4


def get_session_id(request):
    # TODO: Add logic to find session id here
    return getattr(request, 'session_id', None)


class RequestSessionMiddleware(object):
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        _session_id = get_session_id(request)
        if _session_id:
            request.session_id = _session_id
        request.session_id = str(uuid4())
        return self.get_response(request)
