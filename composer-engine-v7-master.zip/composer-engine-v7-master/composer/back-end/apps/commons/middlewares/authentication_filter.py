# Deprecated
# Use OpenID instead

# from django.conf import settings
# from django.http import HttpResponse
# from django.shortcuts import render
# from django.utils.deprecation import MiddlewareMixin
#
# from apps.authentication.views import SAMLAuthen
#
#
# class AuthenticationFilter(MiddlewareMixin):
#
#     def process_request(self, request):
#         if settings.BYPASS_AUTHEN == False:
#             ignore_url = False
#             for url in settings.IGNORE_FILTER_URL:
#                 if request.path.startswith(url):
#                     ignore_url = True
#                     break
#
#             if ignore_url == False:
#                 token = request.headers.get('token')
#                 if token is None:
#                     return HttpResponse('401 Unauthorized - Authentication Filter (Token not found)', status=401)
#
#                 result, desc = SAMLAuthen.getAccess(request, token)
#                 if result == False:
#                     message = '401 Unauthorized - Authentication Filter'
#                     return HttpResponse(message, status=401)
#
#             return None