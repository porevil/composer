import uuid
import os
import sys
import pytz

from django.utils.timezone import now, utc
from django.http import JsonResponse, HttpRequest
from django.conf import settings
from datetime import datetime


from apps.commons.utilities.response import ResponseAPI
from apps.commons.utilities.log import Logger
from apps.commons.error.exception import *
from apps.authentication.models import OpenIDUser as User, JSONWebToken


def get_id_token_header(request):
    id_token = request.headers.get('Authorization', None)
    if id_token and 'token' in id_token:
        return id_token.split(" ")[1]
    return None


def get_id_token_cookie(request):
    id_token = request.COOKIES.get('id_token', None)
    return id_token


def get_id_token(request):
    return get_id_token_cookie(request) or get_id_token_header(request)


class JWTMiddleware:
    request = None
    logger = Logger("JWTMiddleware")

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request: HttpRequest):
        self.logger.set_session_id(request.session_id)
        try:
            if request.path.startswith(settings.IGNORE_FILTER_URL):
                return self.get_response(request)
            else:
                id_token = get_id_token(request)
                jwt_model = JSONWebToken.objects.filter(id_token=id_token).first()
                if jwt_model is None:
                    raise Exception("Not Found Token")

                self.logger.debug("now : {} | expired_at : {}".format(now(),jwt_model.expired_at))
                if jwt_model and now() <= jwt_model.expired_at:
                    request.oidc_user = User(id_token)
                    self.logger.debug(f"Session as {request.oidc_user} {request.oidc_user.permission}")
                    return self.get_response(request)
                if now() > jwt_model.expired_at:
                    jwt_model.delete()
                    raise Exception("Session Timeout")

            raise Exception("Invalid Token")

        except Exception as e:
            if request.path.startswith(settings.SOFT_AUTH_URL):
                self.logger.debug("Request passed by soft authentication")
                return self.get_response(request)

            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = ResponseAPI()
            data = response.error(UnAuthorizedException('Unauthorized'), exception_message, str(uuid.uuid4()))
            return JsonResponse(data)
