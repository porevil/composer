import uuid
import traceback
import os
import sys

from django.http import HttpResponse, JsonResponse, HttpRequest
from django.conf import settings
from apps.commons.utilities.response import ResponseAPI
from apps.commons.error.exception import *


class ApplicationCodeMiddleware:

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        app_code = request.headers.get('app-code', None)
        if request.path.startswith(settings.IGNORE_FILTER_URL):
            return self.get_response(request)
        if request.path.startswith(settings.SOFT_AUTH_URL):
            return self.get_response(request)
        elif str(app_code) in request.oidc_user.permission:
            return self.get_response(request)
        else:
            response = ResponseAPI()
            tb = traceback.format_exc()
            data = response.error(InvalidAppCodeException('Invalid app code'), tb, str(uuid.uuid4()))
            return JsonResponse(data, status=200)
