import uuid
import os
import sys

import rest_framework_filters as filters
from rest_framework import viewsets
from rest_framework.response import Response
from rest_framework import status
from rest_framework.schemas import AutoSchema

from apps.commons.utilities.log import Logger
from apps.commons.utilities.response import ResponseAPI
from apps.commons.connectors.launcher_flow import LauncherFlow
from apps.commons.connectors.launcher_procedure import LauncherProcedure
from apps.commons.connectors.launcher_application import LauncherApplication
from apps.configurations.models import SubState
from apps.flow.models import FlowRepository
from apps.commons.serializers import AbstractSerializer
from apps.commons.error.exception import *
import uuid as uuid_gen


def is_valid_uuid(request_uuid, version=4):
    try:
        uuid_obj = uuid_gen.UUID(str(request_uuid), version=version)
    except ValueError:
        return False

    return str(uuid_obj) == request_uuid

class LauncherFilter(filters.FilterSet):

    class Meta:
        model = FlowRepository
        fields = {
            'uuid': ['exact'],
            'code': ['exact', 'icontains'],
            'name': ['exact', 'icontains'],
            'sub_state_id': ['exact']
        }


class LauncherFlowViewSet(viewsets.ModelViewSet):
    response_meta = ResponseAPI()
    reference_id = str(uuid_gen.uuid4())
    filter_class = LauncherFilter
    serializer_class = AbstractSerializer
    queryset = FlowRepository.objects.all()

    def list(self, request):
        try:
            logger = Logger('List Flow')
            logger.debug('list flow [reference id = {}] start'.format(self.reference_id))

            sub_state_id = request.query_params.get('sub_state_id')
            if sub_state_id is None:
                raise BadRequestException('"sub state id" is required')

            request_uuid = request.query_params.get('uuid')
            if request_uuid is not None and request_uuid:
                is_valid = is_valid_uuid(request_uuid)

                if not is_valid:
                    raise BadRequestException('"uuid" is invalid')

            sub_state = SubState.objects.filter(id=sub_state_id).first()
            if sub_state is None:
                raise BadRequestException('"sub state id" is invalid')

            criteria = dict()
            for key, value in request.query_params.items():
                if key.startswith('code') or key.startswith('name') or key in ['system_data', 'uuid']:
                    criteria[key] = value

            logger.debug('list flow [reference id = {}] sub state name: {}'.format(self.reference_id, sub_state.name))

            response = LauncherFlow.list(sub_state, **criteria)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            logger.error('list flow [reference id = {}] exception - {}'.format(self.reference_id, exception_message))
            
        finally:
            logger.debug('list flow [reference id = {}] response: {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)


    def retrieve(self, request, pk=None):
        try:
            logger = Logger('Get Flow')
            logger.debug('get flow [reference id = {}] start'.format(self.reference_id))

            sub_state_id = request.query_params.get('sub_state_id')
            if sub_state_id is None:
                raise BadRequestException('"sub state id" is required')

            sub_state = SubState.objects.filter(id=sub_state_id).first()
            if sub_state is None:
                raise BadRequestException('"sub state id" is invalid')

            logger.debug('get flow [reference id = {}] sub state name: {}'.format(self.reference_id, sub_state.name))

            if pk is None:
                raise BadRequestException('"uuid" is required')
            # pk is flow uuid
            uuid = pk
            response = LauncherFlow.get(sub_state, uuid)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            logger.error('get flow [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            logger.debug('get flow [reference id = {}] response: {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)


class LauncherProcedureViewSet(viewsets.ModelViewSet):
    response_meta = ResponseAPI()
    reference_id = str(uuid_gen.uuid4())
    filter_class = LauncherFilter
    serializer_class = AbstractSerializer
    queryset = FlowRepository.objects.all()

    def list(self, request):
        try:
            logger = Logger('List Procedure')
            logger.debug('list procedure [reference id = {}] start'.format(self.reference_id))

            sub_state_id = request.query_params.get('sub_state_id')
            if sub_state_id is None:
                raise BadRequestException('"sub state id" is required')

            request_uuid = request.query_params.get('uuid')
            if request_uuid is not None and request_uuid:
                is_valid = is_valid_uuid(request_uuid)

                if not is_valid:
                    raise BadRequestException('"uuid" is invalid')

            sub_state = SubState.objects.filter(id=sub_state_id).first()
            if sub_state is None:
                raise BadRequestException('"sub state id" is invalid')

            criteria = dict()
            for key, value in request.query_params.items():
                if key.startswith('code') or key.startswith('name') or key in ['system_data', 'uuid']:
                    criteria[key] = value

            logger.debug('list procedure [reference id = {}] sub state name: {}'.format(self.reference_id, sub_state.name))

            response = LauncherProcedure.list(sub_state, **criteria)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            logger.error('list procedure [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            logger.debug('list procedure [reference id = {}] response: {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)


    def retrieve(self, request, pk=None):
        try:
            logger = Logger('Get Procedure')
            logger.debug('get procedure [reference id = {}] start'.format(self.reference_id))

            sub_state_id = request.query_params.get('sub_state_id')
            if sub_state_id is None:
                raise BadRequestException('"sub state id" is required')

            sub_state = SubState.objects.filter(id=sub_state_id).first()
            if sub_state is None:
                raise BadRequestException('"sub state id" is invalid')

            logger.debug('get procedure [reference id = {}] sub state name: {}'.format(self.reference_id, sub_state.name))

            # pk is procedure uuid
            if pk is None:
                raise BadRequestException('"uuid" is required')

            uuid = pk
            response = LauncherProcedure.get(sub_state, uuid)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            logger.error('get procedure [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            logger.debug('get procedure [reference id = {}] response: {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)


    def create(self, request):
        try:
            logger = Logger('Create or Update Service Repository')
            logger.debug('create or update procedure [reference id = {}] start'.format(self.reference_id))

            request_data = request.data
            logger.debug('create or update procedure [reference id = {}] request data: {}'.format(self.reference_id, request_data))

            sub_state_id = request_data.get('sub_state_id')
            uuid = request_data.get('uuid') or str(uuid_gen.uuid4())
            code = request_data.get('code')
            name = request_data.get('name')
            description = request_data.get('description')
            system_data = request_data.get('system_data') or False
            display_label = request_data.get('display_label')
            flow_uuids = request_data.get('flow_uuids') or list()

            if code is None:
                raise BadRequestException('"code" is required')
            if name is None:
                raise BadRequestException('"name" is required')
            if sub_state_id is None:
                raise BadRequestException('"sub state id" is required')

            sub_state = SubState.objects.filter(id=sub_state_id).first()
            if sub_state is None:
                raise BadRequestException('"sub state id" is invalid')

            logger.debug('create or update procedure [reference id = {}] sub state name: {}'.format(self.reference_id, sub_state.name))

            response = LauncherProcedure.create_or_update(sub_state, uuid, **{
                'code': code,
                'name': name,
                'description': description,
                'display_label': display_label,
                'system_data': system_data,
                'flow_uuids': flow_uuids
            })

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            logger.error('create procedure [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            logger.debug('create procedure [reference id = {}] response: {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)


    def destroy(self, request,  *args, **kwargs):
        try:
            logger = Logger('Delete Application')
            logger.debug('delete procedure [reference id = {}] start'.format(self.reference_id))

            sub_state_id = request.query_params.get('sub_state_id')
            if sub_state_id is None:
                raise BadRequestException('"sub state id" is required')

            sub_state = SubState.objects.filter(id=sub_state_id).first()
            if sub_state is None:
                raise BadRequestException('"sub state id" is invalid')

            logger.debug('delete procedure [reference id = {}] state name: {}'.format(self.reference_id, sub_state.name))
            pk = kwargs.get('pk', None)
            if pk is None:
                raise BadRequestException('"uuid" is required')
            response = LauncherProcedure.delete(sub_state, pk)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            logger.error('delete procedure [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            logger.debug('delete procedure [reference id = {}] response: {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)


class LauncherApplicationViewSet(viewsets.ModelViewSet):
    response_meta = ResponseAPI()
    reference_id = str(uuid_gen.uuid4())
    filter_class = LauncherFilter
    serializer_class = AbstractSerializer
    queryset = FlowRepository.objects.all()

    def list(self, request):
        try:
            logger = Logger('List Application')
            logger.debug('list application [reference id = {}] start'.format(self.reference_id))

            sub_state_id = request.query_params.get('sub_state_id')
            if sub_state_id is None:
                raise BadRequestException('"sub state id" is required')

            request_uuid = request.query_params.get('uuid')
            if request_uuid is not None and request_uuid:
                is_valid = is_valid_uuid(request_uuid)

                if not is_valid:
                    raise BadRequestException('"uuid" is invalid')

            sub_state = SubState.objects.filter(id=sub_state_id).first()
            if sub_state is None:
                raise BadRequestException('"sub state id" is invalid')

            criteria = dict()
            for key, value in request.query_params.items():
                if key == 'system_data' or key.startswith('code') or key.startswith('name'):
                    criteria[key] = value

            logger.debug('list application [reference id = {}] sub state name: {}'.format(self.reference_id, sub_state.name))

            response = LauncherApplication.list(sub_state, **criteria)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            logger.error('list application [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            logger.debug('list application [reference id = {}] response: {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)


    def retrieve(self, request, pk=None):
        try:
            logger = Logger('Get Application')
            logger.debug('get application [reference id = {}] start'.format(self.reference_id))

            sub_state_id = request.query_params.get('sub_state_id')
            if sub_state_id is None:
                raise BadRequestException('"sub state id" is required')

            sub_state = SubState.objects.filter(id=sub_state_id).first()
            if sub_state is None:
                raise BadRequestException('"sub state id" is invalid')

            logger.debug('get application [reference id = {}] sub state name: {}'.format(self.reference_id, sub_state.name))

            # pk is application code
            if pk is None:
                raise BadRequestException('"code" is required')

            code = pk
            response = LauncherApplication.get(sub_state, code)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            logger.error('get application [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            logger.debug('get application [reference id = {}] response: {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)


    def create(self, request):
        try:
            logger = Logger('Create or Update Service Repository')
            logger.debug('create or update application [reference id = {}] start'.format(self.reference_id))

            request_data = request.data
            logger.debug('create or update application [reference id = {}] request data: {}'.format(self.reference_id, request_data))

            sub_state_id = request_data.get('sub_state_id')
            code = request_data.get('code')
            name = request_data.get('name')
            description = request_data.get('description')
            system_data = request_data.get('system_data') or False
            # meta url is in config
            config = request_data.get('config') or dict()
            procedure_uuids = request_data.get('procedure_uuids') or list()

            if code is None:
                raise BadRequestException('"code" is required')
            if name is None:
                raise BadRequestException('"name" is required')
            if sub_state_id is None:
                raise BadRequestException('"sub state id" is required')

            sub_state = SubState.objects.filter(id=sub_state_id).first()
            if sub_state is None:
                raise BadRequestException('"sub state id" is invalid')

            logger.debug('create or update application [reference id = {}] sub state name: {}'.format(self.reference_id, sub_state.name))

            response = LauncherApplication.create_or_update(sub_state, code, **{
                'name': name,
                'description': description,
                'config': config,
                'system_data': system_data,
                'procedure_uuids': procedure_uuids,
            })

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            logger.error('create application [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            logger.debug('create application [reference id = {}] response: {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def destroy(self, request, *args, **kwargs):
        try:
            logger = Logger('Delete Application')
            logger.debug('delete application [reference id = {}] start'.format(self.reference_id))

            sub_state_id = request.query_params.get('sub_state_id')
            if sub_state_id is None:
                raise BadRequestException('"sub state id" is required')

            sub_state = SubState.objects.filter(id=sub_state_id).first()
            if sub_state is None:
                raise BadRequestException('"sub state id" is invalid')

            logger.debug('delete application [reference id = {}] state name: {}'.format(self.reference_id, sub_state.name))
            code = kwargs.get('pk', None)
            if code is None:
                raise BadRequestException('"code" is required')
            response = LauncherApplication.delete(sub_state, code)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            logger.error('delete application [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            logger.debug('delete application [reference id = {}] response: {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)

