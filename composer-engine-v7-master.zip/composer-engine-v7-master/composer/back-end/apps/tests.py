from unittest import TestCase
from apps.commons.connectors import s3
import os

class S3ClietTest(TestCase):
    region = os.environ.get("INSTANCE_PACKAGE_REPOSITORY_REGION")
    id = os.environ.get("INSTANCE_PACKAGE_REPOSITORY_ACCESS_KEY_ID")
    key = os.environ.get("INSTANCE_PACKAGE_REPOSITORY_SECRET_ACCESS_KEY")

    def setUp(self):
        self.client = s3.S3Client(aws_access_key_id=self.id,
                                  aws_secret_access_key=self.key,
                                  region_name=self.region)
        #     aws_access_key_id=kwargs.get('aws_access_key_id'),
        #     aws_secret_access_key=kwargs.get('aws_secret_access_key'),
        #     region_name=kwargs.get('aws_region'),

    def test_list_object(self):
        objects = self.client.list_objects('tisco.alpha.mobileplatform.app')
        self.assertAlmostEqual(len(objects.data), 0)