from django.apps import AppConfig


class GeneratorSettingConfig(AppConfig):
    name = 'generator_setting'
