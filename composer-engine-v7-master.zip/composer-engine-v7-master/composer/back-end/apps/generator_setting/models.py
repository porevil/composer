import reversion

from jsonfield import JSONField
from django.db import models
from django.utils.translation import ugettext_lazy as _
from apps.metadata.models import Datafield, Dataset


@reversion.register()
class DatafieldSetting(models.Model):
    name = models.CharField(max_length=100, unique=True, verbose_name=_("Field Name"))
    config = JSONField(default=dict(), verbose_name=_("Config"))
    created_by = models.CharField(max_length=100, blank=True, null=True, verbose_name=_("Created by"))
    updated_by = models.CharField(max_length=100, blank=True, null=True, verbose_name=_("Updated by"))
    created_date = models.DateTimeField(auto_now_add=True, verbose_name=_("Created date"))
    updated_date = models.DateTimeField(auto_now=True, blank=True, verbose_name=_("Updated date"))

    def __str__(self):
        return "%s " % (self.name)


@reversion.register()
class VirtualGroup(models.Model):
    name = models.CharField(max_length=100, unique=True, verbose_name=_("Name"))
    main_dataset_name = models.CharField(max_length=200, blank=True, default='', verbose_name=_("Main Dataset Name"))
    description = models.CharField(max_length=200, null=True, blank=True, verbose_name=_("Description"))
    config = JSONField(default=dict(), verbose_name=_("Configuration"))
    created_by = models.CharField(max_length=100, blank=True, null=True, verbose_name=_("Created by"))
    updated_by = models.CharField(max_length=100, blank=True, null=True, verbose_name=_("Updated by"))
    created_date = models.DateTimeField(auto_now_add=True, verbose_name=_("Created date"))
    updated_date = models.DateTimeField(auto_now=True, blank=True, verbose_name=_("Updated date"))

    def __str__(self):
        return "%s " % (self.name)


@reversion.register()
class VirtualElements(models.Model):
    group_id = models.ForeignKey(VirtualGroup, on_delete=models.deletion.CASCADE, verbose_name=_("Group Id"))
    element_name = models.CharField(max_length=100, default="", verbose_name=_("Element Name"))
    sequence = models.IntegerField(null=True, blank=True, verbose_name=_("Sequence"))
    description = models.CharField(max_length=200, verbose_name=_("Description"))

    def __str__(self):
        return "%s " % (self.element_name)


# Create your models here.
@reversion.register()
class VirtualDatafieldConfig(models.Model):
    field_id = models.ForeignKey(Datafield, on_delete=models.deletion.CASCADE, verbose_name=_("Field Id"))
    element_id = models.ForeignKey(VirtualElements, on_delete=models.deletion.CASCADE, default="",
                                   verbose_name=_("Field Id"))
    sequence = models.IntegerField(null=True, blank=True, verbose_name=_("Sequence"))
    config = JSONField(default=dict(), verbose_name=_("Configuration"))
    parent_virtual_config = models.ForeignKey('self', 
                                                null=True,
                                                blank=True,
                                                default=None,
                                                on_delete=models.deletion.CASCADE, 
                                                verbose_name=_("parent virtual configuration"))

    def __str__(self):
        return "%s " % (self.field_id)


@reversion.register()
class DatasetConfiguration(models.Model):
    dataset_id = models.OneToOneField(Dataset, on_delete=models.deletion.CASCADE, verbose_name=_("Dataset Id"))
    description = models.CharField(max_length=200, null=True, blank=True, verbose_name=_("Description"))
    config = JSONField(default=dict(), verbose_name=_("Configuration"))
    created_by = models.CharField(max_length=100, blank=True, null=True, verbose_name=_("Created by"))
    updated_by = models.CharField(max_length=100, blank=True, null=True, verbose_name=_("Updated by"))
    created_date = models.DateTimeField(auto_now_add=True, verbose_name=_("Created date"))
    updated_date = models.DateTimeField(auto_now=True, blank=True, verbose_name=_("Updated date"))

    def __str__(self):
        return "%s " % (self.description)


@reversion.register()
class DatasetSetting(models.Model):
    field_id = models.ForeignKey(Datafield, on_delete=models.deletion.CASCADE, verbose_name=_("DataField Id"))
    dataset_configuration_id = models.ForeignKey(DatasetConfiguration, on_delete=models.deletion.CASCADE, default="",
                                                 verbose_name=_("Dataset Additional Condition Id"))
    sequence = models.IntegerField(null=True, blank=True, verbose_name=_("Sequence"))
    config = JSONField(default=dict(), verbose_name=_("Configuration"))

    class Meta:
        unique_together = [('field_id', 'dataset_configuration_id')]

    def __str__(self):
        return "%s " % (self.field_id)
