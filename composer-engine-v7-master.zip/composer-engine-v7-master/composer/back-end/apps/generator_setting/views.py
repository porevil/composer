import uuid
import traceback
import os
import sys

from django.db import transaction
from django.db import Error
from django.db.models import Count
from django.shortcuts import render
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.decorators import api_view
from rest_framework import status, generics

from apps.generator_setting.models import *
from apps.generator_setting.api.serializers import *
from apps.metadata.api.serializers import *
from apps.metadata.models import Datafield, Dataset
from apps.commons.connectors.metadata import Metadata
from apps.configurations.models import SubState
from apps.commons.utilities.log import Logger
from apps.commons.generator.configuration.constants import ActivityConstants
from apps.commons.managers.role import RoleManager
from apps.commons.utilities.response import ResponseAPI
from apps.commons.error.exception import *


def _get_metadata(dataset_name):
    response_meta = ResponseAPI()
    reference_id = str(uuid.uuid4())
    logger = Logger('Core API', 'Get Metadata')
    
    try:
        logger.debug('get metadata [reference id = {}] start'.format(reference_id))

        metadata_sub_state = SubState.default()
        if metadata_sub_state is None:
            raise ConfigurationErrorException("has not default sub state")

        logger.debug('get metadata [reference id = {}] dataset name'.format(reference_id, dataset_name))

        RoleManager().grant_metadata_access_roles([dataset_name], metadata_sub_state)

        meta_response = Metadata.get(metadata_sub_state, dataset_name)
        # logger.debug('get metadata [reference id = {}] response - {}'.format(reference_id, meta_response))
        
        return meta_response
    
    except Exception as e:
        raise e
        

def _check_metadata_db(name, method_type=None, reference_id=None):
    response_meta = ResponseAPI()
    reference_id = reference_id or str(uuid.uuid4())
    logger = Logger('Get API', 'Check_metadata')

    try:
        logger.debug('check metadata DB [reference id = {}] start'.format(reference_id))

        dataset = Dataset.objects.filter(dataset_name=name).first()
        if dataset is None:
            with transaction.atomic():
                logger.debug('check metadata DB [reference id = {}] dataset name ({}) not found in db'.format(reference_id, name))
            
                metadata_response = _get_metadata(name)
                child_dataset = _list_sub_datasets(metadata_response,0)

                query_dataset = Dataset.objects.filter(dataset_name=name).first()

                response_data = DatasetSettingDetailSerializer(query_dataset).data

                datafields = response_data.get('datafields') or list()
                for datafield in datafields:
                    if datafield.get('parameter_type') in [ActivityConstants.PARAMETER_TYPE_EMBEDDED, ActivityConstants.PARAMETER_TYPE_TISCO]:

                        sub_datafields = datafield.get('datafields') or list()
                        for sub_datafield in sub_datafields:
                            sub_datafield['sequence'] = None
                            sub_datafield['config'] = dict()
                            sub_datafield['datafield_setting_config'] = dict()

                        datafield['sequence'] = None
                        datafield['config'] = dict()
                        datafield['datafield_setting_config'] = dict()

                response = response_meta.success("success", reference_id, response_data)
     
        else:
            logger.debug('check metadata DB [reference id = {}] dataset name ({}) found in db'.format(reference_id, name))

            response_data = DatasetSettingDetailSerializer(dataset).data
            datafields = response_data.get('datafields') or list()

            if method_type == 'DATASETSETING':
                dataset_configurations = DatasetSetting.objects.filter(dataset_configuration_id__dataset_id__dataset_name=name)
            else:
                #old version not use 
                dataset_configurations = VirtualDatafieldConfig.objects.filter(field_id__dataset_id__dataset_name=name)

            for datafield in datafields:
                found = False
                for dataset_configuration in dataset_configurations:
                    if datafield.get('id') == dataset_configuration.field_id_id:
                        datafield['sequence'] = dataset_configuration.sequence
                        datafield['config'] = dataset_configuration.config
                        found = True
                        break

                if found == False:
                    if datafield.get('parameter_type') in [ActivityConstants.PARAMETER_TYPE_EMBEDDED, ActivityConstants.PARAMETER_TYPE_TISCO]:
                        sub_datafields = datafield.get('datafields') or list()

                        for sub_datafield in sub_datafields:
                            sub_datafield['sequence'] = None
                            sub_datafield['config'] = dict()
                            sub_datafield['datafield_setting_config'] = dict()

                    datafield['sequence'] = None
                    datafield['config'] = dict()
                    datafield['datafield_setting_config'] = dict()

            response = response_meta.success("success", reference_id, response_data)

    except Exception as e:
        fname = os.path.abspath(__file__)
        exc_type, exc_obj, exc_tb = sys.exc_info()
        exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

        response = response_meta.error(e, str(e) , reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

    finally:
        logger.debug('check metadata DB [reference id = {}] response - {}'.format(reference_id, response))
        return response


class CheckVersionDatasetFromDataEngine(generics.ListCreateAPIView):
    response_meta = ResponseAPI()
    reference_id = str(uuid.uuid4())
    serializer_class = DatasetDetailSerializer
    http_method_names = ['get']
    logger = Logger('Get API', 'Get Dataset From Data Engine')
    queryset = Datafield.objects.all()

    def get(self, request, name=None):
        try:
            self.logger.debug('get dataset version [reference id = {}] start'.format(self.reference_id))
            self.logger.debug('get dataset version [reference id = {}] dataset name - {}'.format(self.reference_id, name))

            if name is None:
                raise BadRequestException('"dataset name" is required')

            dataset = Dataset.objects.filter(dataset_name=name).first()
            if dataset is None:
                raise BadRequestException('"dataset name" is invalid')

            metadata_response = _get_metadata(name)

            metadata_version = metadata_response.get('version')
            if metadata_version is None:
                raise ExternalServerErrorException('Can\'t get dataset version from data engin')

            self.logger.debug('get dataset version [reference id = {}] dataset version - {}, metadata version - {}'.format(self.reference_id, dataset.version, metadata_version))

            if dataset.version != metadata_version:
                with transaction.atomic():
                    description =  metadata_response.get('description')
                    create_by = metadata_response.get('create_by')
                    update_by = metadata_response.get('update_by')

                    dataset.description = description
                    dataset.created_by = create_by
                    dataset.updated_by = update_by
                    dataset.version = metadata_version
                    dataset.save()

                    fields = metadata_response.get('fields') or list()
                    _fields = list()
                    for field in fields:
                        field_name = field.get('name')
                        field_type = field.get('type')
                        label_name = field.get('label_th')
                        parameter_type = field.get('parameter_type')

                        if parameter_type not in [ActivityConstants.PARAMETER_TYPE_EMBEDDED, ActivityConstants.PARAMETER_TYPE_TISCO]:
                            if field_name is None or field_type is None:
                                continue
                        
                        datafield, created = Datafield.objects.update_or_create(dataset_id=dataset, field_name=field_name,ref_name=None, defaults={
                            'dataset_id': dataset,
                            'field_name': field_name,
                            'field_type': field_type,
                            'label_name': label_name,
                            'parameter_type': parameter_type,
                        })

                        _fields.append(datafield.id)

                        if parameter_type in [ActivityConstants.PARAMETER_TYPE_EMBEDDED, ActivityConstants.PARAMETER_TYPE_TISCO]:
                            param_fields = field.get('fields')
                            _sub_fields = list()

                            for param_field in param_fields:
                                param_field_name = param_field.get('name')
                                param_field_type = param_field.get('type')
                                param_field_label_name = param_field.get('label_th')

                                if param_field_name is None or param_field_type is None:
                                    continue

                                sub_datafield, created = Datafield.objects.update_or_create(dataset_id=dataset, field_name=param_field_name, ref_name=field_name, defaults={
                                    'dataset_id': dataset,
                                    'field_name': param_field_name,
                                    'ref_name': field_name,
                                    'field_type': param_field_type,
                                    'label_name': param_field_label_name,
                                    'parameter_type': parameter_type,
                                })

                                _sub_fields.append(sub_datafield.id)

                            deleted_sub_datafield = Datafield.objects.filter(dataset_id=dataset, ref_name=field_name).exclude(id__in=_sub_fields)
                            deleted_sub_datafield.delete()

                    deleted_datafield = Datafield.objects.filter(dataset_id=dataset).exclude(id__in=_fields)
                    deleted_datafield.delete()

                    dataset_configuration = DatasetConfiguration.objects.filter(dataset_id__dataset_name=name).first()
                    if dataset_configuration is not None: 
                        datafields = Datafield.objects.filter(dataset_id__dataset_name=name)

                        _fields = list()
                        for datafield in datafields:
                            dataset_setting = DatasetSetting.objects.filter(dataset_configuration_id=dataset_configuration, field_id=datafield).first()
                            if dataset_setting is None:
                                dataset_setting = DatasetSetting.objects.create(**{
                                    'dataset_configuration_id': dataset_configuration,
                                    'field_id': datafield,
                                })
                            _fields.append(dataset_setting.id)

                        deleted_dataset_setting = DatasetSetting.objects.filter(dataset_configuration_id=dataset_configuration).exclude(id__in=_fields)
                        deleted_dataset_setting.delete()

            response = self.response_meta.success('success', self.reference_id)
            
        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('get dataset version [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('get dataset version [reference id = {}] response - {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)


class ListDatafieldSettingView(generics.ListCreateAPIView):
    response_meta = ResponseAPI()
    serializer_class = DatafieldSettingSerializer
    reference_id = str(uuid.uuid4())
    logger = Logger('Datafield Setting')
    queryset = DatafieldSetting.objects.all()

    def get(self, request, page=None):
        try:
            self.logger.debug('get datafield setting [reference id = {}] start'.format(self.reference_id))
            datafields = DatafieldSetting.objects.all()
            datafields = DatafieldSettingSerializer(datafields, many=True)

            response = self.response_meta.success('success', self.reference_id, datafields.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('get datafield setting [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('get datafield setting [reference id = {}] response - {}'.format(self.reference_id, str(response)))

            return Response(response, status=status.HTTP_200_OK)

    
    def create(self, request):
        try:
            self.logger.debug('create datafield setting [reference id = {}] start'.format(self.reference_id))

            request_data = request.data or dict()
            self.logger.debug('create datafield setting [reference id = {}] request data - {}'.format(self.reference_id, request_data))

            id = request_data.get('id')
            name = request_data.get('name')
            config = request_data.get('config') or dict()

            datafield = DatafieldSetting.objects.filter(name=name).first()

            if id is None:
                if datafield is None:
                    datafield = DatafieldSetting.objects.create(**{
                        'name': name,
                        'config': config,
                        'created_by': request.oidc_user.preferred_username,
                        'updated_by': request.oidc_user.preferred_username,
                    })
                else:
                    raise BadRequestException('"{}" is duplicate field name'.format(name))

            else:
                if datafield is None:
                    raise BadRequestException('"name" is invalid')

                datafield.name = name
                datafield.config = config
                datafield.updated_by = request.oidc_user.preferred_username
                datafield.save()

            response = self.response_meta.success('success', self.reference_id, DatafieldSettingSerializer(datafield).data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('create datafield setting [reference id = {}] exception - {}'.format(self.reference_id, exception_message))
            
        finally:
            self.logger.debug('create datafield setting [reference id = {}] response - {}'.format(self.reference_id, str(response)))

            return Response(response, status=status.HTTP_200_OK)


class RetrieveDatafieldSettingByNameView(generics.ListCreateAPIView):
    response_meta = ResponseAPI()
    serializer_class = DatafieldSettingSerializer
    reference_id = str(uuid.uuid4())
    logger = Logger('Retrieve Datafield Setting by Name')
    queryset = DatafieldSetting.objects.all()

    def get(self, request, name=None):
        try:
            self.logger.debug('retrieve datafield by name [reference id = {}] start'.format(self.reference_id))
            self.logger.debug('retrieve datafield by name [reference id = {}] field name - {}'.format(self.reference_id, name))
            
            if name is None:
                raise BadRequestException('"name" is required')

            datafield = DatafieldSetting.objects.filter(name=name).first()
            if datafield is None:
                raise BadRequestException('"name" is invalid') 

            response = self.response_meta.success('success', self.reference_id, DatafieldSettingSerializer(datafield).data)
            
        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('retrieve datafield by name [reference id = {}] exception - {}'.format(self.reference_id, exception_message))
            
        finally:
            self.logger.debug('retrieve datafield by name [reference id = {}] response - {}'.format(self.reference_id, str(response)))

            return Response(response, status=status.HTTP_200_OK)


class DeleteDatafieldSettingView(generics.DestroyAPIView):
    response_meta = ResponseAPI()
    serializer_class = DatafieldSettingSerializer
    reference_id = str(uuid.uuid4())
    logger = Logger('Delete Datafield Setting')

    def delete(self, request, id=None):
        try:
            self.logger.debug('delete datafield setting [reference id = {}] start'.format(self.reference_id))

            datafield = DatafieldSetting.objects.filter(id=id).first()
            if datafield is None:
                raise BadRequestException('"id" is invalid')

            datafield.delete()

            response = self.response_meta.success('success', self.reference_id)
        
        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('delete datafield setting [reference id = {}] exception - {}'.format(self.reference_id, exception_message))
            
        finally:
            self.logger.debug('delete datafield setting [reference id = {}] response - {}'.format(self.reference_id, str(response)))

            return Response(response, status=status.HTTP_200_OK)


class ListDatasetView(generics.ListCreateAPIView):
    response_meta = ResponseAPI()
    serializer_class = DatasetSerializer
    reference_id = str(uuid.uuid4())
    logger = Logger('List Dataset')
    http_method_names = ['get']
    queryset = Dataset.objects.filter()

    def get(self, request, page=None):
        try:
            results = list()

            self.logger.debug('list dataset [reference id = {}] start'.format(self.reference_id))
            dataset_configurations = DatasetConfiguration.objects.values('dataset_id').annotate(dataset_count=Count('dataset_id'))
            for dataset_configuration in dataset_configurations:
                dataset = Dataset.objects.filter(id=dataset_configuration['dataset_id']).first()
                dataset = DatasetSerializer(dataset)
                results.append(dataset.data)
                
            response = self.response_meta.success("success", self.reference_id, results)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('list dataset [reference id = {}] exception - {}'.format(self.reference_id, exception_message))
            
        finally:
            self.logger.debug('list dataset [reference id = {}] response - {}'.format(self.reference_id, str(response)))

            return Response(response, status=status.HTTP_200_OK)


class SearchOrCreateDatasetView(generics.ListCreateAPIView):
    response_meta = ResponseAPI()
    serializer_class = DatasetSettingDetailSerializer
    reference_id = str(uuid.uuid4())
    logger = Logger('Search or Create Dataset')
    http_method_names = ['get']
    queryset = DatasetSetting.objects.all()

    def get(self, request, name=None):
        try:
            self.logger.debug('search or create dataset [reference id = {}] start'.format(self.reference_id))

            if name is None:
                raise BadRequestException('"dataset name" is required')

            dataset_setting = DatasetSetting.objects.filter(dataset_configuration_id__dataset_id__dataset_name=name).first()
            if dataset_setting is None:
                response = _check_metadata_db(name, 'DATASETSETING', self.reference_id)

            else:
                dataset = dataset_setting.dataset_configuration_id.dataset_id
                dataset = DatasetSettingDetailSerializer(dataset).data

                response = self.response_meta.success("success", self.reference_id, dataset)
        
        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('search or create dataset [reference id = {}] exception - {}'.format(self.reference_id, exception_message))
            
        finally:
            self.logger.debug('search or create dataset [reference id = {}] response - {}'.format(self.reference_id, str(response)))
            return Response(response, status=status.HTTP_200_OK)


class ListVirtualView(generics.ListCreateAPIView):
    response_meta = ResponseAPI()
    serializer_class = GroupSerializer
    reference_id = str(uuid.uuid4())
    logger = Logger('List Virtual')
    http_method_names = ['get']
    queryset = VirtualGroup.objects.all().order_by('id')

    def get(self, request):
        try:
            self.logger.debug('list virtual [reference id = {}] start'.format(self.reference_id))

            virtual_groups = VirtualGroup.objects.all().order_by('id')
            virtual_groups = GroupSerializer(virtual_groups, many=True)

            response = self.response_meta.success('success', self.reference_id, virtual_groups.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('list virtual [reference id = {}] exception - {}'.format(self.reference_id, exception_message))
            
        finally:
            self.logger.debug('list virtual [reference id = {}] response - {}'.format(self.reference_id, str(response)))

            return Response(response, status=status.HTTP_200_OK)

def _list_sub_datasets(meta_dataset,depth):
    logger = Logger('list_sub_datasets')
    with transaction.atomic():
        result = list()
        dataset_name = meta_dataset.get('dataset_name')
        description = meta_dataset.get('description')
        create_by = meta_dataset.get('create_by')
        update_by = meta_dataset.get('update_by')
        version = meta_dataset.get('version')

        dataset,created = Dataset.objects.update_or_create(dataset_name=dataset_name ,defaults={
            'dataset_name': dataset_name,
            'description': description,
            'version': version,
            'created_by': create_by,
            'updated_by': update_by,
        })

        # logger.debug("    " * depth + "--> Created {} : Dataset : {} at depth %i".format(created,dataset_name) % depth )
        datafields = meta_dataset.get('fields') or list()

        for datafield in datafields:
            parameter_ref = datafield.get('parameter_ref') or dict()
            sub_dataset_name = None
            field_name = datafield.get('name')
            field_type = datafield.get('type')
            label_name = datafield.get('label_th')
            parameter_type = datafield.get('parameter_type')

            if parameter_ref and parameter_type in [ActivityConstants.PARAMETER_TYPE_PUBLIC, ActivityConstants.PARAMETER_TYPE_MASTER]:
                child_dataset = parameter_ref.get('dataset') or dict()
                sub_dataset_name = child_dataset.get('dataset_name')
                if sub_dataset_name is not None:
                    result.append(sub_dataset_name)

                fields = child_dataset.get('fields')
                if fields is not None:
                    list_sub_dataset_response = _list_sub_datasets(child_dataset,depth+1)
                    if list_sub_dataset_response:
                        result.extend(list_sub_dataset_response)

            
            fk_sub_dataset_name = None

            if parameter_type not in [ActivityConstants.PARAMETER_TYPE_EMBEDDED, ActivityConstants.PARAMETER_TYPE_TISCO]:
                if field_name is None or field_type is None:
                    continue

            if parameter_type in [ActivityConstants.PARAMETER_TYPE_EMBEDDED, ActivityConstants.PARAMETER_TYPE_TISCO]:
                param_fields = datafield.get('fields')
                _sub_fields = list()

                for param_field in param_fields:
                    param_field_name = param_field.get('name')
                    param_field_type = param_field.get('type')
                    param_field_label_name = param_field.get('label_th')

                    if param_field_name is None or param_field_type is None:
                        continue

                    sub_datafield, created = Datafield.objects.update_or_create(dataset_id=dataset, field_name=param_field_name, ref_name=field_name, defaults={
                        'dataset_id': dataset,
                        'field_name': param_field_name,
                        'ref_name': field_name,
                        'field_type': param_field_type,
                        'label_name': param_field_label_name,
                        'parameter_type': parameter_type,
                    })

                    _sub_fields.append(sub_datafield.id)

                deleted_sub_datafield = Datafield.objects.filter(dataset_id=dataset, ref_name=field_name).exclude(id__in=_sub_fields)
                deleted_sub_datafield.delete()
            
            if sub_dataset_name is not None:
                fk_sub_dataset_name = Dataset.objects.filter(dataset_name=sub_dataset_name).first()

            query_datafield = Datafield.objects.filter(field_name=field_name,dataset_id=dataset.id).first()

            if query_datafield is None:
                Datafield.objects.create(**{
                    'dataset_id': dataset,
                    'field_name': field_name,
                    'field_type': field_type,
                    'label_name': label_name,
                    'parameter_type': parameter_type,
                    'child_dataset_id' :fk_sub_dataset_name
                })
                # logger.debug("    " * depth + '--> Create Datafield : {} , dataset_name : {} sub_dataset_name : {}'.format(field_name,dataset_name,sub_dataset_name))

            if query_datafield is not None and query_datafield.child_dataset_id is None:
                query_datafield.child_dataset_id = fk_sub_dataset_name
                query_datafield.save()
                # logger.debug("    " * depth + '--> Update Datafield : {} , dataset_name : {} sub_dataset_name : {}'.format(field_name,dataset_name,sub_dataset_name))

            

    # unique
    return list(set(result))

class SearchOrCreateVirtualView(generics.ListCreateAPIView):
    response_meta = ResponseAPI()
    serializer_class = DatasetDetailSerializer
    reference_id = str(uuid.uuid4())
    logger = Logger('Search or Create Virtual')
    http_method_names = ['get']
    queryset = Dataset.objects.all()

    def get(self, request, name=None):
        try:
            self.logger.debug('search or create virtual [reference id = {}] start'.format(self.reference_id))

            if name is None:
                raise BadRequestException('"dataset name" is required')

            metadata_response = _get_metadata(name)
            child_dataset = _list_sub_datasets(metadata_response,0)

            dataset = Dataset.objects.filter(dataset_name=name).first()
            response_data = DatasetVirtualDetailSerializer(dataset).data
            datafields = response_data.get('datafields') or list()
            dataset_configurations = VirtualDatafieldConfig.objects.filter(field_id__dataset_id__dataset_name=name)

            for datafield in datafields:
                found = False
                for dataset_configuration in dataset_configurations:
                    if datafield.get('id') == dataset_configuration.field_id_id:
                        datafield['sequence'] = dataset_configuration.sequence
                        datafield['config'] = dataset_configuration.config
                        found = True
                        break

                if found == False:
                    if datafield.get('parameter_type') in [ActivityConstants.PARAMETER_TYPE_EMBEDDED, ActivityConstants.PARAMETER_TYPE_TISCO]:
                        sub_datafields = datafield.get('datafields') or list()

                        for sub_datafield in sub_datafields:
                            sub_datafield['sequence'] = None
                            sub_datafield['config'] = dict()

                    datafield['sequence'] = None
                    datafield['config'] = dict()

                if datafield.get('parameter_type') in [ActivityConstants.PARAMETER_TYPE_MASTER,ActivityConstants.PARAMETER_TYPE_PUBLIC]:
                    sub_datafields = datafield.get('datafields')
                    sub_found = False
                    for sub_datafield in sub_datafields:
                        sub_datafields_configurations = VirtualDatafieldConfig.objects.filter(parent_virtual_config_id=datafield.get('id'))

                        for sub_datafields_configuration in sub_datafields_configurations:
                            if sub_datafield.get('id') == sub_datafields_configuration.field_id_id:
                                sub_datafield['sequence'] = sub_datafields_configuration.sequence
                                sub_datafield['config'] = sub_datafields_configuration.config
                                sub_found = True
                                break

                        if sub_found == False:
                            sub_datafield['sequence'] = None
                            sub_datafield['config'] = dict()

            response_data['child_dataset'] = child_dataset
            response = self.response_meta.success('success', self.reference_id, response_data)
        
        except Exception as e:
            traceback.print_exc()
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('search or create virtual [reference id = {}] exception - {}'.format(self.reference_id, exception_message))
            
        finally:
            # self.logger.debug('search or create virtual [reference id = {}] response - {}'.format(self.reference_id, str(response)))
            return Response(response, status=status.HTTP_200_OK)


class SaveDatasetSetting(generics.ListCreateAPIView):
    response_meta = ResponseAPI()
    serializer_class = DatasetSettingSerializer
    reference_id = str(uuid.uuid4())
    logger = Logger('Save Dataset Setting')
    http_method_names = ['post']

    def create(self, request):
        try:
            with transaction.atomic():
                self.logger.debug('save dataset setting [reference id = {}] start'.format(self.reference_id))

                request_data = request.data or dict()
                self.logger.debug('save dataset setting [reference id = {}] request data - {}'.format(self.reference_id, request_data))

                dataset_id = request_data.get('id')
                description = request_data.get('description')
                config = request_data.get('config') or dict()

                if dataset_id is None:
                    raise BadRequestException('"dataset id" is required')

                dataset = Dataset.objects.filter(id=dataset_id).first()
                if dataset is None:
                    raise BadRequestException('"dataset id" is invalid')

                dataset_configuration = DatasetConfiguration.objects.filter(dataset_id=dataset).first()
                if dataset_configuration is None:
                    dataset_configuration = DatasetConfiguration.objects.create(**{
                        'config': config,
                        'dataset_id': dataset,
                        'description': description,
                        'created_by': request.oidc_user.preferred_username,
                        'updated_by': request.oidc_user.preferred_username,
                    })

                else:
                    dataset_configuration.config = config
                    dataset_configuration.description = description
                    dataset_configuration.updated_by = request.oidc_user.preferred_username
                    dataset_configuration.save()


                datafields = request_data.get('datafields') or list()
                _fields = list()

                for datafield in datafields:
                    field_id = datafield.get('id')
                    field_config = datafield.get('config')
                    field_sequence = datafield.get('sequence')
                    field_name = datafield.get('label_name')
                    parameter_type = datafield.get('parameter_type')

                    if parameter_type not in [ActivityConstants.PARAMETER_TYPE_EMBEDDED, ActivityConstants.PARAMETER_TYPE_TISCO]:
                        if field_id is None:
                            continue

                    field = Datafield.objects.filter(id=field_id).first()
                    if field is None:
                        continue

                    dataset_setting, created = DatasetSetting.objects.update_or_create(dataset_configuration_id=dataset_configuration, field_id=field, defaults={
                        'config': field_config,
                        'sequence': field_sequence,
                        'dataset_configuration_id': dataset_configuration,
                        'field_id': field,
                    })

                    _fields.append(dataset_setting.id)
                    
                    if parameter_type in [ActivityConstants.PARAMETER_TYPE_EMBEDDED, ActivityConstants.PARAMETER_TYPE_TISCO]:
                        param_fields = datafield.get('datafields') or list()
                        _sub_fields = list()

                        for param_field in param_fields:
                            param_field_id = param_field.get('id')
                            param_field_config = param_field.get('config')
                            param_field_sequence = param_field.get('sequence')
                            param_name = datafield.get('label_name')

                            if param_field_id is None:
                                continue

                            field = Datafield.objects.filter(id=param_field_id).first()
                            if field is None:
                                continue

                            dataset_param_setting, created = DatasetSetting.objects.update_or_create(dataset_configuration_id=dataset_configuration, field_id=field, defaults={
                                'config': param_field_config,
                                'sequence': param_field_sequence,
                                'dataset_configuration_id': dataset_configuration,
                                'field_id': field,
                            })

                            _fields.append(dataset_param_setting.id)

                        # deleted_sub_dataset_setting = DatasetSetting.objects.filter(dataset_configuration_id=dataset_configuration).exclude(id__in=_sub_fields)
                        # deleted_sub_dataset_setting.delete()

                deleted_dataset_setting = DatasetSetting.objects.filter(dataset_configuration_id=dataset_configuration).exclude(id__in=_fields)
                deleted_dataset_setting.delete()

                response = self.response_meta.success('success', self.reference_id)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('save dataset setting [reference id = {}] exception - {}'.format(self.reference_id, exception_message))
            
        finally:
            self.logger.debug('save dataset setting [reference id = {}] response - {}'.format(self.reference_id, response))

            return Response(response, status=status.HTTP_200_OK)


class DeleteDatasetSettingView(generics.DestroyAPIView):
    response_meta = ResponseAPI()
    serializer_class = DatasetSettingSerializer
    reference_id = str(uuid.uuid4())
    logger = Logger('Delete Dataset Setting')

    def delete(self, request, name=None):
        try:
            self.logger.debug('delete dataset setting [reference id = {}] start'.format(self.reference_id))

            dataset_configurations = DatasetConfiguration.objects.filter(dataset_id__dataset_name=name)
            if not dataset_configurations:
                raise BadRequestException('"name" is invalid')

            dataset_configurations.delete()

            response = self.response_meta.success('success', self.reference_id)
        
        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('delete dataset setting [reference id = {}] exception - {}'.format(self.reference_id, exception_message))
            
        finally:
            self.logger.debug('delete dataset setting [reference id = {}] response - {}'.format(self.reference_id, str(response)))

            return Response(response, status=status.HTTP_200_OK)


class SaveVirtualDataset(generics.ListCreateAPIView):
    http_method_names = ['post']
    response_meta = ResponseAPI()
    serializer_class = GroupSerializer
    reference_id = str(uuid.uuid4())
    logger = Logger('Save Virtual Dataset')

    def create(self, request):
        try:
            with transaction.atomic():
                self.logger.debug('save virtual dataset [reference id = {}] start'.format(self.reference_id))

                request_data = request.data or dict()
                self.logger.debug('save virtual dataset [reference id = {}] request data - {}'.format(self.reference_id, request_data))

                virtual_id = request_data.get('id')
                virtual_name = request_data.get('name')
                main_dataset_name = request_data.get('main_dataset_name')
                group_config = request_data.get('config')
                virtual_description = request_data.get('description')

                if virtual_id is None:
                    virtual_group = VirtualGroup.objects.create(**{
                        'name': virtual_name,
                        'main_dataset_name': main_dataset_name,
                        'config':group_config,
                        'description': virtual_description,
                        'created_by': request.oidc_user.preferred_username,
                        'updated_by': request.oidc_user.preferred_username,
                    })

                else:
                    virtual_group = VirtualGroup.objects.filter(id=virtual_id).first()
                    if virtual_group is None:
                        raise BadRequestException('"virtual id" is invalid')

                    virtual_group.name = virtual_name
                    virtual_group.main_dataset_name = main_dataset_name
                    virtual_group.config = group_config
                    virtual_group.description = virtual_description
                    virtual_group.updated_by = request.oidc_user.preferred_username
                    virtual_group.save()

                _elemets = list()
                elements = request_data.get('elements')

                for element in elements:
                    element_id = element.get('id')
                    element_name = element.get('element_name')
                    element_description = element.get('description')
                    element_sequence = element.get('sequence')
                    virtual_element = None
                    if element_id is None:
                        virtual_element = VirtualElements.objects.create(**{
                            'group_id': virtual_group,
                            'element_name': element_name,
                            'description': element_description,
                            'sequence': element_sequence,
                        })
                    
                    else:
                        virtual_element = VirtualElements.objects.filter(id=element_id).first()
                        if virtual_element is None:
                            continue

                        virtual_element.group_id = virtual_group
                        virtual_element.element_name = element_name
                        virtual_element.description = element_description
                        virtual_element.sequence = element_sequence
                        virtual_element.save()

                    _elemets.append(virtual_element.id)

                    # _fields = list()
                    datafields = element.get('datafields') or list()

                    _fields = virtual_field_save(datafields,virtual_element) or list()

                    deleted_field = VirtualDatafieldConfig.objects.filter(element_id=virtual_element).exclude(id__in=_fields)
                    deleted_field.delete()
                    
                deleted_element = VirtualElements.objects.filter(group_id=virtual_group).exclude(id__in=_elemets)
                deleted_element.delete()

                response = self.response_meta.success('success', self.reference_id)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('save virtual dataset [reference id = {}] exception - {}'.format(self.reference_id, exception_message))
            
        finally:
            self.logger.debug('save virtual dataset [reference id = {}] response - {}'.format(self.reference_id, str(response)))

            return Response(response, status=status.HTTP_200_OK)

def virtual_field_save(datafields,virtual_element,parent_id=None):
    with transaction.atomic():
        _fields = list()
        for datafield in datafields:
            field_sequence = datafield.get('sequence')
            field_id = datafield.get('field_id') or datafield.get('id')
            field_config = datafield.get('config')
            parameter_type = datafield.get('parameter_type')

            if parameter_type not in [ActivityConstants.PARAMETER_TYPE_EMBEDDED, ActivityConstants.PARAMETER_TYPE_TISCO]:
                if field_id is None:
                    continue

            _datafield = Datafield.objects.filter(id=field_id).first()
            if _datafield is None:
                continue

            virtual_field, created = VirtualDatafieldConfig.objects.update_or_create(field_id=_datafield, element_id=virtual_element, defaults={
                'element_id': virtual_element,
                'field_id': _datafield,
                'config': field_config,
                'sequence': field_sequence,
                'parent_virtual_config':parent_id
            })

            _fields.append(virtual_field.id)

            if parameter_type in [ActivityConstants.PARAMETER_TYPE_EMBEDDED, ActivityConstants.PARAMETER_TYPE_TISCO]:
                param_fields = datafield.get('datafields') or list()
                _sub_fields = list()

                for param_field in param_fields:
                    param_field_id = param_field.get('field_id') or datafield.get('id')
                    param_field_config = param_field.get('config')
                    param_field_sequence = param_field.get('sequence')

                    if param_field_id is None:
                        continue

                    _sub_datafield = Datafield.objects.filter(id=param_field_id).first()
                    if _sub_datafield is None:
                        continue

                    virtual_sub_field, created = VirtualDatafieldConfig.objects.update_or_create(field_id=_sub_datafield, element_id=virtual_element, defaults={
                        'element_id': virtual_element,
                        'field_id': _sub_datafield,
                        'config': param_field_config,
                        'sequence': param_field_sequence,
                    })

                    _sub_fields.append(virtual_sub_field.id)
                
                deleted_sub_field = VirtualDatafieldConfig.objects.filter(element_id=virtual_element).exclude(id__in=_sub_fields)
                deleted_sub_field.delete()

            child_fields = datafield.get('datafields') or list()
            if parameter_type in [ActivityConstants.PARAMETER_TYPE_PUBLIC, ActivityConstants.PARAMETER_TYPE_MASTER] and len(child_fields) > 0 : 
                list_field_response = virtual_field_save(child_fields,virtual_element,virtual_field)
                if list_field_response:
                    _fields.extend(list_field_response)
    return _fields
                    

class GetVirtualDetailByGroupId(generics.ListCreateAPIView):
    response_meta = ResponseAPI()
    serializer_class = VirtualDatafieldConfigSerializer
    reference_id = str(uuid.uuid4())
    logger = Logger('Get Virtual Detail by Group ID')
    queryset = VirtualGroup.objects.all()

    def get(self, request, id=None):
        try:
            self.logger.debug('get virtual detail by group id [reference id = {}] start'.format(self.reference_id))

            virtual_group = VirtualGroup.objects.filter(id=id).first()
            if virtual_group is None:
                raise BadRequestException('"id" is invalid')

            virtual_group = GroupDetailSerializer(virtual_group)

            response = self.response_meta.success('success', self.reference_id, virtual_group.data)
        
        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('get virtual detail by group id [reference id = {}] exception - {}'.format(self.reference_id, exception_message))
            
        finally:
            self.logger.debug('get virtual detail by group id [reference id = {}] response - {}'.format(self.reference_id, str(response)))

            return Response(response, status=status.HTTP_200_OK)


class DeleteVirtualSettingView(generics.DestroyAPIView):
    response_meta = ResponseAPI()
    serializer_class = DatasetSettingSerializer
    reference_id = str(uuid.uuid4())
    logger = Logger('Delete Virtual Setting')

    def delete(self, request, id=None):
        try:
            self.logger.debug('delete virtual setting [reference id = {}] start'.format(self.reference_id))

            virtual_group = VirtualGroup.objects.filter(id=id)
            if virtual_group is None:
                raise BadRequestException('"id" is invalid')

            virtual_group.delete()

            response = self.response_meta.success('success', self.reference_id)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('delete virtual setting [reference id = {}] exception - {}'.format(self.reference_id, exception_message))
            
        finally:
            self.logger.debug('delete virtual setting [reference id = {}] response - {}'.format(self.reference_id, str(response)))

            return Response(response, status=status.HTTP_200_OK)

class GetSubFieldVirtualSettingView(generics.ListCreateAPIView):
    response_meta = ResponseAPI()
    reference_id = str(uuid.uuid4())
    serializer_class = DatasetDetailSerializer
    http_method_names = ['post']
    logger = Logger('Get SubField VirtualSettingView')

    def post(self, request, id=None):
        try:
            self.logger.debug('Get SubField VirtualSettingView [reference id = {}] start'.format(self.reference_id))

            request_data = request.data or dict()
            response_data = list()
            if type(request_data.get('list_fields')) is not list or len(request_data.get('list_fields')) == 0  :
                raise BadRequestException('"fields" is invalid')
            
            for field_id in request_data.get('list_fields'):
                if field_id is None:
                    raise BadRequestException('"id" is required')

                datafield = Datafield.objects.filter(id=field_id).first()
                if datafield is None:
                    raise BadRequestException('Datafield is not found')

                response_data.append(DatafieldVirtualRefSerializer(datafield).data)

            response = self.response_meta.success('success', self.reference_id, response_data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )
            self.logger.error('Get SubField VirtualSettingView [reference id = {}] exception - {}'.format(self.reference_id, exception_message))
            
        finally:
            self.logger.debug('Get SubField VirtualSettingView [reference id = {}] response - {}'.format(self.reference_id, str(response)))
            return Response(response, status=status.HTTP_200_OK)