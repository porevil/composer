from rest_framework import serializers
from rest_framework.fields import JSONField

from apps.metadata.models import Datafield
from apps.metadata.api.serializers import DatafieldSerializer
from apps.generator_setting.models import DatafieldSetting, VirtualElements, VirtualGroup, DatasetSetting, \
    VirtualDatafieldConfig, DatasetConfiguration


class DatafieldSettingSerializer(serializers.ModelSerializer):
    class Meta:
        model = DatafieldSetting
        fields = [
            'id',
            'name',
            'config',
            'created_by',
            'updated_by',
            'created_date',
            'updated_date',
        ]


class GroupSerializer(serializers.ModelSerializer):
    class Meta:
        model = VirtualGroup
        fields = [
            'id',
            'name',
            'description',
            'created_by',
            'updated_by',
            'created_date',
            'updated_date',
        ]


class DatasetSettingSerializer(serializers.ModelSerializer):
    class Meta:
        model = DatasetSetting
        fields = [
            'id',
            'config'
        ]


class DatasetConfigurationSerializer(serializers.ModelSerializer):
    class Meta:
        model = DatasetConfiguration
        fields = [
            'id',
            'config',
            'created_by',
            'updated_by',
            'created_date',
            'updated_date',
        ]


class VirtualDatafieldConfigSerializer(serializers.ModelSerializer):
    class Meta:
        model = VirtualDatafieldConfig
        fields = [
            'sequence',
            'config',
        ]


class DatasetSettingConfigSerializer(serializers.ModelSerializer):
    class Meta:
        model = DatasetSetting
        fields = [
            'sequence',
            'config',
        ]


class DatasetListSerializer(serializers.ModelSerializer):
    dataset_count = serializers.SerializerMethodField()

    class Meta:
        model = DatasetSetting
        fields = [
            'ds_additional_id',
            'dataset_count'
        ]

    def get_dataset_count(self, obj):
        return obj.ds_additional_id.count()


class DatasetConfigurationListSerializer(serializers.ModelSerializer):
    dataset_count = serializers.SerializerMethodField()

    class Meta:
        model = DatasetConfiguration
        fields = [
            'dataset_id',
            'dataset_count'
        ]

    def get_dataset_count(self, obj):
        return obj.dataset_id.count()


class ElementsSerializer(serializers.ModelSerializer):
    class Meta:
        model = VirtualElements
        fields = [
            'id',
            'element_name',
            'description',
            'sequence',
        ]


class GroupDetailSerializer(serializers.ModelSerializer):
    elements = serializers.SerializerMethodField()

    class Meta:
        model = VirtualGroup
        fields = [
            'id',
            'name',
            'main_dataset_name',
            'config',
            'description',
            'created_by',
            'updated_by',
            'created_date',
            'updated_date',
            'elements'
        ]

    def get_elements(self, obj):
        elements = VirtualElements.objects.filter(group_id=obj.id).order_by('id')
        serializer = ElementsDetailSerializer(elements, many=True)
        return serializer.data


class ElementsDetailSerializer(serializers.ModelSerializer):
    datafields = serializers.SerializerMethodField()

    class Meta:
        model = VirtualElements
        fields = [
            'id',
            'element_name',
            'description',
            'sequence',
            'datafields'
        ]

    def get_datafields(self, obj):
        datafields = VirtualDatafieldConfig.objects.filter(element_id=obj.id, field_id__ref_name=None,
                                                           parent_virtual_config_id=None).order_by('id')
        serializer = VirtualDatafieldConfigDetailSerializer(datafields, many=True)
        return serializer.data


class VirtualDatafieldConfigDetailSerializer(serializers.ModelSerializer):
    field_name = serializers.SerializerMethodField()
    field_type = serializers.SerializerMethodField()
    label_name = serializers.SerializerMethodField()
    dataset_id = serializers.SerializerMethodField()
    dataset_name = serializers.SerializerMethodField()
    dataset_description = serializers.SerializerMethodField()
    parameter_type = serializers.SerializerMethodField()
    datafields = serializers.SerializerMethodField()

    class Meta:
        model = VirtualDatafieldConfig
        fields = [
            'dataset_id',
            'dataset_name',
            'dataset_description',
            'field_id',
            'field_name',
            'field_type',
            'label_name',
            'parameter_type',
            'sequence',
            'config',
            'datafields'
        ]

    def get_parameter_type(self, obj):
        _field = Datafield.objects.filter(id=obj.field_id.id).first()
        return _field.parameter_type

    def get_field_name(self, obj):
        _field = Datafield.objects.filter(id=obj.field_id.id).first()
        return _field.field_name

    def get_label_name(self, obj):
        _field = Datafield.objects.filter(id=obj.field_id.id).first()
        return _field.label_name

    def get_field_type(self, obj):
        _field = Datafield.objects.filter(id=obj.field_id.id).first()
        return _field.field_type

    def get_dataset_id(self, obj):
        _field = Datafield.objects.filter(id=obj.field_id.id).first()
        return _field.dataset_id.id

    def get_dataset_name(self, obj):
        _field = Datafield.objects.filter(id=obj.field_id.id).first()
        return _field.dataset_id.dataset_name

    def get_dataset_description(self, obj):
        _field = Datafield.objects.filter(id=obj.field_id.id).first()
        return _field.dataset_id.description

    def get_datafields(self, obj):
        _field = Datafield.objects.filter(id=obj.field_id.id).first()
        if _field.parameter_type == 'EMBEDED' or _field.parameter_type == 'TISCO':
            datafields = VirtualDatafieldConfig.objects.filter(element_id=obj.element_id,
                                                               field_id__ref_name=_field.field_name).order_by('id')
            serializer = VirtualDatafieldConfigDetailSerializer(datafields, many=True)
            return serializer.data

        elif _field.parameter_type == 'PUBLIC' or _field.parameter_type == 'MASTER':
            datafields = VirtualDatafieldConfig.objects.filter(element_id=obj.element_id,
                                                               parent_virtual_config=obj).order_by('id')
            serializer = ConfigVirtual2RefSerializer(datafields, many=True)
            return serializer.data

        else:
            return list()


class ConfigVirtual2RefSerializer(VirtualDatafieldConfigDetailSerializer):

    def get_datafields(self, obj):
        _field = Datafield.objects.filter(id=obj.field_id.id).first()
        if _field.parameter_type == 'EMBEDED' or _field.parameter_type == 'TISCO':
            datafields = VirtualDatafieldConfig.objects.filter(element_id=obj.element_id,
                                                               field_id__ref_name=_field.field_name).order_by('id')
            serializer = VirtualDatafieldConfigDetailSerializer(datafields, many=True)
            return serializer.data

        elif _field.parameter_type == 'PUBLIC' or _field.parameter_type == 'MASTER':
            datafields = VirtualDatafieldConfig.objects.filter(element_id=obj.element_id,
                                                               parent_virtual_config=obj).order_by('id')
            serializer = ConfigVirtual3RefSerializer(datafields, many=True)
            return serializer.data

        else:
            return list()


class ConfigVirtual3RefSerializer(VirtualDatafieldConfigDetailSerializer):

    def get_datafields(self, obj):
        _field = Datafield.objects.filter(id=obj.field_id.id).first()
        if _field.parameter_type == 'EMBEDED' or _field.parameter_type == 'TISCO':
            datafields = VirtualDatafieldConfig.objects.filter(element_id=obj.element_id,
                                                               field_id__ref_name=_field.field_name).order_by('id')
            serializer = VirtualDatafieldConfigDetailSerializer(datafields, many=True)
            return serializer.data

        elif _field.parameter_type == 'PUBLIC' or _field.parameter_type == 'MASTER':
            datafields = VirtualDatafieldConfig.objects.filter(element_id=obj.element_id,
                                                               parent_virtual_config=obj).order_by('id')
            serializer = ConfigVirtual4RefSerializer(datafields, many=True)
            return serializer.data

        else:
            return list()


class ConfigVirtual4RefSerializer(VirtualDatafieldConfigDetailSerializer):

    def get_datafields(self, obj):
        return list()
