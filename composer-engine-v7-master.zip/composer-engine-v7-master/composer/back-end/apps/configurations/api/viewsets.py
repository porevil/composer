import uuid
import os
import sys

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.schemas import AutoSchema
from rest_framework import viewsets
from django.db import transaction

from apps.configurations.api.serializers import InstanceEnvironmentVariableSerializer, \
    InstanceDeploymentSpecificationSerializer, \
    StateDetailSerializer, \
    StateSerializer, \
    SubStateSerializer
from apps.configurations.models import State, \
    SubState, \
    InstanceEnvironmentVariable, \
    InstanceDeploymentSpecification
from apps.commons.utilities.response import ResponseAPI
from apps.commons.utilities.log import Logger
from apps.commons.error.exception import *


class StateViewSet(viewsets.ModelViewSet):
    response_meta = ResponseAPI()
    reference_id = str(uuid.uuid4())
    serializer_class = StateDetailSerializer
    logger = Logger('State')
    queryset = State.objects.all().order_by('id')

    def list(self, request):
        try:
            self.logger.debug('list state [reference id = {}] start'.format(self.reference_id))

            states = State.objects.all().order_by('id')
            serializer = StateSerializer(states, many=True)
            response = self.response_meta.success("success", self.reference_id, serializer.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('list state [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('list state [reference id = {}] response - {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)


    def retrieve(self, request, pk=None):
        try:
            self.logger.debug('retrieve state [reference id = {}] start'.format(self.reference_id))

            state = State.objects.filter(id=pk).first()
            if state is None:
                raise BadRequestException('"id" is invalid')

            serializer = StateDetailSerializer(state)

            response = self.response_meta.success("success", self.reference_id, serializer.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('retrieve state [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('retrieve state [reference id = {}] response - {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)


    def create(self, request):
        try:
            with transaction.atomic():
                self.logger.debug('create state [reference id = {}] start'.format(self.reference_id))

                request_data = request.data or dict()
                self.logger.debug(
                    'create state [reference id = {}] request data = {}'.format(self.reference_id, request_data))

                name = request_data.get('name')
                virtual_name = request_data.get('virtual_name')
                config = request_data.get('config')

                if name is None:
                    raise BadRequestException('"name" is required')

                state = State.objects.create(**{
                    'name': name,
                    'virtual_name': virtual_name,
                    'config': config
                })

                response = self.response_meta.success("create success", self.reference_id,
                                                      StateDetailSerializer(state).data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('create state [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('create state [reference id = {}] response - {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)


    def update(self, request, pk=None):
        try:
            with transaction.atomic():
                self.logger.debug('update state [reference id = {}] start'.format(self.reference_id))

                state = State.objects.filter(id=pk).first()
                if state is None:
                    raise BadRequestException('"id" is invalid')

                request_data = request.data or dict()
                self.logger.debug(
                    'update state [reference id = {}] request data = {}'.format(self.reference_id, request_data))

                virtual_name = request_data.get('virtual_name')
                config = request_data.get('config') or dict()

                # update state model
                state.virtual_name = virtual_name
                state.config = config
                state.save()

                response = self.response_meta.success('update success', self.reference_id,
                                                      StateDetailSerializer(state).data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('update state [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('update state [reference id = {}] response - {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)


    def destroy(self, request, *args, **kwargs):
        try:
            self.logger.debug('delete state [reference id = {}] start'.format(self.reference_id))

            state = State.objects.filter(id=kwargs.get('pk')).first()
            if state is None:
                raise BadRequestException('"id" is invalid')

            state.delete()

            response = self.response_meta.success("delete success", self.reference_id)
            
        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('delete state [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('delete state [reference id = {}] response - {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)


class SubStateViewSet(viewsets.ModelViewSet):
    response_meta = ResponseAPI()
    reference_id = str(uuid.uuid4())
    serializer_class = SubStateSerializer
    logger = Logger('Sub State')
    queryset = SubState.objects.all()

    def list(self, request):
        try:
            self.logger.debug('list sub state [reference id = {}] start'.format(self.reference_id))

            sub_states = SubState.objects.all().order_by('id')
            serializer = SubStateSerializer(sub_states, many=True)
            response = self.response_meta.success("success", self.reference_id, serializer.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('list sub state [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('list sub state [reference id = {}] response - {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)


    def retrieve(self, request, pk=None):
        try:
            self.logger.debug('retrieve sub state [reference id = {}] start'.format(self.reference_id))

            sub_state = SubState.objects.filter(id=pk).first()
            if sub_state is None:
                raise BadRequestException('"id" is invalid')

            serializer = SubStateSerializer(sub_state)

            response = self.response_meta.success("success", self.reference_id, serializer.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('retrieve sub state [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('retrieve sub state [reference id = {}] response - {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)


    def create(self, request):
        try:
            with transaction.atomic():
                self.logger.debug('create sub state [reference id = {}] start'.format(self.reference_id))

                request_data = request.data or dict()
                self.logger.debug(
                    'create sub state [reference id = {}] request data = {}'.format(self.reference_id, request_data))

                name = request_data.get('name')
                virtual_name = request_data.get('virtual_name')
                state_id = request_data.get('state_id')
                is_default = request_data.get('is_default') or False
                is_advisor = request_data.get('is_advisor') or False
                is_pre_production = request_data.get('is_pre_production') or False
                is_production = request_data.get('is_production') or False
                need_authorized_ticket = request_data.get('need_authorized_ticket') or False
                has_shelf = request_data.get('has_shelf') or False
                next_sub_state_ids = request_data.get('next_sub_state_ids') or list()

                if name is None:
                    raise BadRequestException('"name" is required')

                state = State.objects.filter(id=state_id).first()
                if state is None:
                    raise BadRequestException('"state id" is invalid')

                if type(next_sub_state_ids) is not list:
                    raise BadRequestException('"next_sub_state_ids" must be array')
                
                next_sub_state = SubState.objects.filter(id__in=next_sub_state_ids)
                if len(next_sub_state) != len(next_sub_state_ids):
                    raise BadRequestException('"next_sub_state_ids" is invalid')

                sub_state = SubState.objects.create(**{
                    'name': name,
                    'virtual_name': virtual_name,
                    'state': state,
                    'is_default': is_default,
                    'is_advisor': is_advisor,
                    'is_pre_production': is_pre_production,
                    'is_production': is_production,
                    'need_authorized_ticket': need_authorized_ticket,
                    'has_shelf': has_shelf,
                    'next_sub_state_ids': next_sub_state_ids
                })

                response = self.response_meta.success("create success", self.reference_id,
                                                      SubStateSerializer(sub_state).data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('create sub state [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('create sub state [reference id = {}] response - {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)


    def update(self, request, pk=None):
        try:
            with transaction.atomic():
                self.logger.debug('update sub state [reference id = {}] start'.format(self.reference_id))

                sub_state = SubState.objects.filter(id=pk).first()
                if sub_state is None:
                    raise BadRequestException('"id" is invalid')

                request_data = request.data or dict()
                self.logger.debug(
                    'update sub state [reference id = {}] request data = {}'.format(self.reference_id, request_data))

                virtual_name = request_data.get('virtual_name')
                state_id = request_data.get('state_id')
                is_default = request_data.get('is_default') or False
                is_advisor = request_data.get('is_advisor') or False
                is_pre_production = request_data.get('is_pre_production') or False
                is_production = request_data.get('is_production') or False
                need_authorized_ticket = request_data.get('need_authorized_ticket') or False
                has_shelf = request_data.get('has_shelf') or False
                next_sub_state_ids = request_data.get('next_sub_state_ids') or list()

                state = State.objects.filter(id=state_id).first()
                if state is None:
                    raise BadRequestException('"state id" is invalid')

                if type(next_sub_state_ids) is not list:
                    raise BadRequestException('"next_sub_state_ids" must be array')
                
                next_sub_state = SubState.objects.filter(id__in=next_sub_state_ids)
                if len(next_sub_state) != len(next_sub_state_ids):
                    raise BadRequestException('"next_sub_state_ids" is invalid')

                # update state model
                sub_state.virtual_name = virtual_name
                sub_state.need_authorized_ticket = need_authorized_ticket
                sub_state.state = state
                sub_state.is_default = is_default
                sub_state.is_advisor = is_advisor
                sub_state.is_pre_production = is_pre_production
                sub_state.is_production = is_production
                sub_state.has_shelf = has_shelf
                sub_state.next_sub_state_ids = next_sub_state_ids
                sub_state.save()

                response = self.response_meta.success('update success', self.reference_id,
                                                      SubStateSerializer(sub_state).data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('update sub state [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('update sub state [reference id = {}] response - {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)


    def destroy(self, request, *args, **kwargs):
        try:
            self.logger.debug('delete sub state [reference id = {}] start'.format(self.reference_id))

            sub_state = SubState.objects.filter(id=kwargs.get('pk')).first()
            if sub_state is None:
                raise BadRequestException('"id" is invalid')

            sub_state.delete()

            response = self.response_meta.success("delete success", self.reference_id)
            
        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('delete sub state [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('delete sub state [reference id = {}] response - {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)


class InstanceEnvironmentVariableViewSet(viewsets.ModelViewSet):
    response_meta = ResponseAPI()
    reference_id = str(uuid.uuid4())
    serializer_class = InstanceEnvironmentVariableSerializer
    logger = Logger('Instance Environment Variable')
    queryset = InstanceEnvironmentVariable.objects.all().order_by('id')

    def list(self, request):
        try:
            self.logger.debug('list instance environment variable [reference id = {}] start'.format(self.reference_id))

            instance_envs = InstanceEnvironmentVariable.objects.all().order_by('id')
            serializer = InstanceEnvironmentVariableSerializer(instance_envs, many=True)
            response = self.response_meta.success("success", self.reference_id, serializer.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('list instance environment variable [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('list instance environment variable [reference id = {}] response - {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)


    def retrieve(self, request, pk=None):
        try:
            self.logger.debug(
                'retrieve instance environment variable [reference id = {}] start'.format(self.reference_id))

            instance_environment = InstanceEnvironmentVariable.objects.filter(id=pk).first()
            if instance_environment is None:
                raise BadRequestException('"id" is invalid')

            serializer = InstanceEnvironmentVariableSerializer(instance_environment)

            response = self.response_meta.success("success", self.reference_id, serializer.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('retrieve instance environment variable [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('retrieve instance environment variable [reference id = {}] response - {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)


    def create(self, request):
        try:
            with transaction.atomic():
                self.logger.debug(
                    'create instance environment variable [reference id = {}] start'.format(self.reference_id))

                request_data = request.data or dict()
                self.logger.debug('create instance environment variable [reference id = {}] request data = {}'.format(
                    self.reference_id, request_data))

                state_id = request_data.get('state_id')
                config = request_data.get('config')

                if state_id is None:
                    raise BadRequestException('"state_id" is required')

                state = State.objects.filter(id=state_id).first()
                if state is None:
                    raise BadRequestException('"state_id" is invalid')

                instance_environment = InstanceEnvironmentVariable.objects.create(**{
                    'state': state,
                    'config': config
                })

                response = self.response_meta.success("create success", self.reference_id,
                                                      InstanceEnvironmentVariableSerializer(instance_environment).data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('create instance environment variable [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('create instance environment variable [reference id = {}] response - {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)


    def update(self, request, pk=None):
        try:
            with transaction.atomic():
                self.logger.debug(
                    'update instance environment variable [reference id = {}] start'.format(self.reference_id))

                instance_environment = InstanceEnvironmentVariable.objects.filter(id=pk).first()
                if instance_environment is None:
                    raise BadRequestException('"id" is invalid')

                request_data = request.data or dict()
                self.logger.debug('update instance environment variable [reference id = {}] request data = {}'.format(
                    self.reference_id, request_data))

                config = request_data.get('config') or dict()

                # update state model
                instance_environment.config = config
                instance_environment.save()

                response = self.response_meta.success('update success', self.reference_id,
                                                      InstanceEnvironmentVariableSerializer(instance_environment).data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('update instance environment variable [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('update instance environment variable [reference id = {}] response - {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)


    def destroy(self, request, *args, **kwargs):
        try:
            self.logger.debug(
                'delete instance environment variable [reference id = {}] start'.format(self.reference_id))

            instance_environment = InstanceEnvironmentVariable.objects.filter(id=kwargs.get('pk')).first()
            if instance_environment is None:
                raise BadRequestException('"id" is invalid')

            instance_environment.delete()

            response = self.response_meta.success("delete success", self.reference_id)
            
        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('delete instance environment variable [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('delete instance environment variable [reference id = {}] response - {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)


class InstanceDeploymentSpecificationViewSet(viewsets.ModelViewSet):
    response_meta = ResponseAPI()
    reference_id = str(uuid.uuid4())
    serializer_class = InstanceDeploymentSpecificationSerializer
    logger = Logger('Instance Deployment Specification')
    queryset = InstanceDeploymentSpecification.objects.all().order_by('id')

    def list(self, request):
        try:
            self.logger.debug(
                'list instance deployment specification [reference id = {}] start'.format(self.reference_id))

            instance_deployments = InstanceDeploymentSpecification.objects.all().order_by('id')
            serializer = InstanceDeploymentSpecificationSerializer(instance_deployments, many=True)
            response = self.response_meta.success("success", self.reference_id, serializer.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('list instance deployment specification [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('list instance deployment specification [reference id = {}] response - {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)


    def retrieve(self, request, pk=None):
        try:
            self.logger.debug(
                'retrieve instance deployment specification [reference id = {}] start'.format(self.reference_id))

            instance_deployment = InstanceDeploymentSpecification.objects.filter(id=pk).first()
            if instance_deployment is None:
                raise BadRequestException('"id" is invalid')

            serializer = InstanceDeploymentSpecificationSerializer(instance_deployment)

            response = self.response_meta.success("success", self.reference_id, serializer.data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('retrieve instance deployment specification [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('retrieve instance deployment specification [reference id = {}] response - {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)


    def create(self, request):
        try:
            with transaction.atomic():
                self.logger.debug(
                    'create instance deployment specification [reference id = {}] start'.format(self.reference_id))

                request_data = request.data or dict()
                self.logger.debug(
                    'create instance deployment specification [reference id = {}] request data = {}'.format(
                        self.reference_id, request_data))

                sub_state_id = request_data.get('sub_state_id')
                config = request_data.get('config')

                if sub_state_id is None:
                    raise BadRequestException('"state_id" is required')

                sub_state = SubState.objects.filter(id=sub_state_id).first()
                if sub_state is None:
                    raise BadRequestException('"sub_state_id" is invalid')

                instance_deployment = InstanceDeploymentSpecification.objects.create(**{
                    'sub_state': sub_state,
                    'config': config
                })

                response = self.response_meta.success("create success", self.reference_id,
                                                      InstanceDeploymentSpecificationSerializer(
                                                          instance_deployment).data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('create instance deployment specification [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('create instance deployment specification [reference id = {}] response - {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)


    def update(self, request, pk=None):
        try:
            with transaction.atomic():
                self.logger.debug(
                    'update instance deployment specification [reference id = {}] start'.format(self.reference_id))

                instance_deployment = InstanceDeploymentSpecification.objects.filter(id=pk).first()
                if instance_deployment is None:
                    raise BadRequestException('"id" is invalid')

                request_data = request.data or dict()
                self.logger.debug(
                    'update instance deployment specification [reference id = {}] request data = {}'.format(
                        self.reference_id, request_data))

                config = request_data.get('config')

                # update state model
                instance_deployment.config = config
                instance_deployment.save()

                response = self.response_meta.success('update success', self.reference_id,
                                                      InstanceDeploymentSpecificationSerializer(
                                                          instance_deployment).data)

        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('update instance deployment specification [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('update instance deployment specification [reference id = {}] response - {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)


    def destroy(self, request, *args, **kwargs):
        try:
            self.logger.debug(
                'delete instance deployment specification [reference id = {}] start'.format(self.reference_id))

            instance_deployment = InstanceDeploymentSpecification.objects.filter(id=kwargs.get('pk')).first()
            if instance_deployment is None:
                raise BadRequestException('"id" is invalid')

            instance_deployment.delete()

            response = self.response_meta.success("delete success", self.reference_id)
            
        except Exception as e:
            fname = os.path.abspath(__file__)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            exception_message = '{} ({}, {}, {})'.format(str(e), str(exc_type), fname, str(exc_tb.tb_lineno))

            response = self.response_meta.error(e, str(e) , self.reference_id, str(exc_type), fname, str(exc_tb.tb_lineno) )

            self.logger.error('delete instance deployment specification [reference id = {}] exception - {}'.format(self.reference_id, exception_message))

        finally:
            self.logger.debug('delete instance deployment specification [reference id = {}] response - {}'.format(self.reference_id, response))
            return Response(response, status=status.HTTP_200_OK)


class FlowConfigurationViewSet(viewsets.ModelViewSet):
    reference_id = str(uuid.uuid4())
    serializer_class = InstanceDeploymentSpecificationSerializer
    logger = Logger('Instance Deployment Specification')
