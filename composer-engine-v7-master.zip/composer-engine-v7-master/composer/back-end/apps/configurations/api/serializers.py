from rest_framework import serializers
from rest_framework.fields import JSONField

from apps.configurations.models import State, SubState, InstanceEnvironmentVariable, InstanceDeploymentSpecification


class StateSerializer(serializers.ModelSerializer):
    class Meta:
        model = State
        fields = [
            'id',
            'name',
            'virtual_name',
        ]


class StateDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = State
        fields = [
            'id',
            'name',
            'virtual_name',
            'config',
        ]


class SubStateSerializer(serializers.ModelSerializer):
    state_name = serializers.SerializerMethodField()
    is_start = serializers.SerializerMethodField()
    
    class Meta:
        model = SubState
        fields = [
            'id',
            'name',
            'virtual_name',
            'state_id',
            'state_name',
            'is_advisor',
            'is_pre_production',
            'is_production',
            'is_default',
            'is_start',
            'need_authorized_ticket',
            'has_shelf',
            'next_sub_state_ids',
        ]

    def get_state_name(self, obj):
        return obj.state.name

    def get_is_start(self, obj):
        return len(SubState.objects.filter(next_sub_state_ids__contains=[obj.id])) == 0


class InstanceEnvironmentVariableSerializer(serializers.ModelSerializer):
    state_name = serializers.SerializerMethodField()

    class Meta:
        model = InstanceEnvironmentVariable
        fields = [
            'id',
            'state_id',
            'state_name',
            'config',
        ]

    def get_state_name(self, obj):
        return obj.state.name


class InstanceDeploymentSpecificationSerializer(serializers.ModelSerializer):
    sub_state_name = serializers.SerializerMethodField()

    class Meta:
        model = InstanceDeploymentSpecification
        fields = [
            'id',
            'sub_state_id',
            'sub_state_name',
            'config',
        ]

    def get_sub_state_name(self, obj):
        return obj.sub_state.name
