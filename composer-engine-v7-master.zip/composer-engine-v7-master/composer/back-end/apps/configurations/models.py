import reversion

from jsonfield import JSONField
from django.db import models
from django.utils.translation import ugettext_lazy as _
from django.contrib.postgres.fields import ArrayField
from django.core.exceptions import ValidationError


@reversion.register()
class State(models.Model):
    name = models.CharField(max_length=50, verbose_name=_("Name"))
    virtual_name = models.CharField(max_length=50, verbose_name=_("Virtual Name"), null=True, blank=True)
    config = JSONField(default=dict, verbose_name=_("State Configuration"), null=True, blank=True)

    class Meta:
        unique_together = (['name'])

    @property
    def access_aws_config(self):
        return {
            'aws_access_key_id': self.config['aws']['access_key_id'],
            'aws_secret_access_key': self.config['aws']['secret_access_key'],
            'aws_region': self.config['aws']['region'],
        }

    def __str__(self):
        return self.name


@reversion.register()
class SubState(models.Model):
    name = models.CharField(max_length=50, verbose_name=_("Name"))
    virtual_name = models.CharField(max_length=50, null=True, blank=True, verbose_name=_("Virtual Name"))
    state = models.ForeignKey(State, on_delete=models.CASCADE, verbose_name=_("Reference State"))
    is_default = models.BooleanField(default=False, verbose_name=_("Is Default Sub State"))
    is_advisor = models.BooleanField(default=False, verbose_name=_("Is Advisor Sub State"))
    is_pre_production = models.BooleanField(default=False, verbose_name=_("Is Pre-production Sub State"))
    is_production = models.BooleanField(default=False, verbose_name=_("Is Production Sub State"))
    need_authorized_ticket = models.BooleanField(default=False, verbose_name=_("Require Deployment Authorized Ticket"))
    has_shelf = models.BooleanField(default=False, verbose_name=_("Has Instance Shelf"))
    next_sub_state_ids = ArrayField(models.IntegerField(), null=True, verbose_name=_("Reference Next Sub States"))

    class Meta:
        unique_together = (['name', 'virtual_name'])

    def __str__(self):
        return self.name

    def validate_next_sub_state_ids(self):
        if not self.next_sub_state_ids:
            return

        if self.pk in self.next_sub_state_ids:
            raise ValidationError("Can't save : 'next sub state' is the same self data")

    def save(self, *args, **kwargs):
        self.validate_next_sub_state_ids()
        return super(SubState, self).save(*args, **kwargs)

    @staticmethod
    def default():
        return SubState.objects.filter(is_default=True).first()

    @staticmethod
    def advisor():
        return SubState.objects.filter(is_advisor=True).first()

    @staticmethod
    def pre_production():
        return SubState.objects.filter(is_pre_production=True).first()

    @staticmethod
    def production():
        return SubState.objects.filter(is_production=True).first()

    @staticmethod
    def get(state_virtual_name, sub_state_virtual_name):
        # sync state virtual name
        if state_virtual_name in ['dev']:
            state_virtual_name = 'development'
        elif state_virtual_name in ['operate']:
            state_virtual_name = 'operation'

        if sub_state_virtual_name:
            sub_state = SubState.objects.filter(virtual_name=sub_state_virtual_name,
                                                state__virtual_name=state_virtual_name).first()
        else:
            sub_state = SubState.objects.filter(virtual_name__isnull=True,
                                                state__virtual_name=state_virtual_name).first()
            if sub_state is None:
                sub_state = SubState.objects.filter(virtual_name='',
                                                    state__virtual_name=state_virtual_name).first()
        return sub_state


@reversion.register()
class InstanceEnvironmentVariable(models.Model):
    state = models.OneToOneField(State, on_delete=models.CASCADE, verbose_name=_("Reference State"))
    config = JSONField(default=dict(), verbose_name=_("Configuration"))

    def __str__(self):
        return self.state.name


@reversion.register()
class InstanceDeploymentSpecification(models.Model):
    """
    Storage for config used when deploy
    """
    sub_state = models.OneToOneField(SubState, on_delete=models.CASCADE,
                                     verbose_name=_("Reference Sub State"),
                                     related_name="deployment_specification")
    config = JSONField(default=dict, verbose_name=_("Configuration"))
    """
    Config Example:
        {
          "notification": {
            "recipients": ["string"],
            "carbon_copy": ["string"],
            "template_id": "string",
            "blind_carbon_copy": ["string"],
            "warning_threshold": 1,
            "critical_threshold": 1
          },
          "load_balances": [
            {
              "url": "string url",
              "name": "string",
              "nodes": [
                {
                  "name": "string",
                  "port": "string",
                  "context_path": "string",
                  "limit_instance": 1
                }
              ]
            }
          ],
          "deployment_app": "string",
          "package_bucket": "string",
          "service_role_arn": "string",
          "package_name_prefix": "string"
        }
    """

    @property
    def load_balances(self):
        load_balances = {}
        for lb in self.config.get('load_balances', {}):
            new_lb = dict(lb)
            new_lb["nodes"] = {}
            for node in lb.get('nodes', {}):
                new_node = node
                new_lb["nodes"][new_node['name']] = new_node
            load_balances[new_lb["name"]] = new_lb
        return load_balances

    @property
    def aws_config(self):
        return {
            "deployment_app": self.config.get('deployment_app'),
            "package_bucket": self.config.get('package_bucket'),
            "service_role_arn": self.config.get('service_role_arn'),
            "package_name_prefix": self.config.get('package_name_prefix')
        }

    def get_node(self, lb_name, node_name):
        """

        :return: dict()
        """
        node = {}
        for lb in self.config.get('load_balances', {}):
            if lb['name'] == lb_name:
                for lb_node in lb.get('nodes', {}):
                    if lb_node['name'] == node_name:
                        node = dict(lb_node)
                        node['load_balance'] = lb
        return node

    def get_all_available_node(self, minimum=0):
        nodes = list()
        for lb in self.config.get('load_balances', {}):
            for node in lb.get('nodes', {}):
                if minimum is None or node['limit_instance'] > minimum:
                    new_node = dict(node)
                    new_node['load_balance'] = lb
                    nodes.append(new_node)
        return nodes

    # def get_total_instance_deploy(self, load_balance_name, node_name, *repo_classes):
    #     try:
    #         existing_instance = 0
    #         for repo_class in repo_classes:
    #             repo_class.objects.filter(sub_state=self.sub_state,
    #                                       load_balance_name=load_balance_name,
    #                                       node_name=node_name).count()
    #
    #         return existing_instance
    #
    #     except Exception as e:
    #         raise

    def __str__(self):
        return self.sub_state.name
