#! /bin/sh
python manage.py test 