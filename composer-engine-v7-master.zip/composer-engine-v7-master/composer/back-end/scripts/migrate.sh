#! /bin/sh
python ../manage.py migrate