import uuid
from apps.flow.models import Flow, FlowInstance


def create_flow_instance(flow, sequence, sub_sequence=1, instance_type=1, next_instance_uuids=None):
    if next_instance_uuids is None:
        next_instance_uuids = []
    flow_instance_data = {
        'uuid': uuid.uuid4(),
        'flow': flow,
        'sequence': sequence,
        'sub_sequence': sub_sequence,
        'instance_type': instance_type,
        'instance_uuid': uuid.uuid4(),
        'next_instance_uuids': next_instance_uuids,
        'config': {}
    }
    return FlowInstance.objects.create(**flow_instance_data)


def run():
    """
              | -> 3_1 -> 4_1
    1 -> 2 -> |
              | -> 3_2 -> 4_2 -> 5
    """
    flow_data = {
        'uuid': uuid.uuid4(),
        'code': 'filmmmmmmmmmmm_flow',
        'name': 'filmmmmmmmmmmm_flow',
        'description': 'Nong Film force me to create this flow.',
        'label': 'Filmmmmmmmmmmm Flow, What\'s up everybody put your hand up',
        'latest_build_no': 1,
        'build_with_latest_adjustment': False,
        'system_generated': False
    }
    flow = Flow.objects.create(**flow_data)
    try:
        flow_5_2 = create_flow_instance(flow, sequence=5, sub_sequence=1, instance_type=6)
        flow_4_1 = create_flow_instance(flow, sequence=4, sub_sequence=1, instance_type=6)
        flow_4_2 = create_flow_instance(flow, sequence=4, sub_sequence=1, next_instance_uuids=[flow_5_2.uuid])
        flow_3_1 = create_flow_instance(flow, sequence=3, sub_sequence=1, next_instance_uuids=[flow_4_1.uuid])
        flow_3_2 = create_flow_instance(flow, sequence=3, sub_sequence=1, next_instance_uuids=[flow_4_2.uuid])
        flow_2 = create_flow_instance(flow, sequence=2, sub_sequence=1,
                                      next_instance_uuids=[flow_3_1.uuid, flow_3_2.uuid])
        flow_1 = create_flow_instance(flow, sequence=1, sub_sequence=1, next_instance_uuids=[flow_2.uuid])

    except Exception as e:
        flow.delete()
        raise e
run()

# if __name__ == 'django.core.management.commands.shell':
#     print("Exec run")
#     run()
