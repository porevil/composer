#!groovy​

import java.net.URLEncoder

// ECS Required
env.ecs_app_name = 'composerv7app'
env.ecs_deploy_bucket = 'tisco.pro.ecs.deployment'
env.ecs_trigger = 'pro-composer-v7-app-container-trigger'  
env.ecs_build_number = 'build-' + env.BUILD_NUMBER

env.environment_path = 'composer/back-end/config/configuration.ini'

node {
	try {
		stage('Clone') {
            def git_repo_url = scm.getUserRemoteConfigs()[0].getUrl()
            def git_branch = scm.getBranches()[0].getName().replace("*/", "")

            if (env.TAG_VERSION) {
                env.ecs_docker_tag = env.TAG_VERSION

                checkout([$class: 'GitSCM',
                    branches: [[name: 'refs/tags/' + env.TAG_VERSION]],
                    userRemoteConfigs: [[url: git_repo_url]]
                ])

            } else if (env.COMMIT_HASH) {
                env.ecs_docker_tag = env.COMMIT_HASH

                checkout([$class: 'GitSCM',
                    branches: [[name: env.COMMIT_HASH]],
                    userRemoteConfigs: [[url: git_repo_url]]
                ])

            } else {
                env.ecs_docker_tag = git_branch
                git branch: git_branch, url: git_repo_url
            }

            env.ecs_deploy_package = env.ecs_app_name + '-' + env.ecs_docker_tag + '-build-' + env.BUILD_NUMBER + '.zip'
		}

		stage('Prepare Environment') {
            env._DJANGO_DEBUG                                   = env._DJANGO_DEBUG.replace("/","\\/").trim()
            env._COMPOSER_GROUP_CODE          	            	= env._COMPOSER_GROUP_CODE.replace("/","\\/").trim()
            env._SHELF_APPLICATION_CODE 				        = env._SHELF_APPLICATION_CODE.replace("/","\\/").trim()

            env._DATABASE_USERNAME                              = java.net.URLEncoder.encode(env._DATABASE_USERNAME.replace("/","\\/").trim(), "UTF-8")
            env._DATABASE_PASSWORD                              = java.net.URLEncoder.encode(env._DATABASE_PASSWORD.replace("/","\\/").trim(), "UTF-8")

            env._DATABASE_HOST                                  = env._DATABASE_HOST.replace("/","\\/").trim()
            env._DATABASE_NAME                                  = env._DATABASE_NAME.replace("/","\\/").trim()

            env._INSTANCE_PACKAGE_REPOSITORY_BUCKET             = env._INSTANCE_PACKAGE_REPOSITORY_BUCKET.replace("/","\\/").trim()
            env._INSTANCE_PACKAGE_NAME_PREFIX                 	= env._INSTANCE_PACKAGE_NAME_PREFIX.replace("/","\\/").trim()
            env._INSTANCE_PACKAGE_REPOSITORY_ACCESS_KEY_ID      = env._INSTANCE_PACKAGE_REPOSITORY_ACCESS_KEY_ID.replace("/","\\/").trim()
            env._INSTANCE_PACKAGE_REPOSITORY_SECRET_ACCESS_KEY  = env._INSTANCE_PACKAGE_REPOSITORY_SECRET_ACCESS_KEY.replace("/","\\/").trim()
            env._INSTANCE_PACKAGE_REPOSITORY_REGION             = env._INSTANCE_PACKAGE_REPOSITORY_REGION.replace("/","\\/").trim()

            env._OKTA_CLIENT_ID                                 = env._OKTA_CLIENT_ID.replace("/","\\/").trim()
            env._OKTA_CLIENT_SECRET                             = env._OKTA_CLIENT_SECRET.replace("/","\\/").trim()
            env._OKTA_REDIRECT_URI                              = env._OKTA_REDIRECT_URI.replace("/","\\/").trim()
            env._OKTA_RESPONSE_TYPE                             = env._OKTA_RESPONSE_TYPE.replace("/","\\/").trim()
            env._OKTA_STATE                                     = env._OKTA_STATE.replace("/","\\/").trim()
            env._NONCE                                          = env._NONCE.replace("/","\\/").trim()
            env._OKTA_SCOPE                                     = env._OKTA_SCOPE.replace("/","\\/").trim()
            env._OKTA_SERVICE_ENDPOINT                          = env._OKTA_SERVICE_ENDPOINT.replace("/","\\/").trim()
            env._APPLICATION_CODE 				                = env._APPLICATION_CODE.replace("/","\\/").trim()

            env._REDIS_URL 										= env._REDIS_URL.replace("/","\\/").trim()
            env._IDENTITY_SERVICE_ENDPOINT 					    = env._IDENTITY_SERVICE_ENDPOINT.replace("/","\\/").trim()
            env._SSL_CERT_FILE                                  = env._SSL_CERT_FILE.replace("/","\\/").trim()


			wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[password: "$_DATABASE_PASSWORD", var: 'var1']]]) {
				sh '''
                    rm -rf ${environment_path}
                    mv composer/back-end/config/configuration.prod.ini ${environment_path}

                    sed -i "s/@DJANGO_DEBUG/$_DJANGO_DEBUG/g" $environment_path
                    sed -i "s/@COMPOSER_GROUP_CODE/$_COMPOSER_GROUP_CODE/g" $environment_path
                    sed -i "s/@SHELF_APPLICATION_CODE/$_SHELF_APPLICATION_CODE/g" $environment_path

                    sed -i "s/@DATABASE_URL/postgres:\\/\\/$_DATABASE_USERNAME:$_DATABASE_PASSWORD@$_DATABASE_HOST\\/$_DATABASE_NAME/g" $environment_path

                    sed -i "s/@INSTANCE_PACKAGE_REPOSITORY_BUCKET/$_INSTANCE_PACKAGE_REPOSITORY_BUCKET/g" $environment_path
                    sed -i "s/@INSTANCE_PACKAGE_NAME_PREFIX/$_INSTANCE_PACKAGE_NAME_PREFIX/g" $environment_path
                    sed -i "s/@INSTANCE_PACKAGE_REPOSITORY_ACCESS_KEY_ID/$_INSTANCE_PACKAGE_REPOSITORY_ACCESS_KEY_ID/g" $environment_path
                    sed -i "s/@INSTANCE_PACKAGE_REPOSITORY_SECRET_ACCESS_KEY/$_INSTANCE_PACKAGE_REPOSITORY_SECRET_ACCESS_KEY/g" $environment_path
                    sed -i "s/@INSTANCE_PACKAGE_REPOSITORY_REGION/$_INSTANCE_PACKAGE_REPOSITORY_REGION/g" $environment_path

                    sed -i "s/@OKTA_CLIENT_ID/$_OKTA_CLIENT_ID/g" $environment_path
                    sed -i "s/@OKTA_CLIENT_SECRET/$_OKTA_CLIENT_SECRET/g" $environment_path
                    sed -i "s/@OKTA_REDIRECT_URI/$_OKTA_REDIRECT_URI/g" $environment_path
                    sed -i "s/@OKTA_RESPONSE_TYPE/$_OKTA_RESPONSE_TYPE/g" $environment_path
                    sed -i "s/@OKTA_STATE/$_OKTA_STATE/g" $environment_path
                    sed -i "s/@NONCE/$_NONCE/g" $environment_path
                    sed -i "s/@OKTA_SCOPE/$_OKTA_SCOPE/g" $environment_path

                    sed -i "s/@REDIS_URL/$_REDIS_URL/g" $environment_path
                    sed -i "s/@IDENTITY_SERVICE_ENDPOINT/$_IDENTITY_SERVICE_ENDPOINT/g" $environment_path
                    sed -i "s/@SSL_CERT_FILE/$_SSL_CERT_FILE/g" $environment_path
                    sed -i "s/@OKTA_SERVICE_ENDPOINT/$_OKTA_SERVICE_ENDPOINT/g" $environment_path
                    sed -i "s/@APPLICATION_CODE/$_APPLICATION_CODE/g" $environment_path

                    sed -i "s/okta_service_endpoint:.*/okta_service_endpoint: \\'$_OKTA_SERVICE_ENDPOINT\\'/g" composer/front-end/src/environments/environment.prod.ts
				'''
			}
		}

        // stage('Build') {
        //     sh '''
        //         cd composer/front-end
        //         npm install
        //         ng build --prod --aot

        //         cd ..
        //         rm -rf front-end
        //     '''
        // }

		stage('Deploy Package') {
			sh '''
                rm -rf tmp; mkdir tmp; mkdir tmp/config; mkdir tmp/app; mkdir tmp/newman;
                rsync -av --progress ./ tmp/app/ --exclude *.git* --exclude tmp --exclude newman --exclude container --exclude *venv*
                rsync -av --progress ./composer/newman/ tmp/newman/
                rsync -av --progress ./${environment_path} tmp/config/config.ini
                cd tmp; zip -r $ecs_deploy_package app newman config
                aws s3api put-object --bucket $ecs_deploy_bucket --key $ecs_app_name/$ecs_deploy_package --body $ecs_deploy_package
                rm -rf $ecs_deploy_package
            '''
		}

        stage('Build Downstream Job') {
            build job: env.ecs_trigger, parameters: [[$class: 'StringParameterValue', name: 'ecs_app_name', value: env.ecs_app_name], [$class: 'StringParameterValue', name: 'ecs_deploy_package', value: env.ecs_deploy_package],[$class: 'StringParameterValue', name: 'ecs_docker_tag', value: env.ecs_docker_tag],[$class: 'StringParameterValue', name: 'ecs_build_number', value: env.ecs_build_number]],wait:true
        }

	} catch(e) {
        echo "Something went wrong terminate revision"
		throw e
	} finally {

	}
}
