import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthenticateService, UtilsService } from '../core/services';
import { Store } from '@ngrx/store';
import { State } from '../store/reducers/authen/authen.reducer';
import * as fromActions from '../store/actions/authen.actions';

@Component({
    selector: 'composer-authenticate',
    templateUrl: './authenticate.component.html',
    styleUrls: ['./authenticate.component.scss']
})
export class AuthenticateComponent implements OnInit, OnDestroy {

    
    constructor(
        private activatedRoute: ActivatedRoute,
        private router: Router,
        private authenticateService: AuthenticateService,
        private utilsService: UtilsService,
        private store: Store<State>
    ) {
        this._constructorComponent();
    };

    private verificationCode = null;
    private verifyClickFromOkta = null;

    private offSubscribeQueryParams = null;
    private offSubscribeParams = null;
    private appCode = null;


    ngOnInit(): void {
        this._initComponent();
    };

    ngOnDestroy() : void {
        this._destroyComponent();
    };

    private _constructorComponent() : void {
        this.appCode = this.authenticateService.getAppCode(false);
        this.offSubscribeParams = this.activatedRoute.params.subscribe(datas => {
            const verificationCode = datas["verification_code"];
            const verify = datas["verify"];
            if (typeof(verificationCode) == "string" && verificationCode.trim().length > 0) {
                this.verificationCode = verificationCode;
            } 
            if (typeof(verify) == "string" && verify.trim().length > 0) {
                this.verifyClickFromOkta = verify;
            }
        });
    };

    private _initComponent() : void {
        if (window.location.pathname == `/application/${this.appCode}/verifycode`) {
            this.offSubscribeQueryParams = this.activatedRoute.queryParams.subscribe(
                params => {
                    const code = params['code'];
                    if (!!code) {
                        this.store.dispatch(fromActions.verifyCodeAuthen({ payload: code }))
                    }
                    else {
                        this.router.navigate(["application",this.appCode]);
                    }
                }
            );
        } else {

            if (this.verificationCode != null) {
                this.store.dispatch(fromActions.verifyCodeAuthen({ payload: this.verificationCode }))
            } 
            else {
                if (this.verifyClickFromOkta != null) {
                    this.verifyClickFromOkta = null;
                    this._redirectToLogin()
                } else {
                    this._validateAuthentication();
                }
            }

        }
    };

    private _destroyComponent() : void {
        if(this.offSubscribeQueryParams != null){
            this.offSubscribeQueryParams.unsubscribe();
            this.offSubscribeQueryParams = null;
        }
        if(this.offSubscribeParams != null){
            this.offSubscribeParams.unsubscribe();
            this.offSubscribeParams = null;
        }
    };

    private async _redirectToLogin() : Promise<void> {
        const response = await this.authenticateService.authorizationLoginRedirect();
        if (response.meta.response_code != undefined && response.meta.response_code == 10000 && response.data) {
            window.location.href = response.data;
        } else {
            this.utilsService.errorDialogPopup(response.meta.response_desc, { response: response });
        }
    };

    private _validateAuthentication() : void {
        const validCookie = this.authenticateService.validCookie("id_token");
        if (!validCookie) {
            this._redirectToLogin();
        } else {
            this.router.navigate(["application",this.appCode,"pages"]);
        }
    };
}
