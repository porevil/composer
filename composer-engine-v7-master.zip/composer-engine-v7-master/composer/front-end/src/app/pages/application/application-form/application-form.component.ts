import { Component, ViewEncapsulation } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormControl, Validators, FormBuilder } from '@angular/forms';

import { ApplicationService, UtilsService, SystemConfigurationService } from '../../../core/services';

import { NumberOnlyValidator, ValidateNotAllowStartEndWithBlank } from '../../../core/validators'

@Component({
    selector: 'composer-application-form',
    templateUrl: './application-form.component.html',
    styleUrls: ['./application-form.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class ApplicationFormComponent {

    constructor(
        private router: Router,
        private activatedRoute: ActivatedRoute,
        private formBuilder: FormBuilder,
        private applicationService: ApplicationService,
        private systemConfigurationService: SystemConfigurationService,
        private utilsService: UtilsService
    ) {
        this._contructorComponent();
    }

    public fileName = 'application-form';

    public appTypeOptions = [
        {
            label: "Normal",
            value: 1
        },
        {
            label: "Representative Data Processor",
            value: 2
        },
        {
            label: "View Data Processor",
            value: 3
        },
        {
            label: "Representative Data Controller",
            value: 4
        },
        {
            label: "View Data Controller",
            value: 5
        },
    ]

    public applicationForm = {
        application: null,
        validatingForm: null,
        procedure: {
            displayFields: [
                {
                    title: "'Code'",
                    property: "code"
                },
                {
                    title: "'Name'",
                    sort: "'name'",
                    filter: "'name'",
                    property: "name"
                },
                {
                    title: "'Display Label'",
                    property: "display_label"
                },
                {
                    title: "'UUID'",
                    property: "uuid"
                }
            ]
        }
    };

    public subStateOptions = [];

    private async _contructorComponent(): Promise<void> {
        const params = {
            ...this.activatedRoute.snapshot.params,
            ...this.activatedRoute.snapshot.queryParams
        };
        let application = null;
        let subStateId = params.sub_state_id;
        await this._initSubStates();
        if (!!params.applicationId) {
            const response = await this.applicationService.getApplication(params.sub_state_id, params.applicationId).toPromise();
            if (response.meta.response_code == 10000) {
                application = response.data;
            }
            else {
                this.utilsService.errorDialogPopup(response.meta.response_desc, { response: response, redirect: { back: 2 } });
                return;
            }
        }
        this._initApplicationForm(subStateId, application);
    };

    private _getElementId(parts: Array<string>): string {
        return [this.fileName, ...parts].join('_');
    };

    private async _initSubStates(): Promise<void> {
        const response = await this.systemConfigurationService.getAllSystemConfigurationSubStates().toPromise();
        if (response.meta.response_code == "10000") {
            this.subStateOptions = response.data.map(subState => ({ label: subState.name, value: subState.id }));
        }
        else {
            await this.utilsService.errorDialogPopup(response.meta.response_desc, { response: response });
        }
    };

    private _initApplicationForm(subStateId: string, application: any): void {
        const isEditApplication = !!application;
        let formGroup = {
            sub_state_id: new FormControl({ value: subStateId, disabled: true }, Validators.compose([Validators.required])),
            code: new FormControl({ value: application?.code, disabled: isEditApplication }, Validators.compose([Validators.required, NumberOnlyValidator])),
            name: new FormControl(application?.name, Validators.compose([Validators.required, ValidateNotAllowStartEndWithBlank])),
            description: new FormControl(application?.description, Validators.compose([ValidateNotAllowStartEndWithBlank])),
            config: this.formBuilder.group({
                okta_client_id: new FormControl(application?.config?.okta_client_id, Validators.compose([Validators.required, ValidateNotAllowStartEndWithBlank])),
                okta_client_secret: new FormControl(application?.config?.okta_client_secret, Validators.compose([Validators.required, ValidateNotAllowStartEndWithBlank])),
                okta_redirect_uri: new FormControl(application?.config?.okta_redirect_uri, Validators.compose([Validators.required, ValidateNotAllowStartEndWithBlank])),
                app_type: new FormControl(application?.config?.app_type, Validators.compose([Validators.required])),
            })
        };
        if (!application) {
            application = {
                procedures: []
            }
        }
        application.sub_state_id = subStateId;
        this.applicationForm.application = application;
        this.applicationForm.validatingForm = this.formBuilder.group(formGroup);
    };

    private _backApplications(): void {
        let urls = this.router.url.split('/');
        urls.splice(-1);
        if (!!this.applicationForm.application.id) {
            urls.splice(-1);
        }
        this.router.navigate([urls.join('/')]);
    };

    private async _deleteProcedure(procedure: any): Promise<void> {
        const isConfirm = await this.utilsService.deleteDialogPopup();
        if (isConfirm) {
            const index = this.applicationForm.application.procedures.indexOf(procedure);
            this.applicationForm.application.procedures.splice(index, 1);
        }
    };

    private _prepareApplicationForSave(): any {
        const cleanAppilication = {
            ...this.applicationForm.application,
            ...this.applicationForm.validatingForm.value
        }
        cleanAppilication.config.app_type = + cleanAppilication.config.app_type
        return cleanAppilication;
    };

    private async _saveApplication(): Promise<void> {
        const appilication = this._prepareApplicationForSave();
        const response = await this.applicationService.setApplication(appilication).toPromise();
        if (response.meta.response_code == 10000) {
            await this.utilsService.successDialogPopup();
            this._backApplications();
        }
        else {
            this.utilsService.errorDialogPopup(response.meta.response_desc, { response: response });
        }
    };

    public getElementId(...args: Array<any>): string {
        return this._getElementId(args);
    };

    public btnDeleteProcedure(procedure: any): void {
        this._deleteProcedure(procedure);
    };

    public btnSave(): void {
        this._saveApplication();
    };

    public btnBack(): void {
        this._backApplications();
    };

}
