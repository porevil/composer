import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { 
    WidgetTextboxModule, WidgetButtonModule, WidgetTableModule,
    WidgetIconButtonModule, WidgetDropdownModule, WidgetModalModule
} from '@channel/widgets';

import { ApplicationRoutingModule } from './application-routing.module';

import { ApplicationComponent } from './application.component';
import { ApplicationsComponent } from './applications/applications.component';
import { ApplicationFormComponent } from './application-form/application-form.component';

@NgModule({
    declarations: [
        ApplicationComponent,
        ApplicationsComponent,
        ApplicationFormComponent
    ],
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        ApplicationRoutingModule,
        WidgetTextboxModule,
        WidgetButtonModule,
        WidgetTableModule,
        WidgetIconButtonModule,
        WidgetDropdownModule,
        WidgetModalModule
    ]
})
export class ApplicationModule { }
