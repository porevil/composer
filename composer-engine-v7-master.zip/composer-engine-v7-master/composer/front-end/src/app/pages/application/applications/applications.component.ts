import { Component, ViewEncapsulation, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, Validators, FormBuilder } from '@angular/forms';

import { ApplicationService, SystemConfigurationService, UtilsService, DialogPopupIcon } from '../../../core/services';
@Component({
    selector: 'composer-applications',
    templateUrl: './applications.component.html',
    styleUrls: ['./applications.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class ApplicationsComponent {

    @ViewChild('modalAuthorizeTicket', { static: true }) modalAuthorizeTicket: any;

    constructor(
        private router: Router,
        private applicationService: ApplicationService,
        private systemConfigurationService: SystemConfigurationService,
        private formBuilder: FormBuilder,
        public utilsService: UtilsService
    ) {
        this._contructorComponent();
    }

    public fileName = 'applications';

    public application = {
        dataSource: [],
        displayFields: [
            {
                title: "'Code'",
                sort: "'code'",
                filter: "'code'",
                property: "code"
            },
            {
                title: "'Name'",
                sort: "'name'",
                filter: "'name'",
                property: "name"
            },
            {
                title: "'Description'",
                sort: "'description'",
                filter: "'description'",
                property: "description"
            }
        ],
        actions: {
            edit: {
                label: "Edit Configuration",
                value: "edit"
            },
            move: {
                label: "Move to",
                value: "move"
            },
            delete: {
                label: "Remove Configuration",
                value: "remove"
            }
        }
    };

    public searchForm = {
        validatingForm: null,
        isSearch: false,
        subStateOptions: []
    };

    public modalAuthorizedConfig = {
        title: "",
        value: null,
    }

    private async _contructorComponent(): Promise<void> {
        await this._initSubStates();
        this._initSearchForm();
    };

    private _getElementId(parts: Array<string>): string {
        return [this.fileName, ...parts].join('_');
    };

    private async _initSubStates(): Promise<void> {
        const response = await this.systemConfigurationService.getAllSystemConfigurationSubStates().toPromise();
        if (response.meta.response_code == "10000") {
            this.searchForm.subStateOptions = response.data.map(subState => ({
                label: subState.name,
                value: subState.id,
                subState: subState,
            }));
        }
        else {
            await this.utilsService.errorDialogPopup(response.meta.response_desc, { response: response });
        }
    };

    private _getDefaultSubStateOption(): any {
        const subStateOption = this.searchForm.subStateOptions?.find(option => option.subState.is_default);
        return subStateOption || null;
    };

    private _initSearchForm(): void {
        const subStateOption = this._getDefaultSubStateOption();
        let formGroup = {
            subStateId: new FormControl(subStateOption?.value, Validators.compose([Validators.required])),
            applicationCode: new FormControl(null),
            applicationName: new FormControl(null)
        };
        this.searchForm.validatingForm = this.formBuilder.group(formGroup);

    };

    private async _searchAppications(): Promise<void> {
        if (this.searchForm.validatingForm.valid) {
            const searchForm = this.searchForm.validatingForm.value;
            this.searchForm.isSearch = false;
            this.application.dataSource = [];
            const response = await this.applicationService.getApplications(searchForm.subStateId, {
                application: {
                    code: searchForm.applicationCode,
                    name: searchForm.applicationName
                }
            }).toPromise();
            if (response.meta.response_code == "10000") {
                this.application.dataSource = response.data.map(application => ({ ...application, sub_state_id: searchForm.subStateId }));
                this.searchForm.isSearch = true;
                this._initApplicationOptions(this.application.dataSource);
            }
            else {
                this.utilsService.errorDialogPopup(response.meta.response_desc, { response: response });
            }
        }
    };

    private _clearSearch(): void {
        const subStateOption = this._getDefaultSubStateOption();
        this.searchForm.isSearch = false;
        this.application.dataSource = [];
        this.searchForm.validatingForm.reset();
        this.searchForm.validatingForm.controls.subStateId.setValue(subStateOption?.value);
    };

    private _initApplicationOptions(applications: Array<any>): void {
        const subStateId = this.searchForm.validatingForm.controls.subStateId.value;
        const subState = this.searchForm.subStateOptions.find(option => option.value == subStateId)?.subState || null;
        for (const application of applications) {
            const options = [];
            options.push(this.application.actions.edit);
            for (const nextSubStateId of (subState?.next_sub_state_ids || [])) {
                const nextSubState = this.searchForm.subStateOptions.find(option => option.value == nextSubStateId)?.subState || null;
                options.push({
                    label: `Move to ${nextSubState.name}`,
                    value: `move_${nextSubState.id}`,
                    nextSubState: nextSubState
                });
            }
            options.push(this.application.actions.delete);
            application.options = options;
        }
        // console.debug(applications);
    };

    private _gotoCreateApplication(): void {
        const searchForm = this.searchForm.validatingForm.value;
        let urls = this.router.url.split('/');
        this.router.navigate([urls.join('/'), 'new-application'], {
            queryParams: {
                sub_state_id: searchForm.subStateId
            }
        });
    };

    private async _gotoEditApplication(application: any): Promise<void> {
        const isConfirm = await this.utilsService.confirmDialogPopup(`Application Code : ${application.code}`, "Do you want to edit?");
        if (isConfirm) {
            let urls = this.router.url.split('/');
            this.router.navigate([urls.join('/'), application.code, 'configuration'], {
                queryParams: {
                    sub_state_id: application.sub_state_id
                }
            });
        }
    };

    private async _deleteApplication(application: any): Promise<void> {
        const isConfirm = await this.utilsService.deleteDialogPopup();
        if (isConfirm) {
            const ticket = await this._onVerifyAuthorizedTicket(application, "Remove");
            const response = await this.applicationService.deleteApplication(application.sub_state_id, application.code, ticket).toPromise();
            if (response.meta.response_code == 10000) {
                await this.utilsService.successDialogPopup();
                const index = this.application.dataSource.indexOf(application);
                this.application.dataSource.splice(index, 1);
            }
            else {
                this.utilsService.errorDialogPopup(response.meta.response_desc, { response: response });
            }
        }
    };

    private async _moveApplication(application: any, subState: any): Promise<void> {
        const isConfirm = await this.utilsService.confirmDialogPopup(`Application Code : ${application.code}`, "Do you want to move?");
        if (isConfirm) {
            console.debug(`Move application[${application.code}] from sub_state[${application.sub_state_id}] to sub_state[${subState.id}]`);
        }
    };

    private _onChangeApplicationAction(application: any): void {
        if (application.action == this.application.actions.edit.value) {
            this._gotoEditApplication(application);
        }
        else if (application.action == this.application.actions.delete.value) {
            this._deleteApplication(application);
        }
        else if (application.action.indexOf(this.application.actions.move.value) == 0) {
            const moveToSubState = application.options.find(option => option.value == application.action)?.nextSubState || null;
            this._moveApplication(application, moveToSubState);
        }
        application.action = null;
    };

    private async _onVerifyAuthorizedTicket(application: any, title: string): Promise<string> {
        const needAuthorizedTicket = this.searchForm.subStateOptions.find(option => option.value == application.sub_state_id)?.subState?.need_authorized_ticket;
        if (needAuthorizedTicket) {
            this.modalAuthorizedConfig.title = title
            const modalInstance = this.modalAuthorizeTicket.show();
            const result = await modalInstance.closed;
            if (result && result.isConfirm)
                return this.modalAuthorizedConfig.value
        }
        return null;
    }

    public getElementId(...args: Array<any>): string {
        return this._getElementId(args);
    };

    public btnSearch(): void {
        this._searchAppications();
    };

    public btnReset(): void {
        this._clearSearch();
    };

    public btnCreateApplication(): void {
        this._gotoCreateApplication();
    };

    public onChangeApplicationAction(application: any): void {
        this._onChangeApplicationAction(application);
    };

    public btnConfirmAuthorizedTicket() {
        if (this.modalAuthorizedConfig.value && this.utilsService.validator.notAllowStartEndWithBlank(this.modalAuthorizedConfig.value)) {
            this.modalAuthorizeTicket.hide({ isConfirm: true })
        }
    }

}
