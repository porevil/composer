import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { AuthorityService, UtilsService } from 'src/app/core/services';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';

import { ValidateNotAllowStartEndWithBlank } from '../../../core/validators/not-allow-space';
@Component({
  selector: 'composer-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class UserProfileComponent implements OnInit {

  @ViewChild('modelUserProfileForm', { static : true }) modelUserProfileForm : any;

  constructor(
    private authorityService: AuthorityService,
    private formBuilder: FormBuilder,
    private utilsService:UtilsService,
  ){
    this.getStd_list()
  }

  UserProfileFrom: FormGroup;
  action = ''
  submitted = false;
  public user_profile = {
    dataSource: [],
    displayFields: [
      {
        title: "'Name'",
        sort: "'name'",
        filter: "'name'",
        property: "name"
      },
      {
        title: "'Role'",
        sort: "'role'",
        property: "role",
        filter: "'role'",
      }
    ]
  };

  get f() { return this.UserProfileFrom.controls; }

  ngOnInit(): void {
   
  }

  getStd_list() {
    this.authorityService.get_authorization_user_profile().then((response: any) => {
      if (response.meta.response_code == 10000) {
        this.user_profile.dataSource = response.data
      }else {
        this.utilsService.errorDialogPopup(response.meta.response_desc, {response:response});
    }
    })
  }

  createFormGroup(item?){
    this.action = item ? item.id : 'create'
    let formGroup = {
      name: new FormControl(item ? item.name : '', Validators.compose([Validators.required, ValidateNotAllowStartEndWithBlank])),
      role: new FormControl(item ? item.role : '', Validators.compose([Validators.required, ValidateNotAllowStartEndWithBlank]))
    }
    this.UserProfileFrom = this.formBuilder.group(formGroup);
  }

  deleteItem(id) {
    this.authorityService.delete_authorization_user_profile(id).then((response: any) => {
      if (response.meta.response_code == 10000) {
        this.getStd_list()
        this.utilsService.successDialogPopup();
      }else{
        this.utilsService.errorDialogPopup(response.meta.response_desc, {response:response});
      }
    })
  }

  async dialogPopupConfirm(id) {
    const isConfirm = await this.utilsService.deleteDialogPopup();
    if(isConfirm){
      this.deleteItem(id)
    }
  }

  createItem() {
    this.authorityService.create_authorization_user_profile(this.UserProfileFrom.getRawValue()).then((response: any) => {
      if (response.meta.response_code == 10000) {
        this.modelUserProfileForm.hide();
        this.getStd_list()
        this.utilsService.successDialogPopup();
      }else{
        this.utilsService.errorDialogPopup(response.meta.response_desc, {response:response});
      }
    })
  }

  updateItem() {
    this.authorityService.update_authorization_user_profile(this.action,this.UserProfileFrom.getRawValue()).then((response: any) => {
      if (response.meta.response_code == 10000) {
        this.modelUserProfileForm.hide();
        this.utilsService.successDialogPopup();
        this.getStd_list()
      }else{
        this.utilsService.errorDialogPopup(response.meta.response_desc, {response:response});
      }
    })
  }

  btnCreateUserProfile(): void {
    this.createFormGroup()
    this.modelUserProfileForm.show();
  };

  btnEditUserProfile(item): void {
    this.createFormGroup(item)
    this.modelUserProfileForm.show();
  };

  btnConfirmUserProfile(): void {
    if(this.action=='create'){
      this.createItem()
    }else{
      this.updateItem()
    }
  };
}
