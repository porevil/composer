import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { AuthorityService, UtilsService } from 'src/app/core/services';
import { Store } from '@ngrx/store';
import { State } from 'src/app/store/reducers';
import * as fromMenuAction from 'src/app/store/actions/menu.actions'

@Component({
  selector: 'composer-menu-mapping',
  templateUrl: './menu-mapping.component.html',
  styleUrls: ['./menu-mapping.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class MenuMappingComponent implements OnInit {

  constructor(
    private authorityService: AuthorityService,
    private utilsService:UtilsService,
    private store: Store<State>,
  ) {
    this.getStdRoleMapping_list()
    
  }

  roles = []
  roles_mapping = []
  menu_mapping = []
  resp_maping = []
  options = [{label:'Application Admin',value:false},{label:'System Admin',value:true},{label:'User',value:true}]

  ngOnInit(): void {
  }

  saveRoleMapping_list() {
    this.authorityService.update_authorization_profile_menu_mapping(this.menu_mapping).then((response: any) => {
      if (response.meta.response_code == 10000) {
        this.roles = response.data
        this.getStdRoleMapping_list()
        this.utilsService.successDialogPopup();
        this.store.dispatch(fromMenuAction.loadMenus());
      }else{
        this.utilsService.errorDialogPopup(response.meta.response_desc, { response : response });
      }
    })
  }

  getStdRoleMapping_list() {
    this.authorityService.get_authorization_profile_menu_mapping().then((response: any) => {
      if (response.meta.response_code == 10000) {
        this.menu_mapping = response.data
      }else{
        this.utilsService.errorDialogPopup(response.meta.response_desc, { response : response });
      }
    })
  }

  onCheck(event){
    this.onDelete()
  }

  onDelete(){
    
  }

  btnSave(){
    this.saveRoleMapping_list()
  }

}
