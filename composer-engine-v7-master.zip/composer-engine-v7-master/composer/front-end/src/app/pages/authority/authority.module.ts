import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AuthorityRoutingModule } from './authority-routing.module';
import { AuthorityComponent } from './authority.component';
import { MenuConfigurationComponent } from './menu-configuration/menu-configuration.component';
import { ActionConfigurationComponent } from './action-configuration/action-configuration.component';
import { ActionMappingComponent } from './action-mapping/action-mapping.component';
import { MenuMappingComponent } from './menu-mapping/menu-mapping.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import {
  WidgetTextboxModule, WidgetButtonModule, WidgetTableModule, WidgetIconButtonModule,
  WidgetModalModule, WidgetCheckboxModule, WidgetDropdownModule, WidgetMultiCheckboxModule
} from '@channel/widgets';

import { SharedModule } from '../../shared/shared.module';


@NgModule({
  declarations: [
    AuthorityComponent, 
    MenuConfigurationComponent, 
    ActionConfigurationComponent, 
    ActionMappingComponent, 
    MenuMappingComponent, 
    UserProfileComponent],
  imports: [
    CommonModule,
    FormsModule,
    SharedModule,
    AuthorityRoutingModule,
    WidgetTextboxModule,
    WidgetButtonModule,
    WidgetTableModule,
    WidgetIconButtonModule,
    WidgetModalModule,
    ReactiveFormsModule,
    WidgetCheckboxModule,
    WidgetDropdownModule,
    WidgetMultiCheckboxModule
  ]
})
export class AuthorityModule { }
