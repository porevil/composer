import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { AuthorityService, UtilsService } from 'src/app/core/services';

@Component({
  selector: 'composer-action-mapping',
  templateUrl: './action-mapping.component.html',
  styleUrls: ['./action-mapping.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ActionMappingComponent implements OnInit {

  constructor(
    private authorityService: AuthorityService,
    private utilsService: UtilsService
  ) {
    this.getStdRoleMapping_list()

  }

  roles = []
  roles_mapping = []
  action_mapping = []
  resp_maping = []
  options = [{ label: 'Application Admin', value: false }, { label: 'System Admin', value: true }, { label: 'User', value: true }]

  ngOnInit(): void {
  }

  saveRoleMapping_list() {
    this.authorityService.update_authorization_profile_action_mapping(this.action_mapping).then((response: any) => {
      if (response.meta.response_code == 10000) {
        this.roles = response.data
        this.getStdRoleMapping_list()
        this.utilsService.successDialogPopup();
      } else {
        this.utilsService.errorDialogPopup(response.meta.response_desc, { response: response });
      }
    })
  }

  getStdRoleMapping_list() {
    this.authorityService.get_authorization_profile_action_mapping().then((response: any) => {
      if (response.meta.response_code == 10000) {
        this.action_mapping = response.data
      }else {
        this.utilsService.errorDialogPopup(response.meta.response_desc, {response:response});
    }
    })
  }

  onCheck(event) {
    this.onDelete()
  }

  onDelete() {

  }

  btnSave() {
    this.saveRoleMapping_list()
  }
}
