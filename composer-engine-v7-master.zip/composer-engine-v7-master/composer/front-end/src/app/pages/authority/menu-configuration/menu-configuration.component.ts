import { Component, ViewChild, ViewEncapsulation } from '@angular/core';
import { AuthorityService, UtilsService } from 'src/app/core/services';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import Swal from 'sweetalert2';
import { fail } from 'assert';
import { Store } from '@ngrx/store';
import { State } from 'src/app/store/reducers';
import * as fromMenuAction from 'src/app/store/actions/menu.actions'
import { ValidateNotAllowSpace, ValidateNotAllowStartEndWithBlank } from "../../../core/validators/not-allow-space"
@Component({
    selector: 'composer-menu-configuration',
    templateUrl: './menu-configuration.component.html',
    styleUrls: ['./menu-configuration.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class MenuConfigurationComponent {

    @ViewChild('modelMenuConfigurationForm', { static: true }) modelMenuConfigurationForm: any;

    constructor(
        private authorityService: AuthorityService,
        private formBuilder: FormBuilder,
        private utilsService: UtilsService,
        private store: Store<State>,
    ) {
        this._contructorComponent();
    };

    menuConfigurationFrom: FormGroup;
    action = ''
    submitted = false;
    optionType = [
        {
            value: 'menu',
            label: 'Menu',
        },
        {
            value: 'sub_menu',
            label: 'Sub menu',
        }
    ]
    selectedOptionType = ""
    selectedOptionMenu = ""
    optionMenu = []
    optionDisable = false
    main_id = ''
    public menu_configuration = {
        dataSource: [],
        displayFields: [
            // {
            //   title: "'Sequence'",
            //   sort: "'sequence'",
            //   filter: "'sequence'",
            //   property: "sequence"
            // },
            {
                title: "'Display Label'",
                filter: "'display_label'",
                property: "display_label"
            },
            {
                title: "'Code'",
                property: "code",
                filter: "'code'",
            },
            {
                title: "'Link'",
                property: "link",
                filter: "'link'",
            }
        ]
    };

    get f() { return this.menuConfigurationFrom.controls; }

    private _contructorComponent() : void {
        this._getMenus();
    };

    private _onChangeMenuType() : void {
        this.selectedOptionMenu = '';
        const linkForm = this.menuConfigurationFrom?.controls?.link || null;
        if(this.selectedOptionType =="sub_menu"){
            linkForm?.setValidators([Validators.required, ValidateNotAllowStartEndWithBlank]);
        }
        else {
            linkForm?.setValidators([ValidateNotAllowStartEndWithBlank]);
        }
        linkForm?.updateValueAndValidity();
    };

    private _onChangeParentMenu() : void {
        const menu = this.menu_configuration.dataSource.find((item => item.code == this.selectedOptionMenu));
        if(menu){
            let lastIndex = (menu.sub_menus?.length || 0) - 1; 
            if(lastIndex != -1){
                const lastMenu = menu.sub_menus.sort((a,b)=>a.sequence - b.sequence)[lastIndex];
                this.menuConfigurationFrom?.controls?.sequence?.setValue(lastMenu.sequence + 1);
            }
            
        }
    };

    private async _getMenus() : Promise<void> {
        const response : any = await this.authorityService.get_authorization_menu();
        if (response.meta.response_code == 10000) {
            this.optionMenu = [];
            this.menu_configuration.dataSource = response.data.sort((a, b) => { a.sequence - b.sequence });
            this.menu_configuration.dataSource.forEach(element => {
                this.optionMenu.push({
                    value: element.code,
                    label: element.display_label
                });
                if (element.sub_menus.length > 0) {
                    element.sub_menus = element.sub_menus.sort((a, b) => { a.sequence - b.sequence });
                }
            });
        }
        else {
            this.utilsService.errorDialogPopup(response.meta.response_desc, {response:response});
        }
    };

    private _initMenuConfigurationFrom(item? : any) : void {
        console.log(item);
        
        this.action = item?.id || 'create';
        const formGroup = {
            code: new FormControl({ value : item?.code || '', disabled : this.action != "create" }, Validators.compose([ Validators.required, ValidateNotAllowSpace])),
            display_label: new FormControl(item?.display_label || '', Validators.compose([ValidateNotAllowStartEndWithBlank]) ),
            link: new FormControl(item?.link || '', Validators.compose(this.selectedOptionType == "sub_menu" ? [Validators.required, ValidateNotAllowStartEndWithBlank] : [ValidateNotAllowStartEndWithBlank])),
            sequence: new FormControl(item?.sequence || 0, Validators.compose([ Validators.required])),
            is_active: new FormControl(item?.is_active || true)
        };
        this.menuConfigurationFrom = this.formBuilder.group(formGroup);
    };

    private async _openMenuConfigurationFrom() : Promise<void>{        
        const modalInstance = this.modelMenuConfigurationForm.show();
        await modalInstance.closed;
        this.menuConfigurationFrom = null;
    };

    private _openCreateMenuConfigurationFrom() : void{
        this.optionDisable = false;
        this.selectedOptionType = '';
        this.selectedOptionMenu = '';
        this._initMenuConfigurationFrom();
        this._openMenuConfigurationFrom();
    };

    private async _openEditMenuConfigurationFrom(item : any,sub? : any) : Promise<void> {
        this.optionDisable = true;
        this.main_id = item.id;
        const response : any = await this.authorityService.get_authorization_menu_by_id(item.id);
        if (response.meta.response_code == 10000) {  
            let targetMenu = response.data;
            this.selectedOptionType = 'menu';
            this.selectedOptionMenu = '';
            if (sub && response.data.sub_menus.length > 0) {
                const found = response.data.sub_menus.find(subMenu => subMenu.id == sub.id);
                if(found){
                    this.selectedOptionType = 'sub_menu';
                    this.selectedOptionMenu = response.data.code;
                    targetMenu = found;
                }
            }
            this._initMenuConfigurationFrom(targetMenu);
            this._openMenuConfigurationFrom();
        } else {
            this.utilsService.errorDialogPopup(response.meta.response_desc, { response: response });
        }
    };

    private _enabledConfirmMenu() : boolean {
        return (this.menuConfigurationFrom?.valid || false) 
            && this.selectedOptionType && this.selectedOptionType.trim().length > 0 
            && (this.selectedOptionType == 'menu' || this.selectedOptionMenu && this.selectedOptionMenu.trim().length > 0);
    };

    private updateItem(item : any) : void {
        this.authorityService.update_authorization_menu(this.main_id, item).then((response: any) => {
            if (response.meta.response_code == 10000) {
                this.modelMenuConfigurationForm.hide();
                this.utilsService.successDialogPopup();
                this._getMenus();
                this.store.dispatch(fromMenuAction.loadMenus());
            } else {
                this.utilsService.errorDialogPopup(response.meta.response_desc, { response: response });
            }
        })
    };

    private async _createMenu() : Promise<void> {
        const newMenu = this.menuConfigurationFrom.getRawValue();
        const response : any = await this.authorityService.create_authorization_menu(newMenu);
        if (response.meta.response_code == 10000) {
            this.modelMenuConfigurationForm.hide();
            this._getMenus();
            this.utilsService.successDialogPopup();
            this.store.dispatch(fromMenuAction.loadMenus());
        } else {
            this.utilsService.errorDialogPopup(response.meta.response_desc, { response: response });
        }
    };

    private async _createSubMenu() : Promise<void> {        
        const menu = this.menu_configuration.dataSource.find((item => item.code == this.selectedOptionMenu));
        if(menu){
            const newSubMenu = this.menuConfigurationFrom.getRawValue();
            this.main_id = menu.id;
            menu.sub_menus.push(newSubMenu);
            this.updateItem(menu);
        }        
    };

    private _confirmMenuConfiguration() : void {
        if (this.action == 'create') {            
            if (this.selectedOptionType == 'sub_menu') {
                this._createSubMenu();
            } else {
                this._createMenu();
            }
        } else {
            let search_result = this.menu_configuration.dataSource.find((item => item.id == this.main_id))
            if (search_result.sub_menus.length != 0) {
                if (this.selectedOptionMenu != '') {
                    search_result.sub_menus = search_result.sub_menus.filter(sub => {
                        return sub.id != this.action;
                    })
                    search_result.sub_menus.push(Object.assign(this.menuConfigurationFrom.getRawValue(), { id: this.action }))
                } else {
                    search_result = Object.assign({ ...search_result }, this.menuConfigurationFrom.getRawValue())
                }
                this.updateItem(search_result)
            } else {
                search_result = Object.assign(this.menuConfigurationFrom.getRawValue(), { sub_menus: [] })
                this.updateItem(search_result)
            }
        }
    };

    private async _deleteSubMenu(menu : any, subMenu : any) : Promise<void>{
        this.main_id = menu.id;
        menu.sub_menus = menu.sub_menus.filter(item => {
            return item.id != subMenu.id;
        });
        this.updateItem(menu);
    };

    private async _deleteMenu(menu : any) : Promise<void>{
        const response : any = await this.authorityService.delete_authorization_menu(menu.id);
        if (response.meta.response_code == 10000) {
            this._getMenus();
            this.utilsService.successDialogPopup();
        } else {
            this.utilsService.errorDialogPopup(response.meta.response_desc, { response: response });
        }
    };

    private async _deleteMenuOrSubMenu(menu : any, subMenu? : any) : Promise<void>{
        const isConfirm = await this.utilsService.deleteDialogPopup();
        if(isConfirm){
            if(subMenu){
                this._deleteSubMenu(menu,subMenu);
            }
            else {
                this._deleteMenu(menu);
            }
        }
    };

    public btnCreateMenuConfiguration() : void {
        this._openCreateMenuConfigurationFrom();
    };

    public btnEditMenuConfiguration(item : any, sub? : any): void {
        this._openEditMenuConfigurationFrom(item,sub);
    };

    public btnConfirmMenuConfiguration(): void {
        this._confirmMenuConfiguration();
    };

    public onChangeMenuType() : void {        
        this._onChangeMenuType();
    };

    public onChangeParentMenu() : void {
        this._onChangeParentMenu();
    };

    public enabledConfirmMenu() : boolean {
        return this._enabledConfirmMenu();
    };

    public btnDeleteMenuOrSubMenu(menu : any, subMenu? : any) : void {
        this._deleteMenuOrSubMenu(menu,subMenu);
    };

}
