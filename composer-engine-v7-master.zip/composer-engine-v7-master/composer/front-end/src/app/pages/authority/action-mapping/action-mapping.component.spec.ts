import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActionMappingComponent } from './action-mapping.component';

describe('ActionMappingComponent', () => {
  let component: ActionMappingComponent;
  let fixture: ComponentFixture<ActionMappingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActionMappingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActionMappingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
