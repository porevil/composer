import { Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import { AuthorityService, UtilsService } from 'src/app/core/services';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { ValidateNotAllowSpace, ValidateNotAllowStartEndWithBlank } from '../../../core/validators/not-allow-space'
@Component({
  selector: 'composer-action-configuration',
  templateUrl: './action-configuration.component.html',
  styleUrls: ['./action-configuration.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ActionConfigurationComponent implements OnInit {

  @ViewChild('modelActionConfigurationForm', { static: true }) modelActionConfigurationForm: any;

  constructor(
    private authorityService: AuthorityService,
    private formBuilder: FormBuilder,
    private utilsService: UtilsService,
  ) {
    this.getStd_list()
  }

  actionConfigurationFrom: FormGroup;
  action = ''
  submitted = false;
  public action_configuration = {
    dataSource: [],
    displayFields: [
      {
        title: "'Display Label'",
        sort: "'display_label'",
        filter: "'display_label'",
        property: "display_label"
      },
      {
        title: "'Code'",
        sort: "'code'",
        property: "code",
        filter: "'code'",
      }
    ]
  };

  get f() { return this.actionConfigurationFrom.controls; }

  ngOnInit(): void {

  }

  getStd_list() {
    this.authorityService.get_authorization_action().then((response: any) => {
      if (response.meta.response_code == 10000) {
        this.action_configuration.dataSource = response.data
      } else {
        this.utilsService.errorDialogPopup(response.meta.response_desc, { response: response });
      }
    })
  }

  createFormGroup(item?) {
    this.action = item ? item.id : 'create'
    let formGroup = {
      code: new FormControl(item ? item.code : '', Validators.compose([Validators.required, ValidateNotAllowSpace])),
      display_label: new FormControl(item? item.display_label: '', Validators.compose([ValidateNotAllowStartEndWithBlank])),
      is_active: new FormControl(item ? item.is_active : true)
    }
    this.actionConfigurationFrom = this.formBuilder.group(formGroup)
  }

  deleteItem(id) {
    this.authorityService.delete_authorization_action(id).then((response: any) => {
      if (response.meta.response_code == 10000) {
        this.getStd_list()
        this.utilsService.successDialogPopup();
      } else {
        this.utilsService.errorDialogPopup(response.meta.response_desc, { response: response });
      }
    })
  }

  async dialogPopupConfirm(id) {
    const isConfirm = await this.utilsService.deleteDialogPopup();
    if (isConfirm) {
      this.deleteItem(id);
    }
  }

  createItem() {
    this.authorityService.create_authorization_action(this.actionConfigurationFrom.getRawValue()).then((response: any) => {
      if (response.meta.response_code == 10000) {
        this.modelActionConfigurationForm.hide();
        this.getStd_list()
        this.utilsService.successDialogPopup();
      } else {
        this.utilsService.errorDialogPopup(response.meta.response_desc, { response: response });
      }
    })
  }

  updateItem() {
    this.authorityService.update_authorization_action(this.action, this.actionConfigurationFrom.getRawValue()).then((response: any) => {
      if (response.meta.response_code == 10000) {
        this.modelActionConfigurationForm.hide();
        this.utilsService.successDialogPopup();
        this.getStd_list()
      } else {
        this.utilsService.errorDialogPopup(response.meta.response_desc, { response: response });
      }
    })
  }

  btnCreateActionConfiguration(): void {
    this.createFormGroup()
    this.modelActionConfigurationForm.show();
  };

  btnEditActionConfiguration(item): void {
    this.authorityService.get_authorization_action_by_id(item.id).then((response: any) => {
      if (response.meta.response_code == 10000) {
        this.createFormGroup(response.data)
        this.modelActionConfigurationForm.show();
      } else {
        this.utilsService.errorDialogPopup(response.meta.response_desc, { response: response });
      }
    })
  };

  btnConfirmActionConfiguration(): void {
    if (this.action == 'create') {
      this.createItem()
    } else {
      this.updateItem()
    }
  };

}
