import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthorityComponent } from './authority.component';
import { MenuMappingComponent } from './menu-mapping/menu-mapping.component';
import { ActionMappingComponent } from './action-mapping/action-mapping.component';
import { MenuConfigurationComponent } from './menu-configuration/menu-configuration.component';
import { ActionConfigurationComponent } from './action-configuration/action-configuration.component';
import { UserProfileComponent } from './user-profile/user-profile.component';


const routes: Routes = [
  {
    path: '',
    component: AuthorityComponent,
    children: [
      {
        path: '',
        pathMatch: "full",
        redirectTo: "menu-mapping"
      },
      {
        path: 'menu-mapping',
        component: MenuMappingComponent
      },
      {
        path: 'action-mapping',
        component: ActionMappingComponent
      },
      {
        path: 'menu-configuration',
        component: MenuConfigurationComponent
      },
      {
        path: 'action-configuration',
        component: ActionConfigurationComponent
      },
      {
        path: 'user-profile',
        component: UserProfileComponent
      },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AuthorityRoutingModule { }