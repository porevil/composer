import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'composer-authority',
  templateUrl: './authority.component.html',
  styleUrls: ['./authority.component.scss']
})
export class AuthorityComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
