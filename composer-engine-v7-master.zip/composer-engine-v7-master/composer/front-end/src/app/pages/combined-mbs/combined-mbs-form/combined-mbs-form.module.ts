import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { 
    WidgetTextboxModule, WidgetButtonModule, WidgetTableModule,
    WidgetTabsModule, WidgetTextDisplayModule, WidgetIconButtonModule,
    WidgetModalModule, WidgetDropdownModule, WidgetCheckboxModule
} from '@channel/widgets';

import { SharedModule } from '../../../shared/shared.module';
import { ObjectPropertyValuePipe } from '../../../shared/pipes';

import { DragDropModule } from '@angular/cdk/drag-drop';

import { CombinedMbsFormRoutingModule } from './combined-mbs-form-routing.module';

import { CombinedMbsFormComponent } from './combined-mbs-form.component';
import { CombinedMbsInformationFormComponent } from './combined-mbs-information-form/combined-mbs-information-form.component';
import { CombinedMbsPreSubmitFormComponent } from './combined-mbs-pre-submit-form/combined-mbs-pre-submit-form.component';
import { CombinedMbsPreSubmitsFormComponent } from './combined-mbs-pre-submits-form/combined-mbs-pre-submits-form.component';


@NgModule({
    declarations: [
        CombinedMbsFormComponent,
        CombinedMbsInformationFormComponent,
        CombinedMbsPreSubmitFormComponent,
        CombinedMbsPreSubmitsFormComponent,
        ObjectPropertyValuePipe
    ],
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        CombinedMbsFormRoutingModule,
        SharedModule,
        DragDropModule,
        WidgetTabsModule,
        WidgetButtonModule,
        WidgetTextboxModule,
        WidgetTableModule,
        WidgetTextDisplayModule,
        WidgetIconButtonModule,
        WidgetModalModule,
        WidgetDropdownModule,
        WidgetCheckboxModule
    ]
})
export class CombinedMbsFormModule { }
