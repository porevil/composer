import { Component, ViewEncapsulation, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormControl, Validators, FormBuilder, FormGroup, FormArray } from '@angular/forms';
import { Store } from '@ngrx/store';
import { State } from '../../../../store/reducers';
import * as fromCombinedMBSAction from '../../../../store/actions/combined-mbs.actions';
import * as fromRoot from 'src/app/store/reducers/index';
import { Subscription } from 'rxjs';

import { UtilsService, ServiceMbsService, DialogPopupIcon } from '../../../../core/services';

import { ValidateNotAllowSpace, ValidateNotAllowStartEndWithBlank } from '../../../../core/validators/not-allow-space'

@Component({
    selector: 'composer-combined-mbs-pre-submit-form',
    templateUrl: './combined-mbs-pre-submit-form.component.html',
    styleUrls: ['./combined-mbs-pre-submit-form.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class CombinedMbsPreSubmitFormComponent {

    @ViewChild('modalTableSelection', { static: true }) modalTableSelection: any;

    constructor(
        private router : Router,
        private activatedRoute : ActivatedRoute,
        private formBuilder : FormBuilder,
        private store: Store<State>,
        private utilsService : UtilsService,
        private serviceMbsService : ServiceMbsService
    ) { 
        this._contructorComponent();
    };

    public fileName = 'combined_mbs_pre_submit_form';

    public combinedMBS = null;

    public preSubmitServiceForm = {
        preSubmitService: null,
        validatingForm : null,
        request : {
            parameter : {
                typeOptions : [
                    { label : "Data Field", value : "datafield" },
                    { label : "Constant", value : "constant" },
                    { label : "System", value : "system" }
                ],
                systemOptions : [
                    { label: "Application Code", value: "APP_CODE" },
                    { label: "Branch Info ID", value: "BRANCH_INFO_ID" },
                    { label: "User ID", value: "USER_ID" },
                    { label: "User UCID", value: "USER_UCID" },
                    { label: "Username", value: "USERNAME" },
                    { label: "Enterprise Role", value: "ERM_ROLE" },
                    { label: "Data Controller", value: "DATA_CONTROLLER" },
                    { label: "Sub Controller", value: "SUB_CONTROLLER" },
                    { label: "Data Processor", value: "DATA_PROCESSOR" },
                    { label: "Flow Session ID", value: "FLOW_SESSION_ID" },
                    { label: "Log Session ID", value: "LOG_SESSION_ID" },
                    { label: "Current Date", value: "CURRENT_DATE" },
                    { label: "Current Time", value: "CURRENT_TIME" },
                    { label: "Current Datetime", value: "CURRENT_DATETIME" }
                ],
                datafieldOptions : []
            }
        },
        validity : {
            bypassValidition : {
                valueChangesSubscription : null
            },
            responsePropertyOptions : []
        },
        mappingValue : {
            validatingForm : null,
            datafieldOptions : [],
            responsePropertyOptions : [],
            displayFields : [
                {
                    title: "'Datafield'",
                    labelProperties : ["label","name"],
                    typeProperty : "type"
                },
                {
                    title: "'Response Property'",
                    labelProperties: ["vlabel", "vname"],
                    typeProperty : "vtype"
                }
            ]
        }
    };

    public searchServiceMBSForm = {
        title : "Service MBSes",
        validatingForm : null,
        displayFields : [
            {
                title: "'Code'",
                filter : "'code'",
                sort : "'code'",
                property: "code"
            },
            {
                title: "'Name'",
                filter : "'name'",
                sort : "'name'",
                property: "name"
            }
        ]
    };

    public combinedMBSStateSubscription : Subscription = null;

    get preSubmitServiceValidatingForm() {
        return this.preSubmitServiceForm.validatingForm;
    };

    set preSubmitServiceValidatingForm(validatingForm : any) {
        this.preSubmitServiceForm.validatingForm = validatingForm;
    };

    get mappingValueValidatingForm() {
        return this.preSubmitServiceForm.mappingValue.validatingForm;
    };

    set mappingValueValidatingForm(validatingForm : any) {
        this.preSubmitServiceForm.mappingValue.validatingForm = validatingForm;
    };

    private ngOnDestroy() {
        this._destroyComponent();
    };

    private async _contructorComponent() : Promise<void> {
        this._initCombinedMBSState();  
    };

    private _destroyComponent() : void {
        this._destroyCombinedMBSState();
        this._destroyPreSubmitServiceForm();
    };

    private _getElementId(parts : Array<string>) : string {
        return [this.fileName,...parts].join('_');
    };


    private _initCombinedMBSState() : void {
        this._destroyCombinedMBSState();
        this.combinedMBSStateSubscription = this.store.select(fromRoot.getCombinedMBSInCombinedMBS).subscribe((combinedMBS) => {
            let data = JSON.parse(JSON.stringify(combinedMBS));
            if(this.combinedMBS == null){
                this.combinedMBS = data;
                const params = this.activatedRoute.snapshot.params;
                const preSubmitServiceId = params.preSubmitServiceId;
                if(!!preSubmitServiceId){
                    this.preSubmitServiceForm.preSubmitService = this.combinedMBS.presubmit_services.find(preSubmitService => {
                        return preSubmitService.id == preSubmitServiceId;
                    });
                    this._initValidityMessageResponsePropertyOptions();  
                    this._initMappingValueDatafieldOptions(); 
                    this._initMappingValueResponsePropertyOptions();
                }     
                else {
                    this._initSearchServiceMBSForm();
                }  
                this._initPreSubmitServiceForm(this.preSubmitServiceForm.preSubmitService);         
                this._initRequestDatafieldOptions();   
                this._initMappingValueForm();        
            }
        });
    };

    private _destroyCombinedMBSState(): void {
        if (this.combinedMBSStateSubscription != null) {
            this.combinedMBSStateSubscription.unsubscribe();
        }
    };

    private _setCombinedMBSInStore() : void {
        const cloneObject = JSON.parse(JSON.stringify(this.combinedMBS));
        this.store.dispatch(fromCombinedMBSAction.setCombinedMBSInStore({ payload : cloneObject }));
    };

    private _initSearchServiceMBSForm() : void {
        let formGroup = {
            serviceMBSCode : new FormControl(null, Validators.compose([ Validators.required ]))
        };    
        this.searchServiceMBSForm.validatingForm =  this.formBuilder.group(formGroup);
    };

    private _initPreSubmitServiceForm(preSubmitService? : any) : void {
        this._destroyPreSubmitServiceForm();
        const parameterForms = {}
        for(const parameter of preSubmitService?.data?.request?.params || []){
            const validators = parameter.require ? Validators.compose([ Validators.required ]) : [];
            const parameterForm = this.formBuilder.group({
                vtype : new FormControl({ value : parameter.vtype , disabled : parameter.default },validators),
                value : new FormControl({ value : parameter.value , disabled : parameter.default },validators)
            });
            parameterForms[parameter.name] = parameterForm;
        }

        const bypassValidition = preSubmitService?.data?.validity?.bypass_validation || false;
        const formGroup = {
            request : this.formBuilder.group({
                parameters : this.formBuilder.group(parameterForms)
            }),
            validity : this.formBuilder.group({
                bypass_validation : new FormControl(bypassValidition),
                valid_condition : this.formBuilder.group({
                    name : new FormControl(preSubmitService?.data?.validity?.valid_condition?.name || null, Validators.compose([ Validators.required ])),
                    value : new FormControl(preSubmitService?.data?.validity?.valid_condition?.value || null, Validators.compose([ Validators.required, ValidateNotAllowStartEndWithBlank ]))
                }),
                warning_condition : this.formBuilder.group({
                    name : new FormControl(preSubmitService?.data?.validity?.warning_condition?.name || null),
                    value : new FormControl(preSubmitService?.data?.validity?.warning_condition?.value || null, ValidateNotAllowStartEndWithBlank)
                }),                
                message : this.formBuilder.group({
                    valid : new FormControl(preSubmitService?.data?.validity?.message?.valid || null),
                    fvalid : new FormControl(preSubmitService?.data?.validity?.message?.fvalid || null, Validators.compose([ValidateNotAllowStartEndWithBlank])),
                    warning : new FormControl(preSubmitService?.data?.validity?.message?.warning || null),
                    fwarning : new FormControl(preSubmitService?.data?.validity?.message?.fwarning || null, Validators.compose([ValidateNotAllowStartEndWithBlank])),
                    invalid : new FormControl(preSubmitService?.data?.validity?.message?.invalid || null),
                    finvalid : new FormControl(preSubmitService?.data?.validity?.message?.finvalid || null, Validators.compose([ValidateNotAllowStartEndWithBlank])),
                })
            })
        };
        if(bypassValidition){
            formGroup.validity.controls.valid_condition.disable();
            formGroup.validity.controls.warning_condition.disable();
            formGroup.validity.controls.message.disable();
        }

        this.preSubmitServiceValidatingForm = this.formBuilder.group(formGroup);
        this.preSubmitServiceForm.validity.bypassValidition.valueChangesSubscription = this.preSubmitServiceValidatingForm.controls.validity.controls.bypass_validation.valueChanges.subscribe(form => {
            if(form){
                this.preSubmitServiceValidatingForm.controls.validity.controls.valid_condition.disable();
                this.preSubmitServiceValidatingForm.controls.validity.controls.warning_condition.disable();
                this.preSubmitServiceValidatingForm.controls.validity.controls.message.disable();
            }
            else {
                this.preSubmitServiceValidatingForm.controls.validity.controls.valid_condition.enable();
                this.preSubmitServiceValidatingForm.controls.validity.controls.warning_condition.enable();
                this.preSubmitServiceValidatingForm.controls.validity.controls.message.enable();
            }
        });

        
    };

    private _destroyPreSubmitServiceForm() : void {
        if(this.preSubmitServiceForm.validity.bypassValidition.valueChangesSubscription != null) {
            this.preSubmitServiceForm.validity.bypassValidition.valueChangesSubscription.unsubscribe();
            this.preSubmitServiceForm.validity.bypassValidition.valueChangesSubscription = null;
        }
        this.preSubmitServiceValidatingForm = null;
    };

    private _initRequestDatafieldOptions() : void {
        const datafieldOptions = this.combinedMBS.data?.datafields?.map(datafield => ({ 
            label : `${datafield.label || datafield.name  || '-'} (${datafield.type}${datafield.multiple ? '[]' : ''})`, 
            value : datafield.name 
        })) || [];
        this.preSubmitServiceForm.request.parameter.datafieldOptions = datafieldOptions;
    };

    private _initValidityMessageResponsePropertyOptions() : void {
        const responsePropertyOptions = this.preSubmitServiceForm.preSubmitService?.data?.response?.properties?.filter(property => !property.multiple && property.type != 'object' ).map(property => ({
            label : `${property.label || property.name  || '-'} (${property.type})`, 
            value : property.name 
        })) || [];
        this.preSubmitServiceForm.validity.responsePropertyOptions = responsePropertyOptions;
    };

    private _initMappingValueResponsePropertyOptions() : void {
        const responsePropertyOptions = this.preSubmitServiceForm.preSubmitService?.data?.response?.properties?.map(property => ({
            label : `${property.label || property.name  || '-'} (${property.type}${property.multiple ? '[]' : ''})`, 
            value : property.name,
            property : property
        })) || [];
        this.preSubmitServiceForm.mappingValue.responsePropertyOptions = responsePropertyOptions;
    };

    private _initMappingValueDatafieldOptions() : void {
        const mappingValueNames = this.preSubmitServiceForm.preSubmitService.data.mapping_value.map(mappingValue => mappingValue.name);
        const datafieldOptions = this.combinedMBS.data?.datafields?.filter(datafield => mappingValueNames.indexOf(datafield.name) == -1 ).map(datafield => ({ 
            label : `${datafield.label || datafield.name  || '-'} (${datafield.type}${datafield.multiple ? '[]' : ''})`, 
            value : datafield.name,
            datafield : datafield
        })) || [];
        this.preSubmitServiceForm.mappingValue.datafieldOptions = datafieldOptions;
    };

    private _initMappingValueForm() : void {
        let formGroup = {
            datafieldName : new FormControl(null, Validators.compose([ Validators.required ])),
            responsePropertyName : new FormControl(null, Validators.compose([ Validators.required ]))
        };
        this.mappingValueValidatingForm =  this.formBuilder.group(formGroup,{
            validators : (form : FormGroup) => {                
                const mappingValueForm = form.value;
                const datafieldOption = this.preSubmitServiceForm.mappingValue.datafieldOptions.find(option => option.value == mappingValueForm.datafieldName);
                const responsePropertyOption = this.preSubmitServiceForm.mappingValue.responsePropertyOptions.find(option => option.value == mappingValueForm.responsePropertyName); 
                let condition = datafieldOption && responsePropertyOption && !datafieldOption.datafield.multiple && responsePropertyOption.property.multiple;
                return condition ? { datasetIsNotMultiple : true } : null;
            }
        });
    };

    private _clearMappingValueValidatingForm() : void {
        this.mappingValueValidatingForm.reset();
    };

    private _getPropertyValidatingForm(validatingForm : any,properties : string) : any {
        let controls = validatingForm?.controls;
        const props = properties.split('.');
        const lastProp = props.pop();
        for(const prop of props){
            controls = (controls && controls[prop]?.controls) || null;
        }
        return (controls && controls[lastProp]) || null;
    };

    private _isPropertyFormValid(validatingForm : any,properties : string) : boolean {
        let property = this._getPropertyValidatingForm(validatingForm,properties);      
        return property?.valid || false;
    };

    private _getParameterLabel(parameter : any) : string {
        return `${parameter.label || parameter.name || '-'} (${parameter.type}${parameter.multiple ? '[]' : ''})` 
    };

    private _onChangeRequestParameterType(parameter : any) : void {
        let property = this._getPropertyValidatingForm(
            this.preSubmitServiceValidatingForm,
            `request.parameters.${parameter.name}.value`
        ); 
        property.setValue(null);
    };

    private _getMappingValueItemLabel(item : any, labelProperties : Array<string>, typeProperty : string) : string {
        const labelProperty = labelProperties.find(property => (item[property]));
        return `${item[labelProperty] || '-'} (${item[typeProperty]}${item.multiple ? '[]' : ''})` ;
    };

    private _AddMappingValue() : void {
        const mappingValueForm = this.mappingValueValidatingForm.value;
        const datafieldOption = this.preSubmitServiceForm.mappingValue.datafieldOptions.find(option => option.value == mappingValueForm.datafieldName);
        const responsePropertyOption = this.preSubmitServiceForm.mappingValue.responsePropertyOptions.find(option => option.value == mappingValueForm.responsePropertyName); 
        var newMappingValue = {
            name : datafieldOption.datafield.name,
            label : datafieldOption.datafield.label,
            type : datafieldOption.datafield.type,
            vname : responsePropertyOption.property.name,
            vlabel : responsePropertyOption.property.label,
            vtype : responsePropertyOption.property.type,
            multiple : datafieldOption.datafield.multiple || false
        }
        this.preSubmitServiceForm.preSubmitService.data.mapping_value.push(newMappingValue);
        this._initMappingValueDatafieldOptions();
        this._clearMappingValueValidatingForm();
    };

    private async _deleteMappingValue(mappingValue : any) : Promise<void> {
        const isConfirm = await this.utilsService.deleteDialogPopup();
        if (isConfirm) {
            const index = this.preSubmitServiceForm.preSubmitService.data.mapping_value.indexOf(mappingValue);
            this.preSubmitServiceForm.preSubmitService.data.mapping_value.splice(index, 1);
            this._initMappingValueDatafieldOptions();
        }
    };

    public _isParameterVType(parameter : any, vtype : string) : boolean {
        const parameterForms = this.preSubmitServiceValidatingForm?.getRawValue()?.request?.parameters || {};
        return parameterForms[parameter.name]?.vtype == vtype;
    };

    private async _refreshPreSubmitService() : Promise<void> {
        const response = await this.serviceMbsService.getServiceMBSs({
            mbs : {
                uuid : this.preSubmitServiceForm.preSubmitService.uuid
            }
        }).toPromise();
        if(response.meta.response_code == 10000){            
            const serviceMBS = (response.data && response.data[0]) || null;
            if(!!serviceMBS){

                if(serviceMBS.service_type != "sync"){
                    this.utilsService.alertDialogPopup("Alert","Service is not synchronous service type",{
                        icon : DialogPopupIcon.Warning
                    });
                    return;
                }
                if(serviceMBS.response_type != "json"){
                    this.utilsService.alertDialogPopup("Alert","Service is not json response type",{
                        icon : DialogPopupIcon.Warning
                    });
                    return;
                }

                const preSubmitServiceForm = this.preSubmitServiceValidatingForm.getRawValue();
                const updatedPreSubmitService = this.utilsService.object.merge(
                    this.preSubmitServiceForm.preSubmitService,
                    {
                        data : {
                            code : serviceMBS.code,
                            name : serviceMBS.name,
                            description : serviceMBS.description,
                            version : serviceMBS.latest_version,
                            request : serviceMBS.config?.request || null,
                            response : serviceMBS.config?.response || null,
                            validity : preSubmitServiceForm.validity
                        }
                    }
                );

                updatedPreSubmitService.data.request?.params?.forEach(parameter => {
                    if(!!parameter.value){
                        parameter.default = true;
                        parameter.vtype = "constant";
                    }
                    else {
                        parameter.default = false;
                        parameter.vtype = null;
                        const propertyForm = preSubmitServiceForm.request.parameters[parameter.name];
                        if(!!propertyForm){
                            parameter.vtype = propertyForm.vtype;
                            parameter.value = propertyForm.value;
                        }
                    }
                });

                const responsePropertyNames = serviceMBS.config?.response?.properties?.map(property => {
                    return property.name;
                }) || [];

                const validity = updatedPreSubmitService.data.validity;
                if(!!validity.valid_condition && !!validity.valid_condition?.name){
                    const index = responsePropertyNames.indexOf(validity.valid_condition.name);
                    if(index == -1){
                        validity.valid_condition.name = null;
                    }
                }

                if(!!validity.warning_condition && !!validity.warning_condition?.name){
                    const index = responsePropertyNames.indexOf(validity.warning_condition.name);
                    if(index == -1){
                        validity.warning_condition.name = null;
                    }
                }

                if(!!validity.message){
                    if(!!validity.message.valid){
                        const index = responsePropertyNames.indexOf(validity.message.valid);
                        if(index == -1){
                            validity.message.valid = null;
                        }
                    }
                    if(!!validity.message.warning){
                        const index = responsePropertyNames.indexOf(validity.message.warning);
                        if(index == -1){
                            validity.message.warning = null;
                        }
                    }
                    if(!!validity.message.invalid){
                        const index = responsePropertyNames.indexOf(validity.message.invalid);
                        if(index == -1){
                            validity.message.invalid = null;
                        }
                    }
                }

                updatedPreSubmitService.data.mapping_value = updatedPreSubmitService.data.mapping_value?.filter(mappingValue => {
                    return responsePropertyNames.indexOf(mappingValue.vname) != -1;
                });

                const index = this.combinedMBS.presubmit_services.indexOf(this.preSubmitServiceForm.preSubmitService);
                this.combinedMBS.presubmit_services[index] = updatedPreSubmitService;
                this.preSubmitServiceForm.preSubmitService = updatedPreSubmitService;

                this._initValidityMessageResponsePropertyOptions();
                this._initMappingValueResponsePropertyOptions();
                this._initPreSubmitServiceForm(updatedPreSubmitService);

                

                await this.utilsService.successDialogPopup({
                    text : `Service is updated to version ${serviceMBS.latest_version}`
                });   
            }     
            else {
                this.utilsService.alertDialogPopup("Alert",`Service Not Found`,{
                    icon : DialogPopupIcon.Warning
                });
            }       
        }
        else {
            this.utilsService.errorDialogPopup(response.meta.response_desc, {response:response});
        }
    };

    private _backPreSubmitServicesForm() : void {
        let urls = this.router.url.split('/');
        urls.splice(-1);
        if(!!this.preSubmitServiceForm.preSubmitService?.id){
            urls.splice(-1);
        }
        this.router.navigate([urls.join('/'),'pre-submits']);
    };

    private _savePreSubmitService() : void {     
        
        const preSubmitService = this.preSubmitServiceForm.preSubmitService;
        const preSubmitServiceForm = this.preSubmitServiceValidatingForm.getRawValue();
        for(let name in preSubmitServiceForm?.request?.parameters){
            const editedParameter = preSubmitServiceForm?.request?.parameters[name];
            const parameter = preSubmitService.data.request.params.find(param => param.name == name);
            parameter.value = null;
            parameter.vtype = null;
            if(!!parameter && !!editedParameter.value && !!editedParameter.vtype){
                parameter.value = editedParameter.value;
                parameter.vtype = editedParameter.vtype;
            }
        }

        preSubmitService.data.validity = this.utilsService.object.merge(
            preSubmitService.data.validity,
            preSubmitServiceForm.validity
        );

        const validConditionProperty = preSubmitService?.data?.response?.properties?.find(property => {
            return property.name == preSubmitService.data.validity.valid_condition.name;
        });
        preSubmitService.data.validity.valid_condition = {
            ...preSubmitService.data.validity.valid_condition,
            ...{
                label : validConditionProperty?.label || null,
                type : validConditionProperty?.type || null,
            }
        };

        const warningConditionProperty = preSubmitService?.data?.response?.properties?.find(property => {
            return property.name == preSubmitService.data.validity.warning_condition.name;
        });
        preSubmitService.data.validity.warning_condition = {
            ...preSubmitService.data.validity.warning_condition,
            ...{
                label : warningConditionProperty?.label || null,
                type : warningConditionProperty?.type || null,
            }
        };

        if(preSubmitService && !preSubmitService.id){
            const newId = `ns${Math.floor(Math.random() * 99999) + 100000}`;
            this.combinedMBS.presubmit_services.push({
                id : newId,
                ...preSubmitService
            });
        }

        this._setCombinedMBSInStore();
        this._backPreSubmitServicesForm();
    };

    private _clearSearchServiceMBSForm() : void {
        this.searchServiceMBSForm.validatingForm.reset();
    };

    private async _searchServiceMBSes() : Promise<void>{
        if(this.searchServiceMBSForm.validatingForm?.valid){
            const searchServiceMBSForm = this.searchServiceMBSForm.validatingForm.value;
            const response = await this.serviceMbsService.getServiceMBSs({ 
                mbs : { 
                    code : searchServiceMBSForm.serviceMBSCode,
                    serviceType : 'sync',
                    responseType : 'json'
                } 
            }).toPromise();
            if(response.meta.response_code == "10000"){

                const dataSource = response.data;
                const modalInstance = this.modalTableSelection.open(
                    this.searchServiceMBSForm.title,
                    dataSource,
                    this.searchServiceMBSForm.displayFields
                );
                const serviceMBS = await modalInstance.closed;
                if(!!serviceMBS) {
                    const newPreSubmitService = {
                        sequence: 1,
                        uuid: serviceMBS.uuid,
                        data : {
                            code : serviceMBS.code,
                            name : serviceMBS.name,
                            description: serviceMBS.description,
                            version : serviceMBS.latest_version,
                            request: serviceMBS.config?.request || null,
                            response: serviceMBS.config?.response || null,
                            validity : {
                                bypass_validation : false
                            },
                            mapping_value : []
                        }
                    }; 
                    newPreSubmitService.data.request?.params?.forEach(param => {
                        if (param.value) {
                            param.default = true;
                            param.vtype = "constant";
                        } else {
                            param.default = false;
                            param.vtype = null;
                        }
                    });
                    this.preSubmitServiceForm.preSubmitService = newPreSubmitService;
                    this._initPreSubmitServiceForm(newPreSubmitService);         
                    this._initValidityMessageResponsePropertyOptions();  
                    this._initMappingValueDatafieldOptions(); 
                    this._initMappingValueResponsePropertyOptions();
                }
            }
            else {
                this.utilsService.errorDialogPopup(response.meta.response_desc, { response : response });
            }
            this._clearSearchServiceMBSForm();
        }        
    };

    public getElementId(...args : Array<any>) : string {
        return this._getElementId(args);
    };

    public getParameterLabel(parameter : any) : string {
        return this._getParameterLabel(parameter);
    };

    public onChangeRequestParameterType(parameter : any) : void {
        this._onChangeRequestParameterType(parameter);
    };

    public getMappingValueItemLabel(item : any, labelProperties : Array<string>, typeProperty : string) : string {
        return this._getMappingValueItemLabel(item, labelProperties, typeProperty);
    };

    public isPropertyFormValid(validatingForm : any,...args : Array<string>) : boolean {
        return this._isPropertyFormValid(validatingForm,args.join('.'));
    };

    public isParameterVType(parameter : any, vtype : string) : boolean {
        return this._isParameterVType(parameter,vtype);
    };

    public btnAddMappingValue() : void {
        this._AddMappingValue();
    };

    public btnDeleteMappingValue(mappingValue : any) : void {
        this._deleteMappingValue(mappingValue);
    };

    public btnRefresh() : void {
        this._refreshPreSubmitService();
    };

    public btnSearchServiceMBSes() : void {
        this._searchServiceMBSes();
    };

    public btnBack() : void {
        this._backPreSubmitServicesForm();
    };

    public btnSave() : void {
        this._savePreSubmitService();
    };

}
