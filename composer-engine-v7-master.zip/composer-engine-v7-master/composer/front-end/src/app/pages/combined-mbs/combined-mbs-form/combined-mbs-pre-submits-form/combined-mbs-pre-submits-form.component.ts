import { Component, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { State } from '../../../../store/reducers';
import * as fromCombinedMBSAction from '../../../../store/actions/combined-mbs.actions';
import * as fromRoot from 'src/app/store/reducers/index';
import { Subscription } from 'rxjs';
import {CdkDragDrop, moveItemInArray} from '@angular/cdk/drag-drop';

import { UtilsService, ServiceMbsService, DialogPopupIcon } from '../../../../core/services';

@Component({
    selector: 'composer-combined-mbs-pre-submits-form',
    templateUrl: './combined-mbs-pre-submits-form.component.html',
    styleUrls: ['./combined-mbs-pre-submits-form.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class CombinedMbsPreSubmitsFormComponent {

    constructor(
        private router : Router,
        private serviceMbsService : ServiceMbsService,
        private utilsService : UtilsService,
        private store: Store<State>
    ) { 
        this._contructorComponent();
    };

    public fileName = 'combined_mbs_pre_submits_form';

    public combinedMBSForm = {
        combinedMBS: null,
        presubmitService : {
            displayFields : [
                {
                    title: "'Code'",
                    property: "data.code"
                },
                {
                    title: "'Name'",
                    property: "data.name"
                },
                {
                    title: "'Description'",
                    property: "data.description"
                },
                {
                    title: "'Latest Version'",
                    property: "data.version"
                }
            ]
        }
    };

    public combinedMBSStateSubscription : Subscription = null;


    private ngOnDestroy() {
        this._destroyComponent();
    };

    private async _contructorComponent() : Promise<void> {
        this._initCombinedMBSState();       
    };

    private _destroyComponent() : void {
        this._destroyCombinedMBSState();
    };

    private _getElementId(parts : Array<string>) : string {
        return [this.fileName,...parts].join('_');
    };

    private _initCombinedMBSState() : void {
        this._destroyCombinedMBSState();
        this.combinedMBSStateSubscription = this.store.select(fromRoot.getCombinedMBSInCombinedMBS).subscribe((combinedMBS) => {
            let data = JSON.parse(JSON.stringify(combinedMBS));
            if(this.combinedMBSForm.combinedMBS == null){
                this._initCombinedMBSForm(data); 
            }
        });
    };

    private _destroyCombinedMBSState(): void {
        if (this.combinedMBSStateSubscription != null) {
            this.combinedMBSStateSubscription.unsubscribe();
        }
    };

    private _setCombinedMBSInStore() : void {
        const cloneObject = JSON.parse(JSON.stringify(this.combinedMBSForm.combinedMBS));
        this.store.dispatch(fromCombinedMBSAction.setCombinedMBSInStore({ payload : cloneObject }));
    };

    private _initCombinedMBSForm(combinedMBS? : any) : void {
        this.combinedMBSForm.combinedMBS = {...{ presubmit_services : [] },...(combinedMBS || {})};
    };

    private async _deletePreSubmitService(preSubmitService : any) : Promise<void> {
        const isConfirm = await this.utilsService.deleteDialogPopup();
        if (isConfirm) {
            const index = this.combinedMBSForm.combinedMBS.presubmit_services.indexOf(preSubmitService);
            this.combinedMBSForm.combinedMBS.presubmit_services.splice(index,1);
            this._setCombinedMBSInStore();
        }
    };

    private async _alertUpdatePreSubmitServicesReport(responses : Array<any>) : Promise<void> {
        const preSubmitServices = this.combinedMBSForm.combinedMBS.presubmit_services || [];
        const serviceMBSes = responses
            .map(response => {
                const serviceMBS = (response.data && response.data[0]) || null;
                return serviceMBS;
            })
            .filter(serviceMBS => !!serviceMBS)
            .reduce((serviceMBSes, serviceMBS) => {
                serviceMBSes[serviceMBS.uuid] = serviceMBS;
                return serviceMBSes;
            },{});
        let html = '';
        const successServices = preSubmitServices.filter(presubmitService => {
            const service = serviceMBSes[presubmitService.uuid];
            return !!service && service.service_type == "sync" && service.response_type == "json";
        }).map(presubmitService => presubmitService.data.code);
        if(successServices.length > 0) {
            const successEle = `<div class="mb-3">
                <div class="text-success">Service are successfully updated</div>
                <div class="text-muted" style="font-size: 14px; text-indent: 16px;">${successServices.join(', ')}</div>
            </div>`;
            html = `${html}${successEle}`;
        }
        const notFoundServices = preSubmitServices.filter(presubmitService => {
            const service = serviceMBSes[presubmitService.uuid];
            return !service;
        }).map(presubmitService => presubmitService.data.code);
        if(notFoundServices.length > 0){
            const notFoundEle = `<div class="mb-3">
                <div>Service are not found</div>
                <div class="text-muted" style="font-size: 14px; text-indent: 16px;">${notFoundServices.join(', ')}</div>
            </div>`;
            html = `${html}${notFoundEle}`;
        }
        const invalidTypeServices = preSubmitServices.filter(presubmitService => {
            const service = serviceMBSes[presubmitService.uuid];
            return !!service && (service.service_type != "sync" || service.response_type != "json");
        }).map(presubmitService => presubmitService.data.code);
        if(invalidTypeServices.length > 0){
            const invalidTypeEle = `<div class="mb-3">
                <div class="text-danger">Service are invalid type</div>
                <div class="text-muted" style="font-size: 14px; text-indent: 16px;">${invalidTypeServices.join(', ')}</div>
            </div>`;
            html = `${html}${invalidTypeEle}`;
        }
        await this.utilsService.alertDialogPopup("Update Report",null,{
            icon : DialogPopupIcon.Info,
            html : `<div class="text-left">${html}</div>`
        });
    };

    private _updatePreSubmitServices(responses : Array<any>) : void {
        const preSubmitServices = this.combinedMBSForm.combinedMBS.presubmit_services || [];
        const serviceMBSes = responses        
            .filter(response => {
                if(response.meta.response_code == "10000"){
                    const serviceMBS = (response.data && response.data[0]) || null;
                    return !!serviceMBS && serviceMBS.service_type == "sync" && serviceMBS.response_type == "json";
                }
                return false;
            })
            .map(response => {
                const serviceMBS = (response.data && response.data[0]) || null;
                return serviceMBS;
            })
            .reduce((serviceMBSes, serviceMBS) => {
                serviceMBSes[serviceMBS.uuid] = serviceMBS;
                return serviceMBSes;
            },{});

        for(const preSubmitService of preSubmitServices) {
            const serviceMBS = serviceMBSes[preSubmitService.uuid];
            if(!!serviceMBS){
                
                const updatedPreSubmitService = this.utilsService.object.merge(
                    preSubmitService,
                    {
                        data : {
                            code : serviceMBS.code,
                            name : serviceMBS.name,
                            description : serviceMBS.description,
                            version : serviceMBS.latest_version,
                            request : serviceMBS.config?.request || null,
                            response : serviceMBS.config?.response || null,
                            validity : preSubmitService.validity
                        }
                    }
                );    
    
                const propertyForms = preSubmitService.data.request?.params?.reduce((propertyForms, parameter) => { 
                    propertyForms[parameter.name] = parameter; 
                    return propertyForms; 
                },{}) || {};
                updatedPreSubmitService.data.request?.params?.forEach(parameter => {
                    if(!!parameter.value){
                        parameter.default = true;
                        parameter.vtype = "constant";
                    }
                    else {
                        parameter.default = false;
                        parameter.vtype = null;
                        const propertyForm = propertyForms[parameter.name] || {};
                        if(!!propertyForm){
                            parameter.vtype = propertyForm.vtype || null;
                            parameter.value = propertyForm.value || null;
                        }
                    }
                });
    
                const responsePropertyNames = serviceMBS.config?.response?.properties?.map(property => {
                    return property.name;
                }) || [];
    
                const validity = updatedPreSubmitService.data.validity;
                if(!!validity.valid_condition && !!validity.valid_condition?.name){
                    const index = responsePropertyNames.indexOf(validity.valid_condition.name);
                    if(index == -1){
                        validity.valid_condition.name = null;
                        validity.valid_condition.label = null;
                        validity.valid_condition.type = null;
                    }
                }
    
                if(!!validity.warning_condition && !!validity.warning_condition?.name){
                    const index = responsePropertyNames.indexOf(validity.warning_condition.name);
                    if(index == -1){
                        validity.warning_condition.name = null;
                        validity.warning_condition.label = null;
                        validity.warning_condition.type = null;
                    }
                }
    
                if(!!validity.message){
                    if(!!validity.message.valid){
                        const index = responsePropertyNames.indexOf(validity.message.valid);
                        if(index == -1){
                            validity.message.valid = null;
                        }
                    }
                    if(!!validity.message.warning){
                        const index = responsePropertyNames.indexOf(validity.message.warning);
                        if(index == -1){
                            validity.message.warning = null;
                        }
                    }
                    if(!!validity.message.invalid){
                        const index = responsePropertyNames.indexOf(validity.message.invalid);
                        if(index == -1){
                            validity.message.invalid = null;
                        }
                    }
                }
    
                updatedPreSubmitService.data.mapping_value = updatedPreSubmitService.data.mapping_value?.filter(mappingValue => {
                    return responsePropertyNames.indexOf(mappingValue.vname) != -1;
                });
    
                const index = preSubmitServices.indexOf(preSubmitService);
                preSubmitServices[index] = updatedPreSubmitService;
            } 
        }
        if(Object.keys(serviceMBSes).length > 0){
            this._setCombinedMBSInStore();
        }

    };

    private async _refreshPreSubmitServices() : Promise<void>{
        const promises = [];
        const presubmitServiceUUIDs = this.combinedMBSForm.combinedMBS.presubmit_services?.reduce((presubmitServiceUUIDs,presubmitService)=>{
            if(presubmitServiceUUIDs.indexOf(presubmitService.uuid) == -1){
                presubmitServiceUUIDs.push(presubmitService.uuid);
            }
            return presubmitServiceUUIDs;
        },[]);
        for(let presubmitServiceUUID of presubmitServiceUUIDs){
            const promise = this.serviceMbsService.getServiceMBSs({
                mbs : {
                    uuid : presubmitServiceUUID
                }
            }).toPromise();
            promises.push(promise);
        }
        if(promises.length > 0) {
            const promise = Promise.all(promises);
            promise.then(responses => {
                const errorResponse = responses.find(response => response.meta?.response_code != "10000");
                if(!errorResponse){
                    this._updatePreSubmitServices(responses);
                    this._alertUpdatePreSubmitServicesReport(responses);
                }
                else {
                    this.utilsService.errorDialogPopup(errorResponse.meta.response_desc, { response : errorResponse });
                }
            });
        }   
    };

    private _gotoCreatePreSubmitService() : void {
        let urls = this.router.url.split('/');
        urls.splice(-1);
        this.router.navigate([urls.join('/'), 'new-pre-submit']);
    };

    private _gotoEditPreSubmitService(preSubmitService : any) : void {
        let urls = this.router.url.split('/');
        urls.splice(-1);
        this.router.navigate([urls.join('/'), 'pre-submit', preSubmitService.id]);
    };

    private _adjustPreSubmitServiceSequence() : void {
        let sequence = 1;
        for(const preSubmitService of this.combinedMBSForm.combinedMBS.presubmit_services){
            preSubmitService.sequence = sequence++;
        }
    };

    private _onRearrangePreSubmitServices($event : CdkDragDrop<string[]>) : void {
        moveItemInArray(this.combinedMBSForm.combinedMBS.presubmit_services, $event.previousIndex, $event.currentIndex);
        this._adjustPreSubmitServiceSequence();
    };

    public getElementId(...args : Array<any>) : string {
        return this._getElementId(args);
    };

    public btnRefresh() : void {
        this._refreshPreSubmitServices();
    };

    public btnEditPreSubmitService(preSubmitService : any) : void {
        this._gotoEditPreSubmitService(preSubmitService);
    };

    public btnDeletePreSubmitService(preSubmitService : any) : void {
        this._deletePreSubmitService(preSubmitService);
    };

    public getOjectPropertyValue(object : any, properties : string) : string {
        return this.utilsService.object.getValue(object,properties);
    };

    public onRearrangePreSubmitServices($event : any) : void {
        this._onRearrangePreSubmitServices($event);
    };

    public btnCreatePreSubmitService() : void {
        this._gotoCreatePreSubmitService();
    };

    public getObjectPropertyValue(item, property){
        const objectValue = this.utilsService.object.getValue(item, property);
        return objectValue == null? '-' : objectValue;
    }

}
