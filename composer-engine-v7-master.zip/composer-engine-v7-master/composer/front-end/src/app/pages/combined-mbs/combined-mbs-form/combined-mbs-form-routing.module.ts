import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CombinedMbsFormComponent } from './combined-mbs-form.component';
import { CombinedMbsInformationFormComponent } from './combined-mbs-information-form/combined-mbs-information-form.component';
import { CombinedMbsPreSubmitFormComponent } from './combined-mbs-pre-submit-form/combined-mbs-pre-submit-form.component';
import { CombinedMbsPreSubmitsFormComponent } from './combined-mbs-pre-submits-form/combined-mbs-pre-submits-form.component';

const routes: Routes = [
    {
        path: "",
        component: CombinedMbsFormComponent,
        children: [
            {
                path: "information",
                component: CombinedMbsInformationFormComponent
            },
            {
                path : "pre-submits",
                component : CombinedMbsPreSubmitsFormComponent
            },
            {
                path : "pre-submit/:preSubmitServiceId",
                component : CombinedMbsPreSubmitFormComponent
            },
            {
                path : "new-pre-submit",
                component : CombinedMbsPreSubmitFormComponent
            },
            {
                path: '',
                pathMatch: 'full',
                redirectTo: 'information'
            }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class CombinedMbsFormRoutingModule { }
