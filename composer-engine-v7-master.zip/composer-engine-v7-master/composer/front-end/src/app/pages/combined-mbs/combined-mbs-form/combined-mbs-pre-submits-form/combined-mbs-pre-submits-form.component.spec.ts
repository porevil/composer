import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CombinedMbsPreSubmitsFormComponent } from './combined-mbs-pre-submits-form.component';

describe('CombinedMbsPreSubmitsFormComponent', () => {
  let component: CombinedMbsPreSubmitsFormComponent;
  let fixture: ComponentFixture<CombinedMbsPreSubmitsFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CombinedMbsPreSubmitsFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CombinedMbsPreSubmitsFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
