import { Component, ViewEncapsulation } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { FormControl, Validators, FormBuilder } from '@angular/forms';
import { Store } from '@ngrx/store';
import { State } from '../../../store/reducers';
import * as fromCombinedMBSAction from '../../../store/actions/combined-mbs.actions';
import * as fromSystemConfigurationSubStateAction from '../../../store/actions/system-configuration-sub-state.actions';
import * as fromRoot from 'src/app/store/reducers/index';
import { Subscription } from 'rxjs';

import { CombinedMbsService, UtilsService } from '../../../core/services';

import { ValidateNotAllowSpace, ValidateNotAllowStartEndWithBlank } from '../../../core/validators/not-allow-space'

@Component({
    selector: 'composer-combined-mbs-form',
    templateUrl: './combined-mbs-form.component.html',
    styleUrls: ['./combined-mbs-form.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class CombinedMbsFormComponent {

    constructor(
        private router : Router,
        private activatedRoute : ActivatedRoute,
        private formBuilder : FormBuilder,
        private store: Store<State>,
        private combinedMbsService : CombinedMbsService,
        private utilsService : UtilsService
    ) { 
        this._contructorComponent();
    };

    public fileName = 'combined_mbs_form';

    public combinedMBSForm = {
        combinedMBS : null,
        validatingForm : null
    };

    public tabControls = {
        enabled : false,
        tabs : [
            {
                title : "Information",
                url : "information"
            },
            {
                title : "Pre-Submits",
                url : "pre-submits"
            }
        ],
        index : 0
    };

    public offRouteChange = null;

    public combinedMBSStateSubscription : Subscription = null;

    private ngOnDestroy() {
        this._destroyComponent();
    };

    private async _contructorComponent() : Promise<void> {              
        const params = this.activatedRoute.snapshot.params;
        let isRetrieve = false;
        if(!!params.combinedMBSId) {
            isRetrieve = true;
            this.store.dispatch(fromCombinedMBSAction.getCombinedMBS({ payload : { combinedMBSId : params.combinedMBSId, config : { redirect : { back : 3 } } } }));
        }        
        this.store.dispatch(fromSystemConfigurationSubStateAction.getAllSystemConfigurationSubStates());          
        this._initCombinedMBSState(isRetrieve); 
        this._initRouteDetectionChange(); 
    };

    private _destroyComponent() : void {
        this._destroyCombinedMBSState();
        this._destroyRouteDetectionChange();
    };

    private _getElementId(parts : Array<string>) : string {
        return [this.fileName,...parts].join('_');
    };

    private _initCombinedMBSState(isRetrieve : boolean) : void {
        this._destroyCombinedMBSState();
        let enabledPresubmit = null;
        this.combinedMBSStateSubscription = this.store.select(fromRoot.getCombinedMBSInCombinedMBS).subscribe((combinedMBS) => {
            let data = JSON.parse(JSON.stringify(combinedMBS));
            
            if(enabledPresubmit == null){
                enabledPresubmit = isRetrieve || !!combinedMBS?.isDuplicate;
                this._initTabControls(enabledPresubmit);
            }            
            if(!isRetrieve || !!data){                
                this._initCombinedMBSForm(data); 
            }
        });
    };

    private _destroyCombinedMBSState(): void {
        if (this.combinedMBSStateSubscription != null) {
            this.combinedMBSStateSubscription.unsubscribe();
        }
    };

    private _initCombinedMBSForm(combinedMBS? : any) : void {
        let formGroup = {
            code : new FormControl(combinedMBS?.code || null, Validators.compose([ Validators.required, ValidateNotAllowSpace ])),
            name : new FormControl(combinedMBS?.name || null, Validators.compose([ Validators.required, ValidateNotAllowStartEndWithBlank ])),
            description: new FormControl(combinedMBS?.description, Validators.compose([ValidateNotAllowStartEndWithBlank])),
            base_instance_code : new FormControl(combinedMBS?.base_instance_code || null, Validators.compose([ Validators.required, ValidateNotAllowStartEndWithBlank ]))
        };
        this.combinedMBSForm.validatingForm =  this.formBuilder.group(formGroup);
        this.combinedMBSForm.combinedMBS = combinedMBS || null;
    };

    private _initRouteDetectionChange(): void {
        this._destroyRouteDetectionChange();
        this.offRouteChange = this.router.events.subscribe(event => {
            if (event instanceof NavigationEnd) {
                this._initTabControls(true);
            }
        });
    };

    private _destroyRouteDetectionChange() : void {
        if (this.offRouteChange != null) {
            this.offRouteChange.unsubscribe();
        }
    };

    private _initTabControls(isRetrieve : boolean) : void {
        const url = this.router.url;
        this.tabControls.enabled = false;
        for(let i in this.tabControls.tabs){
            const tab = this.tabControls.tabs[i];
            const reg = new RegExp(`(\\/${tab.url})(($|\\?|\\/\\?|\\/$))`);
            if(reg.test(url)){
                this.tabControls.index = +i;
                this.tabControls.enabled = true;
                break;
            }
        }
        if(!isRetrieve){
            this.tabControls.tabs.splice(-1);
        }
    };

    private _onChangeTab(index : number) : void {
        this.tabControls.index = index;
        const selectedTab = this.tabControls.tabs[index];
        let urls = this.router.url.split('/');
        urls.splice(-1);
        this.router.navigate([urls.join('/'), selectedTab.url]);
    };

    private _backCombinedMBSes() : void {
        let urls = this.router.url.split('/');
        urls.splice(-2);
        if(!!this.combinedMBSForm.combinedMBS?.id){
            urls.splice(-1);
        }
        this.router.navigate([urls.join('/')]);
    };

    private _prepareCombinedMBSForSave() : any {
        const cleanServiceMBS = JSON.parse(JSON.stringify(this.combinedMBSForm.combinedMBS));
        delete cleanServiceMBS.isDuplicate;
        cleanServiceMBS.presubmit_services = cleanServiceMBS.presubmit_services?.map(preSubmitService => {
            if(typeof(preSubmitService.id) == "string" && preSubmitService.id.indexOf('ns') == 0){
                delete preSubmitService.id;
            }
            return preSubmitService;
        }) || null;
        return cleanServiceMBS;        
    };

    private async _saveCombinedMBS() : Promise<void> {
        const isConfirm = await this.utilsService.confirmDialogPopup("Save","Do you want to save?");
        if(isConfirm){
            const combinedMBS = this._prepareCombinedMBSForSave();
            const response = await this.combinedMbsService.setConfigurationMBS(combinedMBS).toPromise();
            if (response.meta.response_code == 10000) {
                await this.utilsService.successDialogPopup();
                this._backCombinedMBSes();
            }
            else {
                this.utilsService.errorDialogPopup(response.meta.response_desc, {response:response});
            }
        }        
    };

    private async _saveAndBuildCombinedMBS() : Promise<void> {
        const isConfirm = await this.utilsService.confirmDialogPopup("Save","Do you want to save and build?");
        if(isConfirm){
            const combinedMBS = this._prepareCombinedMBSForSave();
            const response = await this.combinedMbsService.setConfigurationMBS(combinedMBS).toPromise();
            if (response.meta.response_code == 10000) {
                const updatedCombinedMBS = response.data || null;
                const response2 = await this.combinedMbsService.buildConfigurationMBS(updatedCombinedMBS.uuid).toPromise();
                if(response2.meta.response_code == 10000){
                    await this.utilsService.successDialogPopup();
                    this._backCombinedMBSes();
                }
                else {
                    this.utilsService.errorDialogPopup(response2.meta.response_desc, {response:response2});
                }
            }
            else {
                this.utilsService.errorDialogPopup(response.meta.response_desc, {response:response});
            }
        }        
    };

    public getElementId(...args : Array<any>) : string {
        return this._getElementId(args);
    };

    public onChangeTab($event : any) : void {
        this._onChangeTab($event);
    };

    public btnBack() : void {
        this._backCombinedMBSes();
    };

    public btnSave() : void {
        this._saveCombinedMBS();
    };

    public btnSaveAndBuild() : void {
        this._saveAndBuildCombinedMBS();
    };

}
