import { Component, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, FormBuilder, FormGroup } from '@angular/forms';
import { Store } from '@ngrx/store';
import { State } from '../../../store/reducers';
import * as fromCombinedMBSAction from '../../../store/actions/combined-mbs.actions';

import { UtilsService, DialogPopupIcon, CombinedMbsService } from '../../../core/services';

@Component({
    selector: 'composer-combined-mbses',
    templateUrl: './combined-mbses.component.html',
    styleUrls: ['./combined-mbses.component.scss'],
    encapsulation : ViewEncapsulation.None
})
export class CombinedMbsesComponent {

    constructor(
        private router: Router,
        private formBuilder : FormBuilder,
        private store: Store<State>,
        private combinedMbsService : CombinedMbsService,
        private utilsService : UtilsService
    ) { 
        this._contructorComponent();
    };

    public fileName = 'combined_mbses';

    public searchForm = {
        validatingForm: null,
        isSearch : false
    };

    public combinedMBS = {
        dataSource : [],
        displayFields : [
            {
                title: "'Code'",
                sort: "'code'",
                filter: "'code'",
                property: "code"
            },
            {
                title: "'Name'",
                sort: "'name'",
                filter: "'name'",
                property: "name"
            },
            {
                title: "'Base MBS Code'",
                sort: "'base_instance_code'",
                filter: "'base_instance_code'",
                property: "base_instance_code"
            },
            {
                title: "'Base MBS Name'",
                sort: "'base_instance_name'",
                filter: "'base_instance_name'",
                property: "base_instance_name"
            },
            {
                title: "'Dataset'",
                sort: "'dataset_name'",
                filter: "'dataset_name'",
                property: "dataset_name"
            },
            {
                title: "'UUID'",
                sort: "'uuid'",
                filter: "'uuid'",
                property: "uuid"
            }
        ],
        actions : {
            duplicate :{
                label : "Duplicate Configuration",
                value : "duplicate"
            },
            edit :{
                label : "Edit Configuration",
                value : "edit"
            },
            build :{
                label : "Build",
                value : "build"
            },
            delete :{
                label : "Purge Configuration",
                value : "purge"
            }
        },
        options : []
    };

    private _contructorComponent() : void {
        this._initSearchForm();
        this._initCombinedMBSOptions();
    };

    private _getElementId(parts : Array<string>) : string {
        return [this.fileName,...parts].join('_');
    };

    private _initCombinedMBSOptions () : void {
        this.combinedMBS.options = [];
        for(const i in this.combinedMBS.actions){
            const action = this.combinedMBS.actions[i];
            this.combinedMBS.options.push(action);
        };
    };

    private _initSearchForm() : void {
        let formGroup = {
            combinedMBS : this.formBuilder.group({
                code : new FormControl(null),
                name : new FormControl(null),
                uuid : new FormControl(null),
                baseMBS : this.formBuilder.group({
                    code : new FormControl(null),
                    name : new FormControl(null),
                    datasetName : new FormControl(null)
                })
            })
        };    
        this.searchForm.validatingForm =  this.formBuilder.group(formGroup,{
            // validators : (form : FormGroup)=>{
            //     let condition = true;
            //     function validateObject(object : any) : boolean {
            //         let valid = true;
            //         for(let i in object){
            //             if(typeof(object[i]) == "object"){
            //                 valid = valid && validateObject(object[i]);
            //             }
            //             else {
            //                 valid = valid && (typeof(object[i]) != "string" || object[i].trim().length == 0)
            //             }
            //         }
            //         return valid;
            //     };
            //     const searchForm = form.value;
            //     condition = validateObject(searchForm);
            //     return condition ? { required : true } : null;
            // }
        });
    };

    private _clearSearch() : void {
        this.searchForm.isSearch = false;
        this.combinedMBS.dataSource = [];
        this.searchForm.validatingForm.reset();
    };

    private async _searchCombinedMBSes() : Promise<void>{
        if(this.searchForm.validatingForm.valid){
            const searchForm = this.searchForm.validatingForm.value;
            this.searchForm.isSearch = false;
            const response = await this.combinedMbsService.getConfigurationMBSes(searchForm).toPromise();
            if(response.meta.response_code == 10000){
                this.combinedMBS.dataSource = response.data;
                this.searchForm.isSearch = true;
            }
            else {
                this.utilsService.errorDialogPopup(response.meta.response_desc, { response : response });
            }
        }
    };

    private _gotoCreateCombinedMBS(combinedMBS? : any) : void {
        this.store.dispatch(fromCombinedMBSAction.setCombinedMBSInStore({ payload : combinedMBS || null }));
        let urls = this.router.url.split('/');
        this.router.navigate([urls.join('/'),'new-combined-mbs']);
    };

    private async _gotoEditCombinedMBS(combinedMBS : any) : Promise<void> {
        const isConfirm = await this.utilsService.confirmDialogPopup("Do you want to edit?",'Code:  ' +combinedMBS.code,);
        if(isConfirm){
            this.store.dispatch(fromCombinedMBSAction.setCombinedMBSInStore({ payload : null}));
            let urls = this.router.url.split('/');
            this.router.navigate([urls.join('/'), combinedMBS.id,'configuration']);
        }        
    };

    private async _deleteCombinedMBS(combinedMBS : any) : Promise<void> {
        const isConfirm = await this.utilsService.deleteDialogPopup({
            title : `Purge ${combinedMBS.code}`
        });
        if(isConfirm){
            const response = await this.combinedMbsService.purgeConfigurationMBS(combinedMBS.uuid).toPromise();
            if(response.meta.response_code == 10000){
                await this.utilsService.successDialogPopup();
                const index = this.combinedMBS.dataSource.indexOf(combinedMBS);
                this.combinedMBS.dataSource.splice(index,1);
            }
            else {
                this.utilsService.errorDialogPopup(response.meta.response_desc, {response:response});
            }
        }
    };

    private async _duplicateCombinedMBS(combinedMBS : any) : Promise<void> {
        const isConfirm = await this.utilsService.confirmDialogPopup("Do you want to duplicate?",'Code:  ' +combinedMBS.code);
        if(isConfirm){
            const response = await this.combinedMbsService.getConfigurationMBS(combinedMBS.id).toPromise();
            if(response.meta.response_code == 10000){
                const targetCombinedMBS = response.data || null;
                if(!!targetCombinedMBS){
                    const cloneCombinedMBS = {
                        isDuplicate : true,
                        ...targetCombinedMBS,
                        ...{
                            id : undefined,
                            uuid : undefined,
                            code : undefined,
                            name : undefined,
                            description : undefined,
                            presubmit_services : targetCombinedMBS.presubmit_services.map(preSubmitService => ({
                                ...preSubmitService,
                                id : `ns${Math.floor(Math.random() * 99999) + 100000}`
                            }))
                        }
                    };
                    this._gotoCreateCombinedMBS(cloneCombinedMBS);
                }
            }
            else {
                this.utilsService.errorDialogPopup(response.meta.response_desc, {response:response});
            }
        }        
    };

    private async _buildCombinedMBS(combinedMBS : any) : Promise<void>{
        const isConfirm = await this.utilsService.confirmDialogPopup("Do you want to build?",'Code:  ' +combinedMBS.code,);
        if(isConfirm){
            const response = await this.combinedMbsService.buildConfigurationMBS(combinedMBS.uuid).toPromise();
            if(response.meta.response_code == 10000){
                await this.utilsService.successDialogPopup();
            }
            else {
                this.utilsService.errorDialogPopup(response.meta.response_desc, {response:response});
            }
        }  
    };

    private _onChangeCombinedMBSAction(combinedMBS : any) : void {
        if(combinedMBS.action == this.combinedMBS.actions.duplicate.value){
            this._duplicateCombinedMBS(combinedMBS);
        }
        else if(combinedMBS.action == this.combinedMBS.actions.edit.value) {
            this._gotoEditCombinedMBS(combinedMBS);
        }
        else if(combinedMBS.action == this.combinedMBS.actions.build.value) {
            this._buildCombinedMBS(combinedMBS);
        }
        else if(combinedMBS.action == this.combinedMBS.actions.delete.value) {
            this._deleteCombinedMBS(combinedMBS);
        }
        combinedMBS.action = null;
    };

    public getElementId(...args : Array<any>) : string {
        return this._getElementId(args);
    };

    public btnCreateCombinedMBS() : void {
        this._gotoCreateCombinedMBS();
    };

    public btnReset() : void {
        this._clearSearch();
    };

    public btnSearch() : void {
        this._searchCombinedMBSes();
    };

    public onChangeCombinedMBSAction(combinedMBS : any) : void {
        this._onChangeCombinedMBSAction(combinedMBS);
    };

}
