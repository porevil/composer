import { Component, ViewEncapsulation, ViewChild } from '@angular/core';
import { FormControl, Validators, FormBuilder } from '@angular/forms';
import { Store } from '@ngrx/store';
import { State } from '../../../../store/reducers';
import * as fromCombinedMBSAction from '../../../../store/actions/combined-mbs.actions';
import * as fromRoot from 'src/app/store/reducers/index';
import { Subscription } from 'rxjs';
import { debounceTime } from 'rxjs/operators';

import { CommonMbsService, UtilsService, DialogPopupIcon } from '../../../../core/services';
import { ValidateNotAllowSpace, ValidateNotAllowStartEndWithBlank } from '../../../../core/validators/not-allow-space'

@Component({
    selector: 'composer-combined-mbs-information-form',
    templateUrl: './combined-mbs-information-form.component.html',
    styleUrls: ['./combined-mbs-information-form.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class CombinedMbsInformationFormComponent {

    @ViewChild('modalTableSelection', { static: true }) modalTableSelection: any;

    constructor(
        private formBuilder : FormBuilder,
        private store: Store<State>,
        private utilsService : UtilsService,
        private commonMbsService : CommonMbsService
    ) { 
        this._contructorComponent();
    }

    public fileName = 'combined_mbs_information_form';

    public combinedMBSForm = {
        combinedMBS: null,
        validatingForm : null,
        valueChangesSubscription : null
    };

    public searchCommonMBSForm = {
        title : "Common MBSes",
        validatingForm : null,
        displayFields : [
            {
                title: "'Code'",
                filter : "'code'",
                sort : "'code'",
                property: "code"
            },
            {
                title: "'Name'",
                filter : "'name'",
                sort : "'name'",
                property: "name"
            }
        ]
    };

    public defaultSubState = null;

    public combinedMBSStateSubscription : Subscription = null;
    public subStatesStateSubscription : Subscription = null;


    private ngOnDestroy() {
        this._destroyComponent();
    };

    private _contructorComponent() : void {
        this._initSubStatesState();
        this._initCombinedMBSState();
    };

    private _destroyComponent() : void {
        this._destroyCombinedMBSState();
        this._destroySubStatesState();
        this._destroyCombinedMBSForm();
    };

    private _getElementId(parts : Array<string>) : string {
        return [this.fileName,...parts].join('_');
    };

    private _initCombinedMBSState() : void {
        this._destroyCombinedMBSState();
        this.combinedMBSStateSubscription = this.store.select(fromRoot.getCombinedMBSInCombinedMBS).subscribe((combinedMBS) => {
            let data = JSON.parse(JSON.stringify(combinedMBS));
            if(this.combinedMBSForm.combinedMBS == null){
                if(!data?.id && !data?.isDuplicate){
                    this._initSearchCommonMBSForm();
                }
                this._initCombinedMBSForm(data); 
            }
        });
    };

    private _destroyCombinedMBSState(): void {
        if (this.combinedMBSStateSubscription != null) {
            this.combinedMBSStateSubscription.unsubscribe();
        }
    };

    private _setCombinedMBSInStore() : void {
        let combinedMBSForm = this.combinedMBSForm.validatingForm.value;
        let mergeObject = this.utilsService.object.merge(this.combinedMBSForm.combinedMBS,combinedMBSForm);
        this.store.dispatch(fromCombinedMBSAction.setCombinedMBSInStore({ payload : mergeObject }));
    };

    private _initSubStatesState() : void {
        this._destroySubStatesState();
        this.subStatesStateSubscription = this.store.select(fromRoot.getSubStatesInSystemConfigurationState).subscribe((subStates)=> {
            let data = JSON.parse(JSON.stringify(subStates));
            this.defaultSubState = (data || []).find(subState => subState.is_default) || null;
        });
    };

    private _destroySubStatesState() : void {
        if (this.subStatesStateSubscription != null) {
            this.subStatesStateSubscription.unsubscribe();
        }
    };

    private _destroyCombinedMBSForm() : void {
        if (this.combinedMBSForm.valueChangesSubscription != null) {
            this.combinedMBSForm.valueChangesSubscription.unsubscribe();
        }
    };

    private _initCombinedMBSForm(combinedMBS? : any) : void {
        this._destroyCombinedMBSForm();
        let formGroup = {
            code : new FormControl({ value : combinedMBS?.code || null, disabled : !!combinedMBS?.id }, Validators.compose([ Validators.required, ValidateNotAllowSpace ])),
            name : new FormControl(combinedMBS?.name || null, Validators.compose([ Validators.required, ValidateNotAllowStartEndWithBlank ])),
            description : new FormControl(combinedMBS?.description || null, Validators.compose([ValidateNotAllowStartEndWithBlank]))
        }
        this.combinedMBSForm.combinedMBS = combinedMBS;
        this.combinedMBSForm.validatingForm =  this.formBuilder.group(formGroup);
        this.combinedMBSForm.valueChangesSubscription = this.combinedMBSForm.validatingForm.valueChanges.pipe(debounceTime(500)).subscribe(form => {
            this._setCombinedMBSInStore();
        });
    };

    private _initSearchCommonMBSForm() : void {
        let formGroup = {
            commonMBSCode : new FormControl(null, Validators.compose([ Validators.required ]))
        };    
        this.searchCommonMBSForm.validatingForm =  this.formBuilder.group(formGroup);
    };

    private _clearSearchCommonMBSForm() : void {
        this.searchCommonMBSForm.validatingForm?.reset();
    };

    private async _searchCommonMBSes() : Promise<void> {

        if(this.searchCommonMBSForm.validatingForm?.valid){
            const searchCommonMBSForm = this.searchCommonMBSForm.validatingForm.value;
            const response : any = await this.commonMbsService.getRepositories(
                this.defaultSubState,
                {
                    code : searchCommonMBSForm.commonMBSCode,
                    detail : true
                }
            ).toPromise();
            if(response.meta.response_code == "10000"){
                const dataSource = response.data;
                const modalInstance = this.modalTableSelection.open(
                    this.searchCommonMBSForm.title,
                    dataSource,
                    this.searchCommonMBSForm.displayFields
                );
                const commonMBS = await modalInstance.closed;
                if(!!commonMBS){
                    this.combinedMBSForm.combinedMBS = this.utilsService.object.merge(
                        this.combinedMBSForm.combinedMBS,
                        {
                            base_instance_uuid : commonMBS.uuid || null,
                            base_instance_code : commonMBS.code || null,
                            base_instance_name : commonMBS.name || null,
                            base_instance_build_no : commonMBS.build_no || null,
                            dataset_name : commonMBS.dataset_name || null,
                            data : {
                                dataset : {
                                    version : commonMBS.build_data?.dataset?.version || null,
                                    description : commonMBS.build_data?.dataset?.description || null
                                },
                                datafields : commonMBS.build_data?.datafields || null,
                                intent : commonMBS.build_data?.intent || null
                            }
                        }
                    );   
                    this._setCombinedMBSInStore();           
                }
            }
            else {
                this.utilsService.errorDialogPopup(response.meta.response_desc, { response : response });
            }
            this._clearSearchCommonMBSForm();
        }
    };

    private async _refreshBaseMBS() : Promise<void>{
        const combinedMBS = this.combinedMBSForm.combinedMBS;
        const response : any = await this.commonMbsService.getRepositories(
            this.defaultSubState,
            {
                _uuid : combinedMBS.base_instance_uuid,
                detail : true
            }
        ).toPromise();
        if(response.meta.response_code == "10000"){
            const commonMBS = (response.data && response.data[0]) || null;
            if(commonMBS != null){
                if(combinedMBS.base_instance_build_no != commonMBS.build_no){
                    const isConfirm = await this.utilsService.confirmDialogPopup(
                        "New Version",
                        `Do you want to update base MBS information to version ${commonMBS.build_no}?`
                    );
                    if(isConfirm){
                        
                        this.combinedMBSForm.combinedMBS = this.utilsService.object.merge(
                            this.combinedMBSForm.combinedMBS,
                            {
                                base_instance_code : commonMBS.code || null,
                                base_instance_name : commonMBS.name || null,
                                base_instance_build_no : commonMBS.build_no || null,
                                dataset_name : commonMBS.dataset_name || null,
                                data : {
                                    dataset : {
                                        version : commonMBS.build_data?.dataset?.version || null,
                                        description : commonMBS.build_data?.dataset?.description || null
                                    },
                                    datafields : commonMBS.build_data?.datafields || null,
                                    intent : commonMBS.build_data?.intent || null
                                }
                            }
                        );
                        this._setCombinedMBSInStore();

                        this.utilsService.successDialogPopup({
                            text : `Update Base MBS to version ${commonMBS.build_no} success`
                        });
                    }
                }
                else {
                    this.utilsService.alertDialogPopup(
                        "Nothing change",
                        `${combinedMBS.base_instance_code} is latest version`,
                        {
                            icon : DialogPopupIcon.Info
                        }
                    );
                }
            }
            else {
                this.utilsService.alertDialogPopup("Alert",`${combinedMBS.base_instance_code} Not Found`,{
                    icon : DialogPopupIcon.Warning
                });
            }
        }
        else {
            this.utilsService.errorDialogPopup(response.meta.response_desc, { response : response });
        }
    };

    public getElementId(...args : Array<any>) : string {
        return this._getElementId(args);
    };

    public btnSearchCommonMBSes() : void {
        this._searchCommonMBSes();
    };

    public btnRefresh() : void {
        this._refreshBaseMBS();
    };


}
