import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CombinedMbsFormComponent } from './combined-mbs-form.component';

describe('CombinedMbsFormComponent', () => {
  let component: CombinedMbsFormComponent;
  let fixture: ComponentFixture<CombinedMbsFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CombinedMbsFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CombinedMbsFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
