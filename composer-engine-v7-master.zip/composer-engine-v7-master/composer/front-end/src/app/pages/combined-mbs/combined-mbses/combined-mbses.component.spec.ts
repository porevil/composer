import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CombinedMbsesComponent } from './combined-mbses.component';

describe('CombinedMbsesComponent', () => {
  let component: CombinedMbsesComponent;
  let fixture: ComponentFixture<CombinedMbsesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CombinedMbsesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CombinedMbsesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
