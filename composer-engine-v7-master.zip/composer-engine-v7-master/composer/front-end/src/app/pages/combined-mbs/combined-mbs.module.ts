import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { 
    WidgetTextboxModule, WidgetButtonModule, WidgetTableModule,
    WidgetIconButtonModule, WidgetDropdownModule
} from '@channel/widgets';

import { CombinedMbsRoutingModule } from './combined-mbs-routing.module';

import { CombinedMbsComponent } from './combined-mbs.component';
import { CombinedMbsesComponent } from './combined-mbses/combined-mbses.component';


@NgModule({
    declarations: [
        CombinedMbsComponent,
         CombinedMbsesComponent
    ],
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        CombinedMbsRoutingModule,
        WidgetTextboxModule,
        WidgetButtonModule,
        WidgetTableModule,
        WidgetIconButtonModule,
        WidgetDropdownModule
    ]
})
export class CombinedMbsModule { }
