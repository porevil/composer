import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CombinedMbsPreSubmitFormComponent } from './combined-mbs-pre-submit-form.component';

describe('CombinedMbsPreSubmitFormComponent', () => {
  let component: CombinedMbsPreSubmitFormComponent;
  let fixture: ComponentFixture<CombinedMbsPreSubmitFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CombinedMbsPreSubmitFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CombinedMbsPreSubmitFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
