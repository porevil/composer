import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CombinedMbsComponent } from './combined-mbs.component';
import { CombinedMbsesComponent } from './combined-mbses/combined-mbses.component';

const routes: Routes = [
    {
        path: "",
        component: CombinedMbsComponent,
        children : [
            {
                path : "",
                component : CombinedMbsesComponent
            },
            {
                path: 'new-combined-mbs',
                loadChildren: () => import('./combined-mbs-form/combined-mbs-form.module')
                    .then(mod => mod.CombinedMbsFormModule)
            },
            {
                path: ':combinedMBSId/configuration',
                loadChildren: () => import('./combined-mbs-form/combined-mbs-form.module')
                    .then(mod => mod.CombinedMbsFormModule)
            }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class CombinedMbsRoutingModule { }
