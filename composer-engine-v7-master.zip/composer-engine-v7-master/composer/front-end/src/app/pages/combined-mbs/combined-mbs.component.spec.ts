import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CombinedMbsComponent } from './combined-mbs.component';

describe('CombinedMbsComponent', () => {
  let component: CombinedMbsComponent;
  let fixture: ComponentFixture<CombinedMbsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CombinedMbsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CombinedMbsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
