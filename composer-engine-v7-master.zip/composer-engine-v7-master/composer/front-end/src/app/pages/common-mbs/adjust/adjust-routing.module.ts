import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdjustModule } from './adjust.module';
import { AdjustComponent } from './adjust.component';


const routes: Routes = [
  {
    path: ':uuid',
    component: AdjustComponent,
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdjustRoutingModule { }
