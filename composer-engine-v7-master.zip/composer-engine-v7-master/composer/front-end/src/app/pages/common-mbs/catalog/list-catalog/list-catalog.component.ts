import { Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import { CommonMbsService, UtilsService, SystemConfigurationService } from 'src/app/core/services';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Constant } from 'src/app/shared/constants/constants';

@Component({
    selector: 'composer-list-catalog',
    templateUrl: './list-catalog.component.html',
    styleUrls: ['./list-catalog.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class ListCatalogComponent implements OnInit {

    @ViewChild('modelAuthorizeTicket', { static: true }) modelAuthorizeTicket: any;
    action: any;

    constructor(
        private commonMbsService: CommonMbsService,
        public utilsService: UtilsService,
        private router: Router,
        private systemConfigurationService: SystemConfigurationService,
        private formBuilder: FormBuilder,
        private activatedRoute: ActivatedRoute
    ) {
        this.createFormGroup()
        this.getSubstateList()
    }

    public list_catalog_common_mbs = {
        dataSource: [],
        displayFields: [
            {
                title: "'Code'",
                sort: "'code'",
                filter: "'code'",
                property: "code"
            },
            {
                title: "'Name'",
                sort: "'name'",
                filter: "'name'",
                property: "name"
            },
            {
                title: "'Dataset'",
                sort: "'dataset_name'",
                filter: "'dataset_name'",
                property: "dataset_name"
            },
            {
                title: "'UUID'",
                sort: "'uuid'",
                filter: "'uuid'",
                property: "uuid"
            },
            {
                title: "'Generating Tag'",
                property: "generating_tag"
            },
            {
                title: "'Latest Build No'",
                property: "latest_build_no"
            }
        ]
    };

    commonOptions = [
        {
            label: 'Pre-defined Single Dataset',
            value: '1'
        },
        {
            label: 'Pre-defined Multiple Dataset',
            value: '2'
        },
        {
            label: 'User-defined',
            value: '3'
        }
    ]

    mergeOptions = [
        {
            label: 'View Configuration',
            value: 'Adjust'
        },
        {
            label: 'Purge Configuration',
            value: 'Purge'
        },
    ]

    actionOptions = []
    subStateOptions = []
    isSubstate: any
    authorized_ticket = ''
    catalogCommonMbsFrom: FormGroup;
    get f() { return this.catalogCommonMbsFrom.controls; }
    search_input = {
        name: '',
        code: '',
        dataset: '',
        _uuid: '',
        _type: ''
    }
    isSearch = false


    ngOnInit(): void {

    }

    clr_search_input() {
        this.isSearch = false
        this.search_input = {
            name: '',
            code: '',
            dataset: '',
            _uuid: '',
            _type: ''
        }
    }

    getCatalogCommon_list() {
        this.commonMbsService.getCatalog(this.search_input).then((response: any) => {
            if (response.meta.response_code == 10000) {
                this.isSearch = true
                this.list_catalog_common_mbs.dataSource = response.data
                if (this.list_catalog_common_mbs.dataSource != []) {
                    this.list_catalog_common_mbs.dataSource.forEach(element => {
                        this.changeActionsFromGeneratingType(element)
                    });
                }
            } else {
                this.utilsService.errorDialogPopup(response.meta.response_desc, { response: response });
            }
        })
    }

    changeActionsFromGeneratingType(item) {
        if ((item.generating_type == 1 || item.generating_type == 2) && item.lot_id) {
            item.option = [...this.actionOptions, {
                label: 'My Group',
                value: 'My Group'
            }]
        } else {
            item.option = this.actionOptions
        }
    }

    createFormGroup(item?) {
        this.action = item ? item.id : 'create'
        this.catalogCommonMbsFrom = this.formBuilder.group({
            action: ['']
        });
    }

    getSubstateList() {
        this.actionOptions = []
        let newSub = {}
        this.systemConfigurationService._getOneSystemConfigurationSubStateToPromise().then((response: any) => {
            if (response.meta.response_code == 10000) {
                response.data.forEach(element => {
                    this.subStateOptions.push({
                        label: element.name,
                        value: element.id
                    })
                    if (element.is_default) {
                        this.isSubstate = element
                        newSub = {
                            label: 'Build & Publish to ' + element.name,
                            value: element.id
                        }
                    }
                });
            }
            else {
                this.utilsService.errorDialogPopup(response.meta.response_desc, { response: response });
            }
            this.actionOptions = [...this.mergeOptions, newSub]
        })
    }

    btnAdjust(item) {
        let urls = this.router.url.split('/');
        urls.splice(-2);
        this.router.navigate([urls.join('/'), 'adjust', item]);
    }

    btnBuild(uuid, authorized_ticket) {
        this.commonMbsService.catalog_build_and_publish({ "uuid": uuid, authorized_ticket: authorized_ticket }).then((response: any) => {
            if (response.meta.response_code == 10000) {
                this.utilsService.successDialogPopup({ title: Constant.msgDisplayConsoleOutputId, text: Constant.consoleOutputId + response.data.console_output_id });
                this.getCatalogCommon_list()
            } else {
                this.utilsService.errorDialogPopup(response.meta.response_desc, { response: response });
            }
        })
    }

    btnPurge(uuid) {
        this.commonMbsService.catalog_purge({ "uuid": uuid }).then((response: any) => {
            if (response.meta.response_code == 10000) {
                this.utilsService.successDialogPopup({ title: Constant.msgDisplayConsoleOutputId, text: Constant.consoleOutputId + response.data.console_output_id });
                this.getCatalogCommon_list()
            } else {
                this.utilsService.errorDialogPopup(response.meta.response_desc, { response: response });
            }
        })
    }

    btnMygroup(lot_id) {
        const params = this.activatedRoute.snapshot.params;
        let urls = this.router.url.split('/');
        urls.splice(-2);
        this.router.navigate([urls.join('/'), 'generator', lot_id, 'configuration']);
    }

    onSelect(event, item) {
        switch (event) {
            case 'Adjust':
                this.btnAdjust(item.uuid)
                break;
            case 'Purge':
                this.btnPurge(item.uuid)
                break;
            case 'My Group':
                this.btnMygroup(item.lot_id)
                break;
            default:
                if (this.isSubstate.need_authorized_ticket) {
                    this._openElementConfigurationForm(item.uuid)
                } else {
                    this.btnBuild(item.uuid, undefined)
                }
                break;
        }
    }

    _openElementConfigurationForm(listCheck?: any): void {
        this.authorized_ticket = ''
        const modalInstance = this.modelAuthorizeTicket.show();
        modalInstance.closed.then(result => {
            if (!!result && result.isConfirm) {
                this.btnBuild(listCheck, this.authorized_ticket)
            }
        });
    };

    _closeElementConfigurationForm(result: any): void {
        this.modelAuthorizeTicket.hide(result);
    };

    btnConfirmElementConfigurationForm(): void {
        if (this.authorized_ticket && this.utilsService.validator.notAllowStartEndWithBlank(this.authorized_ticket)) {
            this._closeElementConfigurationForm({
                isConfirm: true
            });
        }
    };

    public async dialogPopupConfirm(event: string, item: any, options: Array<any>): Promise<void> {
        if (event) {
            const text = options?.find(option => event == option.value)?.label?.toLowerCase() || "";
            const isConfirm = await this.utilsService.confirmDialogPopup('Do you want to ' + text + ' ?', 'Code:  ' + item.code);
            if (isConfirm) {
                this.onSelect(event, item)
            }
            item.action = null;
        }
    }
}
