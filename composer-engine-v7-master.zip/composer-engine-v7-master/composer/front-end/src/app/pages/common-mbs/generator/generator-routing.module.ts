import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GeneratorComponent } from './generator.component';
import { ListGeneratorCommonMbsComponent } from './list-generator-common-mbs/list-generator-common-mbs.component';
import { ConfigurationGeneratorCommonMbsComponent } from './configuration-generator-common-mbs/configuration-generator-common-mbs.component';
import { NodeRepositoryComponent } from './node-repository/node-repository.component';


const routes: Routes = [
  {
    path: '',
    component: GeneratorComponent,
    children: [
      {
        path: '',
        pathMatch: "full",
        redirectTo: "list"
      },
      {
        path: 'list',
        component: ListGeneratorCommonMbsComponent
      },
      {
        path: ':generatorCommonMbsId/configuration',
        component: ConfigurationGeneratorCommonMbsComponent
      },
      {
        path: ':generatorCommonMbsId/repository',
        component: NodeRepositoryComponent
      }

    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class GeneratorRoutingModule { }
