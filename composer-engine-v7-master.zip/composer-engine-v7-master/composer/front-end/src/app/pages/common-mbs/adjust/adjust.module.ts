import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdjustRoutingModule } from './adjust-routing.module';
import { AdjustComponent } from './adjust.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { WidgetTextboxModule, WidgetButtonModule, WidgetTableModule, WidgetIconButtonModule, WidgetModalModule, WidgetDropdownModule, WidgetTextareaModule, WidgetMultipleSelectDropdownModule, WidgetTextDisplayModule, WidgetChipsModule, WidgetTabsModule, WidgetToggleModule } from '@channel/widgets';
import { SharedModule } from 'src/app/shared/shared.module';


@NgModule({
  declarations: [AdjustComponent],
  imports: [
    CommonModule,
    AdjustRoutingModule,
    FormsModule,
    WidgetTextboxModule,
    WidgetButtonModule,
    WidgetTableModule,
    WidgetIconButtonModule,
    WidgetModalModule,
    ReactiveFormsModule,
    WidgetDropdownModule,
    WidgetTextareaModule,
    SharedModule,
    WidgetMultipleSelectDropdownModule,
    WidgetTextDisplayModule,
    WidgetChipsModule,
    WidgetTabsModule,
    WidgetToggleModule
  ]
})
export class AdjustModule { }
