import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigurationGeneratorCommonMbsComponent } from './configuration-generator-common-mbs.component';

describe('ConfigurationGeneratorCommonMbsComponent', () => {
  let component: ConfigurationGeneratorCommonMbsComponent;
  let fixture: ComponentFixture<ConfigurationGeneratorCommonMbsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfigurationGeneratorCommonMbsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigurationGeneratorCommonMbsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
