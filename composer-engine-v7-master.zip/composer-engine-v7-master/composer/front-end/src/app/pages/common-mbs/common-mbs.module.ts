import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CommonMbsRoutingModule } from './common-mbs-routing.module';
import { CommonMbsComponent } from './common-mbs.component';


@NgModule({
  declarations: [CommonMbsComponent],
  imports: [
    CommonModule,
    CommonMbsRoutingModule
  ]
})
export class CommonMbsModule { }
