import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommonMbsComponent } from './common-mbs.component';

describe('CommonMbsComponent', () => {
  let component: CommonMbsComponent;
  let fixture: ComponentFixture<CommonMbsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CommonMbsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommonMbsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
