import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import {
  WidgetTextboxModule, WidgetButtonModule, WidgetTableModule, WidgetIconButtonModule,
  WidgetModalModule, WidgetDropdownModule, WidgetTextareaModule, WidgetTextDisplayModule,
  WidgetMultipleSelectDropdownModule, WidgetChipsModule, WidgetCheckboxModule, WidgetTabsModule
} from '@channel/widgets';
import { SharedModule } from 'src/app/shared/shared.module';

import { GeneratorRoutingModule } from './generator-routing.module';
import { GeneratorComponent } from './generator.component';
import { ListGeneratorCommonMbsComponent } from './list-generator-common-mbs/list-generator-common-mbs.component';
import { ConfigurationGeneratorCommonMbsComponent } from './configuration-generator-common-mbs/configuration-generator-common-mbs.component';
import { NodeRepositoryComponent } from './node-repository/node-repository.component';


@NgModule({
  declarations: [GeneratorComponent, ListGeneratorCommonMbsComponent, ConfigurationGeneratorCommonMbsComponent, NodeRepositoryComponent],
  imports: [
    CommonModule,
    GeneratorRoutingModule,
    FormsModule,
    WidgetTextboxModule,
    WidgetButtonModule,
    WidgetTableModule,
    WidgetIconButtonModule,
    WidgetModalModule,
    ReactiveFormsModule,
    WidgetDropdownModule,
    WidgetTextareaModule,
    WidgetTextDisplayModule,
    SharedModule,
    WidgetMultipleSelectDropdownModule,
    WidgetChipsModule,
    WidgetCheckboxModule,
    WidgetTabsModule
  ]
})
export class GeneratorModule { }
