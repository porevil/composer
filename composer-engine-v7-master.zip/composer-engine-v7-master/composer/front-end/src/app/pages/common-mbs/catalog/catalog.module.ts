import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { CatalogRoutingModule } from './catalog-routing.module';
import { CatalogComponent } from './catalog.component';
import { ListCatalogComponent } from './list-catalog/list-catalog.component';

import { SharedModule } from 'src/app/shared/shared.module';

import { 
  WidgetDropdownModule, WidgetTextboxModule, WidgetButtonModule, WidgetTableModule,
  WidgetIconButtonModule, WidgetModalModule, WidgetTextareaModule, WidgetTextDisplayModule,
  WidgetMultipleSelectDropdownModule, WidgetChipsModule, WidgetCheckboxModule
} from '@channel/widgets';


@NgModule({
  declarations: [CatalogComponent, ListCatalogComponent],
  imports: [
    CommonModule,
    CatalogRoutingModule,
    FormsModule,
    WidgetTextboxModule,
    WidgetButtonModule,
    WidgetTableModule,
    WidgetIconButtonModule,
    WidgetModalModule,
    ReactiveFormsModule,
    WidgetDropdownModule,
    WidgetTextareaModule,
    WidgetTextDisplayModule,
    SharedModule,
    WidgetMultipleSelectDropdownModule,
    WidgetChipsModule,
    WidgetCheckboxModule
  ]
})
export class CatalogModule { }
