import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'composer-common-mbs',
  templateUrl: './common-mbs.component.html',
  styleUrls: ['./common-mbs.component.scss']
})
export class CommonMbsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
