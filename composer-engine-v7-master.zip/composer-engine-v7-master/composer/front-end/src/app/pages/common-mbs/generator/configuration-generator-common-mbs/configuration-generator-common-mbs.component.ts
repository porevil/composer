import { Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UtilsService, CommonMbsService, StandardProcessService, SystemConfigurationService } from 'src/app/core/services';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Constant } from 'src/app/shared/constants/constants';

@Component({
    selector: 'composer-configuration-generator-common-mbs',
    templateUrl: './configuration-generator-common-mbs.component.html',
    styleUrls: ['./configuration-generator-common-mbs.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class ConfigurationGeneratorCommonMbsComponent implements OnInit {

    @ViewChild('modelAuthorizeTicket', { static: true }) modelAuthorizeTicket: any;

    constructor(
        private activatedRoute: ActivatedRoute,
        private utilsService: UtilsService,
        private commonMbsService: CommonMbsService,
        private formBuilder: FormBuilder,
        private router: Router,
        private standardProcessService: StandardProcessService,
        private systemConfigurationService: SystemConfigurationService
    ) {
        this.activatedRoute.params.subscribe(datas => {
            if (
                datas["generatorCommonMbsId"] !== undefined &&
                datas["generatorCommonMbsId"] !== ""
            ) {
                this.generatorCommonMbsId = datas["generatorCommonMbsId"];
            }
        });
    }

    onTabEnabled = 0
    tabsList = [
        { title: 'Information' },
        { title: 'Repositories' }
    ];

    generatorCommonMbsId = null
    generatorCommonMbsFrom: FormGroup;
    action = ''
    submitted = false;
    templateOptions = []
    errorMessage = null
    get f() { return this.generatorCommonMbsFrom.controls; }

    public list_routines = {
        action : null,
        selected: [{ uuid: '', selected: false }],
        dataSource: [],
        displayFields: [
            {
                title: "'Name'",
                sort: "'name'",
                filter: "'name'",
                property: "name"
            },
            {
                title: "'Code'",
                sort: "'code'",
                filter: "'code'",
                property: "code"
            },
            {
                title: "'Dataset'",
                sort: "'dataset_name'",
                filter: "'dataset_name'",
                property: "dataset_name"
            },
            {
                title: "'UUID'",
                sort: "'uuid'",
                filter: "'uuid'",
                property: "uuid"
            },
            {
                title: "'Generating Tag'",
                property: "generating_tag"
            },
            {
                title: "'Latest Build No'",
                property: "latest_build_no"
            }
        ]
    };

    mergeOptions = [
        {
            label: 'View Configuration',
            value: 'Adjust'
        },
        {
            label: 'Regenerate Configuration',
            value: 'Regenerate'
        },
        {
            label: 'Purge Configuration',
            value: 'Purge'
        },
    ]

    mergeListOptions = [
        {
            label: 'Regenerate Configuration',
            value: 'Regenerate'
        },
        {
            label: 'Purge Configuration',
            value: 'Purge'
        },
    ]

    commonOptions = []
    commonListOptions = []
    subStateOptions = []
    isSubstate: any
    showActions = false
    authorized_ticket = ''

    ngOnInit(): void {
        this.getSubstateList()
        this.getTemplateList()
    }


    converObj(item) {
        let datasets = []
        item.forEach(element => {
            datasets.push({ title: element })
        });
        return datasets;
    }


    getTemplateList() {
        this.standardProcessService.getstd_mapping().then((response: any) => {
            if (response.meta.response_code == 10000) {
                response.data.forEach(element => {
                    this.templateOptions.push({
                        label: element.code + ' - ' + element.name,
                        value: element.id
                    })
                });
                if (this.generatorCommonMbsId == 'create') {
                    this.createFormGroup()
                } else {
                    this.callLot_by_id()
                    this.callList_routine_by_lot()
                }
            } else {
                this.utilsService.errorDialogPopup(response.meta.response_desc, { response: response });
            }
        })
    }

    callLot_by_id() {
        this.commonMbsService.getLot_by_id(this.generatorCommonMbsId).then((response: any) => {
            if (response.meta.response_code == 10000) {
                this.createFormGroup(response.data)
            } else {
                this.utilsService.errorDialogPopup(response.meta.response_desc, { response: response, redirect: { back: 2 } });
            }
        })
    }

    callList_routine_by_lot() {
        this.commonMbsService.list_routine_by_lot({ "lot_id": this.generatorCommonMbsId }).then((response: any) => {
            if (response.meta.response_code == 10000) {
                this.list_routines.dataSource = response.data
                this.showActions = false
            } else {
                this.utilsService.errorDialogPopup(response.meta.response_desc, { response: response, redirect: { back: 2 } });
            }
        })
    }


    createFormGroup(item?) {
        this.action = item ? item.id : 'create'
        this.generatorCommonMbsFrom = this.formBuilder.group({
            name: [item ? item.name : '', Validators.required],
            id: [item ? item.id : ''],
            description: [item ? item.description : ''],
            datasets: [item ? this.converObj(item.datasets) : null],
            standard_process_ids: [item ? item.standard_process_ids : ''],
            action: ['']
        });
    }


    btnBack() {
        this._backListGeneratorCommonMbs()
    }

    _backListGeneratorCommonMbs(): void {
        const params = this.activatedRoute.snapshot.params;
        let urls = this.router.url.split('/');
        urls.splice(-2);
        this.router.navigate([urls.join('/'), 'list']);
    };

    btnGenerate() {
        this.commonMbsService.generate_configuration({ "lot_id": this.generatorCommonMbsId }).then((response: any) => {
            if (response.meta.response_code == 10000) {
                this.utilsService.successDialogPopup({ title: Constant.msgDisplayConsoleOutputId, text: Constant.consoleOutputId + response.data.console_output_id });
                this.callList_routine_by_lot()
            } else {
                this.utilsService.errorDialogPopup(response.meta.response_desc, { response: response });
            }
        })
    }

    btnAdjust(item) {
        let urls = this.router.url.split('/');
        urls.splice(-3);
        this.router.navigate([urls.join('/'), 'adjust', item[0]]);
    }

    btnRegenerate(uuid) {

        this.commonMbsService.generator_regenerate_configuration({ "lot_id": this.generatorCommonMbsId, "uuids": uuid }).then((response: any) => {
            if (response.meta.response_code == 10000) {
                this.utilsService.successDialogPopup({ title: Constant.msgDisplayConsoleOutputId, text: Constant.consoleOutputId + response.data.console_output_id });
                this.callList_routine_by_lot()
            } else {
                this.utilsService.errorDialogPopup(response.meta.response_desc, { response: response });
            }
        })
    }

    btnBuild(uuid, authorized_ticket) {
        this.commonMbsService.build_and_publish({ "lot_id": this.generatorCommonMbsId, "uuids": uuid, authorized_ticket: authorized_ticket }).then((response: any) => {
            if (response.meta.response_code == 10000) {
                this.utilsService.successDialogPopup({ title: Constant.msgDisplayConsoleOutputId, text: Constant.consoleOutputId + response.data.console_output_id });
                this.callList_routine_by_lot()
            } else {
                this.utilsService.errorDialogPopup(response.meta.response_desc, { response: response });
            }
        })
    }

    btnPurge(uuid) {
        this.commonMbsService.generator_purge({ "lot_id": this.generatorCommonMbsId, "uuids": uuid }).then((response: any) => {
            if (response.meta.response_code == 10000) {
                this.utilsService.successDialogPopup({ title: Constant.msgDisplayConsoleOutputId, text: Constant.consoleOutputId + response.data.console_output_id });
                this.callList_routine_by_lot()
            } else {
                this.utilsService.errorDialogPopup(response.meta.response_desc, { response: response });
            }
        })
    }

    onSelect(event, item) {
        let listCheck = []
        this.authorized_ticket = ''
        if (item == 'list') {
            this.list_routines.dataSource.forEach(element => {
                if (element.selected) {
                    listCheck.push(element.uuid)
                }
            });
        } else {
            listCheck.push(item.uuid)
        }
        switch (event) {
            case 'Adjust':
                this.btnAdjust(listCheck)
                break;
            case 'Regenerate':
                this.btnRegenerate(listCheck)
                break;
            case 'Purge':
                this.btnPurge(listCheck)
                break;
            default:
                if (this.isSubstate.need_authorized_ticket) {
                    this._openElementConfigurationForm(listCheck)
                } else {
                    this.btnBuild(listCheck, undefined)
                }
                break;
        }
    }

    onChecked(event, item) {
        this.showActions = this.list_routines.dataSource.some((item) => item.selected == true)
    }

    getSubstateList() {
        this.commonOptions = []
        this.commonListOptions = []
        let newSub = {}
        this.systemConfigurationService._getOneSystemConfigurationSubStateToPromise().then((response: any) => {
            if (response.meta.response_code == 10000) {
                response.data.forEach(element => {
                    this.subStateOptions.push({
                        label: element.name,
                        value: element.id
                    })
                    if (element.is_default) {
                        this.isSubstate = element
                        newSub = {
                            label: 'Build & Publish to ' + element.name,
                            value: element.id
                        }
                    }
                });
            }
            else {
                this.utilsService.errorDialogPopup(response.meta.response_desc, { response: response });
            }
            this.commonOptions = [...this.mergeOptions, newSub]
            this.commonListOptions = [...this.mergeListOptions, newSub]
        })
    }

    _openElementConfigurationForm(listCheck?: any): void {
        const modalInstance = this.modelAuthorizeTicket.show();
        modalInstance.closed.then(result => {
            if (!!result && result.isConfirm) {
                this.btnBuild(listCheck, this.authorized_ticket)
            }
        });
    };

    _closeElementConfigurationForm(result: any): void {
        this.modelAuthorizeTicket.hide(result);
    };

    btnConfirmElementConfigurationForm(): void {
        this._closeElementConfigurationForm({
            isConfirm: true
        });
    };

    btnNodeGeneratorCommon() {
        this._gotoNodeGeneratorCommon()
    }

    _gotoNodeGeneratorCommon(): void {
        let urls = this.router.url.split('/');
        urls.pop();
        this.router.navigate([urls.join('/'), 'repository']);
    };

    public async dialogPopupConfirm(event : any, item : any, commonOptions : Array<any>) : Promise<void> {
        let text = ''
        if (event) {
            commonOptions.forEach(element => {
                if (event == element.value) {
                    text = element.label.toLowerCase()
                }
            });
            let listCheck = ''
            if (item == 'list') {
                listCheck = this.list_routines.dataSource.filter(element => element.selected).map(element => element.code).join(" , ");
            } else {
                listCheck = item.code
            }
            const isConfirm = await this.utilsService.confirmDialogPopup('Do you want to ' + text + ' ?', 'Code: ' + listCheck);
            if (isConfirm) {
                this.onSelect(event, item)
            }

            if(typeof(item) == "object" && item){
                item.action = null;
            }
            else if(item == 'list') {
                this.list_routines.action = null;
            }
        }
    };
}


