import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NodeRepositoryComponent } from './node-repository.component';

describe('NodeRepositoryComponent', () => {
  let component: NodeRepositoryComponent;
  let fixture: ComponentFixture<NodeRepositoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NodeRepositoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NodeRepositoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
