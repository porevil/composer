import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { CommonMbsService, UtilsService } from 'src/app/core/services';
import { Router } from '@angular/router';

@Component({
  selector: 'composer-list-generator-common-mbs',
  templateUrl: './list-generator-common-mbs.component.html',
  styleUrls: ['./list-generator-common-mbs.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ListGeneratorCommonMbsComponent implements OnInit {

  constructor(
    private commonMbsService: CommonMbsService,
    private utilsService: UtilsService,
    private router: Router
  ) {
    this.getGeneratorCommon_list()
  }

  public list_generator_common_mbs = {
    dataSource: [],
    displayFields: [
      {
        title: "'Name'",
        sort: "'name'",
        filter: "'name'",
        property: "name"
      },
      {
        title: "'Description'",
        sort: "'description'",
        property: "description"
      }
    ]
  };


  ngOnInit(): void {

  }

  getGeneratorCommon_list() {
    this.commonMbsService.getLot().then((response: any) => {
      if (response.meta.response_code == 10000) {
        this.list_generator_common_mbs.dataSource = response.data
      }
      else {
        this.utilsService.errorDialogPopup(response.meta.response_desc, { response: response });
      }
    })
  }


  deleteItem(id) {
    this.commonMbsService.deleteLot(id).then((response: any) => {
      if (response.meta.response_code == 10000) {
        this.list_generator_common_mbs.dataSource = response.data
        this.getGeneratorCommon_list()
        this.utilsService.successDialogPopup();
      } else {
        this.utilsService.errorDialogPopup(response.meta.response_desc, { response: response });
      }
    })
  }

  async dialogPopupConfirm(id) {
    const isConfirm = await this.utilsService.deleteDialogPopup();
    if (isConfirm) {
      this.deleteItem(id);
    }
  }


  btnCreateGeneratorCommon(): void {
    this._gotoGeneratorCommon('create')
  };

  btnEditGeneratorCommon(item): void {
    this._gotoGeneratorCommon(item.id)
  };

  btnNodeGeneratorCommon(item) {
    this._gotoNodeGeneratorCommon(item.id)
  }

  _gotoGeneratorCommon(groupCommonMbsId: any): void {
    let urls = this.router.url.split('/');
    urls.pop();
    this.router.navigate([urls.join('/'), groupCommonMbsId, 'configuration']);
  };

  _gotoNodeGeneratorCommon(groupCommonMbsId: any): void {
    let urls = this.router.url.split('/');
    urls.pop();
    this.router.navigate([urls.join('/'), groupCommonMbsId, 'repository']);
  };

}
