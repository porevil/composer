import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListGeneratorCommonMbsComponent } from './list-generator-common-mbs.component';

describe('ListGeneratorCommonMbsComponent', () => {
  let component: ListGeneratorCommonMbsComponent;
  let fixture: ComponentFixture<ListGeneratorCommonMbsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListGeneratorCommonMbsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListGeneratorCommonMbsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
