import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommonMbsComponent } from './common-mbs.component';


const routes: Routes = [
  {
    path: '',
    component: CommonMbsComponent,
    children: [
      {
        path: '',
        pathMatch: "full",
        redirectTo: "list"
      },
      {
        path: 'group',
        loadChildren: () => import('./group/group.module')
          .then(mod => mod.GroupModule)
      },
      {
        path: 'repositorie',
        loadChildren: () => import('./repository/repository.module')
          .then(mod => mod.RepositoryModule)
      },
      {
        path: 'catalog',
        loadChildren: () => import('./catalog/catalog.module')
          .then(mod => mod.CatalogModule)
      },
      {
        path: 'generator',
        loadChildren: () => import('./generator/generator.module')
          .then(mod => mod.GeneratorModule)
      },
      {
        path: 'adjust',
        loadChildren: () => import('./adjust/adjust.module')
          .then(mod => mod.AdjustModule)
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CommonMbsRoutingModule { }
