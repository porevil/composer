import { Component, OnInit, Input, ViewChild, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonMbsService, UtilsService } from 'src/app/core/services';

@Component({
  selector: 'composer-common-mbs-adjust-form',
  templateUrl: './adjust.component.html',
  styleUrls: ['./adjust.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AdjustComponent implements OnInit {

  @Input() uuid;
  @ViewChild('modelAdjustDetail', { static: true }) modelAdjustDetail: any;
  @ViewChild('modelAdjustAttribute', { static: true }) modelAdjustAttribute: any;

  constructor(
    private commonMbsService: CommonMbsService,
    private utilsService: UtilsService,
    private activatedRoute: ActivatedRoute) {
    this.activatedRoute.params.subscribe(datas => {
      if (
        datas["uuid"] !== undefined &&
        datas["uuid"] !== ""
      ) {
        this.uuid = datas["uuid"];
      }
    });
    if(this.uuid){
      this.getDetail()
    }
  }

  adjustCommonMbsFrom = null

  tabsList = []
  onTabEnabled = 0
  modalTabsList = [
    {title: "Information"},
    {title: "Attribute"}
  ]
  onModalTabEnabled = 1;
  modalDetail = null
  modalName = ''
  public sections = {
    dataSource: [],
    displayFields: [
      {
        title: "'On'",
        property: "enable"
      },
      {
        title: "'Field'",
        filter: "'field_name'",
        property: "field_name"
      },
      {
        title: "'Label Thai'",
        filter: "'caption_th'",
        property: "caption_th"
      },
      {
        title: "'Mandatory'",
        property: "mandatory"
      },
      {
        title: "'Widget type'",
        filter: "'component_name'",
        property: "component_name"
      }
    ]
  };

  ngOnInit(): void {
  }

  getDetail(){
    this.commonMbsService.get_adjust_configuration_by_uuid(this.uuid).then((response: any) => {
      if (response.meta.response_code == 10000) {
        this.adjustCommonMbsFrom = response.data
        this.adjustCommonMbsFrom.activities.forEach(element => {
          this.tabsList.push({ title: element.name })
        });
      } else {
        this.utilsService.errorDialogPopup(response.meta.response_desc, { response: response, redirect: { back: 3 } });
      }
    })
  }

  getFieldDetail(item) {
    this.modalDetail = item
    let f_name = item.field_name || ''
    let caption_th = item.caption_th || ''
    this.modalName = f_name && caption_th ? f_name+" : "+caption_th : f_name? f_name : caption_th? caption_th: 'Detail'
    this._openElementAdjustDetailForm()
  }

  // getFieldAttribute(item) {
  //   this.modalDetail = item
  //   this.modalName = 'Attribute ( ' + item.field_name + ' : ' + item.caption_th + ' )'
  //   this._openElementAdjustAttributeForm()
  // }

  // _openElementAdjustAttributeForm(): void {
  //   const modalInstance = this.modelAdjustAttribute.show();
  // };

  // _closeElementAdjustAttributeForm(): void {
  //   this.modelAdjustAttribute.hide();
  // };

  // btnConfirmAdjustAttributeForm(): void {
  //   this._closeElementAdjustAttributeForm();
  // };

  _openElementAdjustDetailForm(): void {
    
    const modalInstance = this.modelAdjustDetail.show();
    modalInstance.opened.then(() =>{
      this.onModalTabEnabled = 0
    })
    // modalInstance.closed.then(() =>{
    //   this.onModalTabEnabled = -1
    // })
  };

  _closeElementAdjustDetailForm(): void {
    this.onModalTabEnabled = 0
    this.modelAdjustDetail.hide();
  };

  btnConfirmAdjustDetailForm(): void {
    this._closeElementAdjustDetailForm();
  };
}
