import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppCodeComponent } from './app-code.component';
import { AuthenGuard } from '../core/guard/authen.guard';
import { AuthenticateComponent } from '../authenticate/authenticate.component';


const routes: Routes = [
  { path: "", pathMatch: 'full', redirectTo: 'pages' },
  {
    path: "",
    component: AppCodeComponent,
    children: [
      {
        path: 'pages', loadChildren: () => import('../pages/pages.module').then(m => m.PagesModule),
        canActivate: [AuthenGuard],
      },
      { path: 'authen', component:AuthenticateComponent, pathMatch: "full"  },
      { path: "verifycode", component: AuthenticateComponent, pathMatch: "full" },
      { path: "authen-okta/:verify", component: AuthenticateComponent, pathMatch: "full" },
      { path: "verifycode/:verification_code", component: AuthenticateComponent, pathMatch: "full" },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AppCodeRoutingModule { }
