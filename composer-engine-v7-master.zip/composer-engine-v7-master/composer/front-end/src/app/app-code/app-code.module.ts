import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AppCodeRoutingModule } from './app-code-routing.module';
import { AppCodeComponent } from './app-code.component';
import { AuthenticateComponent } from '../authenticate/authenticate.component';


@NgModule({
  declarations: [AppCodeComponent,AuthenticateComponent],
  imports: [
    CommonModule,
    AppCodeRoutingModule
  ]
})
export class AppCodeModule { }
