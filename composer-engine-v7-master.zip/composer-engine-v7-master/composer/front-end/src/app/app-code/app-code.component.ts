import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Store } from '@ngrx/store';
import * as fromRoot from 'src/app/store/reducers/index';
import * as fromActions from 'src/app/store/actions/authen.actions';
import { State } from '../store/reducers/authen/authen.reducer';


@Component({
  selector: 'composer-app-code',
  templateUrl: './app-code.component.html',
  styleUrls: ['./app-code.component.scss']
})
export class AppCodeComponent implements OnInit {

  constructor(
    private _activatedRoute: ActivatedRoute,
    private store: Store<State>
  ) {
    // this._activatedRoute.params.subscribe(datas => {
      // this.store.dispatch(new fromActions.SetAppCodeInStore({ app_code: datas["code"] }));/
    // });
  }

  ngOnInit() {
  }

}
