import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { environment } from '../environments/environment';

import { StoreModule, ActionReducer } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { storeLogger } from 'ngrx-store-logger';
import { State } from './store/reducers';
import * as state from './store/reducers/index';

import { VirtualDatasetSettingEffects } from './store/effect/virtual-dataset-setting/virtual-dataset-setting.effects';
import { DatasetSettingEffects } from './store/effect/dataset-setting/dataset-setting.effects';
import { DatafieldSettingEffects } from './store/effect/datafield-setting/datafield-setting.effects';
import { AuthenEffects } from './store/effect/authen/authen.effects';
import { SystemConfigurationEffects } from './store/effect/system-configuration/system-configuration.effects';
import { ServiceMbsEffects } from './store/effect/service-mbs/service-mbs.effects';
import { CombinedMbsEffects } from './store/effect/combined-mbs/combined-mbs.effects';
import { MenuEffects } from './store/effect/menu/menu.effects';
import { CustomMbsEffects } from './store/effect/custom-mbs/custom-mbs.effects';
import { FlowEffects } from './store/effect/flow/flow.effects';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { CoreModule } from './core/core.module';
import { interceptorProviders } from './core/interceptor/interceptors';
import { SharedModule } from './shared/shared.module';

import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';

import { DragDropModule } from '@angular/cdk/drag-drop';

import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { NgxSpinnerModule } from 'ngx-spinner';
import { ReactiveFormsModule } from '@angular/forms';
import { ErrorPageComponent } from './error-page/error-page.component';

export function logger(reducer: ActionReducer<State>): any {
    // default, no options
    return storeLogger()(reducer);
}

export const metaReducers = environment.production ? [] : [logger];

const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
    suppressScrollX: true
};

@NgModule({
    declarations: [
        AppComponent,
        ErrorPageComponent,
        // AuthenticateComponent,
    ],
    imports: [
        BrowserModule,
        BrowserAnimationsModule,
        CoreModule,
        AppRoutingModule,
        StoreModule.forRoot([]),
        EffectsModule.forRoot([]),
        EffectsModule.forFeature([
            VirtualDatasetSettingEffects, DatasetSettingEffects, DatafieldSettingEffects,
            AuthenEffects, MenuEffects, SystemConfigurationEffects, ServiceMbsEffects,
            CombinedMbsEffects, CustomMbsEffects, FlowEffects
        ]),
        StoreModule.forFeature(state.stateFeatureKey, state.reducers, { metaReducers }),
        !environment.production ? StoreDevtoolsModule.instrument() : [],
        BsDropdownModule.forRoot(),
        PerfectScrollbarModule,
        SharedModule,
        DragDropModule,
        NgxSpinnerModule,
        ReactiveFormsModule,
    ],
    providers: [
        {
            provide: PERFECT_SCROLLBAR_CONFIG,
            useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
        },
        ...interceptorProviders
    ],
    bootstrap: [AppComponent],
    schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class AppModule { }
