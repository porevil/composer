import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ErrorPageComponent } from './error-page/error-page.component';
import { AuthenticateComponent } from './authenticate/authenticate.component';
import { AuthenGuard } from './core/guard/authen.guard';


const routes: Routes = [
    {
        path: '',
        redirectTo: 'error',
        pathMatch: "full"
    },
    {
        path: 'application/:code',
        // canActivate: [AuthenGuard],
        loadChildren: () => import('./app-code/app-code.module').then(mod => mod.AppCodeModule)
    },
    { 
        path: 'error', 
        component: ErrorPageComponent 
    },
    { 
        path: '**', 
        redirectTo: "error", 
        pathMatch: "full" 
    }
];


@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }
