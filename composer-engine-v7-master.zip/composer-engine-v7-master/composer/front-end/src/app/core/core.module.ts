import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';

import {
    VirtualDatasetSettingService, DatasetSettingService, 
    DatafieldSettingService, UtilsService, 
    AuthorityService, AuthenticateService, SystemConfigurationService,
    LogService, StandardProcessService, CommonMbsService, ServiceRepositoryService,
    ApplicationService, DashboardService, ServiceMbsService, CombinedMbsService, FlowsService,
    ProcedureService
} from './services';

import { CookieService } from 'ngx-cookie-service';
import { from } from 'rxjs';

const services = [
    VirtualDatasetSettingService, DatasetSettingService, 
    DatafieldSettingService,UtilsService,AuthorityService,
    AuthenticateService, SystemConfigurationService, CookieService , LogService,
    StandardProcessService, CommonMbsService, ServiceRepositoryService,
    ApplicationService, DashboardService, ServiceMbsService, CombinedMbsService, FlowsService,
    ProcedureService
];

@NgModule({
    declarations: [],
    imports: [
        CommonModule,
        HttpClientModule
    ],
    providers: [
        ...services
    ]
})
export class CoreModule { }
