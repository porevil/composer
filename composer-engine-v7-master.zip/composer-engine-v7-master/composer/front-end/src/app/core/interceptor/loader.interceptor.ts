import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpEvent } from '@angular/common/http';
import { HttpHandler } from '@angular/common/http';
import { HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';
import { finalize } from 'rxjs/operators';
import { NgxSpinnerService } from "ngx-spinner";

@Injectable({
    providedIn: 'root'
})
export class LoaderInterceptor implements HttpInterceptor {

    constructor(
        private spinner: NgxSpinnerService
    ) {}

    public requestCounter = 0;
    private offTimeout = null;



    private setActivedAppLoader(actived: boolean): void {
        if(this.offTimeout != null){
            clearTimeout(this.offTimeout);
        }
        this.offTimeout = setTimeout(()=>{
            if(actived){
                this.spinner.show();
            }
            else {
                this.spinner.hide();
            }
        },100);
    };

    private beginRequest(): void {
        this.requestCounter = Math.max(this.requestCounter, 0) + 1;
        if (this.requestCounter === 1) {
            this.setActivedAppLoader(true);
        }
    };

    private endRequest(): void {
        this.requestCounter = Math.max(this.requestCounter, 1) - 1;
        if (this.requestCounter === 0) {
            this.setActivedAppLoader(false);
        }
    };

    intercept(
        request: HttpRequest<any>,
        next: HttpHandler
    ): Observable<HttpEvent<any>> {
        this.beginRequest();
        return next.handle(request).pipe(
            finalize(() => {
                this.endRequest();
            })
        );
    };

}