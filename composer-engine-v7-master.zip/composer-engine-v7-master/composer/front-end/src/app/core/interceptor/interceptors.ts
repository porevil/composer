import { ErrorHandler } from '@angular/core';
import { HTTP_INTERCEPTORS } from '@angular/common/http';

import { AuthenInterceptor } from './authen.interceptor';
import { LoaderInterceptor } from './loader.interceptor';
import { ErrorHandlerInterceptor } from './error-handler.interceptor';

export const interceptorProviders = [
    { provide: HTTP_INTERCEPTORS, useClass: AuthenInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: LoaderInterceptor, multi: true },
    { provide: ErrorHandler, useClass: ErrorHandlerInterceptor }
];