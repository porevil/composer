import { Injectable, ErrorHandler } from '@angular/core';
import { Observable, of } from 'rxjs';
import { tap } from 'rxjs/operators';
import { LogService, AuthenticateService } from '../services';
// import { LoggerService } from '../services/logger/logger.service';

@Injectable()
export class ErrorHandlerInterceptor extends ErrorHandler {

    constructor(
        private logService: LogService,
        private authenticateService : AuthenticateService
    ) {
        super();
    };

    handleError(error) {
        const message = [];
        const path = /(?<path>pages.*)/g.exec(window.location.pathname)?.groups?.path || null;        
        const username = this.authenticateService.getUserInfo()?.username || null;
        const stack = error.stack;        
        if(path){
            message.push(`Error path : ${path}`);
        }
        if(username){
            message.push(`Email : ${username}`);
        }
        message.push(stack);
        if(typeof(error && error.message) != "string" || !(error && error.message.match(/\$NOT_SEND/g))){
            try { console.error(message.join('\n')) } catch(ex) {};
            this.logService.client_logger({
                "type" : "error",
                "message" : message.join('\n')
            });
        }
    }
}