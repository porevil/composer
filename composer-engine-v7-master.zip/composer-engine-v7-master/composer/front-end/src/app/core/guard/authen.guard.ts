import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';
import { State } from 'src/app/store/reducers';
import * as fromMenuAction from '../../store/actions/menu.actions';
import * as fromAuthenActions from '../../store/actions/authen.actions'
import { AuthenticateService } from '../services';


@Injectable({
    providedIn: 'root'
})
export class AuthenGuard implements CanActivate {

    constructor(
        private router: Router,
        private store: Store<State>,
        private authenticateService: AuthenticateService
    ) {
        this._constructorComponent();
    };

    private appCode = null;

    canActivate(
        next: ActivatedRouteSnapshot,
        state: RouterStateSnapshot
    ):
        | Observable<boolean | UrlTree>
        | Promise<boolean | UrlTree>
        | boolean
        | UrlTree {
        return this._canActivate();
    };

    private _constructorComponent() : void {
        this.appCode = this.authenticateService.getAppCode(true);
    };

    private _canActivate() : boolean {
        const validCookie = this.authenticateService.validCookie("id_token");
        if (validCookie) {
            this.store.dispatch(fromMenuAction.loadMenus());
            this.store.dispatch(fromAuthenActions.getEnvironmentVariable())
            return true;
        } else {
            this.router.navigate(["application",this.appCode,"authen"]);
            return false;
        }
    };

    

}
