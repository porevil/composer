import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ConsoleOutputService {

  constructor(private http: HttpClient) { }

  getConsoleOutput(search_input) {
    let id = search_input.id ? `&id=${search_input.id}` : ''
    let authorized_ticket = search_input.authorized_ticket ? `&authorized_ticket=${search_input.authorized_ticket}`: ''
    let executed_by = search_input.executed_by ? `&executed_by__icontains=${search_input.executed_by}` : ''
    let start_datetime = search_input.start_datetime ? new Date(search_input.start_datetime).toISOString(): ''
    let end_datetime = search_input.end_datetime ? new Date(search_input.end_datetime).toISOString(): ''

    start_datetime = start_datetime ? `&start_datetime__gte=${start_datetime}`: ''
    end_datetime = end_datetime ? `&end_datetime__lte=${end_datetime}`: ''

    let str_path = id + executed_by + authorized_ticket + start_datetime + end_datetime
    if(str_path!=''){
      str_path = '?'+str_path.substr(1,str_path.length)
    }

    return this.http.get(`api/console_output/${str_path}`).toPromise()
  }

  getConsoleOutputDetail(console_output_id) {
    return this.http.get(`api/console_output/${console_output_id}/`).toPromise()
  }

  removeConsoleOutputDetail(console_output_id) {
    return this.http.delete(`api/console_output/${console_output_id}/`).toPromise()
  }

}
