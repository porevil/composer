import { TestBed } from '@angular/core/testing';

import { CombinedMbsService } from './combined-mbs.service';

describe('CombinedMbsService', () => {
  let service: CombinedMbsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CombinedMbsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
