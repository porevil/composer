import { TestBed } from '@angular/core/testing';

import { CommonMbsService } from './common-mbs.service';

describe('CommonMbsService', () => {
  let service: CommonMbsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CommonMbsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
