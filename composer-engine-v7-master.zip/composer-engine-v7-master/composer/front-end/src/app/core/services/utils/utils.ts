export enum DialogPopupIcon {
    Question = 'question',
    Warning = 'warning',
    Success = 'success',
    Error = "error",
    Info = 'info'
};