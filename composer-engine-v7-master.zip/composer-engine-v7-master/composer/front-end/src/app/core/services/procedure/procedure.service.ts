import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class ProcedureService {

    constructor(
        private httpClient: HttpClient
    ) { }


    public getProcedures(subStateId: string, options?: {
        isSystemData?: boolean,
        procedure?: {
            code?: string,
            name?: string
        }
    }): Observable<any> {
        const queryParams = [`sub_state_id=${subStateId}`];
        queryParams.push(`system_data=${options?.isSystemData || 'False'}`);
        if (options?.procedure?.code?.trim().length > 0) {
            queryParams.push(`code__icontains=${options.procedure.code}`);
        }
        if (options?.procedure?.name?.trim().length > 0) {
            queryParams.push(`code__icontains=${options.procedure.name}`);
        }
        return this.httpClient.get(`api/launcher/procedure/?${queryParams.join('&')}`).pipe(
            tap((response: any) => {

            })
        );
    };

    public getFlows(substateId: any, flowCode: any) : Observable<any>{
        let queryParams = `?code__icontains=${flowCode}&sub_state_id=${substateId}`
        //&system_data=False
        return this.httpClient.get(`api/launcher/flow/${queryParams}`).pipe(
            tap((response: any) => {
            })
        );
        
    }

    public getProcedure(uuid : any, substateId: any) : Observable<any> {
        return this.httpClient.get(`api/launcher/procedure/${uuid}/?sub_state_id=${substateId}`).pipe(
            tap((response: any) => {

            })
        );
    };

    public deleteProcedure(uuid : any, substateId: any) : Observable<any> {
        return this.httpClient.delete(`api/launcher/procedure/${uuid}/?sub_state_id=${substateId}`).pipe(
            tap((response: any) => {

            })
        );
    };

    public setProcedure(procedure : any) : Observable<any> {
        return this.httpClient.post('api/launcher/procedure/', procedure).pipe(
            tap((response: any) => {

            })
        );
    };


}
