import { TestBed } from '@angular/core/testing';

import { DatafieldSettingService } from './datafield-setting.service';

describe('DatafieldSettingService', () => {
  let service: DatafieldSettingService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DatafieldSettingService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
