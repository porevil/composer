import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class DashboardService {

    constructor(
        private httpClient: HttpClient
    ) { }

    public getStatisticInstance() : Observable<any> {
        return this.httpClient.get('/api/statistic/instance/');
    }

    public getStatisticInstanceDeploymentResource() : Observable<any> {
        return this.httpClient.get('/api/statistic/instance_deployment_resource/');
    }

}
