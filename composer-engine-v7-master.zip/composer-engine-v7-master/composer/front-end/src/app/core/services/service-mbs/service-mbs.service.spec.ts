import { TestBed } from '@angular/core/testing';

import { ServiceMbsService } from './service-mbs.service';

describe('ServiceMbsService', () => {
  let service: ServiceMbsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ServiceMbsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
