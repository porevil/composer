import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AuthorityService {

  constructor(private http:HttpClient) { }

  //authorization_menu
  get_authorization_menu(){
    return this.http.get('api/authorization/menu/').toPromise()
  }

  get_authorization_menu_by_id(id){
    return this.http.get('api/authorization/menu/'+id+'/').toPromise()
  }

  delete_authorization_menu(id){
    return this.http.delete('api/authorization/menu/'+id+'/').toPromise()
  }

  create_authorization_menu(data){
    return this.http.post('api/authorization/menu/',data).toPromise()
  }

  update_authorization_menu(id,data){
    return this.http.put('api/authorization/menu/'+id+'/',data).toPromise()
  }

  //authorization_action
  get_authorization_action(){
    return this.http.get('api/authorization/action/').toPromise()
  }

  get_authorization_action_by_id(id){
    return this.http.get('api/authorization/action/'+id+'/').toPromise()
  }

  delete_authorization_action(id){
    return this.http.delete('api/authorization/action/'+id+'/').toPromise()
  }

  create_authorization_action(data){
    return this.http.post('api/authorization/action/',data).toPromise()
  }

  update_authorization_action(id,data){
    return this.http.put('api/authorization/action/'+id+'/',data).toPromise()
  }

  //authorization_user_profile
  get_authorization_user_profile(){
    return this.http.get('api/authorization/user_profile/').toPromise()
  }

  get_authorization_user_profile_by_id(id){
    return this.http.get('api/authorization/user_profile/'+id+'/').toPromise()
  }

  delete_authorization_user_profile(id){
    return this.http.delete('api/authorization/user_profile/'+id+'/').toPromise()
  }

  create_authorization_user_profile(data){
    return this.http.post('api/authorization/user_profile/',data).toPromise()
  }

  update_authorization_user_profile(id,data){
    return this.http.put('api/authorization/user_profile/'+id+'/',data).toPromise()
  }

  //authorization_profile_menu_mapping
  get_authorization_profile_menu_mapping(){
    return this.http.get('api/authorization/profile_menu_mapping/').toPromise()
  }

  get_authorization_profile_menu_mapping_by_id(id){
    return this.http.get('api/authorization/profile_menu_mapping/'+id+'/').toPromise()
  }

  delete_authorization_profile_menu_mapping(id){
    return this.http.delete('api/authorization/profile_menu_mapping/'+id+'/').toPromise()
  }

  create_authorization_profile_menu_mapping(data){
    return this.http.post('api/authorization/profile_menu_mapping/',data).toPromise()
  }

  update_authorization_profile_menu_mapping(data){
    return this.http.post('api/authorization/profile_menu_mapping/',data).toPromise()
  }

   //authorization_profile_action_mapping
  get_authorization_profile_action_mapping(){
    return this.http.get('api/authorization/profile_action_mapping/').toPromise()
  }

  get_authorization_profile_action_mapping_by_id(id){
    return this.http.get('api/authorization/profile_action_mapping/'+id+'/').toPromise()
  }

  delete_authorization_profile_action_mapping(id){
    return this.http.delete('api/authorization/profile_action_mapping/'+id+'/').toPromise()
  }

  create_authorization_profile_action_mapping(data){
    return this.http.post('api/authorization/profile_action_mapping/',data).toPromise()
  }

  update_authorization_profile_action_mapping(data){
    return this.http.post('api/authorization/profile_action_mapping/',data).toPromise()
  }

}
