import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { UtilsService } from '../utils/utils.service';


@Injectable({
  providedIn: 'root'
})
export class SystemConfigurationService {

  constructor(
    private httpClient: HttpClient,
    private utilsService: UtilsService
  ) { }

  /*========== State ==========*/

  public getSystemConfigurationStates(): any {
    return this.httpClient.get('api/configurations/state/').pipe(
      tap((resp: any) => { })
    );
  }

  public getOneSystemConfigurationState(stateId: any, config?: { redirect?: { back?: number, path: string } }): any {
    return this.httpClient.get(`api/configurations/state/${stateId}/`).pipe(
      tap((response: any) => {
        if (response.meta.response_code != 10000) {
          if (!!config && !!config.redirect && typeof (config.redirect.back) == "number" && config.redirect.back > 0) {
            this.utilsService.errorDialogPopup(response.meta.response_desc, {
              response: response,
              redirect: {
                back: config.redirect.back,
                path: config.redirect.path
              }
            });
          }
        }
       })
    );
  }

  public setState(stateBody: any): any {
    return this.httpClient.post('api/configurations/state/', stateBody).toPromise();
  }

  public updateState(stateId: any, stateBody: any): any {
    return this.httpClient.put(`api/configurations/state/${stateId}/`, stateBody).toPromise();
  }

  public deleteState(stateId: any): Observable<any> {
    return this.httpClient.delete(`api/configurations/state/${stateId}/`).pipe(
      tap((resp: any) => {

      })
    )
  }


  public _getSystemConfigurationStatesToPromise(): any {
    return this.httpClient.get('api/configurations/state/').toPromise()
  }


  /*========== Sub State ==========*/

  public getAllSystemConfigurationSubStates(): any {
    return this.httpClient.get('api/configurations/sub_state/').pipe(
      tap((resp: any) => {
      })
    );
  }

  public getOneSystemConfigurationSubState(subStateId: any, config?: { redirect?: { back?: number, path: string } }): any {
    return this.httpClient.get(`api/configurations/sub_state/${subStateId}/`).pipe(
      tap((response: any) => {
        if (response.meta.response_code != 10000) {
          if (!!config && !!config.redirect && typeof (config.redirect.back) == "number" && config.redirect.back > 0) {
            this.utilsService.errorDialogPopup(response.meta.response_desc, {
              response: response,
              redirect: {
                back: config.redirect.back,
                path: config.redirect.path
              }
            });
          }
        }
       })
    );
  }

  public setOneSystemConfigurationSubState(subStateBody: any): any {
    return this.httpClient.post('api/configurations/sub_state/', subStateBody).toPromise();
  }

  public updateOneSystemConfigurationSubState(subStateId: any, subStateBody: any): any {
    return this.httpClient.put(`api/configurations/sub_state/${subStateId}/`, subStateBody).toPromise();
  }

  public deleteOneSystemConfigurationSubState(subStateId: any): Observable<any> {
    return this.httpClient.delete(`api/configurations/sub_state/${subStateId}/`).pipe(
      tap((resp: any) => {

      })
    )
  }

  public _getOneSystemConfigurationSubStateToPromise(): any {
    return this.httpClient.get('api/configurations/sub_state/').toPromise()
  }


  /*========== Instance Environment Variable ==========*/

  public getAllSystemConfigurationInstanceEnvironmentVariables(): any {
    return this.httpClient.get('api/configurations/instance_environment_variable/').pipe(
      tap((resp: any) => {
      })
    );
  }

  public getOneSystemConfigurationInstanceEnvironmentVariable(insEnvVarId: any, config?: { redirect?: { back?: number, path: string } }): any {
    return this.httpClient.get(`api/configurations/instance_environment_variable/${insEnvVarId}/`).pipe(
      tap((response: any) => {
        if (response.meta.response_code != 10000) {
          if (!!config && !!config.redirect && typeof (config.redirect.back) == "number" && config.redirect.back > 0) {
            this.utilsService.errorDialogPopup(response.meta.response_desc, {
              response: response,
              redirect: {
                back: config.redirect.back,
                path: config.redirect.path
              }
            });
          }
        }
       })
    );
  }

  public setOneSystemConfigurationInstanceEnvironmentVariable(insEnvVarBody: any): any {
    return this.httpClient.post('api/configurations/instance_environment_variable/', insEnvVarBody).toPromise();
  }

  public updateOneSystemConfigurationInstanceEnvironmentVariable(insEnvVarId: any, insEnvVarBody: any): any {
    return this.httpClient.put(`api/configurations/instance_environment_variable/${insEnvVarId}/`, insEnvVarBody).toPromise();
  }

  public deleteOneSystemConfigurationInstanceEnvironmentVariable(insEnvVarId: any): Observable<any> {
    return this.httpClient.delete(`api/configurations/instance_environment_variable/${insEnvVarId}/`).pipe(
      tap((resp: any) => {

      })
    )
  }

  /*========== Instance Development Specification Variable ==========*/

  public getAllSCInsDevSpecs(): any {
    return this.httpClient.get('api/configurations/instance_deployment_specification/').pipe(
      tap((resp: any) => {
      })
    );
  }

  public getOneSCInsDevSpec(insDevSpecId: any, config?: { redirect?: { back?: number, path: string } }): any {
    return this.httpClient.get(`api/configurations/instance_deployment_specification/${insDevSpecId}/`).pipe(
      tap((response: any) => {
        if (response.meta.response_code != 10000) {
          if (!!config && !!config.redirect && typeof (config.redirect.back) == "number" && config.redirect.back > 0) {
            this.utilsService.errorDialogPopup(response.meta.response_desc, {
              response: response,
              redirect: {
                back: config.redirect.back,
                path: config.redirect.path
              }
            });
          }
        }
      })
    );
  }

  public setOneSCInsDevSpec(insDevSpecBody: any): any {
    return this.httpClient.post('api/configurations/instance_deployment_specification/', insDevSpecBody).toPromise();
  }

  public updateOneSCInsDevSpec(insDevSpecId: any, insDevSpecBody: any): any {
    return this.httpClient.put(`api/configurations/instance_deployment_specification/${insDevSpecId}/`, insDevSpecBody).toPromise();
  }

  public deleteOneSCInsDevSpec(insDevSpecId: any): Observable<any> {
    return this.httpClient.delete(`api/configurations/instance_deployment_specification/${insDevSpecId}/`).pipe(
      tap((resp: any) => {

      })
    )
  }

}
