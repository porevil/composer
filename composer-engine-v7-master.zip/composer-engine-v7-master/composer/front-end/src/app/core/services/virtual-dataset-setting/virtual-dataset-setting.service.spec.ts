import { TestBed } from '@angular/core/testing';

import { VirtualDatasetSettingService } from './virtual-dataset-setting.service';

describe('VirtualDatasetSettingService', () => {
  let service: VirtualDatasetSettingService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(VirtualDatasetSettingService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
