import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class StandardProcessService {

  constructor(private http:HttpClient) { }

  //standard_template
  getstd_templates(){
    return this.http.get('api/standard_process/standard_template/').toPromise()
  }

  getstd_templates_by_id(id){
    return this.http.get('api/standard_process/standard_template/'+id+'/').toPromise()
  }

  deletestd_templates(id){
    return this.http.delete('api/standard_process/standard_template/'+id+'/').toPromise()
  }

  createstd_templates(data){
    return this.http.post('api/standard_process/standard_template/',data).toPromise()
  }

  updatestd_templates(id,data){
    return this.http.put('api/standard_process/standard_template/'+id+'/',data).toPromise()
  }

  //component
  get_component(){
    return this.http.get('api/standard_process/component/').toPromise()
  }

  get_component_by_id(id){
    return this.http.get('api/standard_process/component/'+id+'/').toPromise()
  }

  delete_component(id){
    return this.http.delete('api/standard_process/component/'+id+'/').toPromise()
  }

  create_component(data){
    return this.http.post('api/standard_process/component/',data).toPromise()
  }

  update_component(id,data){
    return this.http.put('api/standard_process/component/'+id+'/',data).toPromise()
  }

  //standard-mapping
  getstd_mapping(){
    return this.http.get('api/standard_process/standard_mapping/').toPromise()
  }

  getstd_mapping_by_id(id){
    return this.http.get('api/standard_process/standard_mapping/'+id+'/').toPromise()
  }

  deletestd_mapping(id){
    return this.http.delete('api/standard_process/standard_mapping/'+id+'/').toPromise()
  }

  createstd_mapping(data){
    return this.http.post('api/standard_process/standard_mapping/',data).toPromise()
  }

  updatestd_mapping(id,data){
    return this.http.put('api/standard_process/standard_mapping/'+id+'/',data).toPromise()
  }

  //templates_rules
  get_templates_rules(){
    return this.http.get('api/standard_process/template_rules/').toPromise()
  }

  get_templates_rules_by_id(id){
    return this.http.get('api/standard_process/template_rules/'+id+'/').toPromise()
  }

  delete_templates_rules(id){
    return this.http.delete('api/standard_process/template_rules/'+id+'/').toPromise()
  }

  create_templates_rules(data){
    return this.http.post('api/standard_process/template_rules/',data).toPromise()
  }

  update_templates_rules(id,data){
    return this.http.put('api/standard_process/template_rules/'+id+'/',data).toPromise()
  }

}
