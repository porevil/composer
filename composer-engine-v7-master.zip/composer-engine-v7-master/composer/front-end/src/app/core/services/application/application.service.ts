import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class ApplicationService {

    constructor(
        private httpClient: HttpClient
    ) { }


    public getApplications(subStateId : string, options? : {
        isSystemData? : boolean,
        application? : {
            code? : string,
            name? : string
        }
    }) : Observable<any> {
        const queryParams = [`sub_state_id=${subStateId}`];
        // queryParams.push(`system_data=${options?.isSystemData || false}`);
        if(options?.application?.code?.trim().length > 0){
            queryParams.push(`code__icontains=${options.application.code}`);
        }
        if(options?.application?.name?.trim().length > 0){
            queryParams.push(`name__icontains=${options.application.name}`);
        }
        return this.httpClient.get(`api/launcher/application/?${queryParams.join('&')}`).pipe(
            tap((response: any) => {

            })
        );
    };

    public getApplication(subStateId : string, applicationCode : string) : Observable<any> {
        return this.httpClient.get(`api/launcher/application/${applicationCode}/?sub_state_id=${subStateId}`).pipe(
            tap((response: any) => {

            })
        );
    };

    public deleteApplication(subStateId : string, applicationCode : string, authorizedTicket: string) : Observable<any> {
        let request:any = {body: {authorized_ticket: authorizedTicket}}
        return this.httpClient.delete(`api/launcher/application/${applicationCode}/?sub_state_id=${subStateId}`, request).pipe(
            tap((response: any) => {

            })
        );
    };

    public setApplication(application : any) : Observable<any> {
        return this.httpClient.post('api/launcher/application/', application).pipe(
            tap((response: any) => {

            })
        );
    };


}
