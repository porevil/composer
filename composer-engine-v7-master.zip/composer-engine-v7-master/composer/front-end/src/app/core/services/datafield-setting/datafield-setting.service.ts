import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';
import { Observable } from 'rxjs';

import { UtilsService } from '../utils/utils.service';

@Injectable({
    providedIn: 'root'
})
export class DatafieldSettingService {

    constructor(
        private httpClient: HttpClient,
        private utilsService : UtilsService
    ) {

    }

    public getDatafields(): Observable<any> {
        return this.httpClient.get(`/api/generator_setting/datafields/`).pipe(
            tap((response: any) => {
                if(response.meta.response_code != 10000){
                    this.utilsService.errorDialogPopup(response.meta.response_desc,{
                        response : response,
                        redirect : {
                            enabled : true,
                            path : 'pages/dashboard'
                        }
                    });
                }
            })
        );
    };

    public setDatafield(datafield : any): Observable<any> {
        return this.httpClient.post(`/api/generator_setting/datafields/`, datafield).pipe(
            tap((response: any) => {

            })
        );
    };

    public deleteDatafield(datafieldId : any): Observable<any> {
        return this.httpClient.delete(`/api/generator_setting/datafields/delete/${datafieldId}/`).pipe(
            tap((response: any) => {

            })
        );
    };

    public getDatafield(datafieldName : string) : Observable<any> {
        return this.httpClient.get(`/api/generator_setting/datafields/${datafieldName}/`).pipe(
            tap((response: any) => {

            })
        );
    };


}
