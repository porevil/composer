import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';
import { Observable, of } from 'rxjs';

import { UtilsService } from '../utils/utils.service';

@Injectable({
  providedIn: 'root'
})
export class CustomMbsService {

  constructor(
    private httpClient: HttpClient,
    private utilsService: UtilsService
  ) { }

  public getAllCustomMBS(item): Observable<any> {
    const queryParams = [];
    if(item?.code?.trim().length > 0){
      queryParams.push(`code__icontains=${item.code}`)
    }
    if(item?.name?.trim().length > 0){
      queryParams.push(`name__icontains=${item.name}`)
    }
    if(item?.uuid?.trim().length > 0){
      queryParams.push(`uuid=${item.uuid}`)
    }
    if(item?.substate?.trim().length > 0){
      queryParams.push(`sub_state=${item.substate}`)
    }
    return this.httpClient.get(`api/custom_instance/configuration/?${queryParams.join('&')}`).pipe(
      tap((response: any) => { })
    )
  }

  public getCustomMBS(customMBSId: any, config?: { redirect?: { back?: number, path: string } }): Observable<any> {
    return this.httpClient.get(`api/custom_instance/configuration/${customMBSId}/`).pipe(
      tap((response: any) => {
        if (response.meta.response_code != 10000) {
          if (!!config && !!config.redirect && typeof (config.redirect.back) == "number" && config.redirect.back > 0) {
            this.utilsService.errorDialogPopup(response.meta.response_desc, {
              response: response,
              redirect: {
                back: config.redirect.back,
                path: config.redirect.path
              }
            });
          }
        }
      })
    )
  }

  public setConfigurationMBS(customMBS: any): Observable<any> {
    let request = null;
    if (customMBS.id) {
      request = this.httpClient.put(`api/custom_instance/configuration/${customMBS.id}/`, customMBS);
    }
    else {
      request = this.httpClient.post(`api/custom_instance/configuration/`, customMBS);
    }
    return request.pipe(
      tap((response: any) => {

      })
    );
  };

  public purgeCustomMBS(customMBS: any): Observable<any> {
    return this.httpClient.post(`api/custom_instance/executions/purge/`, customMBS).pipe(
      tap((response: any) => {

      })
    )
  }

  public getListRepoCustomMBS(item): Observable<any> {
    const mapQuery = {
      'code' : 'code__icontains',
      'name' : 'name__icontains',
      'uuid' : 'uuid',
      'substate' : 'sub_state_id'
    };
    const query = this.utilsService.uri.createQueryString(item,mapQuery);
    return this.httpClient.get(`api/custom_instance/repositories/${query}`).pipe(
      tap((response: any) => { })
    )
  }

  public removeRepoCustomMBS(customMBS: any): Observable<any> {
    return this.httpClient.post(`api/custom_instance/executions/remove/`, customMBS).pipe(
      tap((response: any) => {

      })
    )
  }

  public catalogBuildPublish(data): Observable<any>{
    return this.httpClient.post('api/custom_instance/executions/build_and_publish/', data).pipe(
      tap((response: any) => {

      })
    );
  }

  public repoRepublish(customMBS): Observable<any>{
    return this.httpClient.post(`api/custom_instance/executions/republish/`, customMBS).pipe(
      tap((response: any) => {

      })
    )
  }

  public repoMoveTo(customMBS): Observable<any>{
    return this.httpClient.post(`api/custom_instance/executions/move/`, customMBS).pipe(
      tap((response: any) => {

      })
    )
  }
}
