import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';
import { Observable, of } from 'rxjs';

import { UtilsService } from '../utils/utils.service';

@Injectable({
    providedIn: 'root'
})
export class CombinedMbsService {

    constructor(
        private httpClient: HttpClient,
        private utilsService : UtilsService
    ) { }

    public getConfigurationMBSes(options? : {
        combinedMBS? : {
            code? : string,
            name? : string,
            uuid? : string,
            baseMBS? : {
                code? : string,
                name? : string,
                datasetName? : string
            }
        }
    }) : Observable<any> {        
        const queryParams = [];
        if(options?.combinedMBS?.code?.trim().length > 0){
            queryParams.push(`code__icontains=${options.combinedMBS.code}`);
        }
        if(options?.combinedMBS?.name?.trim().length > 0){
            queryParams.push(`name__icontains=${options.combinedMBS.name}`);
        }
        if(options?.combinedMBS?.uuid?.trim().length > 0){
            queryParams.push(`uuid=${options.combinedMBS.uuid}`);
        }
        if(options?.combinedMBS?.baseMBS?.code?.trim().length > 0){
            queryParams.push(`base_instance_code__icontains=${options.combinedMBS.baseMBS.code}`);
        }
        if(options?.combinedMBS?.baseMBS?.name?.trim().length > 0){
            queryParams.push(`base_instance_name__icontains=${options.combinedMBS.baseMBS.name}`);
        }
        if(options?.combinedMBS?.baseMBS?.datasetName?.trim().length > 0){
            queryParams.push(`dataset_name__contains=${options.combinedMBS.baseMBS.datasetName}`);
        }
        return this.httpClient.get(`api/combined_instance/configuration/?${queryParams.join('&')}`).pipe(
            tap((response: any) => {

            })
        );
    };

    public getConfigurationMBS(combinedMBSId : string, config? : { redirect? : { back? : number } }) : Observable<any>{
        return this.httpClient.get(`api/combined_instance/configuration/${combinedMBSId}/`).pipe(
            tap((response: any) => {
                if(response.meta.response_code != 10000){
                    if(!!config && !!config.redirect && typeof(config.redirect.back) == "number" && config.redirect.back > 0){
                        this.utilsService.errorDialogPopup(response.meta.response_desc,{
                            response : response,
                            redirect : {
                                back : config.redirect.back
                            }
                        });
                    }
                }
            })
        );
    };

    public setConfigurationMBS(combinedMBS : any) : Observable<any>{
        let request = null;
        if(!!combinedMBS.id){
            request = this.httpClient.put(`api/combined_instance/configuration/${combinedMBS.id}/`,combinedMBS);
        }
        else {
            request = this.httpClient.post(`api/combined_instance/configuration/`,combinedMBS);
        }
        return request.pipe(
            tap((response: any) => {

            })
        );
    };

    public deleteConfigurationMBS(combinedMBSId : string) : Observable<any>{
        return this.httpClient.delete(`api/combined_instance/configuration/${combinedMBSId}/`).pipe(
            tap((response: any) => {

            })
        );
    };

    public buildConfigurationMBS(combinedMBSUUID : string) : Observable<any>{
        return this.httpClient.post(`api/combined_instance/build/`,{
            uuid : combinedMBSUUID
        }).pipe(
            tap((response: any) => {
   
            })
        );
    };

    public purgeConfigurationMBS(combinedMBSUUID : string) : Observable<any>{
        return this.httpClient.post(`api/combined_instance/purge/`,{
            uuid : combinedMBSUUID
        }).pipe(
            tap((response: any) => {
   
            })
        );
    };

    public getRepositoryMBSs(options? : {
        mbs? : {
            code? : string,
            name? : string,
            uuid? : string,
            baseMBS? : {
                uuid? : string
            }
        }
    }) : Observable<any>{
        const mapQuery = {
            'mbs.code' : 'code__icontains',
            'mbs.name' : 'name__icontains',
            'mbs.uuid' : 'uuid',
            'mbs.baseMBS.uuid' : 'base_instance_uuid'
        };
        const query = this.utilsService.uri.createQueryString(options,mapQuery);
        return this.httpClient.get(`api/combined_instance/repositories/${query}`).pipe(
            tap((response: any) => {

            })
        );
    };

}
