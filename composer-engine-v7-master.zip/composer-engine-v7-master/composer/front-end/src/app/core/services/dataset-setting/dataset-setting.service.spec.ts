import { TestBed } from '@angular/core/testing';

import { DatasetSettingService } from './dataset-setting.service';

describe('DatasetSettingService', () => {
  let service: DatasetSettingService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DatasetSettingService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
