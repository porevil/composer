import { TestBed } from '@angular/core/testing';

import { CustomMbsService } from './custom-mbs.service';

describe('CustomMbsService', () => {
  let service: CustomMbsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CustomMbsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
