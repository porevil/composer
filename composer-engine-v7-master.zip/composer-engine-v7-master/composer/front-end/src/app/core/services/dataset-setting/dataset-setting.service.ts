import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';
import { Observable } from 'rxjs';

import { UtilsService } from '../utils/utils.service';

@Injectable({
    providedIn: 'root'
})
export class DatasetSettingService {

    constructor(
        private httpClient: HttpClient,
        private utilsService : UtilsService
    ) {

    }

    public getDatasets() : Observable<any> {
        return this.httpClient.get(`/api/generator_setting/dataset/`).pipe(
            tap((response: any) => {
                if(response.meta.response_code != 10000){
                    this.utilsService.errorDialogPopup(response.meta.response_desc,{
                        response : response,
                        redirect : {
                            enabled : true,
                            path : 'pages/dashboard'
                        }
                    });
                }
            })
        );
    };

    public getDataset(datasetName : any, config? : { redirect? : { back? : number } }) : Observable<any> {
        return this.httpClient.get(`api/generator_setting/dataset/${datasetName}/`).pipe(
            tap((response: any) => {
                
                if(response.meta.response_code != 10000){
                    if(!!config && !!config.redirect && typeof(config.redirect.back) == "number" && config.redirect.back > 0){
                        this.utilsService.errorDialogPopup(response.meta.response_desc,{
                            response : response,
                            redirect : {
                                back : config.redirect.back
                            }
                        });
                    }
                }
            })
        );
    };

    public setDataset(dataset : any) : any {
        return this.httpClient.post('api/generator_setting/dataset/save/',dataset).toPromise();
    };

    public deleteDataset(datasetName : any) : Observable<any> {
        return this.httpClient.delete(`api/generator_setting/dataset/delete/${datasetName}/`).pipe(
            tap((response: any) => {

            })
        );
    };

    public refreshDataset(datasetName : any) : any {
        return this.httpClient.get(`api/generator_setting/refresh_dataset/${datasetName}/`).toPromise();
    };

}
