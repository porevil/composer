import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';
import { Observable, of } from 'rxjs';

import { UtilsService } from '../utils/utils.service';

@Injectable({
    providedIn: 'root'
})
export class ServiceMbsService {

    constructor(
        private httpClient: HttpClient,
        private utilsService : UtilsService
    ) { }

    public getServiceMBSs(options? : {
        mbs? : {
            code? : string,
            name? : string,
            uuid? : string,
            serviceType? : string,
            responseType? : string
        }
    }) : Observable<any> {     
        const mapQuery = {
            'mbs.code' : 'code__icontains',
            'mbs.name' : 'name__icontains',
            'mbs.uuid' : 'uuid',
            'mbs.serviceType' : 'service_type',
            'mbs.responseType' : 'response_type'
        };
        const query = this.utilsService.uri.createQueryString(options,mapQuery);
        return this.httpClient.get(`api/service_instance/${query}`).pipe(
            tap((response: any) => {

            })
        );
    };

    public getServiceMBS(serviceMBSId : string, config? : { redirect? : { back? : number } }) : Observable<any>{
        return this.httpClient.get(`api/service_instance/${serviceMBSId}/`).pipe(
            tap((response: any) => {
                if(response.meta.response_code != 10000){
                    if(!!config && !!config.redirect && typeof(config.redirect.back) == "number" && config.redirect.back > 0){
                        this.utilsService.errorDialogPopup(response.meta.response_desc,{
                            response : response,
                            redirect : {
                                back : config.redirect.back
                            }
                        });
                    }
                }
            })
        );
    };

    public setServiceMBS(serviceMBS : any) : Observable<any>{
        let request = null;
        if(!!serviceMBS.id){
            request = this.httpClient.put(`api/service_instance/${serviceMBS.id}/`,serviceMBS);
        }
        else {
            request = this.httpClient.post(`api/service_instance/`,serviceMBS);
        }
        return request.pipe(
            tap((response: any) => {

            })
        );
    };

    public deleteServiceMBS(serviceMBSId : string) : Observable<any>{
        return this.httpClient.delete(`api/service_instance/${serviceMBSId}/`).pipe(
            tap((response: any) => {

            })
        );
    };


}
