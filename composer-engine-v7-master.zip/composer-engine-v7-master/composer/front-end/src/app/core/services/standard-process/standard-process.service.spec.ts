import { TestBed } from '@angular/core/testing';

import { StandardProcessService } from './standard-process.service';

describe('StandardProcessService', () => {
  let service: StandardProcessService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(StandardProcessService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
