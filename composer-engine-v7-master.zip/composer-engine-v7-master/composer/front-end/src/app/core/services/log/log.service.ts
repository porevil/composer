import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class LogService {

  constructor(private http:HttpClient) { }

  client_logger(msg){
    return this.http.post('/api/client_logger/', msg).toPromise()
  }

}
