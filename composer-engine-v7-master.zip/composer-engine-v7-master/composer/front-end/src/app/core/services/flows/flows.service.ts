import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';
import { Observable } from 'rxjs';

import { UtilsService } from '../utils/utils.service';
@Injectable({
    providedIn: 'root'
})
export class FlowsService {

    constructor(
        private httpClient: HttpClient,
        private utilsService: UtilsService
    ) { }

    public getConfigurationFlows(search_input: any, system?: boolean) : Observable<any> {
        let code__icontains = search_input.code ? `&code__icontains=${search_input.code}` : ''
        let name__icontains = search_input.name ? `&name__icontains=${search_input.name}` : ''
        let uuid = search_input._uuid ? `&uuid=${search_input._uuid}` : ''
        let system_generated = '&system_generated=' + !!system
        let str_path = code__icontains + name__icontains + uuid + system_generated
        if (str_path != '') {
            str_path = '?' + str_path.substr(1, str_path.length)
        }
        return this.httpClient.get(`/api/flows/configuration/${str_path}`);
    };

    flows_catalog_by_id(id) {
        return this.httpClient.get(`/api/flows/configuration/${id}/`).toPromise()
    }

    public getConfigurationFlow(flowId: string, config?: { redirect?: { back?: number } }): Observable<any> {
        return this.httpClient.get(`/api/flows/configuration/${flowId}/`).pipe(
            tap((response: any) => {
                if (response.meta.response_code != 10000) {
                    if (!!config && !!config.redirect && typeof (config.redirect.back) == "number" && config.redirect.back > 0) {
                        this.utilsService.errorDialogPopup(response.meta.response_desc, {
                            response: response,
                            redirect: {
                                back: config.redirect.back
                            }
                        });
                    }
                }
            })
        );
    };

}
