import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ServiceRepositoryService {

  constructor(private http:HttpClient) { }

  //service_repository
  getservice_repository(state_id){
    return this.http.get(`api/service_repository/?state_id=${state_id}`).toPromise()
  }

  getservice_repository_by_id(state_id,id){
    return this.http.get('api/service_repository/'+id+`/?state_id=${state_id}`).toPromise()
  }

  deleteservice_repository(state_id,id){
    return this.http.delete('api/service_repository/'+id+`/?state_id=${state_id}`).toPromise()
  }

  createservice_repository(state_id,data){
    return this.http.post(`api/service_repository/?state_id=${state_id}`,data).toPromise()
  }

  updateservice_repository(state_id,id,data){
    return this.http.put('api/service_repository/'+id+`/?state_id=${state_id}`,data).toPromise()
  }

}
