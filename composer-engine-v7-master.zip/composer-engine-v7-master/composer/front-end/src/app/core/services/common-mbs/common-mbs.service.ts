import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { UtilsService } from '../utils/utils.service';

@Injectable({
    providedIn: 'root'
})
export class CommonMbsService {

    constructor(
        private http: HttpClient,
        private utilsService : UtilsService
    ) { }

    //lot
    getLot() {
        return this.http.get('api/common_mbs/generator/lot/').toPromise()
    }

    getLot_by_id(id) {
        return this.http.get('api/common_mbs/generator/lot/' + id + '/').toPromise()
    }

    deleteLot(id) {
        return this.http.delete('api/common_mbs/generator/lot/' + id + '/').toPromise()
    }

    createLot(data) {
        return this.http.post('api/common_mbs/generator/lot/', data).toPromise()
    }

    updateLot(id, data) {
        return this.http.put('api/common_mbs/generator/lot/' + id + '/', data).toPromise()
    }

    //list_routine_by_lot
    list_routine_by_lot(data) {
        return this.http.post('api/common_mbs/generator/list_routine_by_lot/', data).toPromise()
    }

    // list_node_repository_by_lot
    list_node_repository_by_lot(data) {
        return this.http.post('api/common_mbs/generator/list_node_repository_by_lot/', data).toPromise()
    }

    //get_activities_configuration
    get_activities_configuration(data) {
        return this.http.post('api/common_mbs/generator/get_activities_configuration/', data).toPromise()
    }

    // generate_configuration
    generate_configuration(data) {
        return this.http.post('api/common_mbs/generator/generate_configuration/', data).toPromise()
    }

    // build_and_publish
    build_and_publish(data) {
        return this.http.post('api/common_mbs/generator/build_and_publish/', data).toPromise()
    }

    // get_adjust_configuration_by_uuid
    get_adjust_configuration_by_uuid(uuid) {
        return this.http.get('api/common_mbs/generator/adjust_configuration/' + uuid + '/').toPromise()
    }

    adjust_configuration(data) {
        return this.http.post('api/common_mbs/generator/adjust_configuration/', data).toPromise()
    }

    // generator_move
    generator_move(data) {
        return this.http.post('api/common_mbs/generator/move/', data).toPromise()
    }

    // generator_purge
    generator_purge(data) {
        return this.http.post('api/common_mbs/generator/purge/', data).toPromise()
    }

    // generator_regenerate_configuration
    generator_regenerate_configuration(data) {
        return this.http.post('api/common_mbs/generator/regenerate_configuration/', data).toPromise()
    }

    // generator_remove
    generator_remove(data) {
        return this.http.post('api/common_mbs/generator/remove/', data).toPromise()
    }

    // generator_republish
    generator_republish(data) {
        return this.http.post('api/common_mbs/generator/republish/', data).toPromise()
    }

    // repositories_get_lot_by_node_repositories 
    repositories_get_lot_by_node_repositories(data) {
        return this.http.post('api/common_mbs/repositories/get_lot_by_node_repositories/', data).toPromise()
    }
    // repositories
    getRepositories(sub_state, search_input) {
        const mapQuery = {
            code : 'code__icontains',
            name : 'name__icontains',
            dataset : 'routine__dataset_name',
            _uuid : 'uuid',
            _type : 'generating_type',
            sub_state_id : 'sub_state_id',
            detail : 'detail'
        };
        const queryArgs = {...search_input,sub_state_id:sub_state?.id};
        const query = this.utilsService.uri.createQueryString(queryArgs,mapQuery);
        return this.http.get(`api/common_mbs/repositories/list_node_repository/${query}`);
    };
    // repositories_move
    repositories_move(data) {
        return this.http.post('api/common_mbs/repositories/move/', data).toPromise()
    }
    // repositories_remove 
    repositories_remove(data) {
        return this.http.post('api/common_mbs/repositories/remove/', data).toPromise()
    }
    // repositories_republish 
    repositories_republish(data) {
        return this.http.post('api/common_mbs/repositories/republish/', data).toPromise()
    }
    // catalog_purge
    catalog_purge(data) {
        return this.http.post('api/common_mbs/catalog/purge/', data).toPromise()
    }

    getCatalog(search_input) {
        let code__icontains = search_input.code ? `&code__icontains=${search_input.code}` : ''
        let name__icontains = search_input.name ? `&name__icontains=${search_input.name}` : ''
        let dataset_name = search_input.dataset ? `&dataset_name=${search_input.dataset}` : ''
        let uuid = search_input._uuid ? `&uuid=${search_input._uuid}` : ''
        let generating_type = search_input._type ? `&generating_type=${search_input._type}` : ''
        let str_path = code__icontains + name__icontains + dataset_name + uuid + generating_type
        if (str_path != '') {
            str_path = '?' + str_path.substr(1, str_path.length)
        }
        return this.http.get(`api/common_mbs/catalog/list_routine/${str_path}`).toPromise()
    }

    // catalog_get_lot_by_routine
    catalog_get_lot_by_routine(data) {
        return this.http.post('api/common_mbs/catalog/get_lot_by_routine/', data).toPromise()
    }

    // catalog_get_lot_by_routine
    catalog_build_and_publish(data) {
        return this.http.post('api/common_mbs/catalog/build_and_publish/', data).toPromise()
    }



}
