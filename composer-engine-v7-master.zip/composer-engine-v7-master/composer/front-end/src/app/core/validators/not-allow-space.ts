import { AbstractControl } from "@angular/forms"

export function ValidateNotAllowSpace(control: AbstractControl){
    if (control.value?.match(/\s/g)) {
        return { validNotAllowSpace: true}
    }
    return null;
}

export function ValidateNotAllowStartEndWithBlank(control: AbstractControl){
    if (control.value?.match(/^\s+|\s+$/g)){
        return { validNotAllowStartEndWithBlank: true}
    }
    return null;
}