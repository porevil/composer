import { AbstractControl } from "@angular/forms"

export function DatasetNameValidator(control: AbstractControl){
    if (!control.value?.match(/^[0-9_]*$/g)){
        return { validOnlyNumberAndUnderscore: true}
    }
    return null;
}