declare const cy: any;

describe('Test custom MBS ', () => {
    beforeEach(() => {
        cy.visit('http://localhost:1112/application/47/pages/dashboard')

        cy.wait(6000);

        cy.get('[menu-id=17]').click()
        cy.get('[sub-menu-id=54]').click()

        cy.wait(3000);

        cy.url().should('include', '/custom_mbs/catalog')

    })

    describe('[CREATE] CUSTOM MBS', () => {
        it('creates custom MBS successfully', () => {
            cy.get('[id=button_custom_mbs_list_create]').click()

            cy.wait(1000);

            inputValidation('[id=textbox_custom_mbs_form_code]', '1_101')
            inputValidation('[id=textbox_custom_mbs_form_name]', 'Cypress testing')
            inputValidation('[id=textbox_custom_mbs_form_version]', '1.0')
            inputValidation('[id=textbox_custom_mbs_form_git_repository]', 'http://git_repository:8080/application/47/')
            inputValidation('[id=textbox_custom_mbs_form_git_branch]', 'developer')
            inputValidation('[id=textbox_custom_mbs_form_commit_hash]', '#CypressTesting')
            inputValidation('[id=textbox_custom_mbs_form_requirement]', 'Cypress Testing')
            inputValidation('[id=textbox_custom_mbs_form_app_config_path]', '/application/configuration/path/')

            
            // cy.get('[id=textbox_custom_mbs_form_app_config_path]').type('Cypress testing')
            // cy.get('[id=textbox_custom_mbs_form_config]').clear().type('{"Cypress": "testing"}', { "parseSpecialCharSequences": false })

            // cy.get('[id=textbox_custom_mbs_form_code]').type('  ALPHABETS  ')
            // cy.get('#button_custom_mbs_form_save').should('be.disabled')

            // cy.wait(1000);

            // cy.get('[id=textbox_custom_mbs_form_code]').clear().type('1_7856')

            // cy.get('[id=tabs_custom_mbs_form_tabs_1]').click()
            // cy.get('[id^="textarea_configuration_environment_variable_config"]').each((element, index) => {
            //     cy.get(element).clear().type(`{"Cypress": "testing_${index}"}`, { "parseSpecialCharSequences": false })
            // });
            // cy.get('[id=button_custom_mbs_form_save]').click()

            cy.pause()
        })
    })

    function inputValidation(selector, typingWord){
        cy.get(selector)
            .clear()
            .type(typingWord, { "parseSpecialCharSequences": false })
            .should('have.value', typingWord)
    }

    // describe('[Search] CUSTOM MBS', ()=>{
    //     it('opens custom MBS menu and search successfully', () => {
    //         cy.get('[id=textbox_custom_mbs_list_name]')
    //             .type('Cypress')
    //             .should('have.value', 'Cypress')
    //         cy.get('[id=button_custom_mbs_list_search]').click()
    
    //         cy.wait(1000);

    //         cy.debug(cy.contains('PT'))
    //     })
    // })



})