export const environment = {
  production: true,
  okta_service_endpoint: "https://alpha-tisco.okta.com/"
};
