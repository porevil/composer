import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { environment } from '../environments/environment';

import { StoreModule, ActionReducer } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { storeLogger } from 'ngrx-store-logger';
import { State } from './store/reducers';
import * as state from './store/reducers/index';

import { AuthenEffects } from './store/effect/auths/auths.effects';
import { FlowEffects } from './store/effect/flow/flow.effects';
import { MenuEffects } from './store/effect/menu/menu.effects';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ErrorPageComponent } from './error-page/error-page.component';

import { CoreModule } from './core';
import { SharedModule } from './shared';
import { UserInformationEffects } from './store/effect/user-information/user-information.effects';

export function logger(reducer: ActionReducer<State>): any {
    // default, no options
    return storeLogger()(reducer);
}

export const metaReducers = environment.production ? [] : [logger];


@NgModule({
    declarations: [
        AppComponent,
        ErrorPageComponent
    ],
    imports: [
        BrowserModule,
        BrowserAnimationsModule,
        CoreModule,
        AppRoutingModule,
        SharedModule,
        StoreModule.forRoot([]),
        EffectsModule.forRoot([]),
        StoreModule.forFeature(state.stateFeatureKey, state.reducers, { metaReducers }),
        !environment.production ? StoreDevtoolsModule.instrument() : [],
        EffectsModule.forFeature([AuthenEffects,FlowEffects,MenuEffects,UserInformationEffects])
    ],
    bootstrap: [AppComponent],
    providers: [],
})
export class AppModule { }
