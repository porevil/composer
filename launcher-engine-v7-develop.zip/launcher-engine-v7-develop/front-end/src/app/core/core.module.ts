import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { interceptorProviders } from './interceptors/interceptors';
import { 
    AuthenticationService, FlowService, UtilsService, DashboardService, LogService 
} from './services';

const services = [
    AuthenticationService, FlowService, UtilsService, DashboardService, LogService
];

@NgModule({
    declarations: [],
    imports: [
        CommonModule,
        HttpClientModule
    ],
    providers: [
        ...interceptorProviders,
        ...services
    ],
    exports : []
})

export class CoreModule { }