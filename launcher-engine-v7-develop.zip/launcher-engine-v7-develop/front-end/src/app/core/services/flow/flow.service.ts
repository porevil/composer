import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { UtilsService } from '../utils/utils.service';

import { NgxSpinnerService } from "ngx-spinner";

@Injectable({
    providedIn: 'root'
})
export class FlowService {

    constructor(
        public httpClient: HttpClient,
        private utilsService : UtilsService,
        private ngxSpinnerService : NgxSpinnerService
    ) { }

    public getFlowRuntime(flowUUID : string, config? : { redirect? : { path : string } }) : Observable<any> {
        const data = { flow_uuid : flowUUID };
        return this.httpClient.post('/api/launch_flow/',data).pipe(
            tap((response: any) => {
                if(response.meta.response_code != 10000){                    
                    this.utilsService.errorDialogPopup(response.meta.response_desc,{
                        response : response,
                        redirect : {
                            enabled : !!config?.redirect?.path,
                            path : config?.redirect?.path
                        }
                    });
                }
            })
        );
    };

    public setCurrentNode(workflowKey : string, reference_uuid : string) : Observable<any>{
        const data = { 
            workflow_key : workflowKey,
            next_reference_uuid : reference_uuid,
        };
        return this.httpClient.post('/api/go_to_node/',data).pipe(
            tap((response: any) => {
                if(response.meta.response_code != 10000){                    
                    this.utilsService.errorDialogPopup(response.meta.response_desc, {
                        response : response
                    });
                }
            })
        );
    };

    public loaderService = {
        show : () => {
            this.ngxSpinnerService.show();
        },
        hide : () => {
            this.ngxSpinnerService.hide();
        }
    };

}
