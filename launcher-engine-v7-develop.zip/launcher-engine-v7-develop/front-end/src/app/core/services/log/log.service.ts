import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class LogService {

    constructor(
        private httpClient : HttpClient
    ) { }

    public setClientMessage(type : string, message : any) : Observable<any>{
        return this.httpClient.post('/api/client_logger/', {
            type : type,
            message : message
        });
    };

    public setClientErrorMessage(message : any) : Observable<any>{
        return this.setClientMessage("error",message);
    };

}
