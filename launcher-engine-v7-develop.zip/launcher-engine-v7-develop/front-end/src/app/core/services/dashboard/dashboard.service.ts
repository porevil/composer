import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class DashboardService {

    constructor(
        public httpClient: HttpClient
    ) { }

    public getUserInfomation() : Observable<any> {
        return this.httpClient.get('api/user_information/');
    };

    public getRepresentativeUserChoices() : Observable<any>{
        return this.httpClient.get('api/representative_user_choices/');
    }

    public postOverrideRepresentative(overrideRequest: any) :Observable<any>{
        return this.httpClient.post('api/override_representation/', overrideRequest);
    }

}
