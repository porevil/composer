import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { DialogPopupIcon } from './utils';

@Injectable({
    providedIn: 'root'
})
export class UtilsService {

    constructor(
        private router: Router
    ) { }

    private defaultAlertConfig = {
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        reverseButtons: true
    };

    public async dialogPopup(
        displayType, displayTitle, displayText,
        resp?, redirect = false, redirectPath = '',
        displayConfirmButton = true, displayCancelButton = false
    ) : Promise<void> {

        if (resp) {
            displayType = "warning";
            displayText = resp.meta.response_desc;
            // redirect = true;
            const url = this.router.url.split("/");
            let newUrl;
            if (url.length < 2) {
                redirect = true;
                newUrl = "/error";
            } else if(resp.error_detail && (resp.error_detail.error_code == 10001 ||  resp.error_detail.error_code == 10002)) {
                redirectPath = `/${url[1]}/${url[2]}/authen`;
                redirect = true;
            } else {
                // redirect = true;
                redirectPath = `/${url[1]}/${url[2]}/authen${redirectPath}`;
            }
        }
        if (resp && resp.error_detail && resp.error_detail.error_stack) {
            displayText =   `<div>${displayText}</div>
                            <p class="m-0">
                                <a class="font14" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
                                    <i class="fa fa-chevron-circle-down" style="color:#f27474"></i>
                                </a>
                            </p>
                            <div class="collapse" id="collapseExample">
                                <div class="card-body error-detail"> (${resp.error_detail.error_code}) ${resp.error_detail.error_stack}</div>
                            </div>`;
        } else {
            displayText = `<div>${displayText}</div>`;
        }

        const alertConfig : any = {
            title: displayType,
            text: displayTitle,
            html: displayText,
            icon: displayType,
            showConfirmButton: displayConfirmButton,
            showCancelButton: displayCancelButton,
            allowOutsideClick: false,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "OK",
            reverseButtons: true
        };
        await Swal.fire(alertConfig);
        if (redirect) {
            this.router.navigate([redirectPath]);
        }
    };

    public async dialogPopupDefault(
        displayType, displayTitle, displayText, 
        { displayConfirmButton = true, displayCancelButton = false, confirmMsg = "OK" }, 
        redirectPath?
    ) : Promise<void> {
        const alertConfig : any = {
            title: displayTitle,
            text: displayText,
            icon: displayType,
            showConfirmButton: displayConfirmButton,
            showCancelButton: displayCancelButton,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: confirmMsg,
            reverseButtons: true
        };
        await Swal.fire(alertConfig);
        if (redirectPath) {
            this.router.navigate([redirectPath]);
        }
    };

    public async errorDialogPopup(text : string, config? : {        
        response? : any,
        redirect? : {
            enabled? : boolean,
            path? : string,
            back? : number
        },
        title? : string,
        icon? : DialogPopupIcon,
        showConfirmButton? : boolean,
        showCancelButton? : boolean
    }) : Promise<any>{

        const { 
            confirmButtonColor, cancelButtonColor, reverseButtons 
        } = this.defaultAlertConfig;
        const defaultAlertConfig = {
            title: DialogPopupIcon.Error,
            text : 'เกิดข้อผิดพลาด',
            icon : DialogPopupIcon.Error,
            allowOutsideClick: false,
            confirmButtonText: "OK",
            showConfirmButton : true,
            showCancelButton : false,
            confirmButtonColor: confirmButtonColor,
            cancelButtonColor: cancelButtonColor,            
            reverseButtons: reverseButtons
        };

        if(!config){
            config = {};
        }
        let html = `<div>${text}</div>`;
        let redirect = {
            enabled : (config.redirect && config.redirect.enabled) || false,
            path : (config.redirect && config.redirect.path) || null
        };        
        if(!!config.response){

            const response = config.response;                       
            config.icon = DialogPopupIcon.Warning;
            const url = this.router.url.split("/");
            
            if (url.length < 2) {
                redirect.enabled = true;
                redirect.path = "/error";
            } else if(response.error_detail && (response.error_detail.error_code == 10001 ||  response.error_detail.error_code == 10002)) {
                redirect.path = `/${url[1]}/${url[2]}/authen`;
                redirect.enabled = true;
            } else {
                redirect.path = `/${url[1]}/${url[2]}/${redirect.path}`;
            }
            if(!!response.error_detail && !!response.error_detail.error_stack){
                html =  `<div>${text}</div>
                        <p class="m-0">
                            <a class="font14" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
                                <i class="fa fa-chevron-circle-down" style="color:#f27474"></i>
                            </a>
                        </p>
                        <div class="collapse" id="collapseExample">
                            <div class="card-body error-detail"> (${response.error_detail.error_code}) ${response.error_detail.error_stack}</div>
                        </div>`;
            }
        }     

        const overrideAlertConfig = {};
        const overrideProperties = {
            title : 'icon',
            icon : 'icon',
            text : 'title',
            showConfirmButton : 'showConfirmButton',
            showCancelButton : 'showCancelButton'
        };
        for(let i in overrideProperties){
            const value = config[overrideProperties[i]];
            if(!!value){
                overrideAlertConfig[i] = value;
            }
        }   

        const alertConfig : any = {
            ...{ 
                html : html
            },
            ...defaultAlertConfig,
            ...overrideAlertConfig
        };

        await Swal.fire(alertConfig);

        if(redirect.enabled){
            this.router.navigate([redirect.path]);
        }
        else if(config.redirect && typeof(config.redirect.back) == "number" && config.redirect.back > 0){
            let urls = this.router.url.split('/');
            urls.splice(-1*config.redirect.back);
            if(typeof(config.redirect.path) == "string" && config.redirect.path.trim().length > 0){
                urls.push(config.redirect.path);
            }
            this.router.navigate([urls.join('/')]);
        }

    };

    public async deleteDialogPopup(config? : {
        title? : string;
        text? : string;
    }) : Promise<boolean> {

        const defaultConfig = {
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'question',
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            showConfirmButton: true,
            showCancelButton: true,
            reverseButtons: true
        };

        const alertConfig : any = {
            ...defaultConfig,
            ...config
        };


        const result = await Swal.fire(alertConfig);

        return result.value;
    };

    public async alertDialogPopup(title : string, text : string, config? : {
        icon? : DialogPopupIcon,
        confirmButtonText? : string,
        allowOutsideClick? : boolean
    }) : Promise<void>{

        const { 
            confirmButtonColor
        } = this.defaultAlertConfig;
        const defaultAlertConfig = {
            confirmButtonColor: confirmButtonColor,
            showConfirmButton: true,
            showCancelButton: false,
            confirmButtonText : 'OK'
        };
        const alertConfig : any = {
            ...{
                title: title,
                text: text,
            },
            ...defaultAlertConfig,
            ...config
        };
        await Swal.fire(alertConfig);
    };

    public async timeoutDialogPopup(title : string, text : string, second : number, config? : {
        icon : DialogPopupIcon,
        confirmButtonText? : string,
        cancelButtonText? : string
    }) : Promise<{
        isConfirm : boolean,
        isTimeout : boolean
    }> {

        let offInterval = null;
        const html = getTemplate();
        const { 
            confirmButtonColor, cancelButtonColor, reverseButtons 
        } = this.defaultAlertConfig;
        const defaultAlertConfig = {
            icon : DialogPopupIcon.Question,
            confirmButtonColor: confirmButtonColor,
            cancelButtonColor: cancelButtonColor,
            showConfirmButton: true,
            showCancelButton: true,
            allowOutsideClick : false,
            reverseButtons: reverseButtons
        };

        function getTemplate() : string {
            return `<div>
                        <div>
                            <span>${text}</span>
                        </div>
                        <div style="margin:24px 0px;font-size:1.5em;">
                            <span name="timer">${getDisplayTimer(second)}</span>
                        </div>
                    </div>`;
        };

        function convertSecondToDDHHMMSS(second: number) : { days : number, hours : number, minutes : number, seconds : number } {
            const obj = {
                days : 0,
                hours : 0,
                minutes : 0,
                seconds : 0
            };    
            obj.seconds = second%60;
            obj.minutes = Math.floor(second/60)%60;
            obj.hours = Math.floor(second/60/60)%24;
            obj.days = Math.floor(second/60/60/24);    
            return obj;
        };

        function getDisplayTimer(second: number): string {
            const obj = convertSecondToDDHHMMSS(second);
            const units = ['mins', 'hrs', 'days'];
            const times = [];

            if (obj.days > 0) {
                times.push(obj.days);
                times.push(obj.hours);
            }
            else if (obj.hours > 0) {
                times.push(obj.hours);
            }
            times.push(obj.minutes);
            times.push(obj.seconds);

            let timeString = times.map(time => {
                if (time < 10) {
                    time = `0${time}`;
                }
                return `${time}`;
            }).join(':');

            timeString = `${timeString} ${units[times.length - 2]}`;
            return timeString;
        };

        function stopTimer() : void {
            if(offInterval != null){
                clearInterval(offInterval)
                offInterval = null;
            }
        };

        function startTimer() : void {
            stopTimer();
            offInterval = setInterval(() => {
                const content = Swal.getContent();
                if (content) {
                    const timerEle = content.querySelector(`[name="timer"]`);
                    if (timerEle) {
                        const remaining = Math.round(Swal.getTimerLeft()/1000);
                        timerEle.textContent = getDisplayTimer(remaining);
                    }
                }
            }, 1000); 
        };

        const overrideAlertConfig = {};
        const overrideProperties = {
            icon : 'icon',
            confirmButtonText : 'confirmButtonText',
            cancelButtonText : 'cancelButtonText'
        };
        for(let i in overrideProperties){
            const value = config[overrideProperties[i]];
            if(!!value){
                overrideAlertConfig[i] = value;
            }
        }  

        const alertConfig : any = {
            ...{
                title : title,
                html : html,
                timer: second * 1000,
                onOpen : () => { startTimer(); },
                onClose : () => { stopTimer(); }
            },
            ...defaultAlertConfig,
            ...overrideAlertConfig
        };

        const result = await Swal.fire(alertConfig);
        return {
            isConfirm : !!result.value,
            isTimeout : result.dismiss == Swal.DismissReason.timer
        };

    };

    public async successDialogPopup(config? : {
        title? : string;
        text? : string;
    }) : Promise<void>{

        const defaultAlertConfig = {
            title: 'ดำเนินการสำเร็จ',
            icon : DialogPopupIcon.Success
        };
        const alertConfig = {
            ...defaultAlertConfig,
            ...config
        };
        const { title, text } = alertConfig;
        delete alertConfig.title;
        delete alertConfig.text;

        return await this.alertDialogPopup(title,text,alertConfig);

    };
}
export * from './utils';