import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { JwtHelperService } from '@auth0/angular-jwt';
import { UtilsService, DialogPopupIcon } from '../utils/utils.service';
import { environment } from '../../../../environments/environment';

@Injectable({
    providedIn: 'root'
})
export class AuthenticationService {

    constructor(
        private httpClient: HttpClient,
        private router:Router,
        private utilsService:UtilsService,
        private cookieService: CookieService
    ) { 

    }

    private sessionTimeoutControls = {
        offTimeout : null
    };

    public sessionTimeoutConfig = {
        timeBeforeAlert : 1 * 60 + 3,
        timeContinue : 60,
        endSessionRedirect : environment.okta_service_endpoint,
        continueDialogPopup : {
            icon : DialogPopupIcon.Warning,
            title : "Session timeout warning",
            text : "Your session will expire automatically in",
            confirmButtonText : "Continue session",
            cancelButtonText : "End session now"
        },
        timeoutDialogPopup : {
            icon : DialogPopupIcon.Warning,
            title : "Session expired!",
            text : "Your session has expired.",
            confirmButtonText : "Close"
        }
    };

    public getMenuItems() : Observable<any> {
        return this.httpClient.get('api/menu/').pipe(
            tap((response: any) => {
                if(response.meta.response_code != 10000){
                    this.utilsService.errorDialogPopup(response.meta.response_desc,{ response : response});
                }
            })
        );
    };

    public getEnvironmentVariable() : Observable<any> {
        return this.httpClient.get('api/get_environment_variable/').pipe(
            tap((response: any) => {
                if(response.meta.response_code != 10000){
                    this.utilsService.errorDialogPopup(response.meta.response_desc,{ response : response});
                }
            })
        );
    };

    public deleteCacheMenu() : Observable<any> {
        return this.httpClient.get('api/clear_menu_cache/').pipe(
            tap((response: any) => {
                if(response.meta.response_code != 10000){
                    this.utilsService.errorDialogPopup(response.meta.response_desc,{ response : response});
                }
            })
        );
    };

    public getAppCode(isRedirect? : boolean) : any {
        const url = window.location.pathname.split("/");
        if (url.length < 2) { 
            if(!!isRedirect){
                this.router.navigate(['/error']);
            }           
            return null;
        } 
        return url[2];
    };

    public authorizationLoginRedirect() : Observable<any> {
        return this.httpClient.get('api/authentication/login/').pipe(
            tap((resp: any) => {

            })
        );
    };

    public authorizationLoginVerify(code : any) : Observable<any> {
        const appCode = this.getAppCode(false);
        return this.httpClient.get(`api/authentication/verifycode/${code}/`).pipe(
            tap((response: any) => {
                if (response.meta.response_code && response.meta.response_code === "10000") {
                    this.router.navigate(["application",appCode,"pages"]);
                } 
                else {
                    this.utilsService.errorDialogPopup(response.meta.response_desc, {
                        response : response,
                        redirect : { 
                            enabled : true,
                            path : 'error'
                        }
                    });
                }
            })
        );
    };

    public authorizationRefreshCookie() : Observable<any> {
        return this.httpClient.get('api/authentication/refresh/');
    };

    public getUserInfo() : { name : string, username : string} {
        const helper = new JwtHelperService();
        const cookie = this.cookieService.get("id_token");
        const decodeCookie = cookie && helper.decodeToken(cookie) || null;
        if(decodeCookie){
            return {
                name : decodeCookie.name || null,
                username : decodeCookie.preferred_username || null
            };
        }
        return null;
    };

    public validCookie(cookieName : string) : boolean {
        const cookie = this.cookieService.get(cookieName);
        const helper = new JwtHelperService();
        const expireEpoch = cookie && helper.decodeToken(cookie).exp || null;
        const nowEpoch = Math.floor(Date.now()/1000); 
        return expireEpoch && expireEpoch - nowEpoch > 0;
    }; 

    public stopSessionTimeoutWarning() : void {
        if(this.sessionTimeoutControls.offTimeout){
            clearInterval(this.sessionTimeoutControls.offTimeout);
            this.sessionTimeoutControls.offTimeout = null;
        }
    };

    public async startSessionTimeoutWarning() : Promise<void> {
        this.stopSessionTimeoutWarning();
        const helper = new JwtHelperService();
        const self = this;

        async function validateSession() : Promise<void>{
            const cookie = self.cookieService.get('id_token');
            if(!cookie){
                self.stopSessionTimeoutWarning();
                const appCode = self.getAppCode(true);
                self.router.navigate(["application", appCode]);
            }
            else {
                const expireEpoch = helper.decodeToken(cookie).exp;
                const nowEpoch = Math.floor(Date.now()/1000); 
                const remianing = expireEpoch - nowEpoch;         
                if(remianing <= self.sessionTimeoutConfig.timeBeforeAlert){
                    self.stopSessionTimeoutWarning();
                    const appCode = self.getAppCode(true);
                    const continueDialogPopupConfig = self.sessionTimeoutConfig.continueDialogPopup;
                    const dialogInstance = await self.utilsService.timeoutDialogPopup(
                        continueDialogPopupConfig.title, 
                        continueDialogPopupConfig.text, 
                        self.sessionTimeoutConfig.timeContinue, 
                        {
                            icon : continueDialogPopupConfig.icon,
                            confirmButtonText : continueDialogPopupConfig.confirmButtonText,
                            cancelButtonText : continueDialogPopupConfig.cancelButtonText
                        }
                    );
    
                    let isContinueSession = dialogInstance.isConfirm;
                    if(dialogInstance.isTimeout){
                        self.cookieService.delete("id_token","/");
                        const timeoutDialogPopupConfig = self.sessionTimeoutConfig.timeoutDialogPopup;
                        await self.utilsService.alertDialogPopup(
                            timeoutDialogPopupConfig.title,
                            timeoutDialogPopupConfig.text,
                            {
                                icon : timeoutDialogPopupConfig.icon,
                                allowOutsideClick : false,
                                confirmButtonText : timeoutDialogPopupConfig.confirmButtonText
                            }
                        );
                    }
    
                    if(isContinueSession){
                        const response = await self.authorizationRefreshCookie().toPromise();
                    }
                    else {
                        self.cookieService.delete("id_token","/");
                        window.location.href = self.sessionTimeoutConfig.endSessionRedirect;
                    }
                } 
            }                    
        };

        let offTimeout = setInterval(()=>{
            validateSession();            
        },1000);
        this.sessionTimeoutControls.offTimeout = offTimeout;        
    };


}


