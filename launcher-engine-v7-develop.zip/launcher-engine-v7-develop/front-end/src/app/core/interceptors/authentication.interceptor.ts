import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpEvent } from '@angular/common/http';
import { HttpHandler } from '@angular/common/http';
import { HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthenticationService } from '../services';
import { map } from 'rxjs/operators';

declare const $: any;
declare const window : any;

@Injectable({
    providedIn: 'root'
})
export class AuthenticationInterceptor implements HttpInterceptor {

    public appCode = '';

    constructor(
        private authenticationService : AuthenticationService
    ) {
        this.appCode = this.authenticationService.getAppCode(true);
    };

    private setHeaderEnvMode(request : HttpRequest<any>) : HttpRequest<any> {
        let headers = request.headers;

        const customHeaders = <Array<any>>request.headers.getAll('lazyupdate');
        if(customHeaders){
            for(let customHeader of customHeaders){
                headers = headers.set(customHeader.name,customHeader.value);
            }
        }     
        headers = headers.set("app-code", this.appCode);
        headers = headers.set("is-launcher", 'true');

        const isMBS = headers.get('isMBS') == "true" || false;
        if(!isMBS){
            headers = headers.set("Content-Type", "application/json");
        }

        const clonedRequest = request.clone({
            headers: headers
        });
        return clonedRequest;
    }

    intercept(
        request: HttpRequest<any>,
        next: HttpHandler
    ): Observable<HttpEvent<any>> {
        request = this.setHeaderEnvMode(request);
        return next.handle(request);
    };
    

    
}