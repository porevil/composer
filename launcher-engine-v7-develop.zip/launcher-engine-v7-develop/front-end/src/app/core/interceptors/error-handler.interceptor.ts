import { Injectable, ErrorHandler, Injector } from '@angular/core';
import { AuthenticationService, LogService } from '../services';

@Injectable()
export class ErrorHandlerInterceptor extends ErrorHandler {

    constructor(
        private injector: Injector,
        private logService : LogService
    ) {
        super();
    }

    handleError(error : any) : void {
        const message = [];
        const authenticationService = this.injector.get(AuthenticationService);
        const path = /(?<path>pages.*)/g.exec(window.location.pathname)?.groups?.path || null;        
        const username = authenticationService.getUserInfo()?.username || null;
        const stack = error.stack;        
        if(path){
            message.push(`Error path : ${path}`);
        }
        if(username){
            message.push(`Email : ${username}`);
        }
        message.push(stack);
        if(typeof(error && error.message) != "string" || !(error && error.message.match(/\$NOT_SEND/g))){
            try { console.error(message.join('\n')); } catch(ex){ };
            this.logService.setClientErrorMessage(message.join('\n')).toPromise();
        }
    }
}