import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpEvent, HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { HttpHandler } from '@angular/common/http';
import { HttpRequest } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { UtilsService } from '../services';
import { CookieService } from 'ngx-cookie-service';

declare const $: any;

@Injectable({
    providedIn: 'root'
})
export class ErrorInterceptor implements HttpInterceptor {


    constructor(
        private utilsService: UtilsService,
        private cookieService : CookieService
    ) { };

    intercept(
        request: HttpRequest<any>,
        next: HttpHandler
    ): Observable<HttpEvent<any>> {
        return next.handle(request).pipe(
            map((event: HttpEvent<any>) => {
                if (event instanceof HttpResponse) {                    
                    const isByPass = request.headers.get('is-by-pass') == "true" || false;
                    const isMBS = request.headers.get('isMBS') == "true" || false;
                    if(isByPass || isMBS || event.body.meta?.response_code == 10000){
                        return event;
                    }
                    else if(!event.body.meta || !event.body.error_detail){
                        this.utilsService.dialogPopup("error", 'พบข้อผิดพลาด', 'Cannot read property \'meta\' of undefined', '');
                        throw new Error("$NOT_SEND");
                    }
                    else if (event.body.meta.response_code != 10000 && (['10002','10002'].includes(event.body.error_detail.error_code))) {
                        this.utilsService.dialogPopup("error", 'พบข้อผิดพลาด', event.body.meta.response_desc, event.body);
                        this.cookieService.delete("id_token","/");
                        throw new Error("$NOT_SEND");
                    } 
                    else {
                        return event;
                    }
                }
            }),
            catchError((error: HttpErrorResponse) => {
                if(typeof(error && error.message) != "string" || !(error && error.message.match(/\$NOT_SEND/g))){
                    if (error.error instanceof ErrorEvent) {
                        this.utilsService.dialogPopupDefault("error", 'เกิดข้อผิดพลาด', `${error.error} `, {}, 'error');
                    } else {
                        this.utilsService.dialogPopupDefault("error", 'เกิดข้อผิดพลาด', `${error.status} ${error.statusText}`, {}, 'error');
                    }
                }
                return throwError(error);
            })
        );
    };
    
}