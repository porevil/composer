import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';
import { State } from '../../store/reducers';
//import * as fromMenuAction from '../../store/actions/menu.actions'

import {  AuthenticationService } from '../services';


@Injectable({
    providedIn: 'root'
})
export class AuthenGuard implements CanActivate {

    constructor(
        private router: Router,
        private store: Store<State>,
        private authenticationService : AuthenticationService
    ) {
        this._constructorComponent();
    }

    private appCode = null;

    canActivate(
        next: ActivatedRouteSnapshot,
        state: RouterStateSnapshot
    ) :
        | Observable<boolean | UrlTree>
        | Promise<boolean | UrlTree>
        | boolean
        | UrlTree {
        return this._canActivate();
    };

    private _constructorComponent() : void {
        this.appCode = this.authenticationService.getAppCode(true);
    };

    private _canActivate() : boolean {
        const validCookie = this.authenticationService.validCookie("id_token");
        if (validCookie) {
            //this.store.dispatch(fromMenuAction.loadMenus())
            return true;
        } 
        else {
            this.router.navigate(["application",this.appCode,"authen"]);
            return false;
        }
    };

}
