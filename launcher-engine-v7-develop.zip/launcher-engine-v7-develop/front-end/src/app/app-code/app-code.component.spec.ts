import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppCodeComponent } from './app-code.component';

describe('AppCodeComponent', () => {
  let component: AppCodeComponent;
  let fixture: ComponentFixture<AppCodeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppCodeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppCodeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
