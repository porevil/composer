import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
    selector: 'app-app-code',
    templateUrl: './app-code.component.html',
    styleUrls: ['./app-code.component.scss'],
    encapsulation : ViewEncapsulation.None
})
export class AppCodeComponent implements OnInit {

    constructor() { }

    ngOnInit(): void {
    }

}
