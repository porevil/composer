import { Action, createReducer, on } from '@ngrx/store';
import * as fromUserInfomationAction from '../../actions/user-information.actions';

export const userInformationFeatureKey = 'userInformation';

export interface UserInfomationState {
  infomation : null,
  representative:{popup:boolean,choices:{branches:[],representations:[]}}
}

export const initialState: UserInfomationState = {
  infomation:null,
  representative:null
};

export const UserInfomationReducer = createReducer(
  initialState,
  on(
    fromUserInfomationAction.setUserInformationsInStore,
      (state, action) => {
          return {
              ...state,
              infomation: action.payload
          };
      }
  ),
  on(
    fromUserInfomationAction.setRepresentativeUserChoicesInStore,
      (state, action) => {
          return {
              ...state,
              representative: action.payload
          };
      }
  )
);

export function reducer(state= initialState , action: Action):UserInfomationState {
  return UserInfomationReducer(state, action);
}
