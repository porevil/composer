import { Action, createReducer, on } from '@ngrx/store';
import * as fromMenuAction from '../../actions/menu.actions';


export const menuFeatureKey = 'menu';

export interface MenuState {
    menuItems : Array<any>
}

export const initialState: MenuState = {
    menuItems : []
};

export const MenuReducer = createReducer(
    initialState,
    on(
        fromMenuAction.setMenuItemsInStore,
        (state, action) => {
            return {
                ...state,
                menuItems: action.payload
            };
        }
    )
);

export function reducer(state = initialState, action: Action): MenuState {
    return MenuReducer(state, action);
}
