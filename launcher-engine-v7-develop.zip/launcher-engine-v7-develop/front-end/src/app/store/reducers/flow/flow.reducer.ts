import { Action, createReducer, on } from '@ngrx/store';
import * as fromFlowAction from '../../actions/flow.actions'

export const flowFeatureKey = 'flow';

export interface FlowState {
    flowRuntime : any
}

export const initialState: FlowState = {
    flowRuntime : null
}

const flowReducer = createReducer(
    initialState,
    on(
        fromFlowAction.setFlowRuntimeInStore,
        (state, action) => {
            return {
                ...state,
                flowRuntime : action.payload
            }
        }
    ),
    on(
        fromFlowAction.setSequenceFlowRuntimeInStore,
        (state, action) => {
            const flowRuntime = JSON.parse(JSON.stringify(state.flowRuntime));
            flowRuntime.current_reference_uuid = action.payload.reference_uuid;
            return {
                ...state,
                flowRuntime : flowRuntime
            }
        }
    )
);

export function FlowReducer(state: FlowState | undefined, action: Action) : FlowState {
    return flowReducer(state, action);
}
