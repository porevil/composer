import { Action, createReducer, on, State } from '@ngrx/store';
import * as fromAuthsAction from '../../actions/auths.actions'

export const authsFeatureKey = 'authen';

export interface AuthsState {

}

export const initialState: AuthsState = {};

export const authenReducer = createReducer(
    initialState,
    on(
        fromAuthsAction.setAuthenInStore,
        (state, action) => action.payload
    ),
    on(
        fromAuthsAction.setEnvironmentVariableInStore,
        (state, action) =>  {
            return {
                ...state,
                okta_service_endpoint: action.payload.okta_service_endpoint
            };
    })
);

export function AuthenticateReducer(state: AuthsState | undefined, action: Action) : AuthsState{
    return authenReducer(state, action);
}

