import { AuthenticateReducer, initialState } from './auths.reducer';

describe('Authen Reducer', () => {
  describe('an unknown action', () => {
    it('should return the previous state', () => {
      const action = {} as any;

      const result = AuthenticateReducer(initialState, action);

      expect(result).toBe(initialState);
    });
  });
});
