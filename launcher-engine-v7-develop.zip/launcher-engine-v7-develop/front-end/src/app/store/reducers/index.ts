import {
    ActionReducer, ActionReducerMap, createFeatureSelector, createSelector, MetaReducer
} from '@ngrx/store';
import { environment } from '../../../environments/environment';
import { AuthenticateReducer, AuthsState } from './auths/auths.reducer';
import { FlowReducer, FlowState } from './flow/flow.reducer';
import { MenuReducer, MenuState } from './menu/menu.reducer';
import { UserInfomationState, UserInfomationReducer } from './user-information/user-information.reducer';

export const stateFeatureKey = 'stateFeatureKey'

export interface State {
    flow: FlowState,
    authenticate : AuthsState,
    menu : MenuState,
    user:UserInfomationState
}

export const reducers: ActionReducerMap<State> = {
    flow: FlowReducer,
    authenticate : AuthenticateReducer,
    menu : MenuReducer,
    user:UserInfomationReducer
};

export const metaReducers: MetaReducer<State>[] = !environment.production ? [] : [];
export const getLauncherState = createFeatureSelector<State>('stateFeatureKey');
export const getAuthenticateState = createSelector(getLauncherState, (state: State) => state.authenticate);
export const getFlowRuntimeState = createSelector(getLauncherState, (state: State) => state.flow.flowRuntime);
export const getMenuItemsInMenuState = createSelector(getLauncherState, (state: State) => state.menu.menuItems);
export const getUserInfomationState = createSelector(getLauncherState, (state: State) => state.user.infomation);
export const getUserRepresentativeState = createSelector(getLauncherState, (state: State) => state.user.representative);
export const getEnvironmentVariableState = createSelector(getLauncherState, (state: State) => state.authenticate);
