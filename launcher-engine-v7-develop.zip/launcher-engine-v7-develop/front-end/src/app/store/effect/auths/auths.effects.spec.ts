import { TestBed } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { Observable } from 'rxjs';

import { AuthsEffects } from './auths.effects';

describe('UserEffects', () => {
  let actions$: Observable<any>;
  let effects: AuthsEffects;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        AuthsEffects,
        provideMockActions(() => actions$)
      ]
    });

    effects = TestBed.get<AuthsEffects>(AuthsEffects);
  });

  it('should be created', () => {
    expect(effects).toBeTruthy();
  });
});
