import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Observable, throwError } from 'rxjs';
import { map, switchMap, catchError, concatMapTo, concatMap } from 'rxjs/operators';
import * as fromAuthsAction from '../../actions/auths.actions';
import { AuthenticationService } from '../../../core/services';
//import * as fromMenuAction from '../../actions/menu.actions';


@Injectable()
export class AuthenEffects {
    constructor(
        private actions$: Actions,
        private authenticationService: AuthenticationService,
    ) { }

    @Effect()
    verifyCodeAuthen$: Observable<any> = this.actions$.pipe(
        ofType<any>(fromAuthsAction.verifyCodeAuthen),
        map((action: any) => action),
        switchMap((action) =>
            this.authenticationService.authorizationLoginVerify(action.payload).pipe(
                map((resp: any) => {
                    if (resp.meta.response_code != 10000) {
                        return fromAuthsAction.verifyCodeAuthenFailure(resp.error)
                    } else {
                        return fromAuthsAction.verifyCodeAuthenSuccess({ payload: resp.data });
                    }
                })
            )
        ), catchError((e) => {
            return throwError(e);
        })
    );

    @Effect()
    verifyCodeAuthenSuccess$: Observable<any> = this.actions$.pipe(
        ofType<any>(fromAuthsAction.verifyCodeAuthenSuccess),
        map(resp => fromAuthsAction.setAuthenInStore(resp))
    );

}
