import { Injectable } from '@angular/core';
import { Actions, createEffect, Effect, ofType } from '@ngrx/effects';
import { Observable, throwError } from 'rxjs';
import { map, switchMap, catchError } from 'rxjs/operators';
import { FlowService } from '../../../core/services/flow/flow.service';
import * as fromFlowAction from '../../actions/flow.actions';


@Injectable()
export class FlowEffects {

    constructor(
        private actions$: Actions, 
        private flowService: FlowService
    ) { };

    @Effect()
    getFlowRuntime$: Observable<any> = this.actions$.pipe(
        ofType<any>(fromFlowAction.getFlowRuntime),
        map((action: any) => action),
        switchMap((action) =>
            this.flowService.getFlowRuntime(action.payload.flow_uuid, action.payload.config)
                .pipe(
                    map((response: any) => {
                        if (response.meta.response_code != 10000) {
                            return fromFlowAction.getFlowRuntimeFailure({ error : response });
                        } else {
                            return fromFlowAction.getFlowRuntimeSuccess({ payload : response.data });
                        }
                    })
                )
        ), catchError((e) => {
            return throwError(e);
        })
    );

    @Effect()
    getFlowRuntimeSuccess$: Observable<any> = this.actions$.pipe(
        ofType<any>(fromFlowAction.getFlowRuntimeSuccess),
        map((response: any) => {
            return fromFlowAction.setFlowRuntimeInStore(response);
        })
    );

    @Effect()
    setCurrentNode$: Observable<any> = this.actions$.pipe(
        ofType<any>(fromFlowAction.setCurrentNode),
        map((action: any) => action),
        switchMap((action) =>
            this.flowService.setCurrentNode(action.payload.workflowKey,action.payload.reference_uuid)
                .pipe(
                    map((response: any) => {
                        if (response.meta.response_code != 10000) {
                            return fromFlowAction.setCurrentNodeFailure({ error : response });
                        } else {
                            return fromFlowAction.setCurrentNodeSuccess({ payload : { 
                                reference_uuid : action.payload.reference_uuid
                            }});
                        }
                    })
                )
        ), catchError((e) => {
            return throwError(e);
        })
    );

    @Effect()
    setCurrentNodeSuccess$: Observable<any> = this.actions$.pipe(
        ofType<any>(fromFlowAction.setCurrentNodeSuccess),
        map((response: any) => {
            return fromFlowAction.setSequenceFlowRuntimeInStore(response);
        })
    );
    
}
