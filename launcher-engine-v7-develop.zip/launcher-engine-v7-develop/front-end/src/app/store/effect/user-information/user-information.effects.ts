import { Injectable } from '@angular/core';
import { Actions, createEffect, Effect, ofType } from '@ngrx/effects';
import { Observable, throwError } from 'rxjs';
import { map, switchMap, catchError, concatMap } from 'rxjs/operators';
import * as fromUserImfomationAction from '../../actions/user-information.actions';
import * as fromAuthAction from '../../actions/auths.actions'
import { DashboardService, UtilsService } from 'src/app/core/services';


@Injectable()
export class UserInformationEffects {

  constructor(private actions$: Actions,private dashboardService: DashboardService,private utilsService:UtilsService) {}

  @Effect()
    loadUserImfomationItems$: Observable<any> = this.actions$.pipe(
        ofType<any>(fromUserImfomationAction.loadUserInformations),
        map((action: any) => action),
        switchMap((action) =>
            this.dashboardService.getUserInfomation()
                .pipe(
                    map((response: any) => {
                        if (response.meta.response_code != 10000) {
                            this.utilsService.errorDialogPopup(response.meta.response_desc, {response: response});
                            return fromUserImfomationAction.loadUserInformationsFailure({ error : response.error });
                        } else {
                            return fromUserImfomationAction.loadUserInformationsSuccess({ payload : response.data});
                        }
                    })
                )
        ), catchError((e) => {
            return throwError(e);
        })
    );

    @Effect()
    loadUserImfomationItemsSuccess$: Observable<any> = this.actions$.pipe(
        ofType<any>(fromUserImfomationAction.loadUserInformationsSuccess),
        concatMap((response: any) => [
          fromUserImfomationAction.setUserInformationsInStore(response),
          fromUserImfomationAction.loadRepresentativeUserChoices()
      ])
    );

    @Effect()
    updateUserImfomationItems$: Observable<any> = this.actions$.pipe(
        ofType<any>(fromUserImfomationAction.updateUserInformations),
        map((action: any) => action),
        switchMap((action) =>
        this.dashboardService.postOverrideRepresentative(action.payload)
                .pipe(
                    map((response: any) => {
                        if (response.meta.response_code != 10000) {
                            this.utilsService.errorDialogPopup(response.meta.response_desc, {response: response});
                            return fromUserImfomationAction.updateUserInformationsFailure({ error : response.error });
                        } else {
                            this.utilsService.successDialogPopup();
                            return fromUserImfomationAction.updateUserInformationsSuccess({ payload : response.data});
                        }
                    })
                )
        ), catchError((e) => {
            return throwError(e);
        })
    );

    @Effect()
    updateUserImfomationItemsSuccess$: Observable<any> = this.actions$.pipe(
        ofType<any>(fromUserImfomationAction.updateUserInformationsSuccess),
        map((response: any) => {
            return fromUserImfomationAction.setUserInformationsInStore(response);
        })
    );


    @Effect()
    loadRepresentativeUserChoicesItems$: Observable<any> = this.actions$.pipe(
        ofType<any>(fromUserImfomationAction.loadRepresentativeUserChoices),
        map((action: any) => action),
        switchMap((action) =>
        this.dashboardService.getRepresentativeUserChoices()
                .pipe(
                    map((response: any) => {
                        if (response.meta.response_code != 10000) {
                            this.utilsService.errorDialogPopup(response.meta.response_desc, {response: response});
                            return fromUserImfomationAction.loadRepresentativeUserChoicesFailure({ error : response.error });
                        } else {
                            return fromUserImfomationAction.loadRepresentativeUserChoicesSuccess({ payload : response.data});
                        }
                    })
                )
        ), catchError((e) => {
            return throwError(e);
        })
    );

    @Effect()
    loadRepresentativeUserChoicesItemsSuccess$: Observable<any> = this.actions$.pipe(
        ofType<any>(fromUserImfomationAction.loadRepresentativeUserChoicesSuccess),
        concatMap((response: any) => [
            fromUserImfomationAction.setRepresentativeUserChoicesInStore(response),
            fromAuthAction.environmentVariable()
        ])
    );


}
