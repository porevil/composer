import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import * as fromMenuAction from '../../actions/menu.actions';
import * as fromAuthAction from '../../actions/auths.actions';
import * as fromUserInfomationAction from '../../actions/user-information.actions';
import { AuthenticationService, UtilsService } from '../../../core/services';
import { Observable, throwError } from 'rxjs';
import { map, switchMap, catchError, mergeMapTo, concatMap, concatMapTo } from 'rxjs/operators';



@Injectable()
export class MenuEffects {

    constructor(
        private actions$: Actions,
        private authenticationService : AuthenticationService,
        private utilsService:UtilsService
    ) { }

    @Effect()
    getMenuItems$: Observable<any> = this.actions$.pipe(
        ofType<any>(fromMenuAction.getMenuItems),
        map((action: any) => action),
        switchMap((action) =>
            this.authenticationService.getMenuItems()
                .pipe(
                    map((response: any) => {
                        if (response.meta.response_code != 10000) {
                            this.utilsService.errorDialogPopup(response.meta.response_desc, {response: response});
                            return fromMenuAction.getMenuItemsFailure({ error : response.error });
                        } else {
                            return fromMenuAction.getMenuItemsSuccess({ payload : response.data});
                        }
                    })
                )
        ), catchError((e) => {
            return throwError(e);
        })
    );

    @Effect()
    getMenuItemsSuccess$: Observable<any> = this.actions$.pipe(
        ofType<any>(fromMenuAction.getMenuItemsSuccess),
        concatMap((response: any) => [
            fromMenuAction.setMenuItemsInStore(response),
            fromUserInfomationAction.loadUserInformations()
        ])
    );

    @Effect()
    deleteCacheMenu$: Observable<any> = this.actions$.pipe(
        ofType<any>(fromMenuAction.deleteCacheMenu),
        map((action: any) => action),
        switchMap((action) =>
            this.authenticationService.deleteCacheMenu()
                .pipe(
                    map((response: any) => {
                        if (response.meta.response_code != 10000) {
                            this.utilsService.errorDialogPopup(response.meta.response_desc, {response: response});
                            return fromMenuAction.deleteCacheMenuFailure({ error : response.error });
                        } else {
                            return fromMenuAction.deleteCacheMenuSuccess({ payload : response.data});
                        }
                    })
                )
        ), catchError((e) => {
            return throwError(e);
        })
    );

    @Effect()
    deleteCacheMenuSuccess$: Observable<any> = this.actions$.pipe(
        ofType<any>(fromMenuAction.deleteCacheMenuSuccess),
        map((response: any) => {
            return fromMenuAction.getMenuItems();
        })
    );

    @Effect()
    test$: Observable<any> = this.actions$.pipe(
        ofType<any>(fromAuthAction.environmentVariable),
        map((action: any) => action),
        switchMap((action) =>
            this.authenticationService.getEnvironmentVariable()
                .pipe(
                    map((response: any) => {
                        if (response.meta.response_code != 10000) {
                            this.utilsService.errorDialogPopup(response.meta.response_desc, {response: response});
                            return fromAuthAction.environmentVariableFailure({ error : response.error });
                        } else {
                            return fromAuthAction.environmentVariableSuccess({ payload : response.data});
                        }
                    })
                )
        ), catchError((e) => {
            return throwError(e);
        })
    );

    @Effect()
    environmentVariableSuccess$: Observable<any> = this.actions$.pipe(
        ofType<any>(fromAuthAction.environmentVariableSuccess),
        map(resp => fromAuthAction.setEnvironmentVariableInStore(resp))
    );
}
