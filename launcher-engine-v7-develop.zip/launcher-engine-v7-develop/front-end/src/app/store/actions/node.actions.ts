import { createAction, props } from '@ngrx/store';

export const nextNodes = createAction(
  '[Node] Next Nodes'
);

export const previousNodes = createAction(
  '[Node] Previous Nodes'
);

export const loadNodesSuccess = createAction(
  '[Node] Load Nodes Success',
  props<{ data: any }>()
);

export const loadNodesFailure = createAction(
  '[Node] Load Nodes Failure',
  props<{ error: any }>()
);
