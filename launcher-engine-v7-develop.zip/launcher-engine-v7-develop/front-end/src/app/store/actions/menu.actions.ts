import { createAction, props } from '@ngrx/store';

export const getMenuItems = createAction(
    '[Menu] Load Menu Items'
);

export const getMenuItemsSuccess = createAction(
    '[Menu] Load Menu Items Success',
    props<{ payload: any }>()
);

export const getMenuItemsFailure = createAction(
    '[Menu] Load Menu Items Failure',
    props<{ error: any }>()
);

export const setMenuItemsInStore = createAction(
    '[Menu] Set Menu Items In Store',
    props<{ payload: any }>()
);

export const deleteCacheMenu = createAction(
    '[Menu] Delete Cache Menu'
);

export const deleteCacheMenuSuccess = createAction(
    '[Menu] Delete Cache Menu Success',
    props<{ payload: any }>()
);

export const deleteCacheMenuFailure = createAction(
    '[Menu] Delete Cache Menu Failure',
    props<{ error: any }>()
);