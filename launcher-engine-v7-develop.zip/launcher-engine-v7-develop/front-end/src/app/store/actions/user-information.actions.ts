import { createAction, props } from '@ngrx/store';

export const loadUserInformations = createAction(
  '[UserInformation] Load UserInformations'
);

export const loadUserInformationsSuccess = createAction(
  '[UserInformation] Load UserInformations Success',
  props<{ payload: any }>()
);

export const loadUserInformationsFailure = createAction(
  '[UserInformation] Load UserInformations Failure',
  props<{ error: any }>()
);

export const setUserInformationsInStore = createAction(
  '[UserInformation] Set UserInformations In Store',
  props<{ payload: any }>()
);

export const updateUserInformations = createAction(
  '[UserInformation] Update UserInformations',
  props<{ payload: any }>()
);

export const updateUserInformationsSuccess = createAction(
  '[UserInformation] Update UserInformations Success',
  props<{ payload: any }>()
);

export const updateUserInformationsFailure = createAction(
  '[UserInformation] Update UserInformations Failure',
  props<{ error: any }>()
);

export const setRepresentativeUserChoicesInStore = createAction(
  '[UserInformation] Set RepresentativeUserChoices In Store',
  props<{ payload: any }>()
);

export const loadRepresentativeUserChoices = createAction(
  '[UserInformation] Load RepresentativeUserChoices',
);

export const loadRepresentativeUserChoicesSuccess = createAction(
  '[UserInformation] Load RepresentativeUserChoices Success',
  props<{ payload: any }>()
);

export const loadRepresentativeUserChoicesFailure = createAction(
  '[UserInformation] Load RepresentativeUserChoices Failure',
  props<{ error: any }>()
);