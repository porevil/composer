import { createAction, props } from '@ngrx/store';

export const getFlowRuntime = createAction(
    '[Flow] Load Flow Runtime',
    props<{ payload: { flow_uuid : string, config? : { redirect? : { path : string } }  } }>()
);

export const getFlowRuntimeSuccess = createAction(
    '[Flow] Load Flow Runtime Success',
    props<{ payload: any }>()
);

export const getFlowRuntimeFailure = createAction(
    '[Flow] Load Flow Runtime Failure',
    props<{ error: any }>()
);

export const setFlowRuntimeInStore = createAction(
    '[Flow] Set Flow Runtime In Store',
    props<{ payload: any }>()
);

export const setCurrentNode = createAction(
    '[Flow] Set Current Node',
    props<{ payload: { workflowKey : string, reference_uuid : string} }>()
);

export const setCurrentNodeSuccess = createAction(
    '[Flow] Set Current Node Success',
    props<{ payload: { reference_uuid : string} }>()
);

export const setCurrentNodeFailure = createAction(
    '[Flow] Set Current Node Failure',
    props<{ error: any }>()
);

export const setSequenceFlowRuntimeInStore = createAction(
    '[Flow] Set Sequence Flow Runtime In Store',
    props<{ payload: { reference_uuid : string} }>()
);