import { createAction, props } from '@ngrx/store';

export const getAuthen = createAction(
    '[Authen] Load Authen',
);

export const getAuthenSuccess = createAction(
    '[Authen] Load Authen Success',
    props<{ payload: any }>()
);

export const getAuthenFailure = createAction(
    '[Authen] Load Authen Failure',
    props<{ error: any }>()
);

export const setAuthenInStore = createAction(
    '[Authen] Set Authen In Store',
    props<{ payload: any }>()
);

export const verifyCodeAuthen = createAction(
    '[Authen] Verify Code Authen',
    props<{ payload: any }>()
);

export const verifyCodeAuthenSuccess = createAction(
    '[Authen] Verify Code Authen Success',
    props<{ payload: any }>()
);

export const verifyCodeAuthenFailure = createAction(
    '[Authen] Verify Code Authen Failure',
    props<{ error: any }>()
);

export const setEnvironmentVariableInStore = createAction(
    '[Authen] Set Enviroment Variable In Store',
    props<{ payload: any }>()
);

export const environmentVariable = createAction(
    '[Authen] Enviroment Variable',
);

export const environmentVariableSuccess = createAction(
    '[Authen] Enviroment Variable Success',
    props<{ payload: any }>()
);

export const environmentVariableFailure = createAction(
    '[Authen] Enviroment Variable Failure',
    props<{ error: any }>()
);
