import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ErrorPageComponent } from './error-page/error-page.component';

const routes: Routes = [
    {
        path: 'application/:code',
        loadChildren: () => import('./app-code/app-code.module').then(mod => mod.AppCodeModule)
    },
    {
        path: 'error',
        component: ErrorPageComponent
    },
    {
        path: '',
        redirectTo: 'error',
        pathMatch: "full"
    },
    {
        path: '**',
        redirectTo: "error",
        pathMatch: "full"
    }
    
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }
