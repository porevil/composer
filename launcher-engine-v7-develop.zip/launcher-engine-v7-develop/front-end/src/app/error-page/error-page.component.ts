import { Component, ViewEncapsulation } from '@angular/core';

@Component({
    selector: 'app-error-page',
    templateUrl: './error-page.component.html',
    styleUrls: ['./error-page.component.scss'],
    encapsulation : ViewEncapsulation.None
})
export class ErrorPageComponent {

    constructor() {
        
    }

}
