import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthenticationService, UtilsService } from '../core/services';
import { Store } from '@ngrx/store';
import { AuthsState } from '../store/reducers/auths/auths.reducer';
import * as fromActions from '../store/actions/auths.actions'
// import * as fromMenuAction from '../store/actions/menu.actions'

@Component({
    selector: 'app-authenticate',
    templateUrl: './authenticate.component.html',
    styleUrls: ['./authenticate.component.scss'],
    encapsulation : ViewEncapsulation.None
})
export class AuthenticateComponent implements OnInit {

    constructor(
        private activatedRoute: ActivatedRoute,
        private router: Router,
        private authenticationService: AuthenticationService,
        private utilsService: UtilsService,
        private store: Store<AuthsState>
    ) {
        this._constructorComponent();
    }


    private verificationCode = null;
    private verifyClickFromOkta = null;

    private offSubscribeQueryParams = null;
    private offSubscribeParams = null;
    private appCode = null;


    ngOnInit(): void {
        this._initComponent();
    };

    ngOnDestroy() : void {
        this._destroyComponent();
    };

    private _constructorComponent() : void {
        this.appCode = this.authenticationService.getAppCode(false);
        this.offSubscribeParams = this.activatedRoute.params.subscribe(datas => {
            const verificationCode = datas["verification_code"];
            const verify = datas["verify"];
            if (typeof(verificationCode) == "string" && verificationCode.trim().length > 0) {
                this.verificationCode = verificationCode;
            } 
            if (typeof(verify) == "string" && verify.trim().length > 0) {
                this.verifyClickFromOkta = verify;
            }
        });
    };

    private _initComponent() : void {
        if (window.location.pathname == '/application/' + this.appCode + '/verifycode') {
            this.offSubscribeQueryParams = this.activatedRoute.queryParams.subscribe(
                params => {
                    const code = params['code'];
                    if (!!code) {
                        this.store.dispatch(fromActions.verifyCodeAuthen({ payload: code }))
                    }
                }
            );
        } else {

            if (this.verificationCode != null) {
                this.store.dispatch(fromActions.verifyCodeAuthen({ payload: this.verificationCode }))
            } 
            else {
                if (this.verifyClickFromOkta != null) {
                    this.verifyClickFromOkta = null;
                    this._redirectToLogin()
                } else {
                    this._validateAuthentication();
                }
            }

        }
    };

    private _destroyComponent() : void {
        if(this.offSubscribeQueryParams != null){
            this.offSubscribeQueryParams.unsubscribe();
            this.offSubscribeQueryParams = null;
        }
        if(this.offSubscribeParams != null){
            this.offSubscribeParams.unsubscribe();
            this.offSubscribeParams = null;
        }
    };

    private async _redirectToLogin() : Promise<void> {
        const response = await this.authenticationService.authorizationLoginRedirect().toPromise();
        if(response.meta.response_code != undefined && response.meta.response_code == 10000 && response.data){
            window.location.href = response.data; 
        }
        else {
            this.utilsService.dialogPopup("error", 'เกิดข้อผิดพลาด', response.meta.response_desc, response);
        }
    };

    private _validateAuthentication() {
        const validCookie = this.authenticationService.validCookie("id_token");
        if (!validCookie) {
            this._redirectToLogin();
        } else {
            this.router.navigate(["application",this.appCode,"pages"]);
        }
    };

}
