import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
    selector: 'app-notification',
    templateUrl: './notification.component.html',
    styleUrls: ['./notification.component.scss'],
    encapsulation: ViewEncapsulation.None,
    host: {
        class: 'tc-page-container'
    }
})
export class NotificationComponent {

    constructor() {

    };

    public notifications = [
        {
            id: "1",
            title: 'Notification #1',
            content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nisl magna, cursus vel nulla vitae, tempor varius justo. Integer viverra lorem ut metus facilisis, ac cursus odio tristique. Suspendisse rutrum metus mattis, commodo nisi at, volutpat sem. Donec suscipit hendrerit augue. Nulla eu eros lacinia, placerat massa convallis, auctor tellus. Suspendisse ut faucibus magna. Ut dapibus vestibulum venenatis. Duis et purus fringilla metus consectetur volutpat.",
            received_time: 1581064493000,
            is_read: true
        },
        {
            id: "2",
            title: 'Notification #2',
            content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nisl magna, cursus vel nulla vitae, tempor varius justo. Integer viverra lorem ut metus facilisis, ac cursus odio tristique. Suspendisse rutrum metus mattis, commodo nisi at, volutpat sem. Donec suscipit hendrerit augue. Nulla eu eros lacinia, placerat massa convallis, auctor tellus. Suspendisse ut faucibus magna. Ut dapibus vestibulum venenatis. Duis et purus fringilla metus consectetur volutpat.",
            received_time: 1581064491000,
            is_read: false
        },
        {
            id: "3",
            title: 'Notification #3',
            content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nisl magna, cursus vel nulla vitae, tempor varius justo. Integer viverra lorem ut metus facilisis, ac cursus odio tristique. Suspendisse rutrum metus mattis, commodo nisi at, volutpat sem. Donec suscipit hendrerit augue. Nulla eu eros lacinia, placerat massa convallis, auctor tellus. Suspendisse ut faucibus magna. Ut dapibus vestibulum venenatis. Duis et purus fringilla metus consectetur volutpat.",
            received_time: 1581064492000,
            is_read: false
        },
        {
            id: "4",
            title: 'Notification #4',
            content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nisl magna, cursus vel nulla vitae, tempor varius justo. Integer viverra lorem ut metus facilisis, ac cursus odio tristique. Suspendisse rutrum metus mattis, commodo nisi at, volutpat sem. Donec suscipit hendrerit augue. Nulla eu eros lacinia, placerat massa convallis, auctor tellus. Suspendisse ut faucibus magna. Ut dapibus vestibulum venenatis. Duis et purus fringilla metus consectetur volutpat.",
            received_time: 1581064492000,
            is_read: true
        },
        {
            id: "5",
            title: 'Notification #5',
            content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nisl magna, cursus vel nulla vitae, tempor varius justo. Integer viverra lorem ut metus facilisis, ac cursus odio tristique. Suspendisse rutrum metus mattis, commodo nisi at, volutpat sem. Donec suscipit hendrerit augue. Nulla eu eros lacinia, placerat massa convallis, auctor tellus. Suspendisse ut faucibus magna. Ut dapibus vestibulum venenatis. Duis et purus fringilla metus consectetur volutpat.",
            received_time: 1581064492000,
            is_read: true
        }
    ];

    public selectedNotification = null;

    // view functions
    public btnNotification(notification: any): void {
        if (this.selectedNotification == null || this.selectedNotification.id != notification.id) {
            this.selectedNotification = notification;
        }
        else {
            this.selectedNotification = null;
        }
    };





}
