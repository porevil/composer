import { Component, ViewEncapsulation, ViewChild, OnInit } from '@angular/core';
import { DashboardService, UtilsService } from 'src/app/core/services';

import { OverrideDataOwnerModalComponent } from '../../shared/components/override-data-owner-modal/override-data-owner-modal.component';
import { Subscription } from 'rxjs';
import { Store } from '@ngrx/store';
import { State } from 'src/app/store/reducers';
import * as fromRoot from '../../store/reducers/index'
@Component({
    selector: 'app-dashboard',
    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class DashboardComponent implements OnInit {

    @ViewChild('modalOverrideDataOwner', {static:true}) modalOverrideDataOwner: OverrideDataOwnerModalComponent;

    constructor(
        private store:Store<State>
    ) { 
        this._contructorComponent();
    };

    DashboardStateSubscription:Subscription
    
    ngOnInit(){
    }

    public userInformation = null;

    private async _contructorComponent() {
        this.DashboardStateSubscription = this.store.select(fromRoot.getUserInfomationState).subscribe(async (user)=>{
            this.userInformation = user
        })
        this.DashboardStateSubscription = this.store.select(fromRoot.getUserRepresentativeState).subscribe(async (representative)=>{
            if(representative && representative.popup === true){
                const modalInstance = this.modalOverrideDataOwner.show(representative.choices.branches, representative.choices.representations)
                await modalInstance.closed;
            }
        })
    };
}
