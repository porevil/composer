import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


import { PagesComponent } from './pages.component';

const routes: Routes = [
  {
    path: '',
    component: PagesComponent,
    children: [
      {
          path : '',
          pathMatch : 'full',
          redirectTo : 'dashboard'
      },
      {
          path : 'flow/:flowId',
          loadChildren : () => import('../pages/flow-controller/flow-controller.module')
              .then(mod => mod.FlowControllerModule)
      },
      {
          path : 'dashboard',
          loadChildren : () => import('../pages/dashboard/dashboard.module')
              .then(mod => mod.DashboardModule)
      },
      {
          path : 'notifications',
          loadChildren : () => import('../pages/notification/notification.module')
              .then(mod => mod.NotificationModule)
      }            
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PagesRoutingModule { }
