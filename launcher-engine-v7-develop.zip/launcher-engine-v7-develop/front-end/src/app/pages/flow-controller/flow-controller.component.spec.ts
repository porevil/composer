import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FlowControllerComponent } from './flow-controller.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { FlowService, CommonService, ArrayService, StringService } from '../../shared/utils';
import { RouterModule } from '@angular/router';

describe('FlowControllerComponent', () => {
  let component: FlowControllerComponent;
  let fixture: ComponentFixture<FlowControllerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FlowControllerComponent ],
      providers:[FlowService,CommonService,ArrayService,StringService],
      imports: [
        RouterTestingModule,
        HttpClientModule,
        RouterModule.forRoot([])
    ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FlowControllerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });
});
