import { Component, ViewEncapsulation, ViewContainerRef, Injector } from '@angular/core';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';
import * as $ from 'jquery';

import { AuthenticationService, FlowService } from '../../../core/services'; 
import { FlowControllerComponent } from '../flow-controller.component';
import { CommonService } from 'src/app/shared/utils';
declare const window : any;
@Component({
    selector: 'screen-node-page',
    templateUrl: './screen-node-page.component.html',
    styleUrls: ['./screen-node-page.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class ScreenNodePageComponent {


    constructor(
        private activatedRoute: ActivatedRoute,
        private router: Router,
        private viewRef: ViewContainerRef,
        private authenticationService : AuthenticationService,
        private commonService: CommonService,
        private flowService : FlowService,
        private injector: Injector
    ) {
        this._contructorComponent();
    };

    public offRouteChange = null;
    public parentControls : FlowControllerComponent = null;
    public httpClient = null;
    public loaderService = null;
    public appCode = null;


    public btnSelectItem(item: any): void {
        // console.debug(item);
    };

    private ngAfterViewInit(): void {
        this._afterViewInitComponent();
    };

    private ngOnDestroy() {
        this._destroyComponent();
    };
     
    private _contructorComponent(): void {
        this.appCode = this.authenticationService.getAppCode(true);
        this.httpClient = this.flowService.httpClient;
        this.loaderService = this.flowService.loaderService;
        this._initParentControls();
    };

    private async _afterViewInitComponent(): Promise<void> {
        await this.commonService.sleep(10);
        this._runInstance();
        this._initRouteDetectionChange();
    };

    private _destroyComponent(): void {
        this._destroyRouteDetectionChange();
    };

    private _getQueryParams() : {
        flowId : string,
        workflowKey : string,
        nodeSequence : number,
        reference_uuid : string
    } {
        const params = this.activatedRoute.snapshot.params;
        const parentParams = this.activatedRoute.parent.snapshot.params;
        const flowId = parentParams.flowId;
        const workflowKey = params.workflowKey;
        const nodeSequence = params.nodeSequence;
        const reference_uuid = params.reference_uuid;
        return {
            flowId: flowId,
            workflowKey : workflowKey,
            nodeSequence: +nodeSequence,
            reference_uuid : reference_uuid
        };
    };

    private _initParentControls(): void {
        this.parentControls = this.injector.get(FlowControllerComponent);
    };

    private _initRouteDetectionChange(): void {
        this._destroyRouteDetectionChange();
        this.offRouteChange = this.router.events.subscribe(event => {
            if (event instanceof NavigationEnd) {
                this._runInstance();
            }
        });
    };

    private _destroyRouteDetectionChange(): void {
        if (this.offRouteChange != null) {
            this.offRouteChange.unsubscribe();
        }
    };

    private _sleep(milisecond : number) : Promise<any>{
        return new Promise((resolve)=>{
            setTimeout(()=>{resolve()}, milisecond);
        });
    };

    private _clearMBSElement(): void {
        const viewEle = $(this.viewRef.element.nativeElement);
        viewEle.find('.screen-node-container').html("");
    };

    private _getTagNameOfMBSElement(instance : any) : string {
        return `mbs-${instance.uuid}`;
    };

    private _setInstanceRuntimeVariable(instance : any) : void {
        window.launcher.instance_url = instance.url.replace(/(.*)(\/home)/,"$1");
    };

    private async _appendMBSScript(instance : any, workflowKey: string) : Promise<void>{
        const url= `${instance.url}?wfk=${workflowKey}`;
        const options = { 
            responseType: 'text',
            headers : {
                "is-by-pass" : "true"
            }
        };
        await this.httpClient.get(url,options).toPromise();
        if($('body').find(`[name="${instance.uuid}"]`).length == 0){
            const jsEle = $(`<script name="${instance.uuid}" src="${url}" />`);
            $('body').append(jsEle);
        } 
    };

    private _appendMBSElement(instance : any) : void {
        const mbsContainerEle = document.querySelector('.screen-node-container');
        const tag = this._getTagNameOfMBSElement(instance);
        const mbsEle = document.createElement(tag);
        mbsEle['httpClient'] = this.httpClient;       
        mbsEle['loaderService'] = this.loaderService; 
        mbsContainerEle.appendChild(mbsEle);
    };

    private async _appendMBS(instance : any, workflowKey : string): Promise<any> {
        this._setInstanceRuntimeVariable(instance);
        await this._appendMBSScript(instance, workflowKey);
        await this._sleep(100);
        this._appendMBSElement(instance);
        await this._sleep(100);
        this._bindActionEventOfMBS(instance);
        
    };

    private async _runInstance(): Promise<any> {
        let query  = this._getQueryParams();
        if(this.parentControls.isStartedFlow()){
            this._clearMBSElement();            
            const instance = this.parentControls.getInstance(query.reference_uuid);
            await this._appendMBS(instance, query.workflowKey);
        }
        else {
            let urls = ['application',this.appCode,'pages','flow', query.flowId];
            this.router.navigate(urls);
        }
    };

    private _bindActionEventOfMBS(instance : any) : void {
        const tag = this._getTagNameOfMBSElement(instance);
        const buttonEle = document.querySelector(tag);
        buttonEle.addEventListener('action', (event: any) => {
            if(event.detail.action == 'back'){
                this.parentControls.previousNode();
            }
            else {
                this.parentControls.nextNode();
            }            
        });
    };

}