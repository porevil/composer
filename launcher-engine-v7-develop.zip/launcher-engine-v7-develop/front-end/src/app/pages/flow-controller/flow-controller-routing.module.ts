import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';



import {
  FlowControllerComponent
} from './flow-controller.component';
import { ScreenNodePageComponent } from '../flow-controller/screen-node-page/screen-node-page.component';
import { ServiceNodePageComponent } from '../flow-controller/service-node-page/service-node-page.component';
import { FlowResultPageComponent } from './flow-result-page/flow-result-page.component';

export const pages = [
  FlowControllerComponent,
  ScreenNodePageComponent,
  ServiceNodePageComponent,
  FlowResultPageComponent
];

const routes: Routes = [
  {
      path : '',
      component : FlowControllerComponent,
      children : [
          {
              path : ':workflowKey/:reference_uuid/screen',
              component : ScreenNodePageComponent
          },
          {
              path : ':workflowKey/:reference_uuid/service',
              component : ServiceNodePageComponent
          },
          {
              path : ':workflowKey/result',
              component : FlowResultPageComponent
          }
      ]
  }
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FlowControllerRoutingModule { }
