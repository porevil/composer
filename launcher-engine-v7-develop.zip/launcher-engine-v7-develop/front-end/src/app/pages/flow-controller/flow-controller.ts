
export interface Flow {
    workflow_key : any,
    instances : Array<Instance>
};

export interface Instance {
    id : any,
    code : any,
    type : InstanceType,
    name : string,
    display_label? : string,    
    intents? : {
        in? : Array<IntentIn>
    },
    service_type? : InstanceServiceType,
    response_type? :  InstanceResponseType,
    hidden_node? : boolean,
    open_access? : boolean,
    member_instances? : Array<MemberInstance>
};

export interface IntentIn {
    vtype : string,
    vtype_input_component : InputComponentType,
    name : string,
    required : boolean,
    value : any,
    type : InputContentType,
    vtype_input_options : string
};

export interface MemberInstance{
    uuid : any,
    sequence : any,
    url : string
}

export enum InputComponentType {
    DatePicker = 'datepicker',
    TextBox  = 'textbox',
    Checkbox = 'checkbox',
    Radio = 'radio',
    Toggle ='toggle',
    Dropdown = 'dropdown',
    TimePicker = 'timepicker'
};

export enum InputContentType {
    Number = 'number',
    Text = 'text'
};

export enum InstanceServiceType {
    Sync = 'sync',
    Async = 'async'
};

export enum InstanceResponseType {
    Display = 'display',
    JSON = 'json'
};

export enum InstanceType {
    Screen = 'screen',
    Service = 'service'
};