import { Component, ViewEncapsulation, HostListener } from '@angular/core';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';
import { Store } from '@ngrx/store';
import { State } from '../../store/reducers';
import * as fromFlowAction from '../../store/actions/flow.actions';
import * as fromRoot from 'src/app/store/reducers/index';
import { Subscription } from 'rxjs';

import { AuthenticationService } from '../../core/services'; 
import { StringService } from 'src/app/shared/utils';

declare const $: any;
declare const window : any;
@Component({
    selector: 'flow-controller-page',
    templateUrl: './flow-controller.component.html',
    styleUrls: ['./flow-controller.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class FlowControllerComponent {


    constructor(
        private activatedRoute: ActivatedRoute,
        private router: Router,
        private authenticationService : AuthenticationService,
        private stringService : StringService,
        private store: Store<State>,
    ) {
        this._contructorComponent();
    };

    // component variables
    public appCode = null;
    public styleEle = null;
    public flowRuntime = null;
    public flowRuntimeStateSubscription : Subscription = null;
    public meatballControls = {
        enabled : false,
        currentId : null,
        items : [],
        cache : {}
    };

    public offRouteChange = null;
    public flowId = null;
    public instanceId = null;
    public workflowKey = null;
    public enabledNextButton = true;

    public isCollapsed = false;

    private ngOnDestroy() {
        this._destroyComponent();
    };

    public isPress = false;
    @HostListener('document:keydown.alt.control.n', ['$event'])
    private handleKeyDownboardEvent(event: KeyboardEvent) {
        if (!this.isPress) {
            this.isPress = true;
            this._gotoNextNode();
        }
    };

    @HostListener('document:keyup', ['$event'])
    private handleKeyUpboardEvent(event: KeyboardEvent) {
        this.isPress = false;
    };


    // private functions
    private _contructorComponent(): void {
        this.appCode = this.authenticationService.getAppCode(true);
        this.store.dispatch(fromFlowAction.setFlowRuntimeInStore({ payload : null }));
        this._initFlowRuntimeState();
        this._initRouteDetectionChange();  
    };

    private _destroyComponent(): void {        
        this._destroyRouteDetectionChange();
        this._destroyFlowRuntimeState();
        this._removeStylePage();
    };

    private _setFlowRuntimeVariable(flowRuntime : any) : void {
        window.launcher = {};
        window.launcher.user_id = flowRuntime?.login_info?.user_id || null;
        window.launcher.workflow_key = flowRuntime?.workflow_key || null;
    };

    private _initFlowRuntimeState() : void {
        this._destroyFlowRuntimeState();
        this.flowRuntimeStateSubscription = this.store.select(fromRoot.getFlowRuntimeState).subscribe((flowRuntime)=>{
            if(flowRuntime != null){

                this.flowRuntime = JSON.parse(JSON.stringify(flowRuntime));
                this._setFlowRuntimeVariable(this.flowRuntime);

                // const regex = new RegExp('mbs-(?<tag>.*).js');
                // for(const node of this.flowRuntime.nodes){
                //     for(const instance of node.instances){
                //         if(this.flowRuntime.uuid != "77a1bc02-b36c-4b01-8a6c-b44ae4cb106a"){
                //             instance.url = "assets/temp/web-components/templates/mbs-templates-i9-identity-1.js";
                //         }                        
                //         instance.uuid = instance.url.match(regex)?.groups?.tag || instance.uuid;
                //     }
                // }
                
                const instanceSequence = this.flowRuntime.current_instance_sequence;
                const current_reference_uuid = this.flowRuntime.current_reference_uuid;
                const nodeSequence = this.getInstance(current_reference_uuid).sequence

                this._gotoInstance(current_reference_uuid);
                this._setEnabledNextButton(true);
                this._setCacheStep(nodeSequence,instanceSequence);
                this._reloadStepProgressBar();
                this._setEnabledStepProgressBar(true);
            }
        });  
    };

    private _destroyFlowRuntimeState() : void {
        if(this.flowRuntimeStateSubscription != null){
            this.flowRuntimeStateSubscription.unsubscribe();
        }
    };

    private _getQueryParams(): {
        flowId : string,
        workflowKey : string,
        instanceId : string
    } {
        let params = this.activatedRoute.snapshot.params;
        const childParams = this.activatedRoute.firstChild?.snapshot.params;
        const flowId = params.flowId;
        const instanceId = childParams?.instanceId;
        const workflowKey = childParams?.workflowKey;
        return {
            flowId: flowId,
            workflowKey: workflowKey,
            instanceId: instanceId            
        };
    };

    private _initRouteDetectionChange(): void {
        this._destroyRouteDetectionChange();
        this.offRouteChange = this.router.events.subscribe(event => {
            if (event instanceof NavigationEnd) {
                this._runFlow();
            }
        });
    };

    private _destroyRouteDetectionChange(): void {
        if (this.offRouteChange != null) {
            this.offRouteChange.unsubscribe();
        }
    };

    private _addStylePage(): void {
        this.styleEle = $('<style />');
        this.styleEle.append('home-master-page .app-breadcrumb-wrapper{ border-bottom : none; }');
        this.styleEle.appendTo('body')
    };

    private _removeStylePage(): void {
        this.styleEle?.remove();
    };

    private async _runFlow(): Promise<void> {
        const query = this._getQueryParams();
        const workflowKey = query.workflowKey;
        const flowId = query.flowId;
        if(!this.stringService.isNotUndifiedAndNullAndEmpty(workflowKey)
            && this.stringService.isNotUndifiedAndNullAndEmpty(flowId)){        
            this._setEnabledStepProgressBar(false);    
            this.store.dispatch(fromFlowAction.getFlowRuntime({ payload : { 
                flow_uuid : flowId,
                config : { redirect : { path : 'pages' } }
            }})); 
        }
    };

    private _getInstance(reference_uuid : string) : any {
        const instance = this.flowRuntime?.instances.find(instance => instance.reference_uuid == reference_uuid);

        return instance || null;
    };

    private _gotoInstance(reference_uuid : string) : void {
        const instance = this._getInstance(reference_uuid);
        let urls = ['application',this.appCode,'pages','flow'];
        urls = [ ...urls,...[this.flowRuntime.uuid, this.flowRuntime.workflow_key, reference_uuid]];
        if (instance.instance_type != 3) {
            urls.push('screen')
        }
        else if (instance.instance_type == 3) {
            urls.push('service')
        }
        this.router.navigate(urls);
    };

    private _gotoFlowResult() : void {
        this._setEnabledStepProgressBar(false);
        let urls = ['application',this.appCode,'pages','flow'];
        urls = [ ...urls,...[this.flowRuntime.uuid, this.flowRuntime.workflow_key, 'result']];
        this.router.navigate(urls);
    };

    private _gotoNode(reference_uuid : string): void {
        this.store.dispatch(fromFlowAction.setCurrentNode({ payload : {
            workflowKey : this.flowRuntime.workflow_key,
            reference_uuid : reference_uuid,
        }}));
    };

    private _gotoNextNode(): void {
        const instance = this._getInstance(this.flowRuntime.current_reference_uuid);
        if(instance.next_instances.length == 0){
            this._gotoFlowResult();
        }
        else {
            this._gotoNode(instance.next_instances[0].reference_uuid);
        }       
    };

    private _gotoPreviousNode() : void {
        const current_reference_uuid = this.flowRuntime.current_reference_uuid;
        const previousInstance = this.flowRuntime.instances.find(instance => instance.next_instances.find(nextInstance => nextInstance.reference_uuid == current_reference_uuid))
        if(previousInstance){
            // const cache = this._getCacheStep(this.getInstance(previousInstance).sequence);
            this._gotoNode(previousInstance.reference_uuid);
        }
    };

    private _setCacheStep(nodeSequence : number, instanceSequence : number) : void {
        this.meatballControls.cache[nodeSequence] = {
            instanceSequence : instanceSequence
        };
        for(let i in this.meatballControls.cache){
            if(+i > nodeSequence){
                delete this.meatballControls.cache[i];
            }
        }
    };

    private _getCacheStep(nodeSequence : number) : any {
        return this.meatballControls.cache[nodeSequence] || null;
    };

    private _reloadStepProgressBar(): void {
       const instances = this.flowRuntime.instances.sort((a,b) => a.sequence - b.sequence).map(instance => ({...instance, id : instance.reference_uuid }));
        let finished = true;
        let enabled = true;
        this.meatballControls.currentId = this.flowRuntime.current_reference_uuid;
        this.meatballControls.items = instances.map(instance => {
            if (instance.id == this.flowRuntime.current_reference_uuid) {
                finished = false;
                enabled = false;
            }
            return {
                id: instance.id,
                title: instance?.display_label || instance?.name || "",
                finished: finished,
                enabled: enabled || instance?.open_access || true,
                instance: instance,
            };
        });
    };


    private _setEnabledNextButton(enabled: boolean): void {
        this.enabledNextButton = enabled;
    };

    private _setEnabledStepProgressBar(enabled: boolean) : void {
        this.meatballControls.enabled = enabled;
        if(enabled){
            this._addStylePage();
        }
        else {
            this._removeStylePage();
        }
    };
    
    private _isStartedFlow() : boolean {
        const query = this._getQueryParams();
        return this.flowRuntime?.workflow_key == query.workflowKey;
    };



    public getInstance(reference_uuid : string) : any {
        return this._getInstance(reference_uuid);
    };

    public isStartedFlow() : boolean {
        return this._isStartedFlow();
    };

    public setEnabledNextButton(enabled: boolean): void {
        this._setEnabledNextButton(enabled);
    };

    public nextNode(): void {
        this._gotoNextNode();
    };

    public previousNode() : void {
        this._gotoPreviousNode();
    };

    public btnNextNode(): void {
        this._gotoNextNode();
    };

    public onExpandedStepProgressbar($event) : void {
        $($event._el.nativeElement).css('overflow','visible');
    };
 
    public onClickStepItem($event: any): void {
        const stepItem = $event.stepItem;
        this._gotoNode(stepItem.instance.reference_uuid);
    };

}