import { Component, ViewEncapsulation, ViewChild, Injector } from '@angular/core';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';
import { InstanceResponseType } from '../flow-controller'
import { FlowControllerComponent } from '../flow-controller.component';
import { ArrayService, FlowService } from 'src/app/shared/utils';


@Component({
    selector: 'service-node-page',
    templateUrl: './service-node-page.component.html',
    styleUrls: ['./service-node-page.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class ServiceNodePageComponent {

    @ViewChild('inputsModal') inputsModal: any;

    constructor(
        private activatedRoute: ActivatedRoute,
        private router: Router,
        private arrayService: ArrayService,
        private flowService: FlowService,
        private injector: Injector
    ) {
        this._contructorComponent();
    };

    public offRouteChange = null;
    public parentControls = null;
    public flowId = null;
    public instanceId = null;
    public instance = {
        intents: {
            in: [
                {
                    vtype: 'input',
                    vtype_input_component: 'datepicker',
                    name: "Date Picker",
                    required: false,
                    value: null,
                    type: 'text',
                    vtype_input_options: null
                },
                {
                    vtype: 'input',
                    vtype_input_component: 'textbox',
                    name: "Textbox",
                    required: false,
                    value: null,
                    type: 'text',
                    vtype_input_options: null
                },
                {
                    vtype: 'input2',
                    vtype_input_component: 'checkbox',
                    name: "Checkbox",
                    required: true,
                    value: undefined,
                    type: 'text',
                    vtype_input_options: ""
                },
                {
                    vtype: 'input2',
                    vtype_input_component: 'radio',
                    name: "Radio",
                    required: true,
                    value: undefined,
                    type: 'text',
                    vtype_input_options: ""
                },
                {
                    vtype: 'input2',
                    vtype_input_component: 'toggle',
                    name: "Toggle",
                    required: false,
                    value: undefined,
                    type: 'text',
                    vtype_input_options: ""
                },
                {
                    vtype: 'input2',
                    vtype_input_component: 'dropdown',
                    name: "Dropdown",
                    required: false,
                    value: null,
                    type: 'text',
                    vtype_input_options: "1:Option 1,2:Option 2,3:Option 3"
                },
                {
                    vtype: 'input2',
                    vtype_input_component: 'timepicker',
                    name: "Timepicker",
                    required: false,
                    value: null,
                    type: 'text',
                    vtype_input_options: null
                }
            ]
        },
        service_type: '',
        response_type: ''
    };


    private ngAfterViewInit(): void {
        this._afterViewInitComponent();
    };

    private ngOnDestroy() {
        this._destroyComponent();
    };

    // private functions
    private _contructorComponent(): void {
        this._initParentControls();
    };

    private _afterViewInitComponent(): void {
        setTimeout(() => {
            this._runInstance();
            this._initRouteDetectionChange();
        });
    };

    private _destroyComponent(): void {
        this._destroyRouteDetectionChange();
    };

    private _getQueryParams(): any {
        const params = this.activatedRoute.snapshot.params;
        const parentParams = this.activatedRoute.parent?.snapshot.params;
        const flowId = parentParams?.flowId;
        const instanceId = params.instanceId;
        return {
            flowId: flowId,
            instanceId: instanceId
        };
    };

    private _initParentControls(): void {
        this.parentControls = this.injector.get(FlowControllerComponent);
    };

    private _initRouteDetectionChange(): void {
        this._destroyRouteDetectionChange();
        this.offRouteChange = this.router.events.subscribe(event => {
            if (event instanceof NavigationEnd) {
                this._runInstance();
            }
        });
    };

    private _destroyRouteDetectionChange(): void {
        if (this.offRouteChange != null) {
            this.offRouteChange.unsubscribe();
        }
    };

    private _runDisplayService(overrideIntents: Array<any>): void {

    };

    private _runService(overrideIntents: Array<any>): void {

    };

    private async _runInstance(): Promise<any> {

        const query = this._getQueryParams();
        this.flowId = query.flowId;
        this.instanceId = query.instanceId;
        // console.debug(query);

        const instance = this.instance;
        const responseType = instance.response_type;
        let isCallSevice = true;

        const overrideIntents = this.arrayService.findItems(
            instance.intents.in,
            {
                vtype: 'input'
            }
        );

        if (overrideIntents.length > 0) {
            // const ref = this.inputsModal.open('โปรดระบุข้อมูลเงื่อนไข', overrideIntents);
            // const result = await ref.closed;
            // isCallSevice = result.isSubmit;
        }

        if (isCallSevice) {
            if (responseType == InstanceResponseType.Display) {
                this._runDisplayService(overrideIntents);
            }
            else {
                this._runService(overrideIntents);
            }
        }

    };

    // view functions

}