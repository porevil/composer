import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { TimepickerModule } from 'ngx-bootstrap/timepicker';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { CollapseModule } from 'ngx-bootstrap/collapse';
import { ButtonsModule } from 'ngx-bootstrap/buttons';

import { SharedModule } from '../../shared';

import { FlowControllerRoutingModule, pages } from './flow-controller-routing.module';
import { RouterTestingModule } from '@angular/router/testing';

// import {
//     InstanceInputsModalComponent
// } from './components';

const components = [
    // InstanceInputsModalComponent
];

const bootstrapModules = [
    TimepickerModule.forRoot(),
    BsDatepickerModule.forRoot(),
    ButtonsModule.forRoot(),
    CollapseModule.forRoot()
];

@NgModule({
    declarations: [
        ...pages,
        ...components
    ],
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        ...bootstrapModules,
        SharedModule,
        FlowControllerRoutingModule
    ],
    providers: [],
    exports : [
        ...components
    ],
    schemas: [ CUSTOM_ELEMENTS_SCHEMA ] 
})

export class FlowControllerModule { }
