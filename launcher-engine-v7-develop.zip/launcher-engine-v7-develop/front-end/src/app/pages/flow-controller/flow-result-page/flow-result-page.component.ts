import { Component, Injector, ViewEncapsulation } from '@angular/core';
import { FlowControllerComponent } from '../flow-controller.component';
import { Router } from '@angular/router';

@Component({
    selector: 'flow-result-page',
    templateUrl: './flow-result-page.component.html',
    styleUrls: ['./flow-result-page.component.scss'],
    encapsulation : ViewEncapsulation.None
})
export class FlowResultPageComponent {

    public parentControls = null;


    constructor(
        private injector : Injector,
        private router : Router
    ){
        this._contructorComponent();
    };

    // private functions
    private _contructorComponent() : void {
        this._initParentControls();
        this.parentControls.setEnabledNextButton(false);
    };

    private _initParentControls() : void {
        this.parentControls = this.injector.get(FlowControllerComponent);
    };

    public btnOK() : void {
        this.router.navigate(['application/65']);
    };

}
