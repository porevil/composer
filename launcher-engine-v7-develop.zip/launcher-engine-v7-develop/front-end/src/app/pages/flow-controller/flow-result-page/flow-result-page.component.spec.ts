import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FlowResultPageComponent } from './flow-result-page.component';

describe('FlowResultPageComponent', () => {
  let component: FlowResultPageComponent;
  let fixture: ComponentFixture<FlowResultPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FlowResultPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FlowResultPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
