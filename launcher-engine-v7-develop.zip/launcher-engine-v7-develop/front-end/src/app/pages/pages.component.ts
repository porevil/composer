import { Component, ViewEncapsulation, ViewChild, OnInit} from '@angular/core';
import { Router, NavigationEnd, ActivatedRoute } from '@angular/router';

import { Store } from '@ngrx/store';
import { State } from '../store/reducers/index';
import  * as fromMenuAction from '../store/actions/menu.actions'
import * as fromRoot from 'src/app/store/reducers/index';
import { Subscription } from 'rxjs';

import { AppMenuComponent } from '../shared/components';
import { AuthenticationService } from '../core/services';
import { StringService, CommonService, PlatformService } from '../shared/utils';


@Component({
    selector: 'home-master-page',
    templateUrl: './pages.component.html',
    styleUrls: ['./pages.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class PagesComponent implements OnInit {

    @ViewChild('appMenu', { static: true }) appMenu: AppMenuComponent;
    menuSubscription: any;

    constructor(
        private router: Router,
        private stringService: StringService,
        private commonService : CommonService,
        private platformService : PlatformService,
        public _activatedRoute: ActivatedRoute,
        private store: Store<State>,
        private authenticationService : AuthenticationService
    ) {
        this._constructorComponent();
    };

    public appTitle = "";
    public opendMenu = false;
    public menuItems = [];
    public breadcrumbTitle = "";
    public breadcrumbItems = [
        {
            title: 'Home'
        }
    ];
    public userInfo = null;
    public offRouteChange = null;
    public menuItemsSubscription : Subscription = null;
    public envSubscription : Subscription = null;


    public ngOnInit() : void {
        this.authenticationService.startSessionTimeoutWarning();
        this.envSubscription = this.store.select(fromRoot.getEnvironmentVariableState).subscribe((response:any)=>{
            if(response.okta_service_endpoint){
                this.authenticationService.sessionTimeoutConfig.endSessionRedirect = response.okta_service_endpoint
            }
        });
    };

    private ngOnDestroy() : void {
        this.authenticationService.stopSessionTimeoutWarning();
        this._destroyComponent();
    };

    private ngAfterViewInit() : void {
        this._initRouteDetectionChange();
    };

    private _constructorComponent(): void {
        this.opendMenu = this.platformService.isDesktop();
        this._getUserInfo();
        this._initMenuItemsState();
        this.store.dispatch(fromMenuAction.getMenuItems());
    };

    private _destroyComponent(): void {
        this._destroyRouteDetectionChange();
        this._destroyMenuItemsState();
    };

    private _initRouteDetectionChange(): void {
        this.router.events.subscribe(event => {
            if (event instanceof NavigationEnd) {
                this._highlightMenuItem();
            }
        });
    };

    private _destroyRouteDetectionChange(): void {
        if (this.offRouteChange != null) {
            this.offRouteChange.unsubscribe();
        }
    };

    private _destroyMenuItemsState() : void {
        if (this.menuItemsSubscription != null) {
            this.menuItemsSubscription.unsubscribe();
        }
    };

    private _initMenuItemsState() : void {
        this._destroyMenuItemsState();
        this.menuItemsSubscription = this.store.select(fromRoot.getMenuItemsInMenuState).subscribe(menuItems=>{
            let data = JSON.parse(JSON.stringify(menuItems));
            this.menuItems = data || [];
            if(this.menuItems.length > 0){
                const promise = this.commonService.sleep(100);
                promise.then(()=>{
                    this._highlightMenuItem();
                });
            }
        });
    };

    private _getUserInfo() : void {
        this.userInfo = this.authenticationService.getUserInfo();
    };

    private _setHeader(menuItem : any, childMenuItem? : any) : void {
        // this.appTitle = menuItem.display_label;
        // this.breadcrumbTitle = childMenuItem?.display_label || this.appTitle;
    };

    private _highlightMenuItem(): void {
        const url = this.router.url;
        for (let i in this.menuItems) {
            const menuItem = this.menuItems[i];
            if (this.stringService.isNotUndifiedAndNullAndEmpty(menuItem.url)) {
                const regex = new RegExp(`(\\${menuItem.url})(\\b|\\/)`);
                if (url.match(regex)) {
                    this._setHeader(menuItem);
                    this.appMenu.highlightMenuItem(menuItem.code);
                    break;
                }
            }
            else {
                const childItem = menuItem?.flows?.find(childItem => {
                    const regex = new RegExp(`(\\/flow\\/${childItem.uuid})(\\b|\\/)`);
                    return !!url.match(regex);
                });
                if(!!childItem){
                    this._setHeader(menuItem,childItem);
                    this.appMenu.highlightChildMenuItem(childItem.uuid);
                    break;
                }
            }
        }
    };

    private _onRefreshMenuItem() : void {
        this.store.dispatch(fromMenuAction.deleteCacheMenu());
    };

    public onClickMenuItem($event: any): void {
        const appCode = this.authenticationService.getAppCode(true);
        const menuItem = $event.menuItem;
        this._setHeader(menuItem);
        if(!this.platformService.isDesktop()){
            this.opendMenu = false;
        }
        if (this.stringService.isNotUndifiedAndNullAndEmpty(menuItem.url)) {
            this.router.navigate([`/application/${appCode}/pages${menuItem.url}`]);
        }
    };

    public onClickChildMenuItem($event: any): void {
        const appCode = this.authenticationService.getAppCode(true);
        const menuItem = $event.menuItem;
        const childMenuItem = $event.childMenuItem;
        this._setHeader(menuItem,childMenuItem);
        if(!this.platformService.isDesktop()){
            this.opendMenu = false;
        }
        this.router.navigate(['application', appCode, 'pages','flow', childMenuItem.uuid]);
    };

    public btnOpenMenu(): void {
        this.opendMenu = !this.opendMenu;
    };

    public onRefreshMenuItem() : void {
        this._onRefreshMenuItem();
    };

}