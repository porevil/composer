import { Injectable } from '@angular/core';

import { CommonService } from '../common/common.service';
import { ArrayService } from '../array/array.service';
import { Flow,Instance, } from '../../../pages/flow-controller/flow-controller';

@Injectable()
export class FlowService {

    constructor(
        private commonService : CommonService,
        private arrayService : ArrayService
    ){

    };

    private flows = {};

    private _createFlow(workflowKey : any, flow : any) : Flow {
        this.flows[workflowKey] = flow;
        return flow;
    };

    private _getFlow(workflowKey : any) : Flow {
        const currentFlow = this.flows[workflowKey];
        if(this.commonService.isUndefinedOrNull(currentFlow)){
            return null;
        }
        return currentFlow;
    };

    private _getInstance(workflowKey : any, instanceId : any) : Instance {
        const flow = this._getFlow(workflowKey);
        if(flow == null){
            return null;
        }
        const instance = <Instance>this.arrayService.findItem(
            flow.instances,
            {
                id : instanceId
            }
        );
        return instance;
    };

    private _getNextInstance(workflowKey : any, currentInstanceId : any) : Instance{
        const flow = this._getFlow(workflowKey);
        if(flow == null){
            return null;
        }
        const currentInstance = this._getInstance(workflowKey,currentInstanceId);
        const index = flow.instances.indexOf(currentInstance);
        if(flow.instances.length ==  index + 1){
            return null;
        }
        return flow.instances[index + 1];
    };

    private _getPreviousInstance(workflowKey : any, currentInstanceId : any) : Instance {
        const flow = this._getFlow(workflowKey);
        if(flow == null){
            return null;
        }
        const currentInstance = this._getInstance(workflowKey,currentInstanceId);
        const index = flow.instances.indexOf(currentInstance);
        if(index - 1 < 0){
            return null;
        }
        return flow.instances[index - 1];
    };

    // public functions 
    public createFlow(workflowKey : any, flow : any) : Flow {
        return this._createFlow(workflowKey, flow);
    };

    public getFlow(workflowKey : any) : Flow {
        return this._getFlow(workflowKey);
    };

    public getInstance(workflowKey : any, instanceId : any) : Instance {
        return this._getInstance(workflowKey,instanceId);
    };

    public getNextInstance(workflowKey : any, currentInstanceId : any) : Instance {
        return this._getNextInstance(workflowKey,currentInstanceId);
    };

    public getPreviousInstance(workflowKey : any, currentInstanceId : any) : Instance {
        return this._getPreviousInstance(workflowKey,currentInstanceId)
    };


};
