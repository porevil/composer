import { Injectable } from '@angular/core';

declare const _ : any;

@Injectable()
export class CommonService {

    constructor(){
        
    };

    public isDefined(variable : any) : boolean{
        return !this.isUndefined(variable);
    };

    public isUndefined(variable : any) : boolean {
        return _.isUndefined(variable);
    };

    public isUndefinedOrNull(variable : any) : boolean {
        if(this.isUndefined(variable) || variable == null){
            return true;
        }
        return false;
    };

    public isNotUndefinedAndNull(variable : any) : boolean {
        return !this.isUndefinedOrNull(variable);
    };

    public cloneObject(object : any) : any {
        if(_.isArray(object)){
            let clone = [];
            for(let i in object){
                let prop = object[i];
                clone[i] = this.cloneObject(prop);
            }
            return clone;
        }
        else if(_.isObject(object)) {
            let clone = {};
            for(let i in object){
                let prop = object[i];
                clone[i] = this.cloneObject(prop);
            }
            return clone;
        }
        else {
            return object;
        }
    };

    public sleep(millisecond : number) : Promise<any>{
        return new Promise((resolve) =>{ 
            setTimeout(()=>{resolve()},millisecond);
        });
    }

}