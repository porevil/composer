import { Injectable } from '@angular/core';
import { CommonService } from '../common/common.service';
import { StringService } from '../string/string.service';

declare const _ : any;

@Injectable()
export class ArrayService {

    constructor(
        private stringService : StringService,
        private commonService : CommonService
    ) {
    };


    
    private _compareProperties(obj : any, properties : any, isCaseSensitive? : boolean) : boolean {
        let isSame = true;
        
        if(_.isUndefined(obj) || _.isNull(obj)){
            return false;
        }

        if(_.isUndefined(properties) || _.isNull(properties)){
            return true;
        }

        for(let i in properties){
            let value = properties[i];
            if(_.isObject(value)){
                isSame = isSame && this._compareProperties(obj[i],value);
            }
            else if(this.stringService.isString(value)) {
                isSame = isSame && this.stringService.compare(obj[i],value, isCaseSensitive);
            }
            else {
                isSame = isSame && obj[i] === value;
            }
        }

        return isSame;
    };
 




    public isArray(variable : any) : boolean {
        return _.isArray(variable);
    };

    public isNotUndefinedAndNullAndEmpty(variable : any) : boolean {
        if(this.isArray(variable) && variable.length > 0){
            return true;
        }
        return false;
    };

    public findItem(list : Array<any>, properties : any, isCaseSensitive? : boolean) : any {  

        if(!this.isNotUndefinedAndNullAndEmpty(list)){
            return null;
        }
        
        let found = null;
        for(let i in list){
            let item = list[i];
            let isSame = this._compareProperties(item,properties,isCaseSensitive);
            if(isSame){
                found = item;
                break;
            }
        }        

        return found;    
    };

    public findItems(list : Array<any>, properties : any, isCaseSensitive? : boolean) : Array<any> {  

        if(!this.isNotUndefinedAndNullAndEmpty(list)){
            return [];
        }
        
        let found = [];
        for(let i in list){
            let item = list[i];
            let isSame = this._compareProperties(item,properties,isCaseSensitive);
            if(isSame){
                found.push(item);
            }
        }
        return found;       
    };

    public sortBy(list : any ,property : string, isDescending? : boolean) : any {
        if(!this.isArray(list)){
            return list;
        }
        if(this.commonService.isNotUndefinedAndNull(isDescending) && isDescending){
            return _.sortBy(list, property).reverse();
        }   
        return _.sortBy(list, property);
    };

    public searchItems(list : Array<any>, properties : any, isUnionField : boolean = false) : Array<any>{

        if(!this.isNotUndefinedAndNullAndEmpty(list)){
            return [];
        }

        let found = list.filter(item => {

        });

        return found;
    };

}