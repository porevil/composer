import { Injectable } from '@angular/core';

@Injectable()
export class PlatformService {

    public isMobile() : boolean {
        const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
        return isMobile;
    };

    public isDesktop() : boolean {
        return !this.isMobile();
    };

}