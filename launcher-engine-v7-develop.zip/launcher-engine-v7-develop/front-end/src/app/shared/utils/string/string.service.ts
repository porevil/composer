import { Injectable } from '@angular/core';

declare const _ : any;
declare const $ : any;

@Injectable()
export class StringService {

    public isString(variable : any) : boolean {
        return _.isString(variable);
    };

    public isNotUndifiedAndNullAndEmpty(variable : string) : boolean {
        if(_.isString(variable) && variable.trim().length > 0){
            return true;
        }
        return false;
    };

    public convertToLowerCase(text : string) : string {
        let newText = text;
        if(this.isNotUndifiedAndNullAndEmpty(text)){
            newText = text.toLowerCase();
        }
        return newText;
    };

    public compare(textA : string, textB : string, isCaseSensitive? : boolean) : boolean{
        let newTextA = textA;
        let newTextB = textB;
        if(this.isNotUndifiedAndNullAndEmpty(newTextA)){
            newTextA = newTextA.trim();
        }
        if(this.isNotUndifiedAndNullAndEmpty(newTextB)){
            newTextB = newTextB.trim();
        }
        if(_.isUndefined(isCaseSensitive) || _.isNull(isCaseSensitive) || !isCaseSensitive){
            newTextA = this.convertToLowerCase(newTextA);
            newTextB = this.convertToLowerCase(newTextB);
        }
        return newTextA == newTextB;
    };

    public clipboard(text : string) : void {
        var textArea = $('<textarea id="txtCopy" />');
        textArea.attr('style','position: absolute; z-index: -1; top: -1000%; opacity: 0;');
        $('body').append(textArea);
        textArea.val(text);
        textArea.select(); 
        document.execCommand("copy");
        textArea.remove();
    };

}