import { Component, ViewEncapsulation, ViewChild } from '@angular/core';
import { Validators, FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { TCModalComponent } from '..';
import { StringService } from '../../utils';
import { TCModalInstance } from '../tc-modal/tc-modal'
import { InputComponentType, InputContentType, } from '../../../pages/flow-controller/flow-controller'

@Component({
    selector: 'modal-instance-inputs',
    templateUrl: './modal-instance-inputs.component.html',
    styleUrls: ['./modal-instance-inputs.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class ModalInstanceInputsComponent {

    @ViewChild('model') model: TCModalComponent;

    constructor(
        private formBuilder: FormBuilder,
        private stringService: StringService
    ) {
        this._constructorComponent();
    };

    public title = '';
    public inputComponentType = InputComponentType;
    public inputs = [];
    public validatingForm: FormGroup = null;
    public defaultConfig = {
        title: 'Form'
    };

    // private functions
    private _constructorComponent(): void {

    };

    private _initValidatingForm(): void {
        let formGroup = {};
        for (const i in this.inputs) {
            const input = this.inputs[i];
            let value = input.value;
            let validators = [];
            if (input.value != null && input.vtype_input_component == InputComponentType.DatePicker) {
                value = new Date(input.value);
            }
            if (input.required) {
                validators = [Validators.required]
                if (input.vtype_input_component == InputComponentType.Toggle) {
                    value = !!value ? true : false;
                }
            }
            formGroup[input.name] = new FormControl(value, validators);
        }
        this.validatingForm = this.formBuilder.group(formGroup);
    };

    private _setInputsValueFromValidatingForm(): void {
        for (const i in this.inputs) {
            const input = this.inputs[i];
            const field = this.validatingForm.get(input.name);
            if (field.dirty) {
                input.value = field.value;
                if (input.vtype_input_component == InputComponentType.Dropdown) {
                    input.value = input.value == 'null' ? null : input.value;
                    if (input.value != null && input.type == InputContentType.Number) {
                        input.value = parseFloat(input.value);
                    }
                }
                else if (input.value != null && input.vtype_input_component == InputComponentType.TimePicker) {
                    const datetime = new Date(1970, 0, 1, input.value.getHours(), input.value.getMinutes(), input.value.getSeconds())
                    input.value = datetime.getTime();
                }
                else if (input.value != null && input.vtype_input_component == InputComponentType.DatePicker) {
                    const datetime = input.value;
                    datetime.setHours(0);
                    datetime.setMinutes(0);
                    datetime.setSeconds(0);
                    input.value = datetime.getTime();
                }
            }
        }
    };

    private _openModal(title: string, inputs: any): TCModalInstance {
        this.title = this.stringService.isNotUndifiedAndNullAndEmpty(title) ? title : this.defaultConfig.title;
        this.inputs = inputs;
        this._initValidatingForm();
        return this.model.show();
    };

    private _clearInput(input: any): void {
        this.validatingForm.get(input.name).setValue(null);
        if (input.value != null) {
            this.validatingForm.get(input.name).markAsDirty();
        }
    };

    private _submit(): void {
        if (this.validatingForm.valid) {
            this._setInputsValueFromValidatingForm();
            this.model.hide({
                isSubmit: true
            });
        }
    };

    private _closeModal(): void {
        this.model.hide({
            isSubmit: false
        });
    };








    // view functions

    public open(title: string, inputs: any): TCModalInstance {
        return this._openModal(title, inputs);
    };

    public btnSubmit(): void {
        this._submit();
    };

    public btnClearInput(input: any): void {
        this._clearInput(input);
    };

    public btnClose(): void {
        this._closeModal();
    };

}