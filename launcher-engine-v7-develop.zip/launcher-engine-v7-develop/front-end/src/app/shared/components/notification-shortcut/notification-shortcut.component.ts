import { Component, ViewEncapsulation, ViewChild } from '@angular/core';
import { Router } from '@angular/router';

import { NotificationModalComponent } from '../notification-modal/notification-modal.component';

declare const $: any;

@Component({
    selector: 'notification-shortcut',
    templateUrl: './notification-shortcut.component.html',
    styleUrls: ['./notification-shortcut.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class NotificationShortcutComponent {

    @ViewChild('notificationModel') notificationModel: NotificationModalComponent;

    constructor(
        private router: Router
    ) {

    };

    public notificationItems = [
        {
            title: 'Notification #1',
            content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec varius purus mauris, eget sollicitudin neque efficitur at. Nullam commodo, dui quis hendrerit hendrerit, metus nisl tempor arcu, vitae malesuada tortor tortor id justo. Praesent euismod eleifend nunc, vel dignissim metus pulvinar et. Proin at risus tincidunt tortor porttitor euismod. Aliquam tellus est, sollicitudin eget pellentesque eget, venenatis at lacus. Mauris mauris enim, facilisis sed vulputate vel, tempor non nibh. Pellentesque fermentum id nulla auctor sollicitudin. Morbi gravida, ex id semper sollicitudin, mauris risus consectetur libero, non tempor nunc risus sed mauris. Nulla scelerisque ut orci quis aliquam. Donec sed venenatis nunc, ut ultrices nunc.",
            received_time: 1581066504000,
            is_read: true
        },
        {
            title: 'Notification #2',
            content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec varius purus mauris, eget sollicitudin neque efficitur at. Nullam commodo, dui quis hendrerit hendrerit, metus nisl tempor arcu, vitae malesuada tortor tortor id justo. Praesent euismod eleifend nunc, vel dignissim metus pulvinar et. Proin at risus tincidunt tortor porttitor euismod. Aliquam tellus est, sollicitudin eget pellentesque eget, venenatis at lacus. Mauris mauris enim, facilisis sed vulputate vel, tempor non nibh. Pellentesque fermentum id nulla auctor sollicitudin. Morbi gravida, ex id semper sollicitudin, mauris risus consectetur libero, non tempor nunc risus sed mauris. Nulla scelerisque ut orci quis aliquam. Donec sed venenatis nunc, ut ultrices nunc.",
            received_time: 1581066504000,
            is_read: false
        },
        {
            title: 'Notification #3',
            content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec varius purus mauris, eget sollicitudin neque efficitur at. Nullam commodo, dui quis hendrerit hendrerit, metus nisl tempor arcu, vitae malesuada tortor tortor id justo. Praesent euismod eleifend nunc, vel dignissim metus pulvinar et. Proin at risus tincidunt tortor porttitor euismod. Aliquam tellus est, sollicitudin eget pellentesque eget, venenatis at lacus. Mauris mauris enim, facilisis sed vulputate vel, tempor non nibh. Pellentesque fermentum id nulla auctor sollicitudin. Morbi gravida, ex id semper sollicitudin, mauris risus consectetur libero, non tempor nunc risus sed mauris. Nulla scelerisque ut orci quis aliquam. Donec sed venenatis nunc, ut ultrices nunc.",
            received_time: 1581066504000,
            is_read: false
        },
        {
            title: 'Notification #4',
            content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec varius purus mauris, eget sollicitudin neque efficitur at. Nullam commodo, dui quis hendrerit hendrerit, metus nisl tempor arcu, vitae malesuada tortor tortor id justo. Praesent euismod eleifend nunc, vel dignissim metus pulvinar et. Proin at risus tincidunt tortor porttitor euismod. Aliquam tellus est, sollicitudin eget pellentesque eget, venenatis at lacus. Mauris mauris enim, facilisis sed vulputate vel, tempor non nibh. Pellentesque fermentum id nulla auctor sollicitudin. Morbi gravida, ex id semper sollicitudin, mauris risus consectetur libero, non tempor nunc risus sed mauris. Nulla scelerisque ut orci quis aliquam. Donec sed venenatis nunc, ut ultrices nunc.",
            received_time: 1581066504000,
            is_read: false
        },
        {
            title: 'Notification #5',
            content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec varius purus mauris, eget sollicitudin neque efficitur at. Nullam commodo, dui quis hendrerit hendrerit, metus nisl tempor arcu, vitae malesuada tortor tortor id justo. Praesent euismod eleifend nunc, vel dignissim metus pulvinar et. Proin at risus tincidunt tortor porttitor euismod. Aliquam tellus est, sollicitudin eget pellentesque eget, venenatis at lacus. Mauris mauris enim, facilisis sed vulputate vel, tempor non nibh. Pellentesque fermentum id nulla auctor sollicitudin. Morbi gravida, ex id semper sollicitudin, mauris risus consectetur libero, non tempor nunc risus sed mauris. Nulla scelerisque ut orci quis aliquam. Donec sed venenatis nunc, ut ultrices nunc.",
            received_time: 1581066504000,
            is_read: false
        }
    ];






    // view functions 


    public btnNotification(notification: any): void {
        const ref = this.notificationModel.open(notification);
        ref.closed.then((result) => {
            // console.debug(result);
        });
    };

    public btnSeeAllNotifications(): void {
        this.router.navigate(['/notifications']);
    };

}