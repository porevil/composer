import { Component, ViewEncapsulation, TemplateRef, IterableDiffers, IterableDiffer, ViewContainerRef } from '@angular/core';
import { StringService, CommonService, ArrayService } from '../../utils';


declare const $: any;

@Component({
    selector: 'tc-table',
    templateUrl: './tc-table.component.html',
    styleUrls: ['./tc-table.component.scss'],
    encapsulation: ViewEncapsulation.None,
    inputs: ['dataSource', 'bodyTableTemplate']
})
export class TCTableComponent {

    constructor(
        private iterableDiffers: IterableDiffers,
        private viewRef: ViewContainerRef,
        private stringService: StringService,
        private commonService: CommonService,
        private arrayService: ArrayService
    ) {
        this._constructorComponent();
    };

    // input variables
    public dataSource: Array<any> = null;
    public bodyTableTemplate: TemplateRef<any>;


    // template variables
    public context = {
        $implicit: "",
        items: []
    };

    // component variables
    public items = [];
    public tableConfig = {
        counts: [5, 20, 50, 100]
    };
    public tableControls = {
        headers: [],
        count: null,
        sort: {
            field: null,
            isDescending: true
        },
        pager: {
            current: 1,
            total: 1,
            items: []
        }
    };
    public diffItems: IterableDiffer<any> = null;



    private ngDoCheck(): void {
        const changeItems = this.diffItems.diff(this.dataSource);
        if (changeItems) {
            this.items = this.dataSource;
            this._initTable();
        }
    };

    private ngAfterViewInit(): void {
        this._afterViewInitComponent();
    };

    private ngOnDestroy() {
        this._destroyComponent();
    };

    // private functions
    private _constructorComponent(): void {
        this._initTable();
        this.diffItems = this.iterableDiffers.find([]).create(null);
    };

    private _afterViewInitComponent(): void {
        this._initScrollEvent();
    };

    private _destroyComponent(): void {
        this._destroyScrollEvent();
    };

    private removeQuotes(text: string): string {
        if (this.stringService.isString(text)) {
            return text.match(/^("|')(.*)("|')$/)[2];
        };
        return text;
    };

    private _initTableId(): void {
        const viewEle = $(this.viewRef.element.nativeElement);
        const id = viewEle.find('.tc-table').attr('id');
        if (!this.stringService.isNotUndifiedAndNullAndEmpty(id)) {
            viewEle.find('.tc-table').attr('id', 'tc-table-' + Math.floor(Math.random() * 10000000000));
        }
    };

    private async _initTable(): Promise<any> {
        this._initTableId();
        if (this.tableControls.headers.length == 0) {
            await this._initTableHeader();
            setTimeout(() => { this._initResizeTable(); }, 100);
        }
        this._initTableCount();
        this._initTablePager();
        this._initTableSort();
        this._reloadDisplayItem();

    };

    private async _initTableHeader(): Promise<any> {
        return new Promise((resolve) => {
            this.context.items = [{}];
            setTimeout(() => {
                const viewEle = $(this.viewRef.element.nativeElement);
                const trEle = viewEle.find('.tc-table-container tbody tr:first-child td');
                const elements = Array.from(trEle);
                this.tableControls.headers = [];
                for (const i in elements) {
                    const element = elements[i];
                    const title = $(element).attr('title');
                    const fieldSort = $(element).attr('sortable');
                    const enabledSort = this.stringService.isString(fieldSort);
                    this.tableControls.headers.push({
                        title: this.removeQuotes(title),
                        displayed: true,
                        width: null,
                        sort: {
                            enabled: enabledSort,
                            field: this.removeQuotes(fieldSort)
                        }
                    });
                }
                this.context.items = [];
                resolve();
            }, 500);
        });
    };

    private _initTableSort() : void {
        if(this.tableControls.sort.field == null){
            if(this.tableControls.headers.length > 0){
                for(const i in this.tableControls.headers){
                    const header = this.tableControls.headers[i];
                    if(header.sort.enabled && header.displayed){
                        this._setSort(header.sort.field);
                        break;
                    }
                }
            }
        }
    };

    private _initTablePager(): void {
        const total = Math.ceil(this.items.length / this.tableControls.count);
        this.tableControls.pager.total = total;
        this.tableControls.pager.current = 1;
        this._reloadPager();
    };

    private _reloadPager(): void {
        this.tableControls.pager.items = [1];
        const total = this.tableControls.pager.total;
        const current = this.tableControls.pager.current;
        if (total > 0) {
            let startPage = current - 2 < 1 ? 1 : current + 2 > total && total >= 5 ? total - 4 : current - 2;
            const maxItem = total <= 7 ? total : startPage == 1 || total - 2 <= current ? 7 : startPage == 2 || current == total - 3 ? 8 : 9;
            let countSetPage = 0;
            this.tableControls.pager.items = Array(maxItem).fill(0).map((item, index) => {
                if (index == 0) {
                    if (startPage == 1) {
                        startPage = startPage + 1;
                        countSetPage = countSetPage + 1;
                    }
                    return 1;
                }
                else if (index == maxItem - 1) {
                    return total;
                }
                else if (index == 1 && startPage > 2) {
                    return '...';
                }
                else if (countSetPage == 5) {
                    return '...';
                }
                else {
                    const page = startPage;
                    startPage = page + 1;
                    countSetPage = countSetPage + 1;
                    return page;
                }
            });
        }
    };

    private _initTableCount(): void {
        if (this.tableConfig.counts.indexOf(this.tableControls.count) == -1) {
            this.tableControls.count = this.tableConfig.counts[0];
        }
    };

    private _getDisplayItem(): Array<any> {

        let items = this.items;

        // sort items
        if (this.stringService.isNotUndifiedAndNullAndEmpty(this.tableControls.sort.field)) {
            items = this.arrayService.sortBy(
                items,
                this.tableControls.sort.field,
                this.tableControls.sort.isDescending
            );
        }

        // get item with paging
        const startItemIndex = (this.tableControls.pager.current - 1) * this.tableControls.count;
        const endItemIndex = this.tableControls.pager.current * this.tableControls.count - 1;
        return items.filter((item, index) => {
            return startItemIndex <= index && index <= endItemIndex;
        });
    };

    private _reloadDisplayItem(): void {
        this.context.items = this._getDisplayItem();
        setTimeout(() => {
            this._reloadResizeBarHight();
            this._cloneTable();
        }, 10);
    };

    private _setCount(count: number): void {
        this.tableControls.count = count;
        this._initTablePager();
        this._reloadDisplayItem();
    };

    private _setPage(number: number): void {
        if (0 < number && number <= this.tableControls.pager.total) {
            this.tableControls.pager.current = number;
            this._reloadPager();
            this._reloadDisplayItem();
        }
    };

    private _nextPage(): void {
        const nextPage = this.tableControls.pager.current + 1;
        this._setPage(nextPage);
    };

    private _previousPage(): void {
        const previousPage = this.tableControls.pager.current - 1;
        this._setPage(previousPage);
    };

    private _setSort(field: string, isDescending?: boolean): void {
        this.tableControls.sort.isDescending = !this.tableControls.sort.isDescending;
        if (!this.stringService.compare(this.tableControls.sort.field, field)) {
            this.tableControls.sort.field = field;
            this.tableControls.sort.isDescending = true;
        }
        if (this.commonService.isDefined(isDescending)) {
            this.tableControls.sort.isDescending = isDescending;
        }
        this._reloadDisplayItem();
    };

    private _sortDirection(field: string): any {
        if (!this.stringService.compare(this.tableControls.sort.field, field)) {
            return null;
        }
        return this.tableControls.sort.isDescending;
    };

    private _destroyScrollEvent(): void {
        const viewEle = $(this.viewRef.element.nativeElement);
        viewEle.find('.tc-table-container').off('scroll');
    };

    private _initScrollEvent(): void {
        this._destroyScrollEvent();
        const viewEle = $(this.viewRef.element.nativeElement);
        viewEle.find('.tc-table-container').on('scroll', event => {
            viewEle.find('.tc-fixed-header').scrollLeft(event.target.scrollLeft);
        });
    };

    private _cloneTable(): void {
        const viewEle = $(this.viewRef.element.nativeElement);
        const clonedTableEle = viewEle.find('.tc-table-container table').clone();
        const fixedHeaderEle = viewEle.find('.tc-fixed-header');
        fixedHeaderEle.html(clonedTableEle);
    };

    private _reloadDisplayColumn(): void {

        const viewEle = $(this.viewRef.element.nativeElement);
        viewEle.find('[name="column-filter"]').remove();
        const tableEleId = viewEle.find('.tc-table').attr('id');

        const hideColumns = [];
        for (const i in this.tableControls.headers) {
            const header = this.tableControls.headers[i];
            if (!header.displayed) {
                hideColumns.push('tr td:nth-child(' + ((+i) + 1) + ')');
                hideColumns.push('tr th:nth-child(' + ((+i) + 1) + ')');
            }
        }

        if (hideColumns.length > 0) {
            const styles = '#' + tableEleId + ' ' + hideColumns.join(',') + '{ display : none; }';
            viewEle.append($('<style name="column-filter" />').append(styles));
        }

    };

    private _destroyResizeTable(): void {
        const viewEle = $(this.viewRef.element.nativeElement);
        const dragEle = viewEle.find('.tc-table-container .tc-table-header-dragabled');
        const tableEle = viewEle.find('.tc-table-container table');
        if (dragEle.length > 0) {
            dragEle.off('mousedown');
            dragEle.off('dblclick');
        }
        if (tableEle.length > 0) {
            tableEle.off('mousemove');
            tableEle.off('mouseup');
        }
    };

    private _reloadResizeBarHight(): void {
        const viewEle = $(this.viewRef.element.nativeElement);
        const dragEle = viewEle.find('.tc-table-container .tc-table-header-dragabled');
        const tableEle = viewEle.find('.tc-table-container table');
        dragEle.css('height', tableEle.height());
    };

    private _initResizeTable(): void {
        this._destroyResizeTable();
        this._reloadResizeBarHight();

        let pageX;
        let columnWidth;
        let columnEle;
        let header;

        const viewEle = $(this.viewRef.element.nativeElement);
        const dragEle = viewEle.find('.tc-table-container .tc-table-header-dragabled');
        const tableEle = viewEle.find('.tc-table-container table');
        if (dragEle.length > 0) {
            dragEle.on('dblclick', event => {
                const index = +event.target.getAttribute('tc-header-index');
                this.tableControls.headers[index].width = null;
                this._reloadSizeColumn();
            });
            dragEle.on('mousedown', event => {
                const index = +event.target.getAttribute('tc-header-index');
                pageX = event.pageX;
                columnEle = event.target.parentElement;
                columnWidth = columnEle.clientWidth;
                header = this.tableControls.headers[index];
            });
            tableEle.on('mousemove', event => {
                if (columnEle && pageX) {
                    const diffX = event.pageX - pageX;
                    let newWidth = columnWidth + diffX;
                    header.width = newWidth < 70 ? 70 : newWidth;
                    this._reloadSizeColumn();
                }
            });
            tableEle.on('mouseup', event => {
                pageX = undefined;
                columnWidth = undefined;
                columnEle = undefined;
                header = undefined;
                this._reloadResizeBarHight();
            });
        }
    };

    private _reloadSizeColumn() : void {
        
        const viewEle = $(this.viewRef.element.nativeElement);
        viewEle.find('[name="column-size"]').remove();
        const tableEleId = viewEle.find('.tc-table').attr('id');

        const sizeColumns = []; 
        for (const i in this.tableControls.headers) {
            const header = this.tableControls.headers[i];
            let width = header.width;
            if (width == null) {
                const columnEle = $(viewEle).find(`[tc-header-index=${i}]`).parent();
                if(columnEle.length > 0){
                    width = columnEle.width();
                }
            }
            if(width == null){
                continue;
            }
            sizeColumns.push(
                `tr td:nth-child(${((+i) + 1)}),
                tr th:nth-child(${((+i) + 1)}),
                tr td:nth-child(${((+i) + 1)}) > :first-child,
                tr th:nth-child(${((+i) + 1)}) > :first-child
                {width:${width}px;}`
            );
        }

        if (sizeColumns.length > 0) {
            const styles = `#${tableEleId} ${sizeColumns.join(' ')}`;
            viewEle.append($('<style name="column-size" />').append(styles));
        }

    };

    private _setDisplayedHeader(header: any, displayed : boolean) : void {
        header.displayed = displayed;
        if(this.stringService.compare(this.tableControls.sort.field, header.sort.field)){
            this.tableControls.sort.field = null;
            this._initTableSort();
        }
        this._reloadDisplayColumn();
    };



    // view functions
    public btnCount(count: number): void {
        this._setCount(count);
    };

    public btnPage(number: number): void {
        this._setPage(number);
    };

    public btnNextPage(): void {
        this._nextPage();
    };

    public btnPreviousPage(): void {
        this._previousPage();
    };

    public btnHeader(header: any): void {
        if (header.sort.enabled) {
            this._setSort(header.sort.field);
        }
    };

    public getSortDirection(field: string): any {
        return this._sortDirection(field);
    };

    public onChangeCount($event): void {
        this._setCount(+$event);
    };

    public onColumnFilterChange($event: any, header: any): void {        
        this._setDisplayedHeader(header, $event);
    };



}