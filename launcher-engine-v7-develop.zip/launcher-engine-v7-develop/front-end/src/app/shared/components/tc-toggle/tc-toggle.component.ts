import { Component, ViewEncapsulation, forwardRef } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

@Component({
    selector: 'tc-toggle',
    templateUrl: './tc-toggle.component.html',
    styleUrls: ['./tc-toggle.component.scss'],
    encapsulation: ViewEncapsulation.None,
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => TCToggleComponent),
            multi: true
        }
    ]
})
export class TCToggleComponent implements ControlValueAccessor {

    public checked: boolean = false;
    public propagateChange = (_: any) => { };

    writeValue(value: boolean) {
        this.checked = value;
    };

    registerOnChange(fn: any) {
        this.propagateChange = fn;
    };

    registerOnTouched() { };

    public onChangeChecked($event: boolean): void {
        this.checked = $event;
        this.propagateChange(this.checked);
    };

}