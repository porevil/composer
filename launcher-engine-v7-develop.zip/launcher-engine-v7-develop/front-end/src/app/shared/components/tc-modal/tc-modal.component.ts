import { Component, ViewEncapsulation, ViewContainerRef, TemplateRef } from '@angular/core';
import { TCModalConfig,TCModalInstance,TCModalEvent } from './tc-modal'

import { from } from 'rxjs';
import { CommonService, StringService } from '../../utils';

declare const $: any;

@Component({
    selector: 'tc-modal',
    templateUrl: './tc-modal.component.html',
    styleUrls: ['./tc-modal.component.scss'],
    encapsulation: ViewEncapsulation.None,
    inputs: ['modalTemplate']
})
export class TCModalComponent {

    constructor(
        private viewRef: ViewContainerRef,
        private commonService: CommonService,
        private stringService: StringService
    ) {

    };

    public modalTemplate: TemplateRef<any>;
    public result = null;
    public defaultConfig = {
        backdrop: 'static',
    };

    // private functions
    private _getModelElement(): any {
        const viewEle = this.viewRef.element.nativeElement;
        const modalEle = $(viewEle).find('.modal');
        return modalEle;
    };

    private _createPromiseEvent(evantName: string): Promise<any> {
        const modalEle = this._getModelElement();
        return new Promise((resolve) => {
            modalEle.off(evantName);
            modalEle.on(evantName, event => {
                if (this.commonService.isUndefinedOrNull(this.result)) {
                    resolve();
                }
                else {
                    const result = this.commonService.cloneObject(this.result);
                    if (this.stringService.compare(evantName, TCModalEvent.Closed)) {
                        this.result = null;
                    }
                    resolve(result);
                }
            });
        })
    };

    private _show(config?: TCModalConfig): TCModalInstance {
        const modalEle = this._getModelElement();
        const modalConfig = {
            ...this.defaultConfig,
            show: true,
            ...config
        };
        setTimeout(() => { modalEle.modal(modalConfig); }, 100);
        return {
            open: this._createPromiseEvent(TCModalEvent.Open),
            opened: this._createPromiseEvent(TCModalEvent.Opened),
            close: this._createPromiseEvent(TCModalEvent.Close),
            closed: this._createPromiseEvent(TCModalEvent.Closed)
        }
    };

    private _hide(result?: any): void {
        this.result = result;
        const modalEle = this._getModelElement();
        modalEle.modal('hide');
    };

    // view functions 

    public show(config?: TCModalConfig): TCModalInstance {
        return this._show(config);
    };

    public hide(result?: any): any {
        this._hide(result);
    };

};
