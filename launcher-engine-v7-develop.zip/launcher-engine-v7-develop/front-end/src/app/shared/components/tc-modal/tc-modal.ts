
export interface TCModalConfig {
    backdrop?: boolean | string,
    keyboard?: boolean,
    focus?: boolean
}

export interface TCModalInstance {
    open: Promise<void>,
    opened: Promise<void>,
    close: Promise<any>,
    closed: Promise<any>
}

export enum TCModalEvent {
    Open = 'show.bs.modal',
    Opened = 'shown.bs.modal',
    Close = 'hide.bs.modal',
    Closed = 'hidden.bs.modal'
};