import { Component, ViewEncapsulation, ViewChild } from '@angular/core';
import { TCModalComponent } from '..';
import { TCModalInstance } from '../tc-modal/tc-modal'


declare const $: any;

@Component({
    selector: 'notification-modal',
    templateUrl: './notification-modal.component.html',
    styleUrls: ['./notification-modal.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class NotificationModalComponent {

    @ViewChild('model') model: TCModalComponent;

    constructor() {

    };

    public notification = null;

    // view functions    
    public open(notification: any): TCModalInstance {
        this.notification = notification;
        return this.model.show();
    };

    public btnOpenLinkNotification(): void {
        this.model.hide({ lauchActionUrl: true });
    };

}