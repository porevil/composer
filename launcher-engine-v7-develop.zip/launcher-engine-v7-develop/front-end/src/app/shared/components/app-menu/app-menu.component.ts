import { Component, ViewEncapsulation, ViewContainerRef, EventEmitter } from '@angular/core';
import { StringService, CommonService } from '../../utils';
import { AuthenticationService, UtilsService } from 'src/app/core/services';



declare const $: any;

@Component({
    selector: 'app-menu',
    templateUrl: './app-menu.component.html',
    styleUrls: ['./app-menu.component.scss'],
    encapsulation: ViewEncapsulation.None,
    inputs: ['menuItems'],
    outputs: ['onClickMenuItem', 'onClickChildMenuItem' ,'onRefresh']
})
export class AppMenuComponent {

    constructor(
        private viewRef: ViewContainerRef,
        private stringService: StringService,
        private commonService : CommonService,
        private authenticationService:AuthenticationService,
        private utilsService:UtilsService
    ) {

    };


    // input variables
    public menuItems = [];

    // output variables
    public onClickMenuItem: EventEmitter<any> = new EventEmitter();
    public onClickChildMenuItem: EventEmitter<any> = new EventEmitter();
    public onRefresh: EventEmitter<any> = new EventEmitter();

    // component variables
    public searchForm = {
        text: ""
    };

    public filterAutoComplete = {
        items: []
    };

    // private functions
    private _clearHighlightMenuItem(): void {
        const viewEle = this.viewRef.element.nativeElement;
        const menuItemEles = $(viewEle).find('[tc-menu-id]');
        menuItemEles.attr('tc-actived', false);
    };

    private _highlightMenuItem(menuItemId: any): void {
        this._clearHighlightMenuItem();
        this._clearHighlightChildMenuItem();
        const menuItemEle = this._getMenuItemElement(menuItemId);
        menuItemEle.attr('tc-actived', true);
    };

    private _clearHighlightChildMenuItem(): void {
        const viewEle = this.viewRef.element.nativeElement;
        const childMenuItemEles = $(viewEle).find('[tc-child-id]');
        childMenuItemEles.attr('tc-actived', false);
    };

    private _highlightChildMenuItem(childMenuItemId: any): void {

        const menuItem = this._findMenuItemFromChildMenuItem(childMenuItemId);
        this._clearHighlightChildMenuItem();
        this._highlightMenuItem(menuItem.code);
        const viewEle = this.viewRef.element.nativeElement;
        const childMenuItemEle = this._getChildMenuItemElement(childMenuItemId);
        childMenuItemEle.attr('tc-actived', true);

        const menuItemEle = this._getMenuItemElement(menuItem.code);
        const childItemContainerEle = menuItemEle.find('.child-items');
        if (!childItemContainerEle.hasClass('show')) {
            $(viewEle).find('.menu-item-content').attr('aria-expanded', false);
            menuItemEle.find('.menu-item-content').attr('aria-expanded', true);
            $(viewEle).find('.child-items').removeClass('show');
            childItemContainerEle.addClass('show');
        }

    };

    private _findMenuItemFromChildMenuItem(childMenuItemId: any): any {
        const found = this.menuItems.filter(menuItem => {
            return menuItem.flows.some(childItem => {
                return childItem.uuid == childMenuItemId
            });
        });
        return found.length > 0 ? found[0] : null
    };

    private _hideAllMenuItems(): void {
        const viewEle = this.viewRef.element.nativeElement;
        $(viewEle).find('.menu-item').addClass('d-none');
        $(viewEle).find('.child-item').addClass('d-none');
    };

    private _showAllMenuItems(): void {
        const viewEle = this.viewRef.element.nativeElement;
        $(viewEle).find('.menu-item').removeClass('d-none');
        $(viewEle).find('.child-item').removeClass('d-none');
    };

    private _getHighlightHTML(message: string, highlightText: string): string {
        const index = this.stringService.convertToLowerCase(message).indexOf(highlightText);
        let innerHTML = message;
        if (index >= 0) {
            innerHTML = [
                message.substring(0, index),
                "<span class='highlight'>",
                message.substring(index, index + highlightText.length),
                "</span>",
                message.substring(index + highlightText.length)
            ].join('');
        }
        return innerHTML;
    };

    private _highlightTextItem(childItem: any, text: string): void {
        const title = childItem.display_label;
        const index = this.stringService.convertToLowerCase(title).indexOf(text);
        const innerHTML = this._getHighlightHTML(title, text);
        this._getChildMenuItemElement(childItem.uuid).find('.title').html(innerHTML);
    };

    private _getMenuItemElement(menuItemId: any): any {
        const viewEle = this.viewRef.element.nativeElement;
        return $(viewEle).find('[tc-menu-id="' + menuItemId + '"]');
    };

    private _getChildMenuItemElement(childItemId: any): any {
        const viewEle = this.viewRef.element.nativeElement;
        return $(viewEle).find('[tc-child-id="' + childItemId + '"]');
    };

    private _clearAllHighlightTextItems() {
        for (var i in this.menuItems) {
            var menuItem = this.menuItems[i];
            for (var j in menuItem.flows) {
                var childItem = menuItem.flows[j];
                var childItemEle = this._getChildMenuItemElement(childItem.uuid);
                if (childItemEle.find('.title .highlight').length > 0) {
                    childItemEle.find('.title').html(childItem.display_label);
                }
            }
        }
    };

    private _filterItemsWithTitle(items: Array<any>, text: string): Array<any> {
        var filteredItem = [];
        for (var i in items) {
            var item = items[i];
            if (this.stringService
                .convertToLowerCase(item.display_label)
                .includes(this.stringService.convertToLowerCase(text))) {
                filteredItem.push(item);
            }
        }
        return filteredItem;
    };

    private _filterMenuItems_backup(text: string): Array<any> {
        var filteredMenuItems = [];
        for (var i in this.menuItems) {
            var menuItem = this.menuItems[i];
            var filteredChildMenuItems = this._filterItemsWithTitle(
                menuItem.flows,
                text
            );
            if (filteredChildMenuItems.length > 0) {
                filteredMenuItems.push({
                    ...menuItem,
                    childItems: filteredChildMenuItems
                });
            }
        }
        return filteredMenuItems;
    };

    private _expandAllMenuItem(): void {
        const viewEle = this.viewRef.element.nativeElement;
        $(viewEle).find('.child-items').addClass('show');
    };

    private _collapseAllMenuItemWithoutActivedMenuItem() {
        const viewEle = this.viewRef.element.nativeElement;
        $(viewEle).find('.menu-item[tc-actived="false"] .child-items').removeClass('show');
    };

    private _onChangeSearchText_backup(): void {
        const text = this.searchForm.text;
        if (this.stringService.isNotUndifiedAndNullAndEmpty(text)) {
            this._hideAllMenuItems();
            this._expandAllMenuItem();
            var filteredMenuItems = this._filterMenuItems(text);
            for (var i in filteredMenuItems) {
                var menuItem = filteredMenuItems[i];
                this._getMenuItemElement(menuItem.code).removeClass('d-none');
                for (var j in menuItem.flows) {
                    var childItem = menuItem.flows[j];
                    this._getChildMenuItemElement(childItem.uuid).removeClass('d-none');
                    this._highlightTextItem(childItem, text);
                }
            }
        }
        else {
            this._collapseAllMenuItemWithoutActivedMenuItem();
            this._clearAllHighlightTextItems();
            this._showAllMenuItems();
        }
    };

    private _filterMenuItems(text: string): Array<any> {
        var filteredMenuItems = [];
        for (var i in this.menuItems) {
            var menuItem = this.menuItems[i];

            if (menuItem.flows.length > 0
                && this.stringService
                    .convertToLowerCase(menuItem.display_label)
                    .includes(this.stringService.convertToLowerCase(text))) {
                filteredMenuItems.push(menuItem);
                continue;
            }

            var filteredChildMenuItems = this._filterItemsWithTitle(
                menuItem.flows,
                text
            );
            if (filteredChildMenuItems.length > 0) {
                filteredMenuItems.push({
                    ...menuItem,
                    flows: filteredChildMenuItems
                });
            }

        }
        return filteredMenuItems;
    };

    private _onChangeSearchText(): void {
        const text = this.searchForm.text;
        if (this.stringService.isNotUndifiedAndNullAndEmpty(text)) {
            const filteredMenuItems = this._filterMenuItems(text);
            this.filterAutoComplete.items = filteredMenuItems;
            // console.debug(this.filterAutoComplete);
        }
        else {
            this.filterAutoComplete.items = [];
        }
    };

    private async _openAutocompleteSearchMenu(opened : boolean) : Promise<any> {
        const viewEle = $(this.viewRef.element.nativeElement); 
        if(!opened){
            await this.commonService.sleep(100);
        }
        viewEle.find('.menu-search-form').attr('tc-focused',opened);
        viewEle.find('.tc-autocomplete-container').attr('tc-opened',opened);
        $('[tc-app-menu-search-focus]').attr('tc-app-menu-search-focus', opened);
    };











    // view functions
    public btnMenuItem(menuItem: any): void {
        if (menuItem.flows.length == 0) {
            this._highlightMenuItem(menuItem.code);
            this.onClickMenuItem.next({ menuItem: menuItem });
        }
    };

    public highlightMenuItem(menuItemId: any): void {
        this._highlightMenuItem(menuItemId);
    };

    public btnChildMenuItem(menuItem : any, childMenuItem: any): void {
        this._highlightChildMenuItem(childMenuItem.uuid);
        this.onClickChildMenuItem.next({ 
            menuItem : menuItem,
            childMenuItem: childMenuItem 
        });
    };

    public highlightChildMenuItem(childMenuItemId: any): void {
        this._highlightChildMenuItem(childMenuItemId);
    };

    public onChangeSearchText($event: any): void {
        this.searchForm.text = $event;
        this._onChangeSearchText();
    };

    public btnClearSearchText(): void {
        this.searchForm.text = "";
        this._onChangeSearchText();
    };

    public onFocusSearchInput(): void {
        this._openAutocompleteSearchMenu(true);
    };

    public onFocusoutSearchInput(): void {        
        this._openAutocompleteSearchMenu(false);
    };

    public getHighlightHTML(message: string): string {
        return this._getHighlightHTML(message, this.searchForm.text);
    };

    public async btnRefresh() : Promise<void>{
        this.onRefresh.emit();
    };
}