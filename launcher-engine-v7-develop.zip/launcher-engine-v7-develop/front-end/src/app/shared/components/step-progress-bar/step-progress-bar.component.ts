import { Component, ViewEncapsulation, EventEmitter, IterableDiffers, IterableDiffer } from '@angular/core';
import { ArrayService } from '../../utils';


@Component({
    selector: 'step-progress-bar',
    templateUrl: './step-progress-bar.component.html',
    styleUrls: ['./step-progress-bar.component.scss'],
    encapsulation : ViewEncapsulation.None,
    inputs : ['items','currentId'],
    outputs : ['onClickStepItem']
})
export class StepProgressBarComponent {

    constructor(
        private iterableDiffers : IterableDiffers,
        private arrayService : ArrayService
    ) {
        this._constructorComponent();
    };

    // input variables
    public items = [];
    public currentId = null;

    // output variables
    public onClickStepItem : EventEmitter<any> = new EventEmitter();

    // component variables
    public diffItems: IterableDiffer<any> = null;
    public displayedItems = [];

    private ngDoCheck(): void {
        const changeItems = this.diffItems.diff(this.items);
        if (changeItems) {
            this._reloadDisplayedStep();
        }
    };

    // private functions
    private _constructorComponent(): void {
        this.diffItems = this.iterableDiffers.find([]).create(null);
    };

    private _reloadDisplayedStep() : void {
        if(this.items.length <= 7){
            // this.displayedItems = this.items;
            this.displayedItems = []
            this.items.forEach((element,i) => {
                this.displayedItems.push({
                    icon : i+1,
                    ...element
                });
            });
        }
        else {
            this.displayedItems = [];
            const currentItem = this.arrayService.findItem(
                this.items,
                { id : this.currentId }
            );
            const currentIndex = this.items.indexOf(currentItem);
            const lastIndex = this.items.length - 1;
            let nextIndex = currentIndex - 2 < 1 ? 1 : currentIndex + 2  >= lastIndex - 1 ? lastIndex - 5 : currentIndex - 2;
            console.log(nextIndex)
            for(let i = 0; i < 7; i++){
                if(i == 0){
                    this.displayedItems.push({
                        icon : 1,
                        ...this.items[0]
                    });
                }
                else if(i == 6){
                    this.displayedItems.push({
                        icon : lastIndex + 1,
                        ...this.items[lastIndex]
                    }); 
                }
                else {
                    this.displayedItems.push({
                        icon : nextIndex + 1,
                        ...this.items[nextIndex]
                    }); 
                    nextIndex = nextIndex + 1;
                }
            }         

            if(this.displayedItems[1].icon != 2){
                const endItemIndex = this.displayedItems[2].icon - 2;
                const items = this.items.filter((item,index)=>{
                    return index <= endItemIndex && index > 0;
                });
                this.displayedItems[1] = {
                    icon : '...',
                    items : items.map((item,index) => { return { icon : 2 + index, ...item}; }),
                    enabled : true,
                    finished : true
                }
            }
            if(this.displayedItems[this.displayedItems.length - 2].icon != lastIndex){
                const startItemIndex = this.displayedItems[this.displayedItems.length - 2].icon - 1;
                const items = this.items.filter((item,index)=>{
                    return index >= startItemIndex && index < lastIndex;
                });
                this.displayedItems[this.displayedItems.length - 2] = {
                    icon : '...',
                    items : items.map((item,index) => { return { icon : startItemIndex + index + 1, ...item}; }),
                    enabled : false,
                    finished : false
                };
            }
        }
    };

    // view functions
    public btnStepItem(stepItem : any) : void {
        if(stepItem.enabled){
            this.onClickStepItem.next({ stepItem : stepItem });
        }        
    };

}