import { Component, ViewEncapsulation, forwardRef } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

@Component({
    selector: 'tc-checkbox',
    templateUrl: './tc-checkbox.component.html',
    styleUrls: ['./tc-checkbox.component.scss'],
    encapsulation: ViewEncapsulation.None,
    inputs: ['enabledNull'],
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => TCCheckboxComponent),
            multi: true
        }
    ]
})
export class TCCheckboxComponent implements ControlValueAccessor {

    public value: boolean = false;
    public enabledNull = false;
    public propagateChange = (_: any) => { };


    writeValue(value: boolean) {
        this.value = value;
    };

    registerOnChange(fn: any) {
        this.propagateChange = fn;
    };

    registerOnTouched() { };



    public btnToggleValue(): void {
        if (this.enabledNull) {
            this.value = this.value == null ? true : this.value ? false : null;
        }
        else {
            this.value = !this.value;
        }
        this.propagateChange(this.value);
    };


}