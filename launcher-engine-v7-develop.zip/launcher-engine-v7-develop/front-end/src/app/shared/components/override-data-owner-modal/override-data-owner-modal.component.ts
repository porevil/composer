import { Component, ViewEncapsulation, ViewChild } from '@angular/core';
import { DashboardService, UtilsService } from 'src/app/core/services';
import * as fromUserImfomationAction from '../../../store/actions/user-information.actions';
import { Store } from '@ngrx/store';
import { UserInfomationState } from 'src/app/store/reducers/user-information/user-information.reducer';

@Component({
  selector: 'override-data-owner-modal',
  templateUrl: './override-data-owner-modal.component.html',
  styleUrls: ['./override-data-owner-modal.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class OverrideDataOwnerModalComponent {

  @ViewChild('modalOverrideDataOwner', { static: true }) modalOverrideDataOwner;

  public dataProcessorDropdownConfig = {
    label: 'สาขา',
    options: [],
    selectedValue: null
  };

  public dataControllerDropdownConfig = {
    label: 'บริษัท',
    options: [],
    selectedValue: null
  };

  constructor(
    private store: Store<UserInfomationState>
  ) { }

  public async btnConfirm() {
    let representativeUser = this.dataControllerDropdownConfig.options.map(item => ({
      description: item.label,
      value: item.value
    })).find(item => item.value == this.dataControllerDropdownConfig.selectedValue)

    let representativeBranch = this.dataProcessorDropdownConfig.options.map(item => ({
      description: item.label,
      value: item.value
    })).find(item => item.value == this.dataProcessorDropdownConfig.selectedValue)

    this.store.dispatch(fromUserImfomationAction.updateUserInformations({payload:{representative_branch: representativeBranch,representative_user: representativeUser}}))
    this.modalOverrideDataOwner.hide();
    
  }

  public show(branches: Array<any>, representations: Array<any>): any {
    
    this.dataProcessorDropdownConfig.options = branches.map(branch => ({label: branch.description, value: branch.value}));
    this.dataControllerDropdownConfig.options = representations.map(representation => ({label: representation.description, value: representation.value}));

    return this.modalOverrideDataOwner.show();
  }

  public onDisabledConfirm() {
    return !(this.dataControllerDropdownConfig.selectedValue && this.dataProcessorDropdownConfig.selectedValue);
  }

}
