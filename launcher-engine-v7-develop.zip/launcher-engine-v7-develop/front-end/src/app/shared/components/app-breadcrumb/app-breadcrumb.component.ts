import { Component, ViewEncapsulation } from '@angular/core';

@Component({
    selector: 'app-breadcrumb',
    templateUrl: './app-breadcrumb.component.html',
    styleUrls: ['./app-breadcrumb.component.scss'],
    encapsulation : ViewEncapsulation.None,
    inputs : ['title','items']
})
export class AppBreadcrumbComponent {

    // input variables
    public items = [];
    public title = '';
    
}