import { Component, ViewEncapsulation } from '@angular/core';

@Component({
    selector: 'tc-datetime',
    templateUrl: './tc-datetime.component.html',
    styleUrls: ['./tc-datetime.component.scss'],
    encapsulation: ViewEncapsulation.None,
    inputs: ['value', 'isDateOnly']
})
export class TCDatetimeComponent {

    public value = null;
    public isDateOnly = false;
    public dateFormat = 'd/MM/yyyy';
    public timeFormat = 'h:mm a';



}