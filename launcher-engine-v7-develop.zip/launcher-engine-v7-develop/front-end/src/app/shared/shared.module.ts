import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { BsDropdownModule } from 'ngx-bootstrap/dropdown';

import {
    AppMenuComponent, AppHeaderComponent, AppFooterComponent,
    AppBreadcrumbComponent, TCTableComponent, StepProgressBarComponent,
    AppLoaderComponent, TCModalComponent, TCDatetimeComponent,
    TCToggleComponent, TCCheckboxComponent, NotificationModalComponent, NotificationShortcutComponent, OverrideDataOwnerModalComponent
} from './components';

import {
    StringService, ArrayService, CommonService,
    FlowService, PlatformService
} from './utils';

import { 
    WidgetModalModule, WidgetButtonModule, WidgetDropdownModule 
} from '@channel/widgets';

const widgetModules = [
    WidgetModalModule, WidgetButtonModule, WidgetDropdownModule
]

const services = [
    StringService, ArrayService, CommonService,
    FlowService, PlatformService
];

const components = [
    AppMenuComponent, AppHeaderComponent, AppFooterComponent,
    AppBreadcrumbComponent, TCTableComponent, StepProgressBarComponent,
    AppLoaderComponent, TCModalComponent, TCDatetimeComponent,
    TCToggleComponent, TCCheckboxComponent, NotificationModalComponent, NotificationShortcutComponent,
    OverrideDataOwnerModalComponent
];

const bootstrapModules = [
    BsDropdownModule.forRoot()
];

@NgModule({
    declarations: [
        ...components
    ],
    imports: [
        CommonModule,
        FormsModule,
        ...bootstrapModules,
        ...widgetModules
    ],
    providers: [
        ...services
    ],
    exports: [
        ...components
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})

export class SharedModule { }