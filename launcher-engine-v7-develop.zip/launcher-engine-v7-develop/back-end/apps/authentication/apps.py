from django.apps import AppConfig


class Authentication(AppConfig):
    name = 'authentication'
