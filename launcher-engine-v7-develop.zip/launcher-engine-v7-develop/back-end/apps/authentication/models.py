import uuid

import jwt
from django.db import models
from django.utils.timezone import now
from jsonfield import JSONField

from apps.applications.models import Application


class OpenIDUser(object):
    """User from id token"""

    def __init__(self, id_token: str, application_code, addtional_information=dict()):
        id_token_info = jwt.decode(id_token, verify=False)
        self.id_token = id_token

        self.full_name = id_token_info.get('name') or ''
        self.first_name = '' if not id_token_info.get('name') else id_token_info.get('name').split(' ')[0]
        self.last_name = '' if not id_token_info.get('name') else id_token_info.get('name').split(' ', 1)[1]
        self.id = id_token_info.get('user_id')
        self.email = id_token_info.get("email", None)
        self.erm_role = id_token_info.get('erm_role')
        self.preferred_username = id_token_info.get('preferred_username')
        self.regis_service_id = id_token_info.get('regis_service_id')
        self.user_ucid = addtional_information.get('user_ucid')
        self.enterprise_role_name = addtional_information.get('enterprise_role_name')

            # use request.session_id
        # self.log_session_id = str(uuid.uuid4())
        self.last_login = addtional_information.get('last_login')
        self.original_data_controller = addtional_information.get('original_data_controller', dict()).get('value')
        self.original_data_controller_display = addtional_information.get('original_data_controller', dict()).get('display_label') or ''
        self.original_data_processor = addtional_information.get('original_data_processor', dict()).get('value')
        self.original_data_processor_display = addtional_information.get('original_data_processor', dict()).get('display_label') or ''
        self.original_branch = addtional_information.get('original_branch', dict()).get('value')
        self.original_branch_display = addtional_information.get('original_branch', dict()).get('display_label') or ''
        self.data_controller = addtional_information.get('data_controller', dict()).get('value')
        self.data_controller_display = addtional_information.get('data_controller', dict()).get('display_label') or ''
        self.data_processor = addtional_information.get('data_processor', dict()).get('value')
        self.data_processor_display = addtional_information.get('data_processor', dict()).get('display_label') or ''
        self.branch = addtional_information.get('branch', dict()).get('value')
        self.branch_display = addtional_information.get('branch', dict()).get('display_label') or ''
        self.sub_controller = addtional_information.get('sub_controller')

        self.app_id = application_code
        self.application_lable = str()
        self.application_configuration = dict()
        application = Application.objects.filter(code=application_code).first()
        if application is not None:
            self.application_lable = application.name
            self.application_configuration = application.config

        # 47-1, 47-2, {app_code}-{role_code}
        # self.group_role => self.__get_group_role()

    def __getattr__(self, item):
        if item == 'email':
            if '@' in self.preferred_username:
                return self.preferred_username
            else:
                return None
        else:
            return None

    def __str__(self):
        return f"{self.id} - {self.full_name}"



class JSONWebToken(models.Model):
    uuid = models.UUIDField(verbose_name="UUID", null=False, default=uuid.uuid4)
    id_token = models.TextField(verbose_name="ID Token", null=False)
    expired_at = models.DateTimeField(verbose_name="Token Expired Datetime", null=False, default=now)
    access_token = models.TextField(verbose_name="Access Token")
    refresh_token = models.TextField(verbose_name="Refresh Token")
    addtional_information = JSONField(default=dict(), verbose_name="Addtional Information")
