import uuid
import time
from datetime import datetime

import jwt
from django.http.response import HttpResponseRedirect
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.authentication.models import JSONWebToken
from apps.commons.error.exception import StandardException
from apps.commons.okta import core as okta
from apps.commons.connectors.bs import BusinessService
from apps.commons.connectors.ag import AccessGovernance
from apps.commons.utilities.log import Logger
from apps.commons.utilities.response import CustomJsonResponse, CustomResponseObject
from apps.commons.utilities.response import ResponseAPI
from apps.commons.logger.views import ViewLogger
from apps.commons.error.exception import *


class Login(APIView, ViewLogger):
    """
    OpenID login by return endpoint to Okta SSO
    """
    response_meta = ResponseAPI()

    def get(self, request):
        self.module_name = "Login"
        response_data = None
        try:
            self.logger.debug(
                'Login [reference id = {}] start'.format(self.logger.session_id))

            end_point = okta.generate_authen_endpoint(request)
            force_redirect = request.query_params.get('force_redirect', None)
            if force_redirect or force_redirect == '':
                return HttpResponseRedirect(redirect_to=end_point)
            else:
                response_data = self.response_meta.success(
                    'success', self.logger.session_id, end_point)

        except Exception as e:

            self.logger.error('Login [reference id = {}] exception: {} - {}'.format(
                self.logger.session_id, str(e), ""))
            response_data = self.response_meta.error(LoginFailedException, str(e), self.logger.session_id)

        finally:
            if response_data:
                self.logger.debug('Login [reference id = {}] response_data: {}'.format(self.logger.session_id, response_data))

                return Response(response_data, status=status.HTTP_200_OK)


class Authorize(APIView, ViewLogger):
    """
    Authorize by verify code from okta
    """

    @staticmethod
    def build_response_data(access_token: str, id_token: str):
        """
        Build response data after get data from okta verify code
        """
        try:
            id_token_info = jwt.decode(id_token, verify=False)
            data = {
                "agent_code": id_token_info.get("user_id"),
                "agent_id": id_token_info.get("user_id"),
                "agent_name": id_token_info.get("name"),
                "agent_user_lan": id_token_info.get("name").split('@')[0] if id_token_info.get("name", None) else '-',
                "agent_email": id_token_info.get("preferred_username"),
                "external_reference_code": "external_reference_code",
                "access_token": access_token,
                "id_token": id_token,
            }
        except Exception as e:
            data = {
                'meta': {
                    "response_code": 11000,
                    "response_desc": "Login Failed"
                },
                'error_detail': {
                    'error_code': "10002",
                    'error_stack': str(e),
                }
            }
        return data

    def get(self, request, code=None):
        """
        Check Authorize Code from Okta
        """
        response_meta = ResponseAPI()
        self.module_name = 'Authorize'
        response_data = {}
        response = None
        try:
            self.logger.debug(
                'Authorize [reference id = {}] start'.format(self.logger.session_id))

            verify = okta.verify_okta_token(request, code)
            result = verify.json()
            self.logger.debug('Verify Code from Okta :: okta status :: {} '.format(
                verify.status_code))
            if result and verify.status_code == 200:
                id_token = result.get("id_token", None)
                access_token = result.get("access_token", None)
                refresh_token = result.get("refresh_token", None)
                if access_token and id_token:
                    id_token_info = jwt.decode(id_token, verify=False)
                    self.logger.debug('id_token_info')
                else:
                    raise Exception("Invalid token")

                if id_token_info:
                    self.logger.debug('build_response_data after verify code (authorization)')

                    _response_data = response_meta.success(
                        'success', self.logger.session_id, self.build_response_data(access_token, id_token))

                    response = Response(_response_data, status=status.HTTP_200_OK)
                    expires = datetime.utcfromtimestamp(id_token_info['exp'])
                    response.set_cookie('id_token', id_token, expires=expires)
                    self.logger.debug(f"okta token expires [{id_token_info['exp']}] {expires}")

                    addtional_information = _get_employee_information(request, id_token)
                    JSONWebToken.objects.create(**{
                        'id_token': id_token,
                        'expired_at': datetime.fromtimestamp(id_token_info['exp']),
                        'access_token': access_token,
                        'refresh_token': refresh_token,
                        'addtional_information': addtional_information,
                    })

            else:
                raise Exception('Okta: ' + result.get('error_description'))

        except Exception as e:
            self.logger.error('Authorize [reference id = {}] exception: {} '.format(
                self.logger.session_id, str(e)))
            response_data = response_meta.error(UnAuthorizedException, str(e), self.logger.session_id)

        finally:
            self.logger.debug('Authorize [reference id = {}] response = {}'.format(
                self.logger.session_id, str(response)))
            if response and response is not None:
                return response
            else:
                return Response(response_data, status=status.HTTP_200_OK)

class RefreshToken(APIView):
    logger = Logger("RefreshToken")

    def get(self, request):
        try:
            jwt_model = JSONWebToken.objects.get(id_token=request.oidc_user.id_token)
            self.logger.debug(f'refresh length {len(jwt_model.refresh_token)}')
            result = okta.refresh_token(request, jwt_model.refresh_token)
            self.logger.debug(f'refresh response')
            result = result['data']
            id_token = result.get("id_token", None)
            access_token = result.get("access_token", None)
            refresh_token = result.get("refresh_token", None)
            if access_token and id_token:
                id_token_info = jwt.decode(id_token, verify=False)
            else:
                raise Exception("Invalid token")

            self.logger.debug('build_response_data after verify code (authorization)')
            _response_data = CustomResponseObject(data={
                'id_token': result.get('id_token')
            }).data
            response = Response(_response_data, status=status.HTTP_200_OK)
            expires = datetime.utcfromtimestamp(id_token_info['exp'])
            response.set_cookie('id_token', id_token, expires=expires)
            self.logger.debug(f"token expires [{id_token_info['exp']}] {expires}")
            jwt_model.delete()

            addtional_information = _get_employee_information(request, id_token)
            JSONWebToken.objects.create(**{
                'id_token': id_token,
                'expired_at': datetime.fromtimestamp(id_token_info['exp']),
                'access_token': access_token,
                'refresh_token': refresh_token,
                'addtional_information': addtional_information,
            })
            return response
        except ValueError as e:
            return CustomJsonResponse(data=e)
        except StandardException as e:
            return CustomJsonResponse(data=e)


def _get_employee_information(request, id_token):
    data = {
        'original_data_controller': dict(),
        'original_data_processor': dict(),
        'original_branch': dict(),
        'data_controller': dict(),
        'data_processor': dict(),
        'sub_controller': str(),
        'branch': dict(),
        'last_login': str(),
        'enterprise_role_name': str(),
        'user_ucid': str()
    }

    id_token_information = jwt.decode(id_token, verify=False)

    register_service_id = id_token_information.get('regis_service_id')
    if register_service_id is not None and register_service_id:
        try:
            user_attribute = {
                'user_id': id_token_information.get('user_id'),
                'username': id_token_information.get('preferred_username'),
                'log_session_id': str(uuid.uuid4()),
                'app_id': request.app_code
            }
            response = BusinessService.get_register_service_information(user_attribute, register_service_id)

            customer_information = response.get('customer_information')
            if customer_information is not None:
                employee_info = BusinessService.get_employee_information(user_attribute, customer_information)

                data['enterprise_role_name'] = employee_info.get('enterprise_role_name')
                data['user_ucid'] = employee_info.get('customer_information')
                data['sub_controller'] = employee_info.get('sub_controller')

                data['original_branch']['display_label'] = None if type(employee_info.get('branch')) is not list or len(
                    employee_info.get('branch')) < 1 else employee_info.get('branch', list())[0].get('branch_name_th')
                data['original_branch']['value'] = None if type(employee_info.get('branch')) is not list or len(
                    employee_info.get('branch')) < 1 else employee_info.get('branch', list())[0].get(
                    'branch_information')
                data['branch'] = data['original_branch']

                data['original_data_controller']['display_label'] = employee_info.get('company_name', None)
                data['original_data_controller']['value'] = employee_info.get('data_controller')
                data['data_controller'] = data['original_data_controller']

                data['original_data_processor']['display_label'] = employee_info.get('company_name', None)
                data['original_data_processor']['value'] = employee_info.get('data_processor')
                data['data_processor'] = data['original_data_processor']

        except Exception as e:
            pass

    try:
        response = AccessGovernance.get_last_login(user_attribute)

        __datetime = response.get('last_access_time')
        timestamp_str = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(__datetime))

        data['last_login'] = timestamp_str
    except Exception:
        pass

    return data
