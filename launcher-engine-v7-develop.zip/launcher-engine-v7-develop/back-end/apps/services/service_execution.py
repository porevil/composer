import json
import uuid
import re
import traceback
import requests
import sys
import os

from datetime import datetime
from django.db import transaction
from django.conf import settings
from django.http import HttpResponse
from rest_framework import status
from rest_framework import generics
from rest_framework.response import Response

from apps.commons.logger.views import ViewLogger
from apps.commons.utilities.log import Logger
from apps.commons.utilities.response import ResponseAPI, CustomResponseObject
from apps.services.abstract import ServiceExecution
from apps.commons.serializers import AbstractSerializer
from apps.commons.error.exception import *


class ServiceExecutionView(generics.ListCreateAPIView, ViewLogger):
    http_method_names = ['post', 'get']
    serializer_class = AbstractSerializer
    response_meta = ResponseAPI()

    def post(self, request, *args, **kwargs):
        response_type = ''
        service_header = None
        try:
            self.logger.debug('Service Execution API [reference id = {}] start'.format(self.logger.session_id))

            service_execution = ServiceExecution(self.logger.session_id)
            request_data = request.data
            self.logger.debug(
                'Service Execution API [reference id = {}] request data = {}'.format(self.logger.session_id,
                                                                                     str(request_data)))

            workflow_key = request.data.get('workflow_key')
            input_type_value = request.data.get('input_type_value') or dict()

            if workflow_key is None:
                raise BadRequestException('workflow_key is required')

            self.logger.debug(
                'Service Execution API [reference id = {}] workflow key = {}'.format(self.logger.session_id,
                                                                                     str(workflow_key)))

            flow_tracking = service_execution.get_flow_tracking(workflow_key) or dict()
            flow_intent = service_execution.get_flow_intent(workflow_key) or dict()

            self.logger.debug(
                'Service Execution API [reference id = {}] flow intent = {}'.format(self.logger.session_id,
                                                                                    str(flow_intent)))

            instance = service_execution.get_current_instance(flow_tracking)

            # self.logger.debug(
            #     'Service Execution API [reference id = {}] current instance = {}'.format(self.logger.session_id,
            #                                                                              str(current_instance)))
            self.logger.debug(
                'Service Execution API [reference id = {}] instance = {}'.format(self.logger.session_id, str(instance)))

            service_type = instance.get('service_type') or 'sync'
            response_type = instance.get('service_type') or 'json'
            tracking = instance.get('tracking') or dict()
            self.logger.session_id_property_name = tracking.get('self.logger.session_id_property_name')

            self.logger.debug(
                'Service Execution API [reference id = {}] service type = {} - {}'.format(self.logger.session_id,
                                                                                          str(service_type),
                                                                                          str(response_type)))

            intent_value = service_execution.find_intent_value(flow_intent, flow_tracking, input_type_value)

            intent_configurations = instance.get('intent') or dict()
            for intent_config in intent_configurations.get('ins') or list():
                intent_config['runtime_value'] = intent_value.get(intent_config.get('name'))

            request_body = service_execution.create_body_structure(instance)

            self.logger.debug(
                'Service Execution API [reference id = {}] body structure = {}'.format(self.logger.session_id,
                                                                                       str(request_body)))

            request_body = service_execution.assign_request_value(intent_configurations, request_body, instance)

            self.logger.debug(
                'Service Execution API [reference id = {}] body = {}'.format(self.logger.session_id, str(request_body)))

            url = service_execution.create_url(intent_configurations, instance)
            http_method = instance.get('request', dict()).get('http_method') or 'GET'
            http_method = http_method.upper().strip()

            self.logger.debug('Service Execution API [reference id = {}] url = {} - {}'.format(self.logger.session_id,
                                                                                               str(http_method),
                                                                                               str(url)))

            login_info = flow_tracking.get('login_info') or dict()
            headers = {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'client_id': settings.CLIENT_KEY,
                'client_secret': settings.CLIENT_SECRET_KEY,
                'app-meta': json.dumps({
                    'user_id': login_info.get('user_id'),
                    'user_name': login_info.get('username'),
                    'log_session_id': login_info.get('log_session_id') or str(uuid.uuid4()),
                    'state': settings.ENVIRONMENT,
                    'request_datetime': datetime.now().strftime("%d-%m-%Y %H:%M:%S"),
                    'sub_state': settings.SUB_ENVIRONMENT
                })
            }

            stream = None
            if response_type == 'display':
                stream = True

            if http_method == 'POST':
                service_response = requests.post(url, headers=headers, data=json.dumps(request_body),
                                                 verify=settings.SSL_CERT_FILE, stream=stream)
            elif http_method == 'GET':
                service_response = requests.get(url, headers=headers, verify=settings.SSL_CERT_FILE, stream=stream)
            elif http_method == 'PUT':
                service_response = requests.put(url, headers=headers, data=json.dumps(request_body),
                                                verify=settings.SSL_CERT_FILE, stream=stream)
            elif http_method == 'DELETE':
                service_response = requests.delete(url, headers=headers, data=json.dumps(request_body),
                                                   verify=settings.SSL_CERT_FILE, stream=stream)

            self.logger.debug(
                'Service Execution API [reference id = {}] response status code = {}'.format(self.logger.session_id,
                                                                                             str(
                                                                                                 service_response.status_code)))

            if response_type == 'json':
                try:
                    service_response = service_response.json()
                except Exception:
                    self.logger.error('Service Execution API [reference id = {}] service_response.text  = {}'.format(
                        self.logger.session_id, str(service_response.text)))
                    service_response.raise_for_status()

                result = service_execution.validate_service_response(service_response, instance)
                self.logger.debug(
                    'Service Execution API [reference id = {}] validate service response result = {}'.format(
                        self.logger.session_id, str(result)))

                if result['status'] == 'valid':
                    if service_type == 'async':
                        async_result = {
                            'tracking_self.logger.session_id': service_execution.get_value(
                                self.logger.session_id_property_name, service_response)
                        }
                        response = self.response_meta.success(result['message'], self.logger.session_id, async_result)
                    else:
                        service_execution.put_intent_runtime(flow_intent, flow_tracking, service_response)
                        response = self.response_meta.success(result['message'], self.logger.session_id)

                elif result['status'] == 'warning':
                    response = self.response_meta.warning(result['message'], self.logger.session_id)

                else:
                    response = CustomResponseObject(data=result['message'], session=self.logger.session_id).data

            else:
                if service_response.status_code != 200:
                    raise ExternalServerErrorException(
                        'error : API Error {} - {}'.format(url, service_response.status_code))

                try:
                    service_response = service_response.raw.read()
                    service_header = dict(service_response.headers)
                except Exception:
                    self.logger.error('Service Execution API [reference id = {}] service_response.text = {}'.format(
                        self.logger.session_id, str(service_response.text)))
                    raise ExternalServerErrorException(
                        'error : Can not read binary {} - {}'.format(url, str(service_response.text)))
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            exception_message = exc_type, fname, exc_tb.tb_lineno

            self.logger.error(
                'Service Execution API [reference id = {}] exception: {} - {}'.format(self.logger.session_id, str(e),
                                                                                      str(exception_message)))
            response = self.response_meta.error(e, str(e), self.logger.session_id, str(exc_type), fname,
                                                str(exc_tb.tb_lineno))
        finally:
            self.logger.debug(
                'Service Execution API [reference id = {}] response = {}'.format(self.logger.session_id, str(response)))
            if response_type == 'display':
                response_object = HttpResponse(service_response)
                if service_header is not None:
                    header_key = ['access-control-allow-headers',
                                  'access-control-allow-origin',
                                  'access-control-expose-headers',
                                  'access-control-max-age',
                                  'content-disposition',
                                  'content-type',
                                  'Content-Length'
                                  ]

                    for key in header_key:
                        if key in service_header:
                            response_object[key] = service_header.get(key)

                return response_object

            return Response(response, status=status.HTTP_200_OK)

    def get(self, request, *args, **kwargs):
        try:
            logger = Logger('Service Execution API', 'GET')
            self.logger.debug('Service Execution API [reference id = {}] start'.format(self.logger.session_id))

            service_execution = ServiceExecution(self.logger.session_id)

            workflow_key = request.query_params.get('workflow_key') or None
            self.logger.debug(
                'Service Execution API [reference id = {}] workflow_key = {}'.format(self.logger.session_id,
                                                                                     str(workflow_key)))

            tracking_id = request.query_params.get('tracking_id') or None
            self.logger.debug(
                'Service Execution API [reference id = {}] tracking_id = {}'.format(self.logger.session_id,
                                                                                    str(tracking_id)))

            if workflow_key is None:
                raise BadRequestException('workflow_key is required')

            if tracking_id is None:
                raise BadRequestException('tracking_id is required')

            flow_tracking = service_execution.get_flow_tracking(workflow_key) or dict()
            flow_intent = service_execution.get_flow_intent(workflow_key) or dict()

            self.logger.debug(
                'Service Execution API [reference id = {}] flow intent = {}'.format(self.logger.session_id,
                                                                                    str(flow_intent)))

            current_node_sequence = flow_tracking.get('current_node_sequence')
            current_instance_sequence = flow_tracking.get('current_instance_sequence')
            nodes = flow_tracking.get('nodes') or list()

            instance = dict()
            for node in nodes:
                if node.get('sequence') == current_node_sequence:
                    instances = node.get('instances') or list()
                    for instance in instances:
                        if instance.get('sequence') == current_instance_sequence:
                            instance = instance
                            break
                    break

            # self.logger.debug(
            #     'Service Execution API [reference id = {}] current instance = {}'.format(self.logger.session_id,
            #                                                                              str(current_instance)))
            self.logger.debug(
                'Service Execution API [reference id = {}] instance = {}'.format(self.logger.session_id, str(instance)))

            tracking = instance.get('tracking') or dict()
            tracking_url = tracking.get('url')

            if tracking_url is None:
                raise ConfigurationErrorException('Please, configure tracking url')

            if '{{tracking_id}}' in tracking_url:
                tracking_url = tracking_url.replace('{{tracking_id}}', tracking_id)
            else:
                if '?' in tracking_url:
                    tracking_url = tracking_url + tracking_id
                elif tracking_url[-1] == '/':
                    tracking_url = tracking_url + tracking_id
                else:
                    tracking_url = tracking_url + '/' + tracking_id

            self.logger.debug(
                'Service Execution API [reference id = {}] tracking URL = {} - {}'.format(self.logger.session_id,
                                                                                          str(tracking_url),
                                                                                          ''
                                                                                          )
            )

            login_info = flow_tracking.get('login_info') or dict()
            headers = {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'client_id': settings.CLIENT_KEY,
                'client_secret': settings.CLIENT_SECRET_KEY,
                'app-meta': json.dumps({
                    'user_id': login_info.get('user_id'),
                    'user_name': login_info.get('username'),
                    'log_session_id': login_info.get('log_session_id') or str(uuid.uuid4()),
                    'state': settings.ENVIRONMENT,
                    'request_datetime': datetime.now().strftime("%d-%m-%Y %H:%M:%S"),
                    'sub_state': settings.SUB_ENVIRONMENT
                })
            }

            service_response = requests.get(tracking_url, headers=headers, verify=settings.SSL_CERT_FILE)

            if service_response.status_code != 200:
                raise ExternalServerErrorException(
                    'error : API Error {} - {}'.format(tracking_url, service_response.status_code))

            try:
                service_response = service_response.json()
            except Exception:
                self.logger.error('Service Execution API [reference id = {}] service_response.text  = {}'.format(
                    self.logger.session_id, str(service_response.text)))
                service_response.raise_for_status()

            result = service_execution.validate_tracking_response(service_response, instance)
            self.logger.debug('Service Execution API [reference id = {}] validate tracking response result = {}'.format(
                self.logger.session_id, str(result)))

            if result['status'] == 'C':
                service_execution.put_intent_runtime(flow_intent, flow_tracking, service_response)
                response = self.response_meta.success(result['message'], self.logger.session_id, result)
            elif result['status'] == 'P':
                response = self.response_meta.success(result['message'], self.logger.session_id, result)
            else:
                response = CustomResponseObject(data=result['message'], session=self.logger.session_id).data

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            exception_message = exc_type, fname, exc_tb.tb_lineno

            self.logger.error(
                'Service Execution API [reference id = {}] exception: {} - {}'.format(self.logger.session_id, str(e),
                                                                                      str(exception_message)))
            response = self.response_meta.error(e, str(e), self.logger.session_id, str(exc_type), fname,
                                                str(exc_tb.tb_lineno))

        finally:
            self.logger.debug(
                'Service Execution API [reference id = {}] response = {}'.format(self.logger.session_id, str(response)))
            return Response(response, status=status.HTTP_200_OK)
