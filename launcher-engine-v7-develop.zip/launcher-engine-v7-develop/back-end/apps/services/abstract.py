import json
import uuid
import re
import traceback
import time
import uuid
import pytz

from datetime import datetime
from django.db import transaction
from django.conf import settings
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response

from apps.commons.utilities.cache import Cache
from apps.commons.utilities.log import Logger


class ServiceExecution:

    def __init__(self, reference_id):
        self.logger = Logger('Service Execution API', 'Abstract')
        self.reference_id = reference_id
        self.cache = Cache()

    def save_flow_tracking(self, workflow_key, flow):
        self.cache.put_json("FLOWTRACKING_{}".format(workflow_key), flow, (30 * 60))

    def get_flow_tracking(self, workflow_key):
        return self.cache.get_json("FLOWTRACKING_{}".format(workflow_key))

    def save_flow_intent(self, workflow_key, intent):
        self.cache.put_json("INTENT_{}".format(workflow_key), intent, (30 * 60))

    def get_flow_intent(self, workflow_key):
        return self.cache.get_json("INTENT_{}".format(workflow_key))

    def get_current_instance(self, flow_tracking):
        current_node_sequence = flow_tracking.get('current_node_sequence')
        current_instance_sequence = flow_tracking.get('current_instance_sequence')
        nodes = flow_tracking.get('nodes') or list()

        instance = dict()
        for node in nodes:
            if node.get('sequence') == current_node_sequence:
                instances = node.get('instances') or list()
                for instance in instances:
                    if instance.get('sequence') == current_instance_sequence:
                        instance = instance
                        break
                break

        return instance

    def put_intent_runtime(self, runtime_intent, flow_tracking, service_response):
        workflow_key = flow_tracking.get('workflow_key')
        current_instance = self.get_current_instance(flow_tracking)
        intent_config = current_instance.get('intent') or dict()
        intent_outs = intent_config.get('outs') or list()
        current_node_sequence = flow_tracking.get('current_node_sequence')
        current_instance_sequence = flow_tracking.get('current_instance_sequence')

        data = dict()
        data['instance_sequence'] = current_instance_sequence
        data['node_sequence'] = current_node_sequence

        for intent_out in intent_outs:
            intent_out_name = intent_out.get('name')
            intent_out_type = intent_out.get('type')

            if intent_out_name is not None and intent_out_type is not None:
                intent_out_name = intent_out_name.replace('[]', '[0]')
                data[intent_out_name] = self.get_value(intent_out_name, service_response)

        if not runtime_intent:
            runtime_intent['intents'] = list()
            runtime_intent['intents'].append(data)
        else:
            intents = runtime_intent.get('intents') or list()

            for index, intent in enumerate(intents):
                instance_sequence_cache = intent.get('instance_sequence')
                node_sequence_cache = intent.get('node_sequence')

                if current_instance_sequence == instance_sequence_cache and current_node_sequence == node_sequence_cache:
                    runtime_intent['intents'][index] = data
                    break
            else:
                runtime_intent['intents'].append(data)

        self.save_flow_intent(workflow_key, runtime_intent)

    def convert_type_data(self, expect_type, value):
        if expect_type == 'text':
            value = str(value)
        elif expect_type in ['number', 'integer', 'decimal', 'datetime']:
            value_str = str(value)

            if value_str.find('.') == -1:
                value = int(value)
            else:
                value = float(value)
        elif expect_type == 'boolean':
            if type(value).__name__ == 'str':
                value = value.lower()
                if value == 'true':
                    value = True
                elif value == 'false':
                    value = False
                else:
                    value = None
            elif type(value).__name__ == 'int':
                value = bool(value)
        elif expect_type == 'object':
            if not (isinstance(value, dict)):
                value = json.loads(value)

        return value

    def convert_type_json_data(self, expect_type, value):
        if expect_type == 'text':
            value = "\"" + str(value) + "\""
        elif expect_type in ['number', 'integer', 'decimal', 'datetime']:
            if value == '':
                value = None
        elif expect_type == 'boolean':
            if type(value).__name__ == 'str':
                value = value.lower()
                if value == 'true':
                    value = True
                elif value == 'false':
                    value = False
                else:
                    value = None
            elif type(value).__name__ == 'int':
                value = bool(value)
        elif expect_type == 'object':
            if not (isinstance(value, dict)):
                value = json.loads(value)
        else:
            raise Exception('Not support type {}'.format(expect_type))

        return value

    def convert_object_to_associate_array(self, _object):
        hierarchy = _object.split('.')
        parameter = ''
        for node in hierarchy:
            node = node.replace('[]', '[0]')
            _list = re.findall('\[(.+?)\]', node)
            if _list:
                _length = len(_list[0])
                parameter += "[\'" + node[:-(_length + 2)] + "\']" + '[' + _list[0] + ']'
            else:
                parameter += "[\'" + node + "\']"
        return parameter

    def find_intent_value(self, flow_intents, flow_tracking, input_type_values=None):
        if input_type_values is None:
            input_type_values = list()
        instance = self.get_current_instance(flow_tracking)
        intent_configurations = instance.get('intent', dict()).get('ins') or list()
        runtime_intents = flow_intents.get('intents') or list()

        result = dict()
        for intent_config in intent_configurations:
            intent_in_name = intent_config.get('name')
            if intent_in_name is None:
                continue

            intent_in_vtype = intent_config.get('vtype')
            intent_in_type = intent_config.get('type')
            intent_in_value = intent_config.get('value')
            intent_in_multiple = intent_config.get('multiple') or False
            field_value = None
            object_multiple_constant = False

            if intent_in_vtype == 'constant':
                if intent_in_multiple == True:
                    if intent_in_type == 'object':
                        intent_in_value = '[' + intent_in_value + ']'
                        object_multiple_constant = True
                    else:
                        intent_in_value = intent_in_value.split(',')
                        intent_in_value = [item.strip() for item in intent_in_value]

                field_value = intent_in_value

            elif intent_in_vtype == 'intent':
                vtype_intent_node_sequence = intent_config.get('vtype_intent_node_sequence')
                vtype_intent_instance_sequence = intent_config.get('vtype_intent_instance_sequence')

                for flow_intent in runtime_intents:
                    if flow_intent.get('node_sequence') == vtype_intent_node_sequence and flow_intent.get(
                            'instance_sequence') == vtype_intent_instance_sequence:
                        if intent_in_value is not None:
                            intent_in_value = intent_in_value.replace('[]', '[0]')
                            field_value = flow_intent.get(intent_in_value)

            elif intent_in_vtype == 'system':
                login_info = flow_tracking.get('login_info') or dict()

                if intent_in_value == 'APP_CODE':
                    field_value = login_info.get('app_id')
                elif intent_in_value == 'BRANCH_INFO_ID':
                    field_value = login_info.get('branch')
                elif intent_in_value == 'USER_ID':
                    field_value = login_info.get('user_id')
                elif intent_in_value == 'USER_UCID':
                    field_value = login_info.get('user_ucid')
                elif intent_in_value == 'USERNAME':
                    field_value = login_info.get('username')
                elif intent_in_value == 'ERM_ROLE':
                    field_value = login_info.get('erm_role')
                elif intent_in_value == 'DATA_CONTROLLER':
                    field_value = login_info.get('data_controller')
                elif intent_in_value == 'SUB_CONTROLLER':
                    field_value = login_info.get('sub_controller')
                elif intent_in_value == 'DATA_PROCESSOR':
                    field_value = login_info.get('data_processor')
                elif intent_in_value == 'FLOW_SESSION_ID':
                    field_value = flow_tracking.get('workflow_key')
                elif intent_in_value == 'LOG_SESSION_ID':
                    field_value = login_info.get('log_session_id') or str(uuid.uuid4())
                elif intent_in_value == 'REGISTER_SERVICE_ID':
                    field_value = login_info.get('regis_service_id')
                elif intent_in_value == 'CURRENT_DATE':
                    if intent_in_type in ['number', 'integer', 'decimal', 'datetime']:
                        current = datetime.now(pytz.timezone("Asia/Bangkok")) \
                            .replace(hour=0, minute=0, second=0, microsecond=0) \
                            .astimezone(pytz.utc)
                        field_value = round(current.timestamp()) * 1000
                    elif intent_in_type == 'text':
                        field_value = datetime.now().strftime("%d/%m/%Y")
                elif intent_in_value == 'CURRENT_TIME':
                    if intent_in_type in ['number', 'integer', 'decimal', 'datetime']:
                        field_value = int(round(time.time() * 1000))
                    elif intent_in_type == 'text':
                        field_value = datetime.now().strftime("%H:%M:%S")
                elif intent_in_value == 'CURRENT_DATETIME':
                    if intent_in_type in ['number', 'integer', 'decimal', 'datetime']:
                        field_value = int(round(time.time() * 1000))
                    elif intent_in_type == 'text':
                        field_value = datetime.now().strftime("%d/%m/%Y %H:%M:%S")

            elif intent_in_vtype == 'input':
                for item in input_type_values:
                    if intent_in_name == item.get('name'):
                        field_value = item.get('value')
                        break

            if field_value is not None:
                try:
                    if intent_in_multiple == True:
                        result_list = list()
                        if isinstance(field_value, list):
                            for item in field_value:
                                item_value = self.convert_type_data(intent_in_type, item)
                                result_list.append(item_value)
                        elif object_multiple_constant == True:
                            field_value = self.convert_type_data(intent_in_type, field_value)
                            result_list = field_value
                        else:
                            field_value = self.convert_type_data(intent_in_type, field_value)
                            result_list.append(field_value)

                        field_value = result_list
                    else:
                        field_value = self.convert_type_json_data(intent_in_type, field_value)

                except Exception as exc:
                    raise Exception(exc)

            result[intent_in_name] = field_value

        return result

    def assign_request_value(self, intent_config, request_dict, instance):
        request = instance.get('request') or dict()
        request_params = request.get('params') or list()

        # Assign request from request -> params
        for request_param in request_params:
            request_param_name = request_param.get('name')
            request_param_value = request_param.get('value')
            request_param_type = request_param.get('type')
            request_param_multiple = request_param.get('multiple') or False

            if request_param_name is None or (
                    request_param_name[0:2] == '{{' and request_param_name[-2] + request_param_name[-1] == '}}'):
                continue

            request_param_name = self.convert_object_to_associate_array(request_param_name)
            if request_param_value is not None:
                if request_param_multiple == True:
                    result = list()
                    if request_param_type == 'object':
                        request_param_value = '[' + request_param_value + ']'
                        request_param_value = self.convert_type_data(request_param_type, request_param_value)
                        result = request_param_value
                    else:
                        request_param_value = request_param_value.split(',')
                        request_param_value = [item.strip() for item in request_param_value]

                        for value in request_param_value:
                            result.append(self.convert_type_data(request_param_type, value))

                    request_param_value = result

                else:
                    request_param_value = self.convert_type_json_data(request_param_type, request_param_value)

                exec('request_dict' + request_param_name + ' = {}'.format(request_param_value))

        # Assign request from intent
        intent_in_configurations = intent_config.get('ins') or list()
        for intent_in in intent_in_configurations:
            intent_in_name = intent_in.get('name')
            intent_in_value = intent_in.get('runtime_value')
            intent_in_type = intent_in.get('type')
            intent_in_multiple = intent_in.get('multiple') or False

            if intent_in_name is None or (
                    intent_in_name[0:2] == '{{' and intent_in_name[-2] + intent_in_name[-1] == '}}'):
                continue

            intent_in_name = self.convert_object_to_associate_array(intent_in_name)
            if intent_in_value is not None:
                if intent_in_multiple:
                    result = list()
                    if type(intent_in_value) is list:
                        for value in intent_in_value:
                            result.append(self.convert_type_data(intent_in_type, value))
                    else:
                        if intent_in_type == 'object':
                            intent_in_value = '[' + intent_in_value + ']'
                            intent_in_value = self.convert_type_data(intent_in_type, intent_in_value)
                            result = intent_in_value
                        else:
                            intent_in_value = intent_in_value.split(',')
                            intent_in_value = [item.strip() for item in intent_in_value]

                            for value in intent_in_value:
                                result.append(self.convert_type_data(intent_in_type, value))

                    intent_in_value = result

                else:
                    intent_in_value = self.convert_type_json_data(intent_in_type, intent_in_value)

                exec('request_dict' + intent_in_name + ' = {}'.format(intent_in_value))

        return request_dict

    def create_url(self, intent_config, instance):
        request = instance.get('request') or dict()
        request_params = request.get('params') or list()
        url_unique_parameters = list()
        url = instance.get('url', "")
        url_parameters = re.findall('{{(.+?)}}', url)

        for url_parameter in url_parameters:  # remove duplicate
            if url_parameter not in url_unique_parameters:
                url_unique_parameters.append(url_parameter)

        for url_parameter in url_unique_parameters:
            url_parameter_value = str()
            # instance --> request --> params , assign constant value from service request param
            for request_param in request_params:
                request_param_name = request_param.get('name')
                request_param_value = request_param.get('value')
                if '{{' + url_parameter + '}}' == request_param_name:
                    if request_param_value is not None:
                        url = url.replace('{{' + url_parameter + '}}', request_param_value)
                    break

            #  replace with intent value
            for intent in intent_config.get('ins'):
                intent_key_name = intent.get('name')
                intent_value = intent.get('runtime_value')
                if "{{" + url_parameter + "}}" == intent_key_name:
                    if intent_value is not None:
                        url = url.replace('{{' + url_parameter + '}}', intent_value)
                    break

        return url

    def create_body_structure(self, instance):
        request = instance.get('request') or dict()
        request_params = request.get('params') or list()
        request_dict = dict()
        for request_param in request_params:
            request_param_name = request_param.get('name')

            if request_param_name is None or (
                    request_param_name[0:2] == '{{' and request_param_name[-2] + request_param_name[-1] == '}}'):
                continue

            node_parameter = str()
            request_param_hierarchy = request_param.split('.')
            for node in request_param_hierarchy:
                node = node.replace('[]', '[0]')
                node_parameter += self.convert_object_to_associate_array(node)

                try:
                    eval('request_dict' + node_parameter)
                    continue
                except Exception:
                    pass

                array_index = re.findall('\[(.+?)\]', node)

                if array_index:
                    array_index = array_index[0]
                    result = list()
                    for _ in range(int(array_index) + 1):
                        result.append(dict())

                    exec('request_dict' + node_parameter[:-(len(array_index) + 2)] + ' = {}'.format(result))

                else:
                    exec('request_dict' + node_parameter + ' = {}'.format(dict()))

        return request_dict

    def get_value(self, property_name, data):
        result = None
        if property_name is not None:
            property_name = self.convert_object_to_associate_array(property_name)
            try:
                result = eval('data' + property_name)
            except Exception:
                pass

        return result

    def validate_service_response(self, service_response, instance):
        result = {
            'service_response': service_response,
            'status': "valid",
            'message': "success"
        }

        # Validate Success from API
        response_success_condition = instance.get('response', dict()).get('success') or dict()
        condition_name = response_success_condition.get('name')
        condition_type = response_success_condition.get('type')
        condition_value = response_success_condition.get('value')
        failure_message_name = instance.get('response', dict()).get('message')

        if condition_name is not None and condition_type is not None and condition_value is not None:
            service_response_value = self.get_value(condition_name, service_response)
            condition_value = self.convert_type_data(condition_type, condition_value)

            if service_response_value != condition_value:

                failure_message = self.get_value(failure_message_name, service_response) or 'API Failure'
                result['status'] = 'invalid'
                result['message'] = failure_message
                self.logger.debug('Service Execution API [reference id = {}] API Failure {}'.format(self.reference_id, failure_message))
                return result

            self.logger.debug('Service Execution API [reference id = {}] API Success'.format(self.reference_id))

        # Validate condition from flow configuration
        validity = instance.get('validity') or dict()
        validity_message = validity.get('message') or dict()
        bypass_validation = validity.get('bypass_validation') or True

        # Valid condition
        valid_condition = validity.get('valid_condition') or dict()
        valid_name = valid_condition.get('name')
        valid_type = valid_condition.get('type')
        valid_value = valid_condition.get('value')
        valid_message_name = validity_message.get('valid')
        valid_message_format = validity_message.get('fvalid')

        # Warning condition
        warning_condition = validity.get('warning_condition') or dict()
        warning_name = warning_condition.get('name')
        warning_type = warning_condition.get('type')
        warning_value = warning_condition.get('value')
        warning_message_name = validity_message.get('warning')
        warning_message_format = validity_message.get('fwarning')

        # Invalid condition
        invalid_message_name = validity_message.get('invalid')
        invalid_message_format = validity_message.get('finvalid')

        self.logger.debug('Service Execution API [reference id = {}] bypass_validation {}'.format(self.reference_id,
                                                                                                  bypass_validation))

        if bypass_validation == False:
            # Check valid
            if valid_name is not None and valid_type is not None and valid_value is not None:
                service_response_value = self.get_value(valid_name, service_response)
                valid_value = self.convert_type_data(valid_type, valid_value)

                if service_response_value == valid_value:
                    self.logger.debug('Service Execution API [reference id = {}] valid'.format(self.reference_id))

                    valid_message = 'valid'
                    valid_message = self.get_value(valid_message_name, service_response) or str()
                    if valid_message_format is not None:
                        valid_message = valid_message_format.replace('${}', str(valid_message))

                    result['message'] = valid_message
                    return result

            # Check warning
            if warning_name is not None and warning_type is not None and warning_value is not None:
                service_response_value = self.get_value(warning_name, service_response)
                warning_value = self.convert_type_data(warning_type, warning_value)

                if service_response_value == warning_value:
                    self.logger.debug('Service Execution API [reference id = {}] warning'.format(self.reference_id))

                    warning_message = 'warning'
                    warning_message = self.get_value(warning_message_name, service_response) or str()
                    if warning_message_format is not None:
                        warning_message = warning_message_format.replace('${}', str(warning_message))

                    result['status'] = 'warning'
                    result['message'] = warning_message
                    return result

            # Invalid
            self.logger.debug('Service Execution API [reference id = {}] invalid'.format(self.reference_id))

            invalid_message = 'invalid'
            invalid_message = self.get_value(invalid_message_name, service_response) or str()
            if invalid_message_format is not None:
                invalid_message = invalid_message_format.replace('${}', str(invalid_message))

            result['status'] = 'invalid'
            result['message'] = invalid_message
            return result

        return result

    def validate_tracking_response(self, service_response, instance):
        tracking = instance.get('tracking') or dict()
        checking = tracking.get('checking') or dict()
        checking_message_name = checking.get('message')
        status = checking.get('status') or dict()
        status_name = status.get('name')
        status_complete_value = status.get('complete_value')
        status_fail_value = status.get('fail_value')
        response_status_value = None
        response_message_value = 'processing'
        result = dict()

        if status_name is not None:
            response_status_value = self.get_value(status_name, service_response)
        else:
            result['status'] = 'F'
            result['message'] = 'Please, configure status name property'
            return result

        if checking_message_name is not None:
            response_message_value = self.get_value(checking_message_name, service_response)

        result['message'] = response_message_value
        result['status'] = 'P'

        if response_status_value == status_complete_value:
            result['status'] = 'C'
        elif response_status_value == status_fail_value:
            result['status'] = 'F'

        return result
