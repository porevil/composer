import json
import requests
import sys
import os
import re
import time
import uuid

from django.conf import settings
from django.http import HttpResponse, Http404
from rest_framework import status
from rest_framework.response import Response
from rest_framework import generics


from apps.commons.utilities.log import Logger
from apps.commons.utilities.response import ResponseAPI
from apps.flows.models import Flow
from apps.services.abstract import ServiceExecution
from apps.commons.serializers import AbstractSerializer
from apps.commons.logger.views import ViewLogger
from apps.commons.error.exception import *


class GetCacheView(generics.ListCreateAPIView, ViewLogger):
    response_meta = ResponseAPI()
    http_method_names = ['post']
    serializer_class = AbstractSerializer

    def post(self, request):
        logger = Logger('Get Cache API', 'GET')

        try:
            self.logger.debug('Get Cache API [reference id = {}] start'.format(self.logger.session_id))

            service_execution = ServiceExecution(self.logger.session_id)

            workflow_key = request.headers.get('wfk')
            self.logger.debug('Get Cache API [reference id = {}] workflow_key - {}'.format(self.logger.session_id, str(workflow_key)))

            if not workflow_key:
                raise BadRequestException('workflow_key is required')

            flow_tracking = service_execution.get_flow_tracking(workflow_key) or dict()
            flow_intent = service_execution.get_flow_intent(workflow_key) or dict()

            result = service_execution.find_intent_value(flow_intent, flow_tracking)

            data = dict()
            for key, value in result.items():
                if key[0:2] == '{{' and key[len(key) - 2:] == '}}':
                    continue

                node_parameter = str()
                hierarchy = key.split('.')

                for index, node in enumerate(hierarchy, 1):
                    parameter = ''
                    node = node.replace('[]', '[0]')
                    node_parameter += service_execution.convert_object_to_associate_array(node)

                    try:
                        eval('data' + node_parameter)
                        continue
                    except Exception:
                        pass
                    
                    array_index = re.findall('\[(.+?)\]', node)

                    if array_index:
                        array_index = array_index[0]
                        _value = list()
                        for i in range(int(array_index) + 1):
                            _value.append(dict())

                        exec('data' + node_parameter[:-(len(array_index) + 2)] + ' = {}'.format(_value))
                            
                    else:
                        if len(hierarchy) == index:
                            exec('data' + node_parameter + ' = {}'.format(value))
                        else:
                            exec('data' + node_parameter + ' = {}'.format(dict()))

            response = self.response_meta.success('success', self.logger.session_id, data)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            exception_message = exc_type, fname, exc_tb.tb_lineno

            self.logger.error('Get Cache API [reference id = {}] exception: {} - {}'.format(self.logger.session_id, str(e), str(exception_message)))
            response = self.response_meta.error(e, str(e), self.logger.session_id, str(exc_type), fname, str(exc_tb.tb_lineno))

        finally:
            self.logger.debug('Get Cache API [reference id = {}] response = {}'.format(self.logger.session_id, str(response)))
            return Response(response, status=status.HTTP_200_OK)


class PutCacheView(generics.ListCreateAPIView, ViewLogger):
    response_meta = ResponseAPI()
    http_method_names = ['post']
    serializer_class = AbstractSerializer


    def post(self, request):
        logger = Logger('Put Cache API', 'GET')

        try:
            self.logger.debug('Put Cache API [reference id = {}] start'.format(self.logger.session_id))

            request_data = request.data
            self.logger.debug('Put Cache API [reference id = {}] request_data - {}'.format(self.logger.session_id, str(request_data)))

            workflow_key = request.headers.get('wfk')
            if not workflow_key:
                raise BadRequestException('workflow_key is required')
            
            param = request_data.get('param') or dict()
            if type(param) is list:
                param = param[0]

            service_execution = ServiceExecution(self.logger.session_id)

            flow_tracking = service_execution.get_flow_tracking(workflow_key) or dict()
            flow_intent = service_execution.get_flow_intent(workflow_key) or dict()

            instance = service_execution.get_current_instance(flow_tracking) or dict()
            intent_outs = (instance.get('intent') or dict()).get('outs') or list()

            data = dict()
            for intent_out in intent_outs:
                intent_out_name = intent_out.get('name')
                intent_out_multiple = intent_out.get('multiple') or False
                value = service_execution.get_value(intent_out_name, param)

                if intent_out_multiple:
                    result_list = list()
                    if type(value) is not list:
                        result_list.append(value)
                        value = result_list

                intent_out_name = intent_out_name.replace('[]', '[0]')
                data[intent_out_name] = value

            current_node_sequence = flow_tracking.get('current_node_sequence')
            current_instance_sequence = flow_tracking.get('current_instance_sequence')

            data['node_sequence'] = current_node_sequence
            data['instance_sequence'] = current_instance_sequence

            if not flow_intent:
                intents = list()
                intents.append(data)

            else:
                intents = flow_intent.get('intents') or list()
                for index, intent in enumerate(intents):
                    if intent.get('node_sequence') == current_node_sequence and intent.get('instance_sequence') == current_instance_sequence:
                        intents[index] = data
                        break

                else:
                    intents.append(data)

            data = {
                'intents': intents,
            }

            service_execution.save_flow_intent(workflow_key, data)

            response = self.response_meta.success('success', self.logger.session_id, data)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            exception_message = exc_type, fname, exc_tb.tb_lineno

            self.logger.error('Put Cache API [reference id = {}] exception: {} - {}'.format(self.logger.session_id, str(e), str(exception_message)))
            response = self.response_meta.error(e, str(e), self.logger.session_id, str(exc_type), fname, str(exc_tb.tb_lineno))

        finally:
            self.logger.debug('Put Cache API [reference id = {}] response = {}'.format(self.logger.session_id, str(response)))
            return Response(response, status=status.HTTP_200_OK)

