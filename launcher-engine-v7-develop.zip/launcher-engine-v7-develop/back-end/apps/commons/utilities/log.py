from django.conf import settings
from tisco.core.tfg_log.logger import TfgLogger
from apps.commons.utilities.log_color import init_logger
import logging

class Logger:

    def __init__(self, module_name=None, class_name=None, **kwargs):
        self.engine_name = settings.ENGINE_CODE
        self.module_name = module_name
        self.class_name = class_name
        self.user_type = 'System'
        self.portal_id = kwargs.get('portal_id', None)
        self.workflow_Id = kwargs.get('workflow_Id', None)
        self.request = None
        self.session_id = kwargs.get('session_id', None)
        self.user_id = kwargs.get('user_id', None)
        self.user_role = kwargs.get('user_role', None)
        self.tfg_log = self.get_log()

    def set_portal_id(self, portal_id):
        self.portal_id = portal_id

    def set_workflow_id(self, workflow_id):
        self.workflow_Id = workflow_id

    def set_request(self, request):
        self.request = request

    def set_session_id(self, session_id):
        self.session_id = session_id

    def set_user_id(self, user_id):
        self.user_type = 'Employee'
        self.user_id = user_id

    def set_user_role(self, user_role):
        self.user_role = user_role

    def get_log(self):
        return TfgLogger.getLogger(
            ENGINE_NAME=self.engine_name,
            COMPONENT_NAME=self.module_name,
            SERVICE_NAME=self.class_name,
            USER_TYPE=self.user_type,
            PORTAL_ID=self.portal_id,
            WORKFLOW_ID=self.workflow_Id,
            REQUEST=self.request,
            SESSION_ID=self.session_id,
            USER_ID=self.user_id,
            USER_ROLE=self.user_role,
        )
        # return tfg_log

    def authen(self, message):
        # print('authen : {}'.format(message))
        if settings.LOG_MODE == "DEV":
            logger = init_logger("AUTHEN", testing_mode=True)
            logger.info(format(message))
        # self.tfg_log = self.get_log()
        self.tfg_log.debug(message)

    def activity(self, message):
        # print('activity : {}'.format(message))
        if settings.LOG_MODE == "DEV":
            logger = init_logger("ACTIVITY", testing_mode=True)
            logger.info(format(message))
        # self.tfg_log = self.get_log()
        self.tfg_log.info(message)

    def debug(self, message):
        # print('debug : {}'.format(message))
        if settings.LOG_MODE == "DEV":
            logger = init_logger("DEBUG", testing_mode=True)
            logger.info(format(message))
        # self.tfg_log = self.get_log()
        self.tfg_log.debug(message)

    def error(self, message):
        # print('error : {}'.format(message))
        if settings.LOG_MODE == "DEV":
            logger = init_logger("ERROR", testing_mode=True)
            logger.error(format(message))
        # self.tfg_log = self.get_log()
        self.tfg_log.exception(message)
