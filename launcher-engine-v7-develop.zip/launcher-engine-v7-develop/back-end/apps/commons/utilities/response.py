import traceback
import uuid
from datetime import datetime

from django.http.response import JsonResponse as BaseJsonResponse
from django.db import Error
from rest_framework.exceptions import APIException

from apps.commons.error.exception import *
from apps.commons.logger.views import ViewLogger
from apps.commons.utilities.log import Logger


def get_error_response(exception, error_stack=str(), ref=str(), exc_type=str(), filename=str(), lineno=str()):
    response_format = {
        'meta': {
            'response_code': '11000',
            'response_datetime': datetime.now().strftime("%d-%m-%Y %H:%M:%S"),
            'response_ref': ref,
            'response_desc': str()
        },
        'error_detail': {
            'error_code': str(),
            'error_stack': str(),
            'exception_type': type(exception).__name__,
            'error_file': filename,
            'error_line': lineno,
        }
    }
    custom_exception = (ConfigurationErrorException
                        , LoginFailedException
                        , UnAuthorizedException
                        , InvalidAppCodeException
                        , ActionUnAuthorizedException,)

    if isinstance(exception, custom_exception):
        response_format['meta']['response_desc'] = exception.error_message
        response_format['error_detail']['error_code'] = exception.error_code
        response_format['error_detail']['error_stack'] = error_stack or str(exception)

    elif isinstance(exception, (ExternalServerErrorException, BadRequestException)):
        response_format['meta']['response_desc'] = str(exception).capitalize()
        response_format['error_detail']['error_code'] = exception.error_code
        response_format['error_detail']['error_stack'] = exception.error_message
    elif isinstance(exception, Error):
        response_format['meta']['response_desc'] = 'Database has problem'
        response_format['error_detail']['error_code'] = '20001'
        response_format['error_detail']['error_stack'] = error_stack or str(exception)
    else:
        response_format['meta']['response_desc'] = 'Internal server error'
        response_format['error_detail']['error_code'] = '40001'
        response_format['error_detail']['error_stack'] = error_stack or str(exception)

    # response_format['error_detail']['error_stack'] = error_stack or str(exception)

    return response_format


class ResponseAPI:

    def ok(self, description, ref='', data=None):
        response = {
            "meta": {
                "response_code": "10000",
                "response_datetime": datetime.now().strftime("%d-%m-%Y %H:%M:%S"),
                "response_ref": ref,
                "response_desc": description
            }
        }

        if data is not None:
            response['data'] = data

        return response

    def success(self, description, ref='', data=None, pagination=None):
        response = {
            "meta": {
                "response_code": "10000",
                "response_datetime": datetime.now().strftime("%d-%m-%Y %H:%M:%S"),
                "response_ref": ref,
                "response_desc": description
            }
        }

        if data is not None:
            response['data'] = data

        if pagination is not None:
            response['pagination'] = pagination

        return response

    def error(self, exception, error_stack=str(), ref=str(), exc_type=str(), filename=str(), lineno=str()):
        return get_error_response(exception, error_stack, ref, exc_type, filename, lineno)

    def warning(self, description, ref='', data=None):
        response = {
            "meta": {
                "response_code": "10001",
                "response_datetime": datetime.now().strftime("%d-%m-%Y %H:%M:%S"),
                "response_ref": ref,
                "response_desc": description
            }
        }

        if data is not None:
            response['data'] = data
        return response


class CustomResponseObject(object):

    def __init__(self,
                 data=None,
                 session_id=str(uuid.uuid4()),
                 description=None,
                 **kwargs):
        self.session_id = session_id
        if isinstance(data, Exception):
            self.data = get_error_response(data)
        else:
            self.data = {
                'meta': {
                    "response_code": "10000",
                    "response_datetime": datetime.now().strftime("%d-%m-%Y %H:%M:%S"),
                    "response_ref": session_id,
                    "response_desc": description or 'Success'
                }
            }
        if isinstance(data, (dict, list)) or data:
            self.data['data'] = data


class CustomJsonResponse(BaseJsonResponse):
    """
    :param data: Any Data to response represent as json
    :param **kwargs:
    """
    logger = Logger("CustomJsonResponse")

    def __init__(self,
                 data=None,
                 session_id=str(uuid.uuid4()),
                 description=None,
                 **kwargs):
        if kwargs.get('logger', None):
            print("setting ...")
            self.logger = kwargs.get('logger')
        # self.logger.debug(f'CustomJsonResponse data: {data}')
        # self.logger.debug(
        #     f'CustomJsonResponse response: {CustomResponseObject(data, session_id, description, **kwargs).data}')
        super().__init__(data=CustomResponseObject(data, session_id, description, **kwargs).data, **kwargs)
