import enum

class ApplicationType(enum.Enum):
    Normal = 1
    RepresentativeDataProcessor = 2
    ViewDataProcessor = 3
    RepresentativeDataController = 4
    ViewDataController = 5
