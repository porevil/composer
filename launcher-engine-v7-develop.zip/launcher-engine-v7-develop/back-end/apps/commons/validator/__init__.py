from django.core import exceptions
from django.core.validators import BaseValidator
import jsonschema
from jsonschema import Draft7Validator, validators


def extend_with_default(validator_class):
    validate_properties = validator_class.VALIDATORS["properties"]

    def set_defaults(validator, properties, instance, schema):
        for _property, sub_schema in properties.items():
            if "default" in sub_schema:
                instance.setdefault(_property, sub_schema["default"])

        for error in validate_properties(
                validator, properties, instance, schema,
        ):
            yield error

    return validators.extend(
        validator_class, {"properties": set_defaults},
    )


class JSONSchemaValidator(BaseValidator):
    def compare(self, a, b):
        try:
            validator_class = extend_with_default(Draft7Validator)
            validator_class(b).validate(a)
        except jsonschema.exceptions.ValidationError as e:
            raise exceptions.ValidationError(e.message)
        except Exception as e:
            raise e
