def generate_okta_header():
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'accept': 'application/json',
        'Cache-Control': 'no-cache',
        'cache-control': 'no-cache'
    }
    return headers
