import requests
from django.conf import settings
from django.http import JsonResponse
from requests.auth import HTTPBasicAuth

from apps.applications.models import Application


def generate_json_endpoint(request):  # not used
    if settings.IS_LOCAL:
        okta_client_id = settings.OKTA_CLIENT_ID
        okta_client_secret = settings.OKTA_CLIENT_SECRET
        okta_redirect_uri = settings.OKTA_REDIRECT_URI
    else:
        application = Application.objects.filter(code=request.app_code).first()
        if application is None:
            raise Exception('application code: {} is invalid'.format(request.app_code))

        application_configuration = application.config

        okta_client_id = application_configuration.get('okta_client_id')
        okta_client_secret = application_configuration.get('okta_client_secret')
        okta_redirect_uri = application_configuration.get('okta_redirect_uri')

    data = {
        'data': [{
            'client_id': okta_client_id,
            'redirect_uri': okta_redirect_uri,
            'response_type': settings.OKTA_RESPONSE_TYPE,
            'state': settings.OKTA_STATE,
            'nonce': settings.NONCE,
            'scope': settings.OKTA_SCOPE
        }]
    }
    return JsonResponse(data)


def generate_authen_endpoint(request):
    if settings.IS_LOCAL:
        okta_client_id = settings.OKTA_CLIENT_ID
        okta_client_secret = settings.OKTA_CLIENT_SECRET
        okta_redirect_uri = settings.OKTA_REDIRECT_URI

    else:
        application = Application.objects.filter(code=request.app_code).first()
        if application is None:
            raise Exception('application code: {} is invalid'.format(request.app_code))

        application_configuration = application.config

        okta_client_id = application_configuration.get('okta_client_id')
        okta_client_secret = application_configuration.get('okta_client_secret')
        okta_redirect_uri = application_configuration.get('okta_redirect_uri')

    query_string_in_list_format = [
        'client_id=' + okta_client_id,
        'redirect_uri=' + okta_redirect_uri,
        'response_type=' + settings.OKTA_RESPONSE_TYPE,
        'state=' + settings.OKTA_STATE,
        'nonce=' + settings.NONCE,
        'scope=' + settings.OKTA_SCOPE
    ]
    authen_endpoint = settings.OKTA_SERVICE_ENDPOINT + '/oauth2/default/v1/authorize?' + '&'.join(query_string_in_list_format)
    return authen_endpoint


def verify_okta_token(request, token):
    """
    token : token from okta
    :return:
    """
    if settings.IS_LOCAL:
        okta_client_id = settings.OKTA_CLIENT_ID
        okta_client_secret = settings.OKTA_CLIENT_SECRET
        okta_redirect_uri = settings.OKTA_REDIRECT_URI

    else:
        application = Application.objects.filter(code=request.app_code).first()
        if application is None:
            raise Exception('application code: {} is invalid'.format(request.app_code))

        application_configuration = application.config

        okta_client_id = application_configuration.get('okta_client_id')
        okta_client_secret = application_configuration.get('okta_client_secret')
        okta_redirect_uri = application_configuration.get('okta_redirect_uri')

    endpoint = settings.OKTA_SERVICE_ENDPOINT + '/oauth2/default/v1/token'
    # application = Application.objects.get(ag_app_id=ag_app_id)
    body = {
        'grant_type': 'authorization_code',
        'redirect_uri': okta_redirect_uri,  # 'http://localhost:3200/verifycode'
        'client_id': okta_client_id,  # '0oaajfqpqu9kYwL971t7'
        'client_secret': okta_client_secret,  # 'NshhQRqkWihYBIGyk3mCtzvb_i1tcW68YxwAP1Q7'
        'code': token
    }
    res = requests.post(endpoint, data=body, verify=not settings.IS_LOCAL)
    return res


def refresh_token(request, token):
    if settings.IS_LOCAL:
        okta_client_id = settings.OKTA_CLIENT_ID
        okta_client_secret = settings.OKTA_CLIENT_SECRET
        okta_redirect_uri = settings.OKTA_REDIRECT_URI

    else:
        application = Application.objects.filter(code=request.app_code).first()
        if application is None:
            raise Exception('application code: {} is invalid'.format(request.app_code))

        application_configuration = application.config

        okta_client_id = application_configuration.get('okta_client_id')
        okta_client_secret = application_configuration.get('okta_client_secret')
        okta_redirect_uri = application_configuration.get('okta_redirect_uri')

    endpoint = settings.IDENTITY_SERVICE_ENDPOINT + '/refreshToken'
    body = {
        'data': {
            'grant_type': 'refresh_token',
            'refresh_token': token,
        }
    }
    res = requests.post(endpoint, json=body, auth=HTTPBasicAuth(okta_client_id, okta_client_secret), verify=not settings.IS_LOCAL)
    # :success response
    # {
    #     "data": {
    #         "token_type": "Bearer",
    #         "id_token": "XXXXXXX",
    #         "expires_in": 3600,
    #         "access_token": "XXXXX",
    #         "refresh_token": "XXXXXX"
    #     },
    #     "meta": {
    #         "response_desc": "Success",
    #         "response_ref": "x-x-x-x-x",
    #         "response_code": "20000",
    #         "response_datetime": "07-05-2020 02:37:52"
    #     }
    # }
    return res.json()
