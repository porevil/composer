import uuid

from django.http import HttpRequest
from rest_framework.request import Request

from apps.commons.utilities.log import Logger
from django.conf import settings


class ViewLogger(object):
    """
    Integration for Django and TfgLogger
    """
    engine_name = settings.ENGINE_CODE

    request = None

    user_id = None
    """
    USER_ID: for identify user request
    """
    module_name = None
    """
    COMPONENT_NAME: log display
    """

    class_name = None
    """
    SERVICE_NAME: log display
    """

    user_type = None

    portal_id = None

    workflow_Id = None

    session_id = None

    user_role = None

    def __get_log(self):
        """
        get logger instance
        :return:
        """
        log_params = {
            'engine_name': settings.ENGINE_CODE,
            'module_name': self.get_module_name(),
            'class_name': self.class_name,
            'user_type': 'System',
            'portal_id': self.portal_id,
            'workflow_Id': self.workflow_Id,
            'request': self.request,
            'session_id': self.get_session_id(),
            'user_id': self.user_id,
            'user_role': self.user_role,
        }
        return Logger(**log_params)

    def __getattribute__(self, name):
        if name == 'logger':
            return self.get_logger()
        else:
            return object.__getattribute__(self, name)

    def get_module_name(self):
        if self.module_name:
            return self.module_name
        else:
            return self.__class__.__name__

    def get_session_id(self):
        if isinstance(self.request, (HttpRequest, Request)) and hasattr(self.request, 'session_id'):
            return self.request.session_id
        elif self.session_id is not None:
            return self.session_id
        else:
            self.session_id = str(uuid.uuid4())
        return self.session_id

    def get_logger(self):
        if self.request is not None and hasattr(self.request, 'logger'):
            return self.request.logger
        if hasattr(self.request, 'oidc_user'):
            self.user_id = self.request.oidc_user.email
            self.user_role = self.request.oidc_user.erm_role
        return self.__get_log()
