import uuid
import traceback

from datetime import datetime

from django.http.response import JsonResponse
from rest_framework.views import exception_handler as base_exception_handler

from apps.commons.error.exception import StandardException
from apps.commons.utilities.log import Logger
from apps.commons.utilities.response import get_error_response
from apps.commons.utilities.log import Logger

def exception_handler(exc: Exception, context):
    # logger = Logger(exc.__class__.__name__)
    # ref = uuid.uuid4()
    # response_data = {
    #     "meta": {
    #         "response_code": "11000",
    #         "response_datetime": datetime.now().strftime("%d-%m-%Y %H:%M:%S"),
    #         "response_ref": ref,
    #         "response_desc": "Fail"
    #     },
    #
    # }
    # if isinstance(exc, StandardException):
    #     response_data['meta']['response_desc'] = exc.error_message
    #     response_data['error_detail'] = {
    #         'error_code': exc.error_code,
    #         'error_stack': exc.error_message
    #     }
    #     logger.error(f"StandardException exc.error_message")
    #     response = JsonResponse(data=response_data)
    # else:
    #     try:
    #         response_data['error_detail'] = {
    #             'error_code': "10000",
    #             'error_stack': str(exc)
    #         }
    #         logger.error(str(exc))
    #         response = JsonResponse(data=response_data)
    #     except Exception as e:
    #         logger.error(f"Exception catch {e}")
    #         response = base_exception_handler(exc, context)
    # traceback.print_exc()
    logger = Logger("Exception Handler")
    response = get_error_response(exc, ref=context['request'].session_id, filename=str(context['view']))
    logger.error(f"Error Response {response}")
    return JsonResponse(data=response)
