from rest_framework import serializers
from rest_framework.fields import JSONField

from apps.flows.models import Flow

class AbstractSerializer(serializers.ModelSerializer):

    class Meta:
        model = Flow
        fields = []
