import sys
import json
import requests

from django.conf import settings

from apps.commons.utilities.log import Logger


class DataEngine:

    LOGGER = Logger('Core Connector', 'Data Engine')
    RESPONSE_CODE_SUCCESS = "30000"

    @staticmethod
    def query_journal(dataset_name, filter_condition, order_by, options=dict()):
        try:
            query_command = 'select * from {}'.format(dataset_name)

            if filter_condition is not None and filter_condition:
                query_command += ' where {}'.format(filter_condition)

            if order_by is not None and order_by:
                query_command += ' order by {}'.format(order_by)

            request = {
                'request_data': {
                    'query': query_command,
                    '$options': options
                }
            }

            DataEngine.LOGGER.debug('Data Engine | Query journal request: {}'.format(request))

            endpoint, headers = DataEngine._get_endpoint_and_header()
            DataEngine.LOGGER.debug('Data Engine | Query journal endpoint: {}'.format(endpoint))

            response = requests.post(endpoint, headers=headers, data=json.dumps(request))
            status_code = response.status_code

            if status_code != 200:
                raise Exception('Cannot query journal (status code = {})'.format(status_code))
            
            response = response.json()
            if response["msg_code"] != DataEngine.RESPONSE_CODE_SUCCESS:
                raise Exception('Cannot query journal ({} - {})'.format(response['msg_code'], response['msg_detail']))

            return response.get('response_data')
        except Exception as e:
            DataEngine.LOGGER.error('Data Engine | Query journal exception: {}'.format(str(e)))
            raise e


    @staticmethod
    def _get_endpoint_and_header():
        endpoint = settings.DEP_URL + '/journal/query'

        return endpoint, {
            'Content-Type': 'application/json',
            'client_id': settings.CLIENT_KEY,
            'client_secret': settings.CLIENT_SECRET_KEY,
            'app-meta': json.dumps({
                'user_id': settings.COMPOSER_SERVICE_ACCOUNT,
                'user_name': 'channel service account',
                'sub_state': settings.SUB_ENVIRONMENT
            })
        }
