import sys
import json
import requests
import uuid

from django.conf import settings

from apps.commons.utilities.log import Logger


class AccessGovernance:

    LOGGER = Logger('Core Connector', 'Access Governance')
    RESPONSE_CODE_SUCCESS = "20000"

    @staticmethod
    def check_authorization(user_attribute, flow_roles):
        try:
            endpoint, headers = AccessGovernance._get_endpoint_and_header(user_attribute)
            AccessGovernance.LOGGER.debug('Access Governance | Check authorization endpoint: {}'.format(endpoint))

            request_data = dict()
            request_data['data'] = dict()
            request_data['data']['id'] = flow_roles

            AccessGovernance.LOGGER.debug('Access Governance | Check authorization request_data: {}'.format(request_data))
            
            response = requests.post(endpoint, headers=headers, data=json.dumps(request_data))
            status_code = response.status_code

            if status_code != 200:
                raise Exception('Cannot check authorization (status code = {})'.format(status_code))
            
            try:
                response = response.json()
            except Exception:
                raise Exception('response is not json - {}'.format(response.text))

            meta_response = response.get('meta') or dict()
            if not meta_response:
                raise Exception('Cannot get employee information - {}'.format(response))
            if meta_response.get('response_code') != AccessGovernance.RESPONSE_CODE_SUCCESS:
                raise Exception('Cannot check authorization ({} - {})'.format(meta_response.get('response_code'), meta_response.get('response_desc')))

            AccessGovernance.LOGGER.debug('Access Governance | Check authorization response: {}'.format(response))
            return response.get('data')
        except Exception as e:
            AccessGovernance.LOGGER.error('Access Governance | Check authorization exception: {}'.format(str(e)))
            raise e

    
    @staticmethod
    def get_last_login(user_attribute):
        try:
            endpoint, headers = AccessGovernance._get_endpoint_and_header(user_attribute, True)
            AccessGovernance.LOGGER.debug('Access Governance | Get last login endpoint: {}'.format(endpoint))

            response = requests.get(endpoint, headers=headers)
            # response = requests.get(endpoint, headers=headers, verify=settings.SSL_CERT_FILE)
            status_code = response.status_code

            if status_code != 200:
                raise Exception('Cannot Get last login (status code = {})'.format(status_code))
            
            try:
                response = response.json()
            except Exception:
                raise Exception('response is not json - {}'.format(response.text))

            meta_response = response.get('meta') or dict()
            if not meta_response:
                raise Exception('Cannot get employee information - {}'.format(response))
            if meta_response.get('response_code') != AccessGovernance.RESPONSE_CODE_SUCCESS:
                raise Exception('Cannot Get last login ({} - {})'.format(meta_response.get('response_code'), meta_response.get('response_desc')))

            AccessGovernance.LOGGER.debug('Access Governance | Get last login response: {}'.format(response))
            return response.get('data')
        except Exception as e:
            AccessGovernance.LOGGER.error('Access Governance | Get last login exception: {}'.format(str(e)))
            raise e


    @staticmethod
    def _get_endpoint_and_header(user_attribute, ag_management=False):
        if ag_management == False:
            endpoint = settings.AGS_AUTHORIZE_CHECK_URL + '/users/' + user_attribute.get('user_id')
        else:
            endpoint = settings.AG_MANAGEMENT_URL + '/users/' + user_attribute.get('user_id') + '/logs?app_access=' + user_attribute.get('app_id')

        return endpoint, {
            'Content-Type': 'application/json',
            'client_id': settings.CLIENT_KEY,
            'client_secret': settings.CLIENT_SECRET_KEY,
            'app-meta': json.dumps({
                'user_id': user_attribute.get('user_id'),
                'user_name': user_attribute.get('username'),
                'sub_state': settings.SUB_ENVIRONMENT,
                'log_session_id': user_attribute.get('log_session_id')
            })
        }
