# from django.http import HttpResponse, CustomJsonResponse, HttpRequest
from django.conf import settings

from apps.commons.error.exception import PermissionDeniedError, \
    InvalidAppCodeError
from apps.commons.utilities.response import CustomJsonResponse


def app_code_authorize(user_id, app_code):
    # TODO: authorize user permission
    result = True
    return result


class ApplicationCodeMiddleware:

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        app_code = request.headers.get('app-code', None)
        response = CustomJsonResponse(data={})
        try:
            if not request.path.startswith(settings.IGNORE_APP_CODE_URL) and not app_code:
                raise InvalidAppCodeError()
            if request.path.startswith(settings.IGNORE_APP_CODE_URL) \
                    or app_code_authorize(request.oidc_user.id, app_code):
                request.app_code = app_code
                return self.get_response(request)
            else:
                raise PermissionDeniedError()
        except Exception as e:
            return CustomJsonResponse(data=e)
