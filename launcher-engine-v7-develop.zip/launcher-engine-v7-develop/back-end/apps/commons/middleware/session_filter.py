import time

from django.conf import settings
from django.http import HttpResponse
from django.utils.deprecation import MiddlewareMixin

from apps.authentication.views import invalidate_workflowkeys


class SessionAge(MiddlewareMixin):

    def process_request(self, request):
        validate_session_expiry_paths = ['/api/launch_flow/' \
                                        , '/api/go_to_node/' ]

        token = request.headers.get('token')
        if token is None:
            # no need to reset time if calling notification api
            if request.path != "/api/notification_message/": 
                request.session.set_expiry(0)
        else:
            if request.path in validate_session_expiry_paths:
                for app_code, session in request.session.items():
                    if type(session) is not dict or session.get('token') is None:
                        continue

                    if token == session.get('token'):
                        if not settings.BYPASS_AUTHEN:
                            elapsedTime = time.time() - session.get('last_request')
                            if elapsedTime > (45*60):
                                invalidate_workflowkeys(request, token=token)
                                return HttpResponse('401 Unauthorized - Flow session expired', status=401)

                            session['last_request'] = time.time()
                            break
                        
                request.session.modified = True
                
        return None


        # # validate only new version (application-procedure)                                       
        # if 'token' in request.session:
        #     if request.path in validate_session_expiry_paths:
        #         token = json.loads(request.body.decode('utf-8')).get('token')
        #         if token != request.session.get('token'):
        #             return HttpResponse('401 Unauthorized - Flow session expired (Token invalid)', status=401)

        #         if 'lastRequest' in request.session:            
        #             elapsedTime = datetime.datetime.now() - request.session['lastRequest']
        #             if elapsedTime.seconds > (45 * 60):
        #                 invalidate_workflowkeys(request)
        #                 request.session.flush()
        #                 return HttpResponse('401 Unauthorized - Flow session expired', status=401)
        #         request.session['lastRequest'] = datetime.datetime.now()
        # else:
        #     # no need to reset time if calling notification api
        #     if request.path != "/api/notification_message/": 
        #         request.session.set_expiry(0)

        # return None
