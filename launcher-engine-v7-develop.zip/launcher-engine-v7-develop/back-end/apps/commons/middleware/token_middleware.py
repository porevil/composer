import uuid
import sys
import os

from django.conf import settings
from django.http import JsonResponse, HttpRequest
from django.utils.timezone import now

from apps.authentication.models import OpenIDUser as User, JSONWebToken
from apps.commons.utilities.log import Logger
from apps.commons.utilities.response import ResponseAPI
from apps.commons.error.exception import *



def get_token_header(request):
    id_token = request.headers.get('Authorization', None)
    if id_token and 'c' in id_token:
        return id_token.split(" ")[1]
    return None


def get_token_cookie(request):
    id_token = request.COOKIES.get('id_token', None)
    return id_token


def get_token(request):
    return get_token_cookie(request) or get_token_header(request)


class TokenMiddleware:
    request = None
    logger = Logger("TokenMiddleware")

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request: HttpRequest):
        self.logger.set_session_id(request.session_id)
        try:
            if request.path.startswith(settings.IGNORE_FILTER_URL):
                return self.get_response(request)
            else:
                id_token = get_token(request)
                jwt_model = JSONWebToken.objects.filter(id_token=id_token).first()
                if jwt_model is None:
                    raise Exception("Not Found Token")
                if jwt_model is not None and now() <= jwt_model.expired_at:
                    self.logger.debug(f"token length {len(id_token)}")
                    application_code = request.headers.get('app-code')
                    request.oidc_user = User(id_token, application_code, jwt_model.addtional_information)
                    self.logger.debug(f"Session as {request.oidc_user.email}")
                    return self.get_response(request)
                if jwt_model is not None and now() > jwt_model.expired_at:
                    jwt_model.delete()
                    raise Exception("Session Timeout")
            raise Exception("Invalid Token")
        except Exception as e:
            if request.path.startswith(settings.SOFT_AUTH_URL):
                self.logger.debug("Request passed by soft authentication")
                return self.get_response(request)

            self.logger.debug("Validate token fail")
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            exception_message = exc_type, fname, exc_tb.tb_lineno

            response = ResponseAPI()
            data = response.error(UnAuthorizedException, 'Unauthorized', str(uuid.uuid4()), exc_type, fname, exc_tb.tb_lineno)

            return JsonResponse(data)
