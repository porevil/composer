import json
import uuid
import re
import traceback
import requests
import sys
import os

from django.conf import settings
from rest_framework import status, generics
from rest_framework.response import Response

from apps.commons.logger.views import ViewLogger
from apps.commons.utilities.log import Logger
from apps.commons.utilities.response import ResponseAPI
from apps.commons.connectors.de import DataEngine
from apps.commons.serializers import AbstractSerializer
from apps.applications.models import Application
from apps.commons.constants import ApplicationType
from apps.authentication.models import JSONWebToken
from apps.commons.error.exception import *


class GetUserInformationView(generics.ListCreateAPIView, ViewLogger):
    http_method_names = ['get']
    serializer_class = AbstractSerializer
    response_meta = ResponseAPI()

    def get(self, request):
        try:
            self.module_name = 'Get User Information'
            self.logger.debug('get employee information API [reference id = {}] start'.format(self.logger.session_id))

            data = {
                'firstname': request.oidc_user.first_name,
                'lastname': request.oidc_user.last_name,
                'email': request.oidc_user.preferred_username,
                'last_login': request.oidc_user.last_login,
                'company': request.oidc_user.data_controller_display,
                'branch': request.oidc_user.branch_display,
                'enterprise_role': request.oidc_user.enterprise_role_name,
            }

            response = self.response_meta.success('success', self.logger.session_id, data)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            exception_message = exc_type, fname, exc_tb.tb_lineno

            self.logger.error('get employee information API [reference id = {}] exception: {} - {}'.format(self.logger.session_id, str(e), str(exception_message)))
            response = self.response_meta.error(e, str(e), self.logger.session_id, str(exc_type), fname, str(exc_tb.tb_lineno))

        finally:
            self.logger.debug('get employee information API [reference id = {}] response = {}'.format(self.logger.session_id,
                                                                                                 str(response)))
            return Response(response, status=status.HTTP_200_OK)


class GetRepresentativeUserChoicesView(generics.ListCreateAPIView, ViewLogger):
    http_method_names = ['get']
    serializer_class = AbstractSerializer
    response_meta = ResponseAPI()

    def get(self, request):
        try:
            self.module_name = 'Get Representative User Choices'
            self.logger.debug('get representative user choices API [reference id = {}] start'.format(self.logger.session_id))

            application = Application.objects.filter(code=request.oidc_user.app_id).first()
            if application is None:
                raise BadRequestException('"application code" is invalid')

            application_type = application.config.get('app_type') or ApplicationType.Normal.value

            result = {
                'popup': True,
                'choices': {
                    'branches': list(),
                    'representations': list()
                }
            }

            if application_type in [ApplicationType.RepresentativeDataProcessor.value,
                                    ApplicationType.RepresentativeDataController.value]:
                # find branch choices
                dataset_name = '1_1896'
                filter_condition = '_80005 = 2 and _1 = \"{}\"'.format(request.oidc_user.user_ucid)
                order_by = None
                options = {
                    'embed': ['_1358']
                }

                branches = list()

                try:
                    response = DataEngine.query_journal(dataset_name, filter_condition, order_by, options)
                    for branch in response:
                        description = (branch.get('_1358') or dict()).get('_9622')
                        value = (branch.get('_1358') or dict()).get('_1358')

                        if description is not None and value is not None:
                            branches.append({
                                'description': description,
                                'value': value
                            })
                except Exception as e:
                    self.logger.debug(
                        'get representative user choices API [reference id = {}] query branch error: {}'.format(
                            self.logger.session_id, str(e)))

                result['choices']['branches'] = branches

                # find representation choices
                if application_type == ApplicationType.RepresentativeDataProcessor.value:
                    dataset_name = '1_2108'
                    filter_condition = '_10011 = \"{}\" and _11639 = \"{}\" and _11638 = \"{}\" and _80005 = 2'.format(
                        request.oidc_user.app_id
                        , request.oidc_user.data_controller
                        , request.oidc_user.data_processor)
                else:
                    dataset_name = '1_2387'
                    filter_condition = '_10011 = \"{}\" and _80005 = 2'.format(request.oidc_user.app_id)

                order_by = None
                options = {
                    'embed': ['_1']
                }

                representations = list()

                try:
                    response = DataEngine.query_journal(dataset_name, filter_condition, order_by, options)

                    for representation in response:
                        description = (representation.get('_1') or dict()).get('_1291')
                        value = (representation.get('_1') or dict()).get('_1')

                        if description is not None and value is not None:
                            representations.append({
                                'description': description,
                                'value': value
                            })

                except Exception as e:
                    self.logger.debug(
                        'get representative user choices API [reference id = {}] query representation error: {}'.format(
                            self.logger.session_id, str(e)))

                result['choices']['representations'] = representations

            else:
                result['popup'] = False

            response = self.response_meta.success('success', self.logger.session_id, result)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            exception_message = exc_type, fname, exc_tb.tb_lineno

            self.logger.error('get representative user choices API [reference id = {}] exception: {} - {}'.format(self.logger.session_id, str(e), str(exception_message)))
            response = self.response_meta.error(e, str(e), self.logger.session_id, str(exc_type), fname, str(exc_tb.tb_lineno))

        finally:
            self.logger.debug(
                'get representative user choices API [reference id = {}] response = {}'.format(self.logger.session_id,
                                                                                               str(response)))
            return Response(response, status=status.HTTP_200_OK)


class OverrideRepresentation(generics.ListCreateAPIView, ViewLogger):
    http_method_names = ['post']
    serializer_class = AbstractSerializer
    response_meta = ResponseAPI()

    def post(self, request):
        try:
            self.module_name = 'Override Representation'
            self.logger.debug('override representative user API [reference id = {}] start'.format(self.logger.session_id))

            request_data = request.data
            self.logger.debug(
                'override representative user API [reference id = {}] request data - {}'.format(self.logger.session_id,
                                                                                                request_data))

            representative_user = request_data.get('representative_user')
            if representative_user is not None:
                if type(representative_user) is not dict or ('value' not in representative_user and 'description' not in representative_user):
                    raise BadRequestException('"representative_user" is wrong format')

            representative_branch = request_data.get('representative_branch') or dict()
            if representative_branch is not None:
                if type(representative_branch) is not dict or ('value' not in representative_branch and 'description' not in representative_branch):
                    raise BadRequestException('"representative_branch" is wrong format')

            application = Application.objects.filter(code=request.oidc_user.app_id).first()
            if application is None:
                raise BadRequestException('"application code" is invalid')

            application_type = application.config.get('app_type') or ApplicationType.Normal.value

            data = {
                'firstname': request.oidc_user.first_name,
                'lastname': request.oidc_user.last_name,
                'email': request.oidc_user.preferred_username,
                'last_login': request.oidc_user.last_login,
                'company': request.oidc_user.original_data_contoller_display,
                'branch': request.oidc_user.original_branch_display,
                'enterprise_role': request.oidc_user.enterprise_role_name,
            }

            if application_type in [ApplicationType.RepresentativeDataProcessor.value, ApplicationType.RepresentativeDataController.value]:
                jwt_model = JSONWebToken.objects.filter(id_token=request.oidc_user.id_token).first()
                if jwt_model is None:
                    raise BadRequestException('token is invalid')

                addtional_information = jwt_model.addtional_information

                if representative_branch:
                    addtional_information['branch']['value'] = representative_branch.get('value')
                    addtional_information['branch']['display_label'] = representative_branch.get('description')

                if representative_user:
                    addtional_information['data_processor']['value'] = representative_user.get('value')
                    addtional_information['data_processor']['display_label'] = representative_user.get('description')

                    if application_type == ApplicationType.RepresentativeDataController.value:
                        addtional_information['data_controller']['value'] = representative_user.get('value')
                        addtional_information['data_controller']['display_label'] = representative_user.get('description')

                jwt_model.addtional_information = addtional_information
                jwt_model.save()

                data['override'] = dict()
                data['override']['data_processor'] = (addtional_information.get('data_processor') or dict()).get('display_label')
                data['override']['data_controller'] = (addtional_information.get('data_controller') or dict()).get('display_label')
                data['override']['branch'] = (addtional_information.get('branch') or dict()).get('display_label')

            response = self.response_meta.success('success', self.logger.session_id, data)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            exception_message = exc_type, fname, exc_tb.tb_lineno

            self.logger.error('override representative user API [reference id = {}] exception: {} - {}'.format(self.logger.session_id, str(e), str(exception_message)))
            response = self.response_meta.error(e, str(e), self.logger.session_id, str(exc_type), fname, str(exc_tb.tb_lineno))

        finally:
            self.logger.debug('override representative user API [reference id = {}] response = {}'.format(self.logger.session_id,
                                                                                                     str(response)))
            return Response(response, status=status.HTTP_200_OK)
