import reversion

from django.db import models
from django.utils.translation import ugettext_lazy as _
from jsonfield import JSONField


@reversion.register()
class Flow(models.Model):

    uuid = models.UUIDField(verbose_name=_("UUID"))
    code = models.CharField(max_length=100, verbose_name=_("Code"))
    name = models.CharField(max_length=150, verbose_name=_("Name"))
    display_label = models.CharField(max_length=150, null=True, blank=True, verbose_name=_("Display Label"))
    sub_state = models.CharField(max_length=100, default=None, null=True, blank=True, verbose_name=_("Sub state"))
    system_data = models.BooleanField(default=False, verbose_name=_("Sysytem Data"))
    config = JSONField(null=True, verbose_name=_("Config"))

    create_date = models.DateTimeField(auto_now_add=True, verbose_name=_("Create Date"))
    update_date = models.DateTimeField(auto_now=True, verbose_name=_("Update Date"))

    class Meta:
        unique_together = ("uuid", "sub_state",)

    def __str__(self):
        return str(self.code)
