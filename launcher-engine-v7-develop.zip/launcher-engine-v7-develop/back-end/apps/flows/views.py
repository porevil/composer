import json
import requests
import sys
import os
import re
import time
import uuid
import redis

from django.conf import settings
from django.http import HttpResponse, Http404
from rest_framework import status
from rest_framework.response import Response
from rest_framework import generics

from apps.commons.utilities.log import Logger
from apps.commons.utilities.response import ResponseAPI
from apps.commons.error.exception import *
from apps.flows.api.serializers import AccessNodeSerializer
from apps.flows.models import Flow
from apps.commons.utilities.cache import Cache
from apps.commons.serializers import AbstractSerializer
from apps.commons.logger.views import ViewLogger


class LaunchFlowView(generics.ListCreateAPIView, ViewLogger):
    http_method_names = ['post']
    serializer_class = AbstractSerializer
    response_meta = ResponseAPI()
    cache = Cache()

    def contains(self, list, filter):
        for x in list:
            if filter(x):
                try:
                    return x['reference_uuid']
                except:
                    pass
        return None

    def post(self, request):
        # logger = Logger('Generate Flow Tracking API', 'GET')
        self.module_name = 'Generate Flow Tracking API'

        try:
            self.logger.debug('Generate Flow Tracking API [reference id = {}] start'.format(self.logger.session_id))

            request_data = request.data
            self.logger.debug(
                'Generate Flow Tracking API [reference id = {}] request_data - {}'.format(self.logger.session_id,
                                                                                          str(request_data)))

            flow_uuid = request_data.get('flow_uuid')
            self.logger.debug(
                'Generate Flow Tracking API [reference id = {}] flow_uuid - {}'.format(self.logger.session_id,
                                                                                       str(flow_uuid)))

            if not flow_uuid:
                raise BadRequestException('"flow_uuid" is required')

            workflow_key = str(uuid.uuid4())
            self.logger.debug(
                'Generate Flow Tracking API [reference id = {}] workflow_key - {}'.format(self.logger.session_id,
                                                                                          str(workflow_key)))

            flow = Flow.objects.filter(uuid=flow_uuid, sub_state=settings.SUB_ENVIRONMENT or None).first()
            if flow is None:
                raise BadRequestException(f'"flow_uuid {flow_uuid}" is invalid')

            instances = list()
            flow_config = flow.config
            ref_uuid = self.contains(flow_config.get('instances'), lambda x: x['sequence'] == 1)

            login_info = {
                'app_id': request.headers.get('app-code'),
                'app_label': request.oidc_user.application_label,
                'erm_role': request.oidc_user.erm_role,
                'sub_state': settings.SUB_ENVIRONMENT,
                'firstname': request.oidc_user.first_name,
                'lastname': request.oidc_user.last_name,
                'log_session_id': workflow_key,
                'user_id': request.oidc_user.id,
                'username': request.oidc_user.preferred_username,
                'user_ucid': request.oidc_user.user_ucid,
                'data_controller': request.oidc_user.data_contoller,
                'data_processor': request.oidc_user.data_processor,
                'sub_controller': request.oidc_user.sub_controller,
                'branch': request.oidc_user.branch,
                'regis_service_id': request.oidc_user.regis_service_id
            }

            data = {
                "code": flow.code,
                "uuid": str(flow.uuid),
                "name": flow.name,
                "display_label": flow.display_label,
                "login_info": login_info,
                "system_data": flow.system_data or False,
                "instances": flow_config.get('instances'),
                "workflow_key": workflow_key,
                # "current_node_sequence": 1,
                "current_reference_uuid": ref_uuid
            }

            self.cache.put_json("FLOWTRACKING_{}".format(workflow_key), data, (30 * 60))

            response = self.response_meta.success('success', self.logger.session_id, data)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            exception_message = exc_type, fname, exc_tb.tb_lineno

            self.logger.error(
                'Generate Flow Tracking API [reference id = {}] exception: {} - {}'.format(self.logger.session_id,
                                                                                           str(e),
                                                                                           str(exception_message)))
            response = self.response_meta.error(e, str(e), self.logger.session_id, str(exc_type), fname,
                                                str(exc_tb.tb_lineno))

        finally:
            self.logger.debug(
                'Generate Flow Tracking API [reference id = {}] response = {}'.format(self.logger.session_id,
                                                                                      str(response)))
            return Response(response, status=status.HTTP_200_OK)


class GoToNodeView(generics.ListCreateAPIView, ViewLogger):
    http_method_names = ['post']
    serializer_class = AccessNodeSerializer
    response_meta = ResponseAPI()
    cache = Cache()

    def post(self, request):
        self.module_name = 'Go To Node API'

        try:
            self.logger.debug('Go To Node API [reference id = {}] start'.format(self.logger.session_id))

            request_data = request.data
            self.logger.debug('Go To Node API [reference id = {}] request_data - {}'.format(self.logger.session_id,
                                                                                            str(request_data)))

            workflow_key = request_data.get('workflow_key')
            next_reference_uuid = request_data.get('next_reference_uuid')

            self.logger.debug('Go To Node API [reference id = {}] workflow_key - {}'.format(self.logger.session_id,
                                                                                            str(workflow_key)))

            if not workflow_key:
                raise BadRequestException('bad request: workflow_key is required')

            flow_tracking = self.cache.get_json("FLOWTRACKING_{}".format(workflow_key))

            flow_tracking['current_reference_uuid'] = next_reference_uuid

            data = dict()
            for instance in flow_tracking.get('instances') or list():
                if instance.get('reference_uuid') == next_reference_uuid:
                    data = instance
                    break  

            if data:
                self.cache.put_json("FLOWTRACKING_{}".format(workflow_key), flow_tracking, (30 * 60))
            else:
                raise Exception('bad request : "current_node_sequence" or "current_instance_sequence" is invalid')

            response = self.response_meta.success('success', self.logger.session_id, data)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            exception_message = exc_type, fname, exc_tb.tb_lineno

            self.logger.error(
                'Go To Node API [reference id = {}] exception: {} - {}'.format(self.logger.session_id, str(e),
                                                                               str(exception_message)))
            response = self.response_meta.error(e, str(e), self.logger.session_id, str(exc_type), fname,
                                                str(exc_tb.tb_lineno))

        finally:
            self.logger.debug(
                'Go To Node API [reference id = {}] response = {}'.format(self.logger.session_id, str(response)))
            return Response(response, status=status.HTTP_200_OK)
