import uuid
import json
import re
import traceback
import sys
import os

import rest_framework_filters as filters
from rest_framework import viewsets
from rest_framework import serializers
from rest_framework import status
from rest_framework.response import Response
from django.db import transaction
from django_filters.rest_framework import DjangoFilterBackend

from apps.flows.models import Flow
from apps.flows.api.serializers import FlowSerializer, FlowDetailSerializer
from apps.commons.utilities.response import ResponseAPI
from apps.commons.utilities.log import Logger
from apps.commons.logger.views import ViewLogger
from apps.commons.error.exception import *


class FlowFilter(filters.FilterSet):
    class Meta:
        model = Flow
        fields = {
            'code': ['exact', 'startswith', 'contains', 'icontains'],
            'name': ['exact', 'startswith', 'contains', 'icontains'],
            'uuid': ['exact'],
            'system_data': ['exact'],
        }


class FlowViewSet(viewsets.ViewSet, ViewLogger):
    response_meta = ResponseAPI()
    filter_class = FlowFilter

    def list(self, request):
        self.module_name = 'ListFlow API'

        try:
            self.logger.debug('List Flow API [reference id = {}] start'.format(self.logger.session_id))

            request_app_meta = request.META.get('HTTP_APP_META') or None
            if request_app_meta is None:
                raise BadRequestException('"headers app_meta" is required')

            request_app_meta = json.loads(request_app_meta)
            sub_state = None

            if 'env' not in request_app_meta:
                if 'sub_state' not in request_app_meta:
                    raise BadRequestException('"env or sub_state in app_meta" is required')
                else:
                    sub_state = request_app_meta.get('sub_state') or None
            else:
                sub_state = request_app_meta.get('env') or None

            self.logger.debug(
                'List Flow API [reference id = {}] sub_state = {}'.format(self.logger.session_id, str(sub_state)))

            queryset = Flow.objects.filter(sub_state=sub_state).order_by('id')
            queryset = DjangoFilterBackend().filter_queryset(self.request, queryset, self)
            serializer = FlowSerializer(queryset, many=True)
            response = self.response_meta.success("success", self.logger.session_id, serializer.data)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            exception_message = exc_type, fname, exc_tb.tb_lineno

            self.logger.error('List Flow API [reference id = {}] exception: {} - {}'.format(self.logger.session_id, str(e), str(exception_message)))
            response = self.response_meta.error(e, str(e), self.logger.session_id, str(exc_type), fname, str(exc_tb.tb_lineno))

        finally:
            self.logger.debug('Get Flow API [reference id = {}] response = {}'.format(self.logger.session_id, response))
            return Response(response, status=status.HTTP_200_OK)

    def retrieve(self, request, pk=None):
        self.module_name = 'Get Flow API'

        try:
            self.class_name = "GERERATE"
            self.logger.debug('Get Flow API [reference id = {}] start'.format(self.logger.session_id))

            request_app_meta = request.META.get('HTTP_APP_META') or None
            if request_app_meta is None:
                raise BadRequestException('"headers app_meta" is required')

            request_app_meta = json.loads(request_app_meta)
            sub_state = None

            if 'env' not in request_app_meta:
                if 'sub_state' not in request_app_meta:
                    raise BadRequestException('"env or sub_state in app_meta" is required')
                else:
                    sub_state = request_app_meta.get('sub_state') or None
            else:
                sub_state = request_app_meta.get('env') or None

            self.logger.debug(
                'Get Flow API [reference id = {}] sub_state = {}'.format(self.logger.session_id, str(sub_state)))

            result = list()
            queryset = Flow.objects.filter(uuid=pk, sub_state=sub_state).first()
            if queryset is None:
                raise BadRequestException('flow uuid is invalid')

            result = FlowDetailSerializer(queryset).data
            response = self.response_meta.success("success", self.logger.session_id, result)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            exception_message = exc_type, fname, exc_tb.tb_lineno

            self.logger.error('Get Flow API [reference id = {}] exception: {} - {}'.format(self.logger.session_id, str(e), str(exception_message)))
            response = self.response_meta.error(e, str(e), self.logger.session_id, str(exc_type), fname, str(exc_tb.tb_lineno))

        finally:
            self.logger.debug(
                'Get Flow API [reference id = {}] response = {}'.format(self.logger.session_id, str(response)))
            return Response(response, status=status.HTTP_200_OK)

    def create(self, request):
        self.module_name = 'Create Flow API'

        try:
            self.logger.debug('Create or Update Flow API [reference id = {}] start'.format(self.logger.session_id))

            request_data = request.data
            self.logger.debug('Create or Update Flow API [reference id = {}] request data = {}'.format(self.logger.session_id,
                                                                                                  str(request_data)))

            request_app_meta = request.META.get('HTTP_APP_META') or None
            if request_app_meta is None:
                raise BadRequestException('"headers app_meta" is required')

            request_app_meta = json.loads(request_app_meta)
            sub_state = None

            if 'env' not in request_app_meta:
                if 'sub_state' not in request_app_meta:
                    raise BadRequestException('"env or sub_state in app_meta" is required')
                else:
                    sub_state = request_app_meta.get('sub_state') or None
            else:
                sub_state = request_app_meta.get('env') or None

            self.logger.debug('Create or Update Flow API [reference id = {}] sub_state = {}'.format(self.logger.session_id,
                                                                                               str(sub_state)))

            flow_uuid = request_data.get('uuid')
            code = request_data.get('code')
            name = request_data.get('name')
            display_label = request_data.get('display_label')
            system_data = request_data.get('system_data') or False
            config = request_data.get('config') or dict()

            if flow_uuid is None:
                raise BadRequestException('"uuid" is required')
            if code is None:
                raise BadRequestException('"code" is required')

            result, created = Flow.objects.update_or_create(sub_state=sub_state, uuid=flow_uuid, defaults={
                'uuid': flow_uuid,
                'code': code,
                'name': name,
                'display_label': display_label,
                'system_data': system_data,
                'config': config,
                'sub_state': sub_state,
            })

            if created:
                response = self.response_meta.success("create success", self.logger.session_id,
                                                      FlowDetailSerializer(result).data)
            else:
                response = self.response_meta.success("update success", self.logger.session_id,
                                                      FlowDetailSerializer(result).data)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            exception_message = exc_type, fname, exc_tb.tb_lineno

            self.logger.error('Create or Update Flow API [reference id = {}] exception: {} - {}'.format(self.logger.session_id, str(e), str(exception_message)))
            response = self.response_meta.error(e, str(e), self.logger.session_id, str(exc_type), fname, str(exc_tb.tb_lineno))

        finally:
            self.logger.debug(
                'Create or Update Flow API [reference id = {}] response = {}'.format(self.logger.session_id, str(response)))
            return Response(response, status=status.HTTP_200_OK)


    def destroy(self, request, *args, **kwargs):
        self.module_name = 'Destroy Flow API'

        try:
            self.logger.debug('Delete Flow API [reference id = {}] start'.format(self.logger.session_id))

            request_app_meta = request.META.get('HTTP_APP_META') or None
            if request_app_meta is None:
                raise BadRequestException('"headers app_meta" is required')

            request_app_meta = json.loads(request_app_meta)
            sub_state = None

            if 'env' not in request_app_meta:
                if 'sub_state' not in request_app_meta:
                    raise BadRequestException('"env or sub_state in app_meta" is required')
                else:
                    sub_state = request_app_meta.get('sub_state') or None
            else:
                sub_state = request_app_meta.get('env') or None

            self.logger.debug(
                'Delete Flow API [reference id = {}] sub_state = {}'.format(self.logger.session_id, str(sub_state)))

            flow_uuid = kwargs.get('pk')
            flow = Flow.objects.filter(uuid=flow_uuid, sub_state=sub_state).first()
            if flow is None:
                raise BadRequestException('"flow uuid" is invalid')

            flow.delete()
            response = self.response_meta.success("delete success", self.logger.session_id)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            exception_message = exc_type, fname, exc_tb.tb_lineno
            
            self.logger.error('Delete Flow API [reference id = {}] exception: {} - {}'.format(self.logger.session_id, str(e), str(exception_message)))
            response = self.response_meta.error(e, str(e), self.logger.session_id, str(exc_type), fname, str(exc_tb.tb_lineno))

        finally:
            self.logger.debug('Delete Flow API [reference id = {}] response = {}'.format(self.logger.session_id, str(response)))
            return Response(response, status=status.HTTP_200_OK)
