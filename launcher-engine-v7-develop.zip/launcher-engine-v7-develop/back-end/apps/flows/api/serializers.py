import uuid
import json

from rest_framework import serializers

from apps.flows.models import Flow
from apps.procedures.models import ProcedureFlowMapping
from apps.procedures.api.serializers import ProcedureSerializer


class FlowSerializer(serializers.ModelSerializer):

    class Meta:
        model = Flow
        fields = [
            'id',
            'uuid',
            'code',
            'name',
            'display_label',
            'create_date',
            'update_date', 
        ]


class FlowDetailSerializer(serializers.ModelSerializer):

    class Meta:
        model = Flow
        fields = [
            'id',
            'uuid',
            'code',
            'name',
            'display_label',
            'system_data',
            'sub_state',
            'config',
            'create_date',
            'update_date', 
        ]


class AccessNodeSerializer(serializers.Serializer):
    workflow_key = serializers.CharField(required=True)
    next_node_sequence = serializers.IntegerField()
    next_instance_sequence = serializers.IntegerField(default=1)

    def create(self, validated_data):
        pass

    def update(self, instance, validated_data):
        pass
