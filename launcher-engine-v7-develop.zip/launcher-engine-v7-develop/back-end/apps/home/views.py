# import requests
# import json
# import uuid
# import sys
# import os
# import time
# import copy

# from decimal import *
# from operator import itemgetter

# from django.conf import settings
# from django.urls import reverse
# from django.shortcuts import render
# from django.template.loader import render_to_string
from django.views.generic import TemplateView
# from saml2 import BINDING_HTTP_POST
# from saml2 import BINDING_HTTP_REDIRECT
# from saml2 import entity
# from saml2.client import Saml2Client
# from saml2.config import Config as Saml2Config
# from django.http import HttpResponseRedirect
# from django.http import HttpResponseForbidden

# from apps.commons.utilities.log import Logger


class IndexTemplateView(TemplateView):

    template_name = "index.html"


    # def get_context_data(self, **kwargs):
    #     self.log_ref = str(uuid.uuid4())
    #     self.logger = Logger('IndexTemplateView')

    #     X_okta_request_id = self.request.session.get('X_Okta_Request_id', None)
    #     self.logger.set_session_id(X_okta_request_id)
    #     self.logger.debug('Home [reference id = {}] start'.format(self.log_ref))

    #     context = super().get_context_data(**kwargs)

    #     application = self.request.session.get('application', None)
    #     application_code = self.request.session.get('app_code', None)
    #     shelf_application_code = settings.APP_SHELF 
    #     bypass_authentication = settings.BYPASS_AUTHEN
    #     saml_attributes = self.request.session.get('saml_attributes', None)

    #     data_owner = self._get_employee_info(X_okta_request_id, saml_attributes)
    #     if bool(data_owner):
    #         self.request.session['data_owner'] = data_owner

    #     last_login = self._get_last_login()
    #     if bool(last_login):
    #         self.request.session['saml_attributes']['last_login'] = [ last_login ]

    #     self.logger.debug('Home [reference id = {}] application - {}'.format(self.log_ref, str(application)))
    #     self.logger.debug('Home [reference id = {}] application code - {}'.format(self.log_ref, str(application_code)))
    #     self.logger.debug('Home [reference id = {}] saml_attributes - {}'.format(self.log_ref, str(saml_attributes)))
    #     self.logger.debug('Home [reference id = {}] X_okta_request_id - {}'.format(self.log_ref, str(X_okta_request_id)))

    #     # Get Menu (Application --> Procedure --> Flow)
    #     use_cache = not bypass_authentication
    #     procedure_info = self._get_procedure_info(application, use_cache)
    #     self.logger.debug('Home [reference id = {}] use_cache - {}'.format(self.log_ref, use_cache))

    #     # get identity check flow Authorized
    #     if bypass_authentication:
    #         authorized_procedure_info = procedure_info
    #     else:
    #         authorized_procedure_info = self._filter_authorized_procedure_info(procedure_info, saml_attributes, X_okta_request_id)
    #     authorized_procedure_info = list(filter(lambda p: len(p.get('flows')) > 0, authorized_procedure_info))
        
    #     context = {
    #         'config_router': render_to_string('new_config.router.pattern.html', {
    #             'procedure_info': authorized_procedure_info,
    #         }),
    #         'procedure_info': authorized_procedure_info,
    #         'okta_data': saml_attributes,
    #         'sub_state': settings.SUB_ENVIRONMENT,
    #         'is_application_procedure': True,
    #         'display_data_owner_popup': application.get('representative_app', False),
    #         'override_data_controller': application.get('override_data_controller', False),
    #         'all_data_processor': application.get('all_data_processor', False),
    #         'debug': settings.DEBUG,
    #         'session_token': self.request.session.get('token'),
    #         # first serve rendering (launcher.html)
    #         'context_configuration': {
    #             'google_api_map_key': settings.GOOGLE_API_MAP_KEY,
    #         },
    #     }

    #     return context



    # def render_to_response(self, context, **response_kwargs):
    #     response = super(IndexTemplateView, self).render_to_response(context, **response_kwargs)
    #     response.set_cookie("se", self.request.session.session_key)
    #     return response

