import os

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.template.loader import render_to_string
from django.http import HttpResponse

from apps.commons.logger.views import ViewLogger


class GetStaticfile(APIView, ViewLogger):

    def get(self, request, filename=None):
        current_path = os.path.dirname(os.path.abspath(__file__))
        static_path = current_path.replace('/get_staticfile', '/static')

        response = str()
        with open(os.path.join(static_path, filename), 'r') as file:
            response = file.read()

        return HttpResponse(response, status=status.HTTP_200_OK, content_type="application/javascript")
