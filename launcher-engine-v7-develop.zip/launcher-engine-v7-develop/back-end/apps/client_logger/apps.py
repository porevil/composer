from django.apps import AppConfig


class ClientLoggerConfig(AppConfig):
    name = 'client_logger'
