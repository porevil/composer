from rest_framework import serializers


class ClientLoggerSerializer(serializers.Serializer):
    type = serializers.ChoiceField(choices=['debug', 'error', 'info'])
    message = serializers.CharField(max_length=255)
