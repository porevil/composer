import reversion

from django.db import models
from django.utils.translation import ugettext_lazy as _

from apps.flows.models import Flow


@reversion.register()
class Procedure(models.Model):

    uuid = models.UUIDField(verbose_name=_("UUID"))
    code = models.CharField(max_length=100, verbose_name=_("Code"))
    name = models.CharField(max_length=150, verbose_name=_("Name"))
    description = models.TextField(null=True, blank=True, verbose_name=_("description"))
    display_label = models.CharField(max_length=150, null=True, blank=True, verbose_name=_("Display Label"))
    sub_state = models.CharField(max_length=100, default=None, null=True, blank=True, verbose_name=_("Sub State"))
    system_data = models.BooleanField(default=False, verbose_name=_("Sysytem Data"))

    create_date = models.DateTimeField(auto_now_add=True, verbose_name=_("Create Date"))
    update_date = models.DateTimeField(auto_now=True, verbose_name=_("Update Date"))

    class Meta:
        unique_together = ("uuid", "sub_state",)

    def __str__(self):
        return str(self.code)



@reversion.register()
class ProcedureFlowMapping(models.Model):

    sequence = models.PositiveIntegerField(default=0, verbose_name=_("sequence"))
    procedure = models.ForeignKey(Procedure, on_delete=models.deletion.CASCADE, verbose_name=_("Procedure"))
    flow = models.ForeignKey(Flow, on_delete=models.deletion.CASCADE, verbose_name=_("Flow"))

    class Meta:
        unique_together = ("flow", "procedure",)

    def __str__(self):
        return "{} - {}".format(self.procedure.code, self.flow.code)
