import uuid
import json
import traceback

from rest_framework import serializers

from apps.procedures.models import Procedure
from apps.procedures.models import ProcedureFlowMapping
from apps.flows.models import Flow
# from apps.flows.api.serializers import FlowSerializer

traceback.print_exc()
class ProcedureSerializer(serializers.ModelSerializer):

    class Meta:
        model = Procedure
        fields = [
            'id',
            'uuid',
            'code',
            'name',
            'description',
            'sub_state',
            'display_label',
            'system_data',
            'create_date',
            'update_date', 
        ]


class ProcedureDetailSerializer(serializers.ModelSerializer):
    flows = serializers.SerializerMethodField()

    class Meta:
        model = Procedure
        fields = [
            'id',
            'uuid',
            'code',
            'name',
            'description',
            'display_label',
            'system_data',
            'sub_state',
            'flows',
            'create_date',
            'update_date', 
        ]

    def get_flows(self, obj):
        from apps.flows.api.serializers import FlowSerializer

        results = list()
        procedure_flow_mappings = ProcedureFlowMapping.objects.filter(procedure=obj)
        for procedure_flow_mapping in procedure_flow_mappings:
            flow = FlowSerializer(procedure_flow_mapping.flow).data
            if flow.get('system_data') == False:
                results.append(flow)

        return results

