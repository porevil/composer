import uuid
import json
import re
import traceback
import sys
import os

import rest_framework_filters as filters
from rest_framework import viewsets
from rest_framework import serializers
from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import list_route
from django.db import transaction
from django_filters.rest_framework import DjangoFilterBackend

from apps.commons.logger.views import ViewLogger
from apps.flows.models import Flow
from apps.procedures.models import Procedure
from apps.procedures.models import ProcedureFlowMapping
from apps.procedures.api.serializers import ProcedureSerializer
from apps.procedures.api.serializers import ProcedureDetailSerializer
from apps.commons.utilities.response import ResponseAPI
from apps.commons.utilities.log import Logger
from apps.commons.error.exception import *

class ProcedureFilter(filters.FilterSet, ViewLogger):
    class Meta:
        model = Procedure
        fields = {
            'code': ['exact', 'startswith', 'contains', 'icontains'],
            'name': ['exact', 'startswith', 'contains', 'icontains'],
            'uuid': ['exact'],
            'system_data': ['exact'],
        }


class ProcedureViewSet(viewsets.ViewSet, ViewLogger):
    response_meta = ResponseAPI()
    filter_class = ProcedureFilter

    def list(self, request):
        # logger = Logger('List Procedure API', 'GET')

        try:
            self.logger.debug('List Procedure API [reference id = {}] start'.format(self.logger.session_id))

            request_app_meta = request.META.get('HTTP_APP_META') or None
            if request_app_meta is None:
                raise BadRequestException('"headers app_meta" is required')

            request_app_meta = json.loads(request_app_meta)
            sub_state = None

            if 'env' not in request_app_meta:
                if 'sub_state' not in request_app_meta:
                    raise BadRequestException('"env or sub_state in app_meta" is required')
                else:
                    sub_state = request_app_meta.get('sub_state') or None
            else:
                sub_state = request_app_meta.get('env') or None

            self.logger.debug(
                'List Procedure API [reference id = {}] sub_state = {}'.format(self.logger.session_id, str(sub_state)))

            queryset = Procedure.objects.filter(sub_state=sub_state).order_by('id')
            queryset = DjangoFilterBackend().filter_queryset(self.request, queryset, self)
            serializer = ProcedureSerializer(queryset, many=True)
            response = self.response_meta.success("success", self.logger.session_id, serializer.data)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            exception_message = exc_type, fname, exc_tb.tb_lineno

            self.logger.error('List Procedure API [reference id = {}] exception: {} - {}'.format(self.logger.session_id, str(e), str(exception_message)))
            response = self.response_meta.error(e, str(e), self.logger.session_id, str(exc_type), fname, str(exc_tb.tb_lineno))

        finally:
            self.logger.debug(
                'Get Procedure API [reference id = {}] response = {}'.format(self.logger.session_id, str(response)))
            return Response(response, status=status.HTTP_200_OK)

    def retrieve(self, request, pk=None):
        # logger = Logger('Get Procedure API', 'GET')

        try:
            self.logger.debug('Get Procedure API [reference id = {}] start'.format(self.logger.session_id))

            request_app_meta = request.META.get('HTTP_APP_META') or None
            if request_app_meta is None:
                raise BadRequestException('"headers app_meta" is required')

            request_app_meta = json.loads(request_app_meta)
            sub_state = None

            if 'env' not in request_app_meta:
                if 'sub_state' not in request_app_meta:
                    raise BadRequestException('"env or sub_state in app_meta" is required')
                else:
                    sub_state = request_app_meta.get('sub_state') or None
            else:
                sub_state = request_app_meta.get('env') or None

            self.logger.debug(
                'Get Procedure API [reference id = {}] sub_state = {}'.format(self.logger.session_id, str(sub_state)))

            result = list()
            queryset = Procedure.objects.filter(uuid=pk, sub_state=sub_state).first()
            if queryset is None:
                raise BadRequestException('procedure uuid is invalid')

            result = ProcedureDetailSerializer(queryset).data
            response = self.response_meta.success("success", self.logger.session_id, result)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            exception_message = exc_type, fname, exc_tb.tb_lineno

            self.logger.error('Get Procedure API [reference id = {}] exception: {} - {}'.format(self.logger.session_id, str(e), str(exception_message)))
            response = self.response_meta.error(e, str(e), self.logger.session_id, str(exc_type), fname, str(exc_tb.tb_lineno))

        finally:
            self.logger.debug(
                'Get Procedure API [reference id = {}] response = {}'.format(self.logger.session_id, str(response)))
            return Response(response, status=status.HTTP_200_OK)

    def create(self, request):
        # logger = Logger('Create or Update Procedure API', 'POST')

        try:
            self.logger.debug('Create or Update Procedure API [reference id = {}] start'.format(self.logger.session_id))

            request_data = request.data
            self.logger.debug(
                'Create or Update Procedure API [reference id = {}] request data = {}'.format(self.logger.session_id,
                                                                                              str(request_data)))

            request_app_meta = request.META.get('HTTP_APP_META') or None
            if request_app_meta is None:
                raise BadRequestException('"headers app_meta" is required')

            request_app_meta = json.loads(request_app_meta)
            sub_state = None

            if 'env' not in request_app_meta:
                if 'sub_state' not in request_app_meta:
                    raise BadRequestException('"env or sub_state in app_meta" is required')
                else:
                    sub_state = request_app_meta.get('sub_state') or None
            else:
                sub_state = request_app_meta.get('env') or None

            self.logger.debug('Create or Update Procedure API [reference id = {}] sub_state = {}'.format(self.logger.session_id,
                                                                                                    str(sub_state)))

            procedure_uuid = request_data.get('uuid')
            code = request_data.get('code')
            name = request_data.get('name')
            description = request_data.get('description')
            display_label = request_data.get('display_label')
            system_data = request_data.get('system_data') or False
            flow_uuids = request_data.get('flow_uuids')

            if procedure_uuid is None:
                raise BadRequestException('"uuid" is required')
            if code is None:
                raise BadRequestException('"code" is required')

            procedure, created = Procedure.objects.update_or_create(sub_state=sub_state, uuid=procedure_uuid, defaults={
                'uuid': procedure_uuid,
                'code': code,
                'name': name,
                'description': description,
                'display_label': display_label,
                'system_data': system_data,
                'sub_state': sub_state,
            })

            flows_do_not_exist = list()
            if flow_uuids is not None and type(flow_uuids) is list:
                procedure_flow_mapping = ProcedureFlowMapping.objects.filter(procedure=procedure, flow__system_data=False)
                procedure_flow_mapping.delete()

                if len(flow_uuids) > 0:
                    flow_sequence = 1
                    for flow_uuid in flow_uuids:
                        flow = Flow.objects.filter(uuid=flow_uuid, sub_state=sub_state).first()

                        if flow is None:
                            flows_do_not_exist.append(flow_uuid)
                        else:
                            ProcedureFlowMapping.objects.create(**{
                                'sequence': flow_sequence,
                                'flow': flow,
                                'procedure': procedure,
                            })
                            flow_sequence += 1

            if created:
                if flows_do_not_exist:
                    response = self.response_meta.warning('create success with warning', self.logger.session_id,
                                                          {'flows_do_not_exist': flows_do_not_exist})
                else:
                    response = self.response_meta.success("create success", self.logger.session_id,
                                                          ProcedureDetailSerializer(procedure).data)
            else:
                if flows_do_not_exist:
                    response = self.response_meta.warning('update success with warning', self.logger.session_id,
                                                          {'flows_do_not_exist': flows_do_not_exist})
                else:
                    response = self.response_meta.success('update success', self.logger.session_id,
                                                          ProcedureDetailSerializer(procedure).data)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            exception_message = exc_type, fname, exc_tb.tb_lineno

            self.logger.error('Create or Update Procedure API [reference id = {}] exception: {} - {}'.format(self.logger.session_id, str(e), str(exception_message)))
            response = self.response_meta.error(e, str(e), self.logger.session_id, str(exc_type), fname, str(exc_tb.tb_lineno))

        finally:
            self.logger.debug('Create or Update Procedure API [reference id = {}] response = {}'.format(self.logger.session_id,
                                                                                                   str(response)))
            return Response(response, status=status.HTTP_200_OK)


    def destroy(self, request, *args, **kwargs):
        # logger = Logger('Delete Procedure API', 'Delete')

        try:
            self.logger.debug('Delete Procedure API [reference id = {}] start'.format(self.logger.session_id))

            request_app_meta = request.META.get('HTTP_APP_META') or None
            if request_app_meta is None:
                raise BadRequestException('"headers app_meta" is required')

            request_app_meta = json.loads(request_app_meta)
            sub_state = None

            if 'env' not in request_app_meta:
                if 'sub_state' not in request_app_meta:
                    raise BadRequestException('"env or sub_state in app_meta" is required')
                else:
                    sub_state = request_app_meta.get('sub_state') or None
            else:
                sub_state = request_app_meta.get('env') or None

            self.logger.debug(
                'Delete Procedure API [reference id = {}] sub_state = {}'.format(self.logger.session_id, str(sub_state)))

            procedure_uuid = kwargs.get('pk')
            procedure = Procedure.objects.filter(uuid=procedure_uuid, sub_state=sub_state).first()
            if procedure is None:
                raise BadRequestException('"procedure uuid" is invalid')

            procedure.delete()
            response = self.response_meta.success("delete success", self.logger.session_id)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            exception_message = exc_type, fname, exc_tb.tb_lineno
            
            self.logger.error('Delete Procedure API [reference id = {}] exception: {} - {}'.format(self.logger.session_id, str(e), str(exception_message)))
            response = self.response_meta.error(e, str(e), self.logger.session_id, str(exc_type), fname, str(exc_tb.tb_lineno))

        finally:
            self.logger.debug(
                'Delete Procedure API [reference id = {}] response = {}'.format(self.logger.session_id, str(response)))
            return Response(response, status=status.HTTP_200_OK)


class ProcedureFlowMappingViewSet(viewsets.ViewSet, ViewLogger):
    response_meta = ResponseAPI()

    def create(self, request):
        # logger = Logger('Procedure Flow Mapping API', 'POST')

        try:
            self.logger.debug('Procedure Flow Mapping API [reference id = {}] start'.format(self.logger.session_id))

            request_data = request.data
            self.logger.debug('Procedure Flow Mapping API [reference id = {}] request data = {}'.format(self.logger.session_id,
                                                                                                   str(request_data)))

            request_app_meta = request.META.get('HTTP_APP_META') or None
            if request_app_meta is None:
                raise BadRequestException('"headers app_meta" is required')

            request_app_meta = json.loads(request_app_meta)
            sub_state = None

            if 'env' not in request_app_meta:
                if 'sub_state' not in request_app_meta:
                    raise BadRequestException('"env or sub_state in app_meta" is required')
                else:
                    sub_state = request_app_meta.get('sub_state') or None
            else:
                sub_state = request_app_meta.get('env') or None

            self.logger.debug('Procedure Flow Mapping API [reference id = {}] sub_state = {}'.format(self.logger.session_id,
                                                                                                str(sub_state)))

            procedure_uuid = request_data.get('procedure_uuid')
            flow_uuids = request_data.get('flow_uuids')

            if procedure_uuid is None:
                raise BadRequestException('"procedure_uuid" is required')
            if flow_uuids is None:
                raise BadRequestException('"flow_uuids" is required')

            procedure = Procedure.objects.filter(uuid=procedure_uuid, sub_state=sub_state).first()
            if procedure is None:
                raise BadRequestException('"procedure_uuid" is invalid')

            with transaction.atomic():
                for flow_uuid in flow_uuids:
                    flow = Flow.objects.filter(uuid=flow_uuid, sub_state=sub_state).first()
                    if flow is not None:
                        procedure_flow = ProcedureFlowMapping.objects.filter(flow=flow, procedure=procedure).first()
                        if procedure_flow is None:
                            ProcedureFlowMapping.objects.create(**{
                                'flow': flow,
                                'procedure': procedure,
                            })

            response = self.response_meta.success("success", self.logger.session_id)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            exception_message = exc_type, fname, exc_tb.tb_lineno

            self.logger.error('Procedure Flow Mapping API [reference id = {}] exception: {} - {}'.format(self.logger.session_id, str(e), str(exception_message)))
            response = self.response_meta.error(e, str(e), self.logger.session_id, str(exc_type), fname, str(exc_tb.tb_lineno))

        finally:
            self.logger.debug('Procedure Flow Mapping API [reference id = {}] response = {}'.format(self.logger.session_id,
                                                                                               str(response)))
            return Response(response, status=status.HTTP_200_OK)

    def destroy(self, request, *args, **kwargs):
        # logger = Logger('Delete Procedure Flow Mapping API', 'Delete')

        try:
            self.logger.debug('Delete Procedure Flow Mapping API [reference id = {}] start'.format(self.logger.session_id))

            request_data = request.data
            self.logger.debug('Procedure Flow Mapping API [reference id = {}] request data = {}'.format(self.logger.session_id,
                                                                                                   str(request_data)))

            request_app_meta = request.META.get('HTTP_APP_META') or None
            if request_app_meta is None:
                raise BadRequestException('"headers app_meta" is required')

            request_app_meta = json.loads(request_app_meta)
            sub_state = None

            if 'env' not in request_app_meta:
                if 'sub_state' not in request_app_meta:
                    raise BadRequestException('"env or sub_state in app_meta" is required')
                else:
                    sub_state = request_app_meta.get('sub_state') or None
            else:
                sub_state = request_app_meta.get('env') or None

            self.logger.debug(
                'Delete Procedure Flow Mapping API [reference id = {}] sub_state = {}'.format(self.logger.session_id,
                                                                                              str(sub_state)))

            procedure_uuid = kwargs.get('pk')
            procedure = Procedure.objects.filter(uuid=procedure_uuid, sub_state=sub_state).first()
            if procedure is None:
                raise BadRequestException('"procedure uuid" is invalid')

            flow_uuids = request_data.get('flow_uuids')
            if flow_uuids is None:
                raise BadRequestException('"flow_uuids" is required')

            with transaction.atomic():
                procedure_flow_mappings = ProcedureFlowMapping.objects.filter(flow__uuid__in=flow_uuids,
                                                                              procedure=procedure)
                procedure_flow_mappings.delete()

            response = self.response_meta.success("success", self.logger.session_id)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            exception_message = exc_type, fname, exc_tb.tb_lineno
            
            self.logger.error('Delete Procedure Flow Mapping API [reference id = {}] exception: {} - {}'.format(self.logger.session_id, str(e), str(exception_message)))
            response = self.response_meta.error(e, str(e), self.logger.session_id, str(exc_type), fname, str(exc_tb.tb_lineno))

        finally:
            self.logger.debug(
                'Delete Procedure Flow Mapping API [reference id = {}] response = {}'.format(self.logger.session_id,
                                                                                             str(response)))
            return Response(response, status=status.HTTP_200_OK)
