from django.contrib import admin

from .models import Procedure, ProcedureFlowMapping


@admin.register(Procedure)
class ProcedureAdmin(admin.ModelAdmin):
    pass



@admin.register(ProcedureFlowMapping)
class ProcedureFlowMappingAdmin(admin.ModelAdmin):
    pass
