from django.apps import AppConfig


class ProcedureConfig(AppConfig):
    name = 'Procedure'
