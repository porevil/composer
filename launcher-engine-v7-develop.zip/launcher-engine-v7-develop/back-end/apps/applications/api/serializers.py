import uuid
import json

from rest_framework import serializers

from apps.applications.models import Application
from apps.applications.models import ApplicationProcedureMapping
from apps.procedures.api.serializers import ProcedureSerializer


class ApplicationSerializer(serializers.ModelSerializer):

    class Meta:
        model = Application
        fields = [
            'id',
            'code',
            'name',
            'description',
            'sub_state',
            'system_data',
            'create_date',
            'update_date', 
        ]


class ApplicationDetailSerializer(serializers.ModelSerializer):
    procedures = serializers.SerializerMethodField()

    class Meta:
        model = Application
        fields = [
            'id',
            'code',
            'name',
            'description',
            'system_data',
            'config',
            'procedures',
            'sub_state',
            'create_date',
            'update_date', 
        ]

    def get_procedures(self, obj):
        results = list()

        application_procedure_mappings = ApplicationProcedureMapping.objects.filter(application=obj)
        for application_procedure_mapping in application_procedure_mappings:
            procedure = ProcedureSerializer(application_procedure_mapping.procedure).data
            if procedure.get('system_data') == False:
                results.append(procedure)

        return results


