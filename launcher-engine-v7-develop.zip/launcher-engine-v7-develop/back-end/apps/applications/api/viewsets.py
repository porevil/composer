import json
import os
import sys
import uuid

import rest_framework_filters as filters
from django.conf import settings
from django.db import transaction
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import status
from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

from apps.applications.api.serializers import ApplicationDetailSerializer
from apps.applications.api.serializers import ApplicationSerializer
from apps.applications.models import Application
from apps.applications.models import ApplicationProcedureMapping
from apps.commons.utilities.cache import Cache
from apps.commons.utilities.log import Logger
from apps.commons.utilities.response import ResponseAPI
from apps.procedures.models import Procedure
from apps.procedures.models import ProcedureFlowMapping
from apps.commons.logger.views import ViewLogger
from apps.commons.error.exception import *


class ApplicationFilter(filters.FilterSet):
    class Meta:
        model = Application
        fields = {
            'code': ['exact', 'startswith', 'contains', 'icontains'],
            'name': ['exact', 'startswith', 'contains', 'icontains'],
            'system_data': ['exact'],
        }


class ApplicationViewSet(viewsets.ViewSet, ViewLogger):
    response_meta = ResponseAPI()
    filter_class = ApplicationFilter
    # logger = Logger("ApplicationViewSet")

    def list(self, request):
        self.module_name = 'List Application API'

        try:
            self.logger.debug('List Application API [reference id = {}] start'.format(self.logger.session_id))

            request_app_meta = request.META.get('HTTP_APP_META') or None
            if request_app_meta is None:
                raise BadRequestException('"headers app_meta" is required')

            request_app_meta = json.loads(request_app_meta)
            sub_state = None

            if 'env' not in request_app_meta:
                if 'sub_state' not in request_app_meta:
                    raise BadRequestException('"env or sub_state in app_meta" is required')
                else:
                    sub_state = request_app_meta.get('sub_state') or None
            else:
                sub_state = request_app_meta.get('env') or None

            self.logger.debug(
                'List Application API [reference id = {}] sub_state = {}'.format(self.logger.session_id, str(sub_state)))

            queryset = Application.objects.filter(sub_state=sub_state).order_by('id')
            queryset = DjangoFilterBackend().filter_queryset(self.request, queryset, self)
            serializer = ApplicationSerializer(queryset, many=True)
            response = self.response_meta.success("success", self.logger.session_id, serializer.data)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            exception_message = exc_type, fname, exc_tb.tb_lineno

            self.logger.error('List Application API [reference id = {}] exception: {} - {}'.format(self.logger.session_id, str(e),
                                                                                              str(exception_message)))

            response = self.response_meta.error(e, str(e), self.logger.session_id, str(exc_type), fname, str(exc_tb.tb_lineno))

        finally:
            self.logger.debug(
                'Get Application API [reference id = {}] response = {}'.format(self.logger.session_id, str(response)))
            return Response(response, status=status.HTTP_200_OK)

    def retrieve(self, request, pk=None):
        self.module_name = 'Get Application API'

        try:
            self.logger.debug('Get Application API [reference id = {}] start'.format(self.logger.session_id))

            request_app_meta = request.META.get('HTTP_APP_META') or None
            if request_app_meta is None:
                raise BadRequestException('"headers app_meta" is required')

            request_app_meta = json.loads(request_app_meta)
            sub_state = None

            if 'env' not in request_app_meta:
                if 'sub_state' not in request_app_meta:
                    raise BadRequestException('"env or sub_state in app_meta" is required')
                else:
                    sub_state = request_app_meta.get('sub_state') or None
            else:
                sub_state = request_app_meta.get('env') or None

            self.logger.debug(
                'Get Application API [reference id = {}] sub_state = {}'.format(self.logger.session_id, str(sub_state)))

            result = list()
            queryset = Application.objects.filter(code=pk, sub_state=sub_state).first()
            if queryset is None:
                raise BadRequestException('"application code" is invalid')

            result = ApplicationDetailSerializer(queryset).data
            response = self.response_meta.success("success", self.logger.session_id, result)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            exception_message = exc_type, fname, exc_tb.tb_lineno

            self.logger.error('Get Application API [reference id = {}] exception: {} - {}'.format(self.logger.session_id, str(e),
                                                                                             str(exception_message)))

            response = self.response_meta.error(e, str(e), self.logger.session_id, str(exc_type), fname, str(exc_tb.tb_lineno))

        finally:
            self.logger.debug(
                'Get Application API [reference id = {}] response = {}'.format(self.logger.session_id, str(response)))
            return Response(response, status=status.HTTP_200_OK)

    def create(self, request):
        self.module_name = 'Create or Update Application API'

        try:
            self.logger.debug('Create or Update Application API [reference id = {}] start'.format(self.logger.session_id))

            request_data = request.data
            self.logger.debug(
                'Create or Update Application API [reference id = {}] request data = {}'.format(self.logger.session_id,
                                                                                                str(
                                                                                                    request_data)))

            request_app_meta = request.META.get('HTTP_APP_META') or None
            if request_app_meta is None:
                raise BadRequestException('"headers app_meta" is required')

            request_app_meta = json.loads(request_app_meta)
            sub_state = None

            if 'env' not in request_app_meta:
                if 'sub_state' not in request_app_meta:
                    raise BadRequestException('"env or sub_state in app_meta" is required')
                else:
                    sub_state = request_app_meta.get('sub_state') or None
            else:
                sub_state = request_app_meta.get('env') or None

            self.logger.debug('Create or Update Application API [reference id = {}] sub_state = {}'.format(self.logger.session_id,
                                                                                                           str(
                                                                                                               sub_state)))
            code = request_data.get('code')
            name = request_data.get('name')
            description = request_data.get('description')
            system_data = request_data.get('system_data') or False
            config = request_data.get('config') or dict()
            procedure_uuids = request_data.get('procedure_uuids')

            if code is None:
                raise BadRequestException('"code" is required')
            if config.get('okta_client_id') is None:
                raise BadRequestException('"okta client id" is required')
            if config.get('okta_client_secret') is None:
                raise BadRequestException('"okta client secret" is required')
            if config.get('okta_redirect_uri') is None:
                raise BadRequestException('"okta redirect uri" is required')
            if config.get('app_type') is None:
                raise BadRequestException('"application type" is required')

            application, created = Application.objects.update_or_create(sub_state=sub_state, code=code, defaults={
                'code': code,
                'name': name,
                'description': description,
                'system_data': system_data,
                'config': config,
                'sub_state': sub_state,
            })

            procedures_do_not_exist = list()
            if procedure_uuids is not None and type(procedure_uuids) is list:
                application_procedure_mapping = ApplicationProcedureMapping.objects.filter(application=application,
                                                                                           procedure__system_data=False)
                application_procedure_mapping.delete()

                if len(procedure_uuids) > 0:
                    procedure_sequence = 1
                    for procedure_uuid in procedure_uuids:
                        procedure = Procedure.objects.filter(uuid=procedure_uuid, sub_state=sub_state).first()

                        if procedure is None:
                            procedures_do_not_exist.append(procedure_uuid)
                        else:
                            ApplicationProcedureMapping.objects.create(**{
                                'sequence': procedure_sequence,
                                'application': application,
                                'procedure': procedure,
                            })
                            procedure_sequence += 1

            if created:
                if procedures_do_not_exist:
                    response = self.response_meta.warning('create success with warning', self.logger.session_id,
                                                          {'procedures_do_not_exist': procedures_do_not_exist})
                else:
                    response = self.response_meta.success("create success", self.logger.session_id,
                                                          ApplicationDetailSerializer(application).data)
            else:
                if procedures_do_not_exist:
                    response = self.response_meta.warning('update success with warning', self.logger.session_id,
                                                          {'procedures_do_not_exist': procedures_do_not_exist})
                else:
                    response = self.response_meta.success('update success', self.logger.session_id,
                                                          ApplicationDetailSerializer(application).data)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            exception_message = exc_type, fname, exc_tb.tb_lineno

            self.logger.error(
                'Create or Update Application API [reference id = {}] exception: {} - {}'.format(self.logger.session_id, str(e),
                                                                                                 str(
                                                                                                     exception_message)))

            response = self.response_meta.error(e, str(e), self.logger.session_id, str(exc_type), fname, str(exc_tb.tb_lineno))

        finally:
            self.logger.debug('Create or Update Application API [reference id = {}] response = {}'.format(self.logger.session_id,
                                                                                                          str(response)))
            return Response(response, status=status.HTTP_200_OK)


    def destroy(self, request, *args, **kwargs):
        self.module_name = 'Delete Application API'

        try:
            self.logger.debug('Delete Application API [reference id = {}] start'.format(self.logger.session_id))

            request_app_meta = request.META.get('HTTP_APP_META') or None
            if request_app_meta is None:
                raise BadRequestException('"headers app_meta" is required')

            request_app_meta = json.loads(request_app_meta)
            sub_state = None

            if 'env' not in request_app_meta:
                if 'sub_state' not in request_app_meta:
                    raise BadRequestException('"env or sub_state in app_meta" is required')
                else:
                    sub_state = request_app_meta.get('sub_state') or None
            else:
                sub_state = request_app_meta.get('env') or None

            self.logger.debug(
                'Delete Application API [reference id = {}] sub_state = {}'.format(self.logger.session_id, str(sub_state)))

            application_code = kwargs.get('pk')
            application = Application.objects.filter(code=application_code, sub_state=sub_state).first()
            if application is None:
                raise BadRequestException('"application code" is invalid')

            application.delete()
            response = self.response_meta.success("delete success", self.logger.session_id)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            exception_message = exc_type, fname, exc_tb.tb_lineno

            self.logger.error('Delete Application API [reference id = {}] exception: {} - {}'.format(self.logger.session_id, str(e),
                                                                                                str(exception_message)))
            response = self.response_meta.error(e, str(e), self.logger.session_id, str(exc_type), fname, str(exc_tb.tb_lineno))

        finally:
            self.logger.debug(
                'Delete Application API [reference id = {}] response = {}'.format(self.logger.session_id, str(response)))
            return Response(response, status=status.HTTP_200_OK)


class ApplicationProcedureMappingViewSet(viewsets.ViewSet, ViewLogger):
    response_meta = ResponseAPI()

    def create(self, request):

        self.module_name = 'Application Procedure Mapping API'

        try:
            self.logger.debug('Application Procedure Mapping API [reference id = {}] start'.format(self.logger.session_id))

            request_data = request.data
            self.logger.debug(
                'Application Procedure Mapping API [reference id = {}] request data = {}'.format(self.logger.session_id,
                                                                                                 str(request_data)))

            request_app_meta = request.META.get('HTTP_APP_META') or None
            if request_app_meta is None:
                raise BadRequestException('"headers app_meta" is required')

            request_app_meta = json.loads(request_app_meta)
            sub_state = None

            if 'env' not in request_app_meta:
                if 'sub_state' not in request_app_meta:
                    raise BadRequestException('"env or sub_state in app_meta" is required')
                else:
                    sub_state = request_app_meta.get('sub_state') or None
            else:
                sub_state = request_app_meta.get('env') or None

            self.logger.debug(
                'Application Procedure Mapping API [reference id = {}] sub_state = {}'.format(self.logger.session_id,
                                                                                              str(sub_state)))

            application_code = request_data.get('application_code')
            procedure_uuids = request_data.get('procedure_uuids')

            if application_code is None:
                raise BadRequestException('"application_code" is required')
            if procedure_uuids is None:
                raise BadRequestException('"procedure_uuids" is required')

            application = Application.objects.filter(code=application_code, sub_state=sub_state).first()
            if application is None:
                raise BadRequestException('"application_code" is invalid')

            with transaction.atomic():
                for procedure_uuid in procedure_uuids:
                    procedure = Procedure.objects.filter(uuid=procedure_uuid, sub_state=sub_state).first()
                    if procedure is not None:
                        application_procedure = ApplicationProcedureMapping.objects.filter(application=application,
                                                                                           procedure=procedure).first()

                        if application_procedure is None:
                            ApplicationProcedureMapping.objects.create(**{
                                'application': application,
                                'procedure': procedure,
                            })

            response = self.response_meta.success("success", self.logger.session_id)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            exception_message = exc_type, fname, exc_tb.tb_lineno

            self.logger.error(
                'Application Procedure Mapping API [reference id = {}] exception: {} - {}'.format(self.logger.session_id, str(e),
                                                                                                  str(
                                                                                                      exception_message)))
            response = self.response_meta.error(e, str(e), self.logger.session_id, str(exc_type), fname, str(exc_tb.tb_lineno))

        finally:
            self.logger.debug('Application Procedure Mapping API [reference id = {}] response = {}'.format(self.logger.session_id,
                                                                                                           str(
                                                                                                               response)))
            return Response(response, status=status.HTTP_200_OK)

    def destroy(self, request, *args, **kwargs):
        self.module_name = 'Delete Application Procedure Mapping API'

        try:
            self.logger.debug('Delete Application Procedure Mapping API [reference id = {}] start'.format(self.logger.session_id))

            request_data = request.data.get('data') or dict()
            self.logger.debug(
                'Application Procedure Mapping API [reference id = {}] request data = {}'.format(self.logger.session_id,
                                                                                                 str(
                                                                                                     request_data)))

            request_app_meta = request.META.get('HTTP_APP_META') or None
            if request_app_meta is None:
                raise BadRequestException('"headers app_meta" is required')

            request_app_meta = json.loads(request_app_meta)
            sub_state = None

            if 'env' not in request_app_meta:
                if 'sub_state' not in request_app_meta:
                    raise BadRequestException('"env or sub_state in app_meta" is required')
                else:
                    sub_state = request_app_meta.get('sub_state') or None
            else:
                sub_state = request_app_meta.get('env') or None

            self.logger.debug(
                'Delete Application Procedure Mapping API [reference id = {}] sub_state = {}'.format(self.logger.session_id,
                                                                                                     str(sub_state)))

            application_code = kwargs.get('pk')
            application = Application.objects.filter(code=application_code, sub_state=sub_state).first()
            if application is None:
                raise BadRequestException('"application code" is invalid')

            procedure_uuids = request_data.get('procedure_uuids')
            if procedure_uuids is None:
                raise BadRequestException('"procedure_uuids" is required')

            with transaction.atomic():
                application_procedure_mappings = ApplicationProcedureMapping.objects.filter(
                    procedure__uuid__in=procedure_uuids, application=application)
                application_procedure_mappings.delete()

            response = self.response_meta.success("success", self.logger.session_id)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            exception_message = exc_type, fname, exc_tb.tb_lineno

            self.logger.error(
                'Delete Application Procedure Mapping API [reference id = {}] exception: {} - {}'.format(self.logger.session_id,
                                                                                                         str(e), str(
                        exception_message)))
            response = self.response_meta.error(e, str(e), self.logger.session_id, str(exc_type), fname, str(exc_tb.tb_lineno))

        finally:
            self.logger.debug(
                'Delete Application Procedure Mapping API [reference id = {}] response = {}'.format(self.logger.session_id, str(response)))
            return Response(response, status=status.HTTP_200_OK)
