from django.contrib import admin

from .models import Application, ApplicationProcedureMapping


@admin.register(Application)
class ApplicationAdmin(admin.ModelAdmin):
    pass



@admin.register(ApplicationProcedureMapping)
class ApplicationProcedureMappingAdmin(admin.ModelAdmin):
    pass
