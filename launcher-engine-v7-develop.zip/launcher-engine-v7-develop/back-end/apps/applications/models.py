import reversion

from django.db import models
from jsonfield import JSONField
from django.utils.translation import ugettext_lazy as _

from apps.procedures.models import Procedure


@reversion.register()
class Application(models.Model):

    code = models.CharField(max_length=100, verbose_name=_("Code"))
    name = models.CharField(max_length=150, verbose_name=_("Name"))
    description = models.TextField(null=True, blank=True, verbose_name=_("description"))
    sub_state = models.CharField(max_length=100, default=None, null=True, blank=True, verbose_name=_("Sub State"))
    system_data = models.BooleanField(default=False, verbose_name=_("Sysytem Data"))
    config = JSONField(default=dict(), verbose_name=_("Config"))

    create_date = models.DateTimeField(null=True, blank=True, auto_now_add=True, verbose_name=_("Create Date"))
    update_date = models.DateTimeField(null=True, blank=True, auto_now=True, verbose_name=_("Update Date"))

    class Meta:
        unique_together = ("code", "sub_state",)

    def __str__(self):
        return str(self.code)



@reversion.register()
class ApplicationProcedureMapping(models.Model):

    sequence = models.PositiveIntegerField(default=0, verbose_name=_("sequence"))
    application = models.ForeignKey(Application, on_delete=models.deletion.CASCADE, verbose_name=_("Applcation"))
    procedure = models.ForeignKey(Procedure, on_delete=models.deletion.CASCADE, verbose_name=_("Procedure"))

    class Meta:
        unique_together = ("application", "procedure",)

    def __str__(self):
        return "{} - {}".format(self.application.code, self.procedure.code)
