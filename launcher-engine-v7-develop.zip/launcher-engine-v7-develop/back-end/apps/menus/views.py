import json
import uuid
import re
import traceback
import requests
import sys
import os

from django.conf import settings
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.applications.models import ApplicationProcedureMapping
from apps.applications.models import ApplicationProcedureMapping
from apps.procedures.models import ProcedureFlowMapping
from apps.commons.utilities.log import Logger
from apps.commons.utilities.cache import Cache
from apps.commons.utilities.response import ResponseAPI, CustomJsonResponse
from apps.commons.connectors.ag import AccessGovernance
from apps.commons.logger.views import ViewLogger
from apps.commons.error.exception import *

class ClearMenuCacheView(APIView, ViewLogger):
    response_meta = ResponseAPI()

    def get(self, request):
        # logger = Logger('Clear Menu Cache API', 'GET')
        self.module_name = 'Clear Menu Cache API'
        cache_api = Cache()

        try:
            self.logger.debug('Clear Menu Cache API [reference id = {}] start'.format(self.logger.session_id))

            pattern = "*"+request.oidc_user.id+"*"
            keys = cache_api.list_key_matching(pattern)

            key_list = list()
            for key in keys:
                cache_api.delete(key)
                key_list.append(key)

            response = self.response_meta.success('success', self.logger.session_id, key_list)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            exception_message = exc_type, fname, exc_tb.tb_lineno

            self.logger.error('Clear Menu Cache API [reference id = {}] exception: {} - {}'.format(self.logger.session_id, str(e), str(exception_message)))
            response = self.response_meta.error(e, str(e), self.logger.session_id, str(exc_type), fname, str(exc_tb.tb_lineno))

        finally:
            self.logger.debug('Clear Menu Cache API [reference id = {}] response = {}'.format(self.logger.session_id, str(response)))
            return Response(response, status=status.HTTP_200_OK)


class MenuView(APIView, ViewLogger):
    logger = Logger("MenuView")

    def get(self, request, *args, **kwargs):
        self.logger.debug(f"App-code {request.app_code}")
        self.logger.debug(f"{request.oidc_user.preferred_username}")
        if request.app_code == settings.APP_SHELF:
            data = self._get_application_menu(request)
            return CustomJsonResponse(data=data)
        else:
            # TODO: Implement non app_shelf
            return CustomJsonResponse(data={})

    def _get_application_menu(self, request):
        app_code = request.app_code

        is_app_shelf = app_code == settings.APP_SHELF
        try:
            cache_api = Cache()
            menu_key = f'MENU-V7-{app_code}-{settings.SUB_ENVIRONMENT}-{settings.ENVIRONMENT}-{request.oidc_user.id}'
            cache_menu = cache_api.get_json(menu_key)
            self.logger.debug(f"get cached {cache_menu}")

            if not cache_menu:
                self.logger.debug("not using cache")
                application_procedure_mapping = \
                    ApplicationProcedureMapping.objects.filter(application__code=app_code,
                                                               application__sub_state=settings.SUB_ENVIRONMENT or None) or list()
                if not application_procedure_mapping:
                    raise Exception('Not found Application Procedure Mapping')

                procedure_uuids = list()
                for application_procedure in application_procedure_mapping:
                    if application_procedure.procedure.uuid not in procedure_uuids:
                        procedure_uuids.append(application_procedure.procedure.uuid)
                if not procedure_uuids:
                    raise Exception('Not found Procedure UUID')
                procedure_flow_mapping = ProcedureFlowMapping.objects.filter(procedure__uuid__in=procedure_uuids)
                if not procedure_flow_mapping:
                    raise Exception('Not found Procedure Flow Mapping')

                # Use Flow Role
                roles = []
                verify_role_result = {}
                for procedure_flow in list(procedure_flow_mapping):
                    flow_config = procedure_flow.flow.config
                    if flow_config.get('role_id') is not None and flow_config.get('role_id') not in roles:
                        roles.append(flow_config.get('role_id'))
                if roles:
                    user_attributes = {
                        'user_id': request.oidc_user.id,
                        'username': request.oidc_user.preferred_username,
                        'log_session_id': self.logger.session_id,
                    }
                    for result in AccessGovernance().check_authorization(user_attributes, roles):
                        # verify_role_result[result['id']] = result['result']
                        verify_role_result[result['id']] = True

                if is_app_shelf:
                    verify_role_result[None] = True

                menu_results = list()
                for procedure_flow in procedure_flow_mapping:
                    # self.logger.debug(procedure_flow)

                    flow_config = procedure_flow.flow.config
                    for role_id, role_result in verify_role_result.items():
                        # self.logger.debug(f"Logger: {role_id} {role_result}")

                        if (is_app_shelf and flow_config.get('role_id', None) is None) or \
                                (role_id == flow_config.get('role_id') and role_result):
                            found = False
                            for menu in menu_results:
                                if str(menu.get('uuid')) == str(procedure_flow.procedure.uuid):
                                    menu['flows'].append({
                                        'sequence': procedure_flow.sequence,
                                        'uuid': str(procedure_flow.flow.uuid),
                                        'code': procedure_flow.flow.code,
                                        'display_label': procedure_flow.flow.display_label,
                                    })
                                    found = True
                                    break
                            if not found:
                                for application_procedure in application_procedure_mapping:
                                    if str(application_procedure.procedure.uuid) == str(procedure_flow.procedure.uuid):
                                        menu_results.append({
                                            'sequence': application_procedure.sequence + 2,
                                            'display_label': procedure_flow.procedure.display_label,
                                            'code': procedure_flow.procedure.code,
                                            'name': procedure_flow.procedure.name,
                                            'uuid': str(procedure_flow.procedure.uuid),
                                            'flows': [{
                                                'sequence': procedure_flow.sequence,
                                                'uuid': str(procedure_flow.flow.uuid),
                                                'code': procedure_flow.flow.code,
                                                'display_label': procedure_flow.flow.display_label,
                                            }]
                                        })
                                        break
                            break

                # Add dashboard
                menu_results.append({
                    'sequence': 1,
                    'display_label': 'Dashboard',
                    'code': 'dashboard',
                    'name': 'dashboard',
                    'flows': [],
                    'url': '/dashboard'
                })

                # Add notification
                menu_results.append({
                    'sequence': 2,
                    'display_label': 'Notifications',
                    'code': 'notifications',
                    'name': 'notifications',
                    'flows': [],
                    'url': '/notifications'
                })

                # Sort menu
                menu_results = sorted(menu_results, key=lambda i: i['sequence'])
                for menu in menu_results:
                    if 'flows' in menu:
                        menu['flows'] = sorted(menu['flows'], key=lambda i: i['sequence'])

                cache_api.put_json(menu_key, menu_results, (60 * 60))
            else:
                menu_results = cache_menu

            return menu_results
        except Exception as exc:
            raise exc
