from django.conf.urls import url
from django.urls import path
from drf_yasg import openapi
from drf_yasg.views import get_schema_view
from rest_framework import permissions
from rest_framework.routers import DefaultRouter

from apps.environment_variable.views import EnvironmentVariable
from apps.applications.api.viewsets import ApplicationProcedureMappingViewSet
from apps.applications.api.viewsets import ApplicationViewSet
from apps.authentication.views import Login, Authorize, RefreshToken
from apps.client_logger.api.views import ClientLoggerView
from apps.flows.api.viewsets import FlowViewSet
from apps.flows.views import GoToNodeView
from apps.flows.views import LaunchFlowView
from apps.home.views import IndexTemplateView
# from apps.menus.views import MenuView
from apps.menus.views import ClearMenuCacheView, MenuView
from apps.procedures.api.viewsets import ProcedureFlowMappingViewSet
from apps.procedures.api.viewsets import ProcedureViewSet
from apps.proxy_management.api.viewsets import ServiceRepositoryViewSet, ServiceReverseProxyView
from apps.services.service_execution import ServiceExecutionView
from apps.services.cache_management import GetCacheView
from apps.services.cache_management import PutCacheView
from apps.user_information.views import GetUserInformationView, GetRepresentativeUserChoicesView, OverrideRepresentation

# from apps.applications.api.viewsets import ApplicationMenuView
# Deprecated
# from apps.authentication.views import Authentication
# from apps.authentication.views import ExtendExpiration
# from apps.authentication.views import logout
# from apps.authentication.views import session_expired

schema_view = get_schema_view(
    openapi.Info(
        title="Launcher API",
        # default_version='3.0.0',
        default_version="v6",
        description="Test description",
        terms_of_service="https://www.google.com/policies/terms/",
        contact=openapi.Contact(email="laphatrad@tisco.co.th"),
        license=openapi.License(name="BSD License"),
    ),
    public=True,
    permission_classes=(permissions.AllowAny,),
)

router = DefaultRouter()
# viewsets
router.register(r'^flow', FlowViewSet, basename='flow')
router.register(r'^procedure', ProcedureViewSet, basename='procedure')
router.register(r'^application', ApplicationViewSet, basename='application')
router.register(r'^procedure_flow_mapping', ProcedureFlowMappingViewSet, basename='procedure_flow_mapping')
router.register(r'^application_procedure_mapping', ApplicationProcedureMappingViewSet, basename='application_procedure_mapping')
router.register(r'^service_repository', ServiceRepositoryViewSet, basename='proxy_management')

# views
urlpatterns = [
    # url('application/{app_code}/menu', ApplicationMenuView.as_view(), name='application_menu'),

    url(r'^swagger(?P<format>\.json|\.yaml)$', schema_view.without_ui(cache_timeout=0), name='schema-json'),
    url(r'^swagger/?$', schema_view.with_ui('swagger', cache_timeout=0), name='schema-swagger-ui'),
    url(r'^redoc/?$', schema_view.with_ui('redoc', cache_timeout=0), name='schema-redoc'),

    # url(r'^authentication/$', Authentication.as_view(), name="acs_app"),
    # url(r'^extend_expiration/$', ExtendExpiration.as_view(), name="extend_expiration"),
    # url(r'^logout/$', logout, name="logout_app"),
    # url(r'^session_expired/$', session_expired, name="expired_app"),
    url(r'^authentication/login/?$', Login.as_view(), name="login"),
    url(r'^authentication/verifycode/(?P<code>[^/.]+)/?$', Authorize.as_view(), name="verifycode"),
    url(r'^authentication/refresh/?$', RefreshToken.as_view(), name="refresh"),

    url(r'^index/?$', IndexTemplateView.as_view(), name='home_app'),

    url(r'^launch_flow/?$', LaunchFlowView.as_view(), name='launch_flow'),
    url(r'^go_to_node/?$', GoToNodeView.as_view(), name='go_to_node'),
    url(r'^clear_menu_cache/?$', ClearMenuCacheView.as_view(), name='clear_menu_cache'),
    url(r'^menu/?$', MenuView.as_view(), name='get_menu_list'),

    url(r'^service_execution/?$', ServiceExecutionView.as_view(), name='service_execution'),

    url(r'^user_information/?$', GetUserInformationView.as_view(), name='user_information'),
    url(r'^representative_user_choices/?$', GetRepresentativeUserChoicesView.as_view(), name='representative_user_choices'),
    url(r'^override_representation/?$', OverrideRepresentation.as_view(), name='override_representation'),
    # url(r'^compant_choices/$', DataOwnerView.as_view(), name='data_owner'),
    # url(r'^user_information/$', DataOwnerView.as_view(), name='data_owner'),
    url(r'^client_logger/$', ClientLoggerView.as_view(), name='client_logger'),
    url(r'^get_environment_variable/?$', EnvironmentVariable.as_view(), name='get environment'),
    path('reverse/<name>', ServiceReverseProxyView.as_view(), name='reverse'),

    # url(r'^get_menu/$', MenuView.as_view(), name='get_menu'),
]

# Final URL
urlpatterns += router.urls
