from django.apps import AppConfig


class ProxyManagementConfig(AppConfig):
    name = 'proxy_management'
