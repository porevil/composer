from django.contrib.postgres.fields import JSONField
from django.db import models

from apps.commons.validator import JSONSchemaValidator

REQUEST_SCHEMA = {
    'type': 'object',
    'properties': {
        'method': {
            'type': 'string',
            'enum': ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTION']
        },
        'content_type': {
            'type': 'string',
            'enum': ['form-data', 'json']
        },
        'is_override_service_account': {
            'type': 'boolean',
            'default': False
        }
    },
    'required': ['method']
}


class ServiceRepository(models.Model):
    name = models.CharField(max_length=255,
                            unique=True,
                            null=False)
    url = models.URLField(null=False, verbose_name="Service URL")
    request = JSONField(null=False,
                        verbose_name="Request Schema Object",
                        validators=[JSONSchemaValidator(limit_value=REQUEST_SCHEMA)])
    # response = JSONField(null=False,
    #                      validators=[JSONSchemaValidator(limit_value=RESPONSE_SCHEMA)],
    #                      verbose_name="Response Schema Object")
