import requests
import json
import datetime
from urllib import parse

from django.core.files.uploadedfile import UploadedFile
from django.conf import settings
from rest_framework.request import HttpRequest

from apps.commons.utilities.log import Logger


class ProxyRequestHandler:
    """
    ProxyHandler Object
    """

    class RequestObject(object):
        """
        Request Builder
        """
        flag = False
        json = None
        data = None
        files = None
        headers = {}

    def __init__(self, url, request: HttpRequest, config: dict, setting: settings, **kwargs):
        """
        Use to build and modify data before forward to other service

        :param url: URL
        :param request: HttpRequest Object
        :param config: ServiceRepository Object
        :param settings: Django setting passed as parameter
        :param kwargs:
        """
        self.logger = kwargs.get('logger', Logger('ProxyRequestHandler'))
        self.logger.set_session_id(request.session_id)
        self.url = url
        self.__origin_request__ = request
        self.config = config
        self.setting = setting
        self.request = self.RequestObject()
        self.response = None
        self.__except_headers__ = settings.PROXY_MANAGEMENT['EXCEPT_HEADERS']
        self.request.headers = dict(request.headers)

    def execute(self):
        """
        sent request to external service
        :return:
        """
        if self.config['method'] != 'GET':
            self.__build_data__()

        self.__build_header__()

        params = {
            'method': self.config['method'],
            'url': self.url,
            'headers': self.request.headers,
            'timeout': self.config.get('time_out', 120)
        }
        for k in ['json', 'data', 'files']:
            if getattr(self.request, k, None):
                params[k] = getattr(self.request, k, None)

        self.response = requests.request(**params)
        self.response.close()
        return self.response

    def __getattr__(self, item):
        pass

    def __build_data__(self):
        content_type = self.__origin_request__.META.get("CONTENT_TYPE")

        # set request data
        if self.config['method'] == 'GET':
            pass

        elif content_type == 'application/json':
            self.request.json = {}
            for k, v in self.__origin_request__.data.items():
                if k not in settings.PROXY_MANAGEMENT['EXCEPT_BODY']:
                    self.request.json[k] = v

        elif content_type in ['multipart/form-data', 'application/x-www-form-urlencoded'] \
                or 'multipart/form-data' in content_type:
            self.request.data = {}
            for k, v in self.__origin_request__.data.items():
                if k not in settings.PROXY_MANAGEMENT['EXCEPT_BODY']:
                    if isinstance(v, UploadedFile):
                        if self.request.files is None:
                            self.request.files = {}
                            # remove header content
                            self.__except_headers__ += ('Content-Type', 'Content-Length')
                        self.request.files[k] = (v.name, v.file, v.content_type)
                    else:
                        self.request.data[k] = v
        else:
            raise Exception('Content type not support %s' % (content_type,))

    def __build_header__(self):
        for k in self.__except_headers__:
            if k in self.request.headers:
                del self.request.headers[k]
        self.__add_headers__()
        if self.config.get('method', 'POST') == "GET":
            if 'Content-Type' in self.request.headers:
                del self.request.headers['Content-Type']
            if 'Content-Length' in self.request.headers:
                del self.request.headers['Content-Length']
        # self.logger.debug(f"Forward header, {self.request.headers}")

    def __add_headers__(self):
        self.request.headers["client_id"] = settings.CLIENT_KEY
        self.request.headers["client_secret"] = settings.CLIENT_SECRET_KEY
        if self.config.get('is_override_service_account', False):
            original_app_meta = json.loads(self.request.headers.get('App-Meta', '{}'))
            # self.logger.debug(f"before add app-meta: {original_app_meta}")
            app_meta = {
                'user_id': settings.PROXY_MANAGEMENT.get('USER_ID') or '00ub91zxphSgxjCp30h7',
                'user_name': 'channel service account',
                'request_datetime': str(datetime.datetime.utcnow().isoformat()),
                'log_session_id': self.__origin_request__.session_id
            }
            if 'sub_state' in original_app_meta:
                app_meta['sub_state'] = original_app_meta['sub_state']
            if 'state' in original_app_meta:
                app_meta['state'] = original_app_meta['state']

            self.request.headers['App-Meta'] = json.dumps(app_meta)
        return self.request.headers


def replace_url(pattern, adict):
    result = pattern
    if adict.get('parameters', {}):
        params = adict.get('parameters', {})
        for k, v in params.items():
            result = result.replace("{{%s}}" % (k,), v)

    if adict.get('query', {}):
        if result[-1] != '?':
            result += '?'
        result += parse.urlencode(adict.get('query'))
    return result
