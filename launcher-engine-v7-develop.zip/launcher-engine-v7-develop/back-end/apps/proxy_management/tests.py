from django.test import TestCase
from rest_framework.test import APIClient

from apps.proxy_management.models import ServiceRepository

# Create your tests here.

mock_data = {
    'name': 'get_user_service',
    'url': 'https://randomuser.me/api/{{api_version}}/',
    'request': {
        'method': 'GET',
        'url': {
            'param': ['name'],
            'query': {}
        },
        'body': None
    },
    'response': {
        'type': 'json'
    }

}


def get_mock_service_repo():
    return ServiceRepository.objects.get_or_create(defaults=mock_data)


class ServiceRepositoryTestCase(TestCase):

    def setUp(self) -> None:
        self.client = APIClient()

    def test_replace_url(self):
        pass
