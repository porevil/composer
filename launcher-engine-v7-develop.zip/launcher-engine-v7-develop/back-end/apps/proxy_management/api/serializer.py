from rest_framework import serializers

from apps.proxy_management import models


class ServiceRepositorySerializer(serializers.ModelSerializer):
    class Meta:
        model = models.ServiceRepository
        fields = [
            'id',
            'name',
            'url',
            'request',
        ]

        read_only = [
            'id'
        ]

        unique = (
            ['state_virtual_name']
        )


class ServiceReverseProxySerializer(serializers.Serializer):
    content = serializers.JSONField()
    file = serializers.FileField()

    def create(self, validated_data):
        pass

    def update(self, instance, validated_data):
        pass
