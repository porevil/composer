import requests
import json
import datetime
import uuid
from urllib import parse

from django.core.files.uploadedfile import UploadedFile
from django.conf import settings
from django.http.response import HttpResponse, JsonResponse

from rest_framework import generics, mixins
from rest_framework.parsers import FormParser, MultiPartParser, JSONParser, FileUploadParser
from rest_framework.viewsets import ModelViewSet
from rest_framework.request import HttpRequest

import django_filters.rest_framework

from apps.commons.logger.views import ViewLogger
from apps.commons.utilities.log import Logger
from apps.commons.utilities.response import CustomJsonResponse
from apps.proxy_management.api.serializer import ServiceRepositorySerializer, \
    ServiceReverseProxySerializer
from apps.proxy_management.models import ServiceRepository

from apps.commons.error.exception import StandardException, BadRequestException
from apps.proxy_management.proxy_handler import replace_url, ProxyRequestHandler


class ServiceReverseProxyView(generics.CreateAPIView,
                              generics.GenericAPIView,
                              ViewLogger):
    # logger = Logger("ServiceReverseProxy")
    parser_classes = [FormParser, JSONParser, MultiPartParser, FileUploadParser]
    serializer_class = ServiceReverseProxySerializer
    module_name = "ServiceReverseProxyView"

    def post(self, request, name=None, *args, **kwargs):
        """
        Service Proxy Caller
        :param request:
        :param name:
        :return:
        """
        model = ServiceRepository.objects.filter(name=name).first()
        if not model:
            raise BadRequestException(f"ServiceRepository name '{name}' not exist")
        url_mod = request.data.get('_url', {})
        endpoint = replace_url(pattern=model.url, adict=url_mod)

        self.logger.debug(f"Session request start: {request.session_id}")
        # Debug after forward request
        self.logger.debug(f"Request config: {model.request}")

        # Debug before building
        self.logger.debug(f"Original endpoint: {endpoint}")
        self.logger.debug(f"Original content: {request.headers.get('Content-Length')}")

        # Build request
        proxy = ProxyRequestHandler(endpoint, request, model.request, settings)

        try:
            res = proxy.execute()
        except requests.exceptions.Timeout as e:
            ex = StandardException(message="Connection Timeouta", code="10000")
            return CustomJsonResponse(data=ex, description="Connection Timeout", session_id=request.session_id)

        # Debug Response
        self.logger.debug(f"Destination URL: {proxy.url}")
        # self.logger.debug(f"Response Object Size: {len(res.content)}")
        self.logger.debug(f"Response Content-Type: {res.headers.get('Content-Type')}")
        self.logger.debug(f"Response Content-Length: {res.headers.get('Content-Length')}")
        # self.logger.debug(f"Response Header: {res.headers}")

        forward_headers = [
            'content-disposition',
            'access-control-expose-headers'
        ]

        try:
            res_json = res.json()
            if 'meta' in res_json:
                self.logger.debug(f"Response Object Meta: {res_json.get('meta')}")
            elif 'msg_detail' in res_json:
                self.logger.debug(f"Response Msg_detail '{res_json.get('msg_detail')}'")

            return JsonResponse(data=res_json, status=res.status_code)
        except json.JSONDecodeError as e:
            """
            Can not decode as json it does not mean error.
            That because response can be file or html
            """
            pass
        forward_response = HttpResponse(content=res.content, content_type=res.headers.get('content-type'),
                                        status=res.status_code)

        for k in forward_headers:
            if k.lower() in res.headers:
                forward_response[k] = res.headers[k]
        return forward_response


class ServiceRepositoryViewSet(ModelViewSet, ViewLogger):
    serializer_class = ServiceRepositorySerializer
    queryset = ServiceRepository.objects.all()
    # filter_backends = [django_filters.rest_framework.DjangoFilterBackend]

    def list(self, request, *args, **kwargs):
        self.module_name = "List ServiceRepositoryViewSet"
        serializer = ServiceRepositorySerializer(ServiceRepository.objects.all(), many=True)
        return CustomJsonResponse(serializer.data, session_id=request.session_id)

    def create(self, request, *args, **kwargs):
        self.module_name = "Create ServiceRepositoryViewSet"
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        # headers = self.get_success_headers(serializer.data)
        return CustomJsonResponse(serializer.data, description="Create Success", session_id=request.session_id)

    def retrieve(self, request, *args, **kwargs):
        self.module_name = "Get ServiceRepositoryViewSet"
        instance = self.get_object()
        serializer = self.get_serializer(instance)
        return CustomJsonResponse(serializer.data, description="Success", session_id=request.session_id)

    def update(self, request, *args, **kwargs):
        self.module_name = "Update ServiceRepositoryViewSet"
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)

        if getattr(instance, '_prefetched_objects_cache', None):
            # If 'prefetch_related' has been applied to a queryset, we need to
            # forcibly invalidate the prefetch cache on the instance.
            instance._prefetched_objects_cache = {}

        return CustomJsonResponse(serializer.data, description="Update Success", session_id=request.session_id)

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        self.perform_destroy(instance)
        return CustomJsonResponse(None, description="Delete Success", session_id=request.session_id)



